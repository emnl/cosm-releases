# gran

- **Rows go to gran.** Rows that would otherwise be a spreadsheet (expenses, balances, figures by date, a list of people or cases) are kept in gran (`.cosm/gran.db`, with a CSV copy of each table in `.cosm/gran/`), not in a page table. A figure that fits an existing table turns up in other work: offer it in one line. The gran skill says how.
- **Count in gran scratch.** Adding up, comparing or matching more than about 20 rows goes through a `tmp_` table (the gran skill): SQL does the arithmetic and the rows never pass through the chat. Never by eye or mental arithmetic. Say so in one line.
- A message may say a gran table is open in Cosm right now: "this table" means that one.
