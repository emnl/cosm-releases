# Star chart

Cosm's own way of keeping a cosm: the layout, how pages are written, and how sessions open and close.

`profile.md` (who the user is, how they like to work) and the map (what exists and where, made fresh from the cosm at the start of each session) go with these rules. If they aren't already loaded, read `profile.md` and run `cosm map` before the first reply.

Inside `01-inbox/`, filing, moving and deleting what the user dropped in is done without asking (the engine's rules otherwise ask for **y**).

## Session start and end

- First reply: if `## Me` in `profile.md` is empty, the cosm is new: suggest `/cosm:setup`. Otherwise run `/cosm:recall`, then answer, unless the message is already a task or a command ("go through my email", `/cosm:inbox`); then just do that.
- When the user says they are done, or the session has clearly wound down, ask once: "`/cosm:reflect` before you go? **y** yes · **n** no". Never add this to ordinary replies.

## Where things go

| Where | What goes there |
|---|---|
| `01-inbox/` | anything the user drops in; `/cosm:inbox` files it |
| `02-spaces/<space>/` | something the user runs (project, client, area): state page `<space>.md` (where it stands, what is open), `tasks.md` (the agent's), `notes/<YYYY-MM-DD> <Topic>.md` (meetings, other dated notes) |
| `02-spaces/<user>/todo.md` | what the user will do: their own list (`<user>` is the space `/cosm:setup` makes for them, named with their first name) |
| `03-knowledge/<kind>/<name>/` | what the user knows about a person, company or other thing: state page `<name>.md`, `notes/` when needed. `people/` and `companies/` to start; for anything else propose a new kind (`things/`, `places/`) on **y** |
| `03-knowledge/preferences/<name>.md` | how the user wants one kind of work done |
| `03-knowledge/fixes/<tool>.md` | what works where a tool or file type failed (§ Learning) |
| `03-knowledge/skills/<name>/` | skills the user made: `SKILL.md` and its files. |
| `04-archive/` | `spaces/` (finished, same layout), `logs/<YYYY-MM>/` (written there by `/cosm:log`, never changed afterwards) |
| `profile.md` | who the user is, how they work in general (propose, write on **y**) |

Root files: `profile.md`, the `.trash/` folder, and `.cosm/` (the app's and packages' own files; Star chart keeps `last-review` there, the date of the last review or of setup, and `last-mail`, the date of the last mail pass for users who keep their inbox). The agent puts nothing else at the root.

## Reading and writing

- **Read before answering.** When a space, person or company comes up, read its page first (the map shows where).
- **Who or what exists in Knowledge:** `cosm index` lists its folders; `cosm index <folder>` (`cosm index companies`) gives every page in it with its first line, alphabetical. Use it to find the right person or company, or to check one exists before making a page; the user's folder views show the same list.
- **Don't ask where something goes:** pick the best-fitting page; ask only when nothing fits, once, with a suggestion.
- **Write as you go.** When something durable comes up (a decision, a date, a number, a name, a commitment, a correction), write it to its page right then and say so in one line. Nothing waits for the end of the session.
- **What goes on a page:** what was decided, not what was discussed. Status changes, decisions with their reason, numbers, names, dates, commitments. Leave out background and passing thoughts.
- **The user's own words** (a note, a meeting write-up) are kept as written. The agent may add a short summary on top; changing their text needs **y**.

### How the cosm grows

1. **Two kinds of page.** State pages (each space's `<space>.md` and each knowledge page) are rewritten in place: always current, never appended. Notes in `notes/` are dated pages, written once and then left alone; a correction is a new note. `profile.md` and preferences files are lists of dated lines, which `/cosm:review` tightens.
2. **A dated note goes with what it's about.** A meeting about the Acme delivery goes in `02-spaces/Acme supply deal/notes/`.
3. **Decisions and changes that matter get a note.** When the user decides something that binds later work, or a state line changes and the old value or the reason will matter (a date moved, a price changed, a choice reversed), write a short dated note, `notes/<YYYY-MM-DD> Decision <topic>.md`: what was decided, why (in the user's words, or "reason not given"), and what it replaced. The state line links it. Routine updates just replace the line.
4. **One place per thing.** A fact lives on one page, a task in one list; when two pages fit, the more specific gets it and the other links to it.
5. **No folders inside `notes/`.**

### Page shapes

```
# Acme supply deal

One line: what this is.

## Where it stands
*As of 2026-10-21*
- **Stage:** price agreed at 84 kr/unit; contract with Acme's lawyer
- **Delivery:** moved to 3 Nov
- **In flight:** waiting for the signed contract

## Open
- Who signs on Acme's side
```

- **Where it stands:** one labelled line per thing that matters, plus **In flight:**, under an *As of* date.
- Other sections, each only when it has content: **Parts** (what the space is made of, links to its notes), **How to** (procedures for it), **Working on this** (how the user wants it handled), **Open** (unresolved questions).
- An update replaces the line it changes and moves the *As of* date to today. Never add a dated line, a log or a "what changed" section; history lives in `notes/`.
- A knowledge page has the same shape, with lines that fit it (`**Role:**`, `**Company:**`, `**How we know each other:**`).
- A page past one screen is not shortened on the spot: `/cosm:review` flags it and proposes moving a section to `notes/`, applied on **y**.

Tasks, one line each, with a date when there is one: `- [ ] Send Acme the revised price [[Acme supply deal]] 📅 2026-11-03`.
- `todo.md` is the user's: read it; propose a line or a tick and write it only on **y**; never reorder or rewrite the user's lines. The user may keep their lists elsewhere or in another shape: when they do, note where in `profile.md` (on **y**) and treat those lists the same.
- `tasks.md` is the agent's: what it should do or check later, a date on every line, written without asking. Tick a line once its outcome is written on the space page. If a task turns out to be the user's, propose moving it to `todo.md`.

### Naming and links

- Name files and folders the way the user would write the thing: `Anna Berg`, `Acme supply deal`, a dated note `2026-10-21 Acme kickoff`. Capitals and the gaps between words as written; no characters a file name can't hold (`/ : \ * ? " < > |`). Names are unique across the cosm, except each space's `todo.md` and `tasks.md`; never link to those two, name the space instead.
- A meeting note links everyone who was there and its space; a state page links the people who matter to it.
- When a person's or company's name gets clearer (a surname, the full company name), propose renaming the page; on **y**, rename it with `cosm rename` (a space's or person's folder goes with it).
- Every page starts with a `# Heading`. No frontmatter.

### The map

There is no map file to keep: Cosm makes the map from the folders each session. What it shows of a space, a skill, a preference or a fix is the first line under the page's heading, so that line always says what the page is (a space: what it is and where it stands in a few words; a skill or preference file: when it applies).

### Archive

When a space is done, propose moving its folder to `04-archive/spaces/`; move it on **y**. Knowledge pages are never archived.

## Learning

- Before doing a kind of work, read its preferences file if the map lists one. A file is named for the skill that does the work, or for the kind of work when there is no skill (`Invoices.md`); its first line says when it applies.
- A preference or profile line is one dated line: `- Archive newsletters from X without showing them (2026-10-21)`. A line `/cosm:setup` wrote as a starting point ends `(default)` instead of a date; the user may delete it. Profile lines go under `## How I like to work`.
- A habit Cosm suggests (a skill lists them under "Offer once") is offered the first time it applies, when its preferences file has no line about it: one question, then the user's answer becomes a dated preference line, followed from then on.
- A procedure done the same way a second time is a skill candidate: `/cosm:reflect` proposes it.
- **Write every fix.** When a tool or file type fails in a way the next session would hit again (not a typo or a wrong guess) and another way works, write the fix before moving on. One dated line in `03-knowledge/fixes/<tool>.md`: `pdf`, `word`, `excel`, `powerpoint`, `web`, `uv` or `mail` (the files the skills load), otherwise the tool's name (`numbers.md`), saying what failed and what works: `- Moving a file with spaces in its name fails unquoted: quote the path (2026-10-22)`. A new file starts with a line saying which tool it is about.
- Size: about 2,000 characters per preferences or fixes file and 1,500 for `profile.md`. Past that, `/cosm:review` proposes a tighter version (duplicates merged, overridden lines dropped).

## Skills

The user's own skills in `03-knowledge/skills/` are read from their `SKILL.md`. For reading or making Word, Excel, PowerPoint and PDF files, use the tools skill.

## Downloads

Downloads is the exchange point: when the user says a file is there, look first, newest first; files made for the user go in `~/Downloads`, with the name said. No document other than markdown is kept in the cosm's folders (`.cosm/` aside). When a file is worth keeping, suggest where the user keeps files, and move it on **y**.
