# At a glance's data, for its page (COSM_EVENT=data, COSM_DATA=summary): the folders at the top with how many pages
# each holds, and the ten pages changed most recently, as JSON.
[ "$COSM_EVENT" = data ] && [ "$COSM_DATA" = summary ] || exit 0
find . -mindepth 1 -type f -name '*.md' -not -path '*/.*' -print0 2>/dev/null | xargs -0 stat -f $'%m\t%N' 2>/dev/null | sed 's#\t\./#\t#' | perl -MJSON::PP -e '
  my (%n, @all);
  while (<STDIN>) { chomp; my ($t, $p) = split /\t/, $_, 2; my ($top) = $p =~ m{^([^/]+)/}; $n{$top // "(top)"}++; push @all, [$t, $p] }
  my @recent = map { my ($t, $p) = @$_; (my $name = $p) =~ s{^.*/|\.md$}{}g; { name => $name, path => $p, when => $t + 0 } } (sort { $b->[0] <=> $a->[0] } @all)[0 .. 9];
  print JSON::PP->new->canonical->encode({ folders => [map { { name => $_, pages => $n{$_} } } sort keys %n], recent => [grep { $_->{path} } @recent] });'
