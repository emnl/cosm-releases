---
name: packages
description: Extending or changing Cosm itself with a package. Use when the user wants Cosm to do something it doesn't (keep the cosm in git, send sessions somewhere, a page that sums something up, a button, a reminder line, a different look, another agent), wants to change how Cosm behaves (its layout, its rules, its commands, the sidebar), asks what packages they have or to switch one on or off, and when a package reports a problem. A procedure the agent follows when the work comes up is a skill in the user's skills folder, not a package.
---
# Packages

Cosm is a small engine: a window on a folder of markdown, with the agent beside it. Everything else it does comes from packages, its own opinions included. The agent extends Cosm by building packages, and changes it by changing them.

Packages now (id, on or off, built in or this cosm's, name — what it does): !`cosm package list`

## Package, skill or preference

Choose the smallest that does it:

- **A preference** (Star chart: `03-knowledge/preferences/`): how the user wants something done. "Write to Anna in English."
- **A skill** (Star chart: `03-knowledge/skills/<name>/SKILL.md`): a procedure the agent follows when the work comes up.
- **A package**: anything that must happen without the agent being asked, anything in the window (a sidebar row, a page of its own, a button, a reminder, colours), a secret, a different agent.

A change to how the agent works is a preference or profile line, even when it overrides a package's rules ("stop asking before filing"). Copy a built-in package only for what a line can't change: its sidebar, its commands, its scripts.

## Where packages live

A package is a folder with a `cosm.json`. The cosm's own are in `.cosm/packages/<id>/` (id: lowercase letters, digits and `-`). The built-in ones come with the app and are never edited where they are; `cosm package list` shows them. To change a built-in package (its sidebar, a command, a script), copy its whole folder into `.cosm/packages/<the same id>/` and change the copy, on **y**, after saying that the copy replaces the built-in one for this cosm at once and stops getting the app's updates to it. The folder of the built-in packages is `$COSM_BUILTIN`.

## What a package can bring

All of it is declared in `cosm.json`; `reference.md` beside this skill gives every key with an example. In short:

| It brings | Key | Example |
|---|---|---|
| Rules for the agent | `rules.md` (or `"rules"`) | Star chart's page rules |
| Skills and commands for the agent | `skills/`, `commands/` (as `/cosm:<name>`) | Star chart's Recall |
| Lookups for `cosm <lookup>` | `"cli"` | Star chart's `cosm map` |
| A script at moments | `"run"`, `"when"` | Git sync every 10 minutes |
| Actions in ⌘K or a page's menu | `"actions"` | Sync now, Send to habit |
| Secrets kept outside the cosm | `"secrets"` | a token |
| What the window shows | `"frame"` | sidebar rows, views, the session's commands |
| A page of its own, in HTML | a view of type `html` | At a glance |
| Colours | `"theme"` | Cosm's indigo |
| An agent | `"agent"` | Claude Code; Echo |
| Settings and hooks for Claude Code | `"claude"`, `claude/hooks.json` | a hook before every tool call |
| Folders and files for a new cosm | `"scaffold"` | Star chart's layout |

A script tells the user things with `cosm notify "…"` (a notice in the window's top right that fades) and `cosm problem "…"` (one that stays, with an Ask the agent button that hands it to you). A script that fails becomes a problem by itself.

## Building one

1. Say in one or two lines what it will do, when, which secret it needs, and any Claude Code permissions or hooks it adds (those apply without asking).
2. Write the folder. Start from the closest example beside this skill (`examples/`): `git-sync` (a script at moments, an action; it needs a remote the Mac can push to without a password, and gran's database is one binary file, so tables changed on two Macs between syncs make a conflict it reports and can't merge), `glance` (a page of its own, in HTML), `echo-agent` (an agent that speaks Cosm's chat protocol).
3. Try it before switching it on: `cosm package run <id> <moment>` (for data: `COSM_DATA=<name> cosm package run <id> data`); it prints what the script prints, and `FAIL:` with the reason when it fails. Fix it until it works and says the right thing. A package that needs a secret can't be tried fully until it is on and the user has entered the secret in Cosm's window: try what you can without it, switch it on, then try again.
4. Ask before switching it on, because it then runs by itself: "Turn on Git sync, every 10 minutes? **y** yes · **n** no". On **y**: `cosm package on <id>`; it starts at once (its `open` moment). A secret it needs is asked for by Cosm in a small window once it is on. Never ask for a secret in the chat, never read the secrets file, never print a secret or let a script print one, never pass one as an argument, and never write one into a file in the cosm. If the user pastes a secret in the chat, don't repeat it or write it anywhere; ask them to enter it in Cosm's window instead.
5. What the window shows changes at once. Rules, skills, commands, hooks and a new agent reach the agent from the next session: say so.

Changing a package: edit its files; the next run, and the window, use them. `cosm package off <id>` switches one off; to remove one, switch it off and move its folder to the trash with `cosm trash .cosm/packages/<id>`. Switching off a built-in package is allowed (the user may want Cosm without Star chart): say what goes with it, and switch it off on **y**.

When a package reports a problem and the user asks about it: read its `cosm.json` and script, run it by hand to see the error, fix the cause, and say what it was.
