# Git sync: what others pushed comes in first, then what changed here goes out. Quiet when nothing changed.
remote="${OPTION_REMOTE:-origin}"
git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { cosm problem "Git sync: this cosm is not a git repository yet."; exit 0; }
# A rebase left half done (a run stopped in the middle) is for a person to finish, not for the next run.
[ -d .git/rebase-merge ] || [ -d .git/rebase-apply ] && { cosm problem "Git sync: a rebase was left half done in this cosm; it needs finishing by hand (git status) before syncing again."; exit 0; }
branch="${OPTION_BRANCH:-$(git symbolic-ref --short HEAD 2>/dev/null)}"
[ -n "$branch" ] || { cosm problem "Git sync: no branch is checked out."; exit 0; }

# Cosm's own passing files stay out of git.
for line in '.cosm/notices'; do
  grep -qxF "$line" .gitignore 2>/dev/null && continue
  # A last line without its newline gets one first, so the rule isn't glued onto it.
  [ -s .gitignore ] && [ -n "$(tail -c1 .gitignore)" ] && echo >> .gitignore
  echo "$line" >> .gitignore
done

if [ -n "$(git status --porcelain)" ]; then
  git add -A && git commit -q -m "Cosm: $(date '+%Y-%m-%d %H:%M')" || { cosm problem "Git sync: couldn't commit the changes here."; exit 0; }
fi

# A remote without this branch yet (a new, empty one): the first push makes it.
if ! git ls-remote --exit-code --heads "$remote" "$branch" >/dev/null 2>&1; then
  git ls-remote "$remote" >/dev/null 2>&1 || { cosm problem "Git sync: couldn't reach $remote. Offline, or the Mac can't sign in to it."; exit 0; }
  git push -q -u "$remote" "HEAD:$branch" 2>/dev/null && cosm notify "Git sync: this cosm is now on $remote" || cosm problem "Git sync: couldn't push to $remote."
  exit 0
fi
git fetch -q "$remote" "$branch" 2>/dev/null || { cosm problem "Git sync: couldn't reach $remote. Offline, or the Mac can't sign in to it."; exit 0; }
before=$(git rev-parse HEAD)
incoming=$(git rev-list --count "HEAD..$remote/$branch" 2>/dev/null || echo 0)
if [ "$incoming" -gt 0 ]; then
  if ! git rebase -q "$remote/$branch" >/dev/null 2>&1; then
    git rebase --abort >/dev/null 2>&1
    cosm problem "Git sync: the same lines changed here and on $remote, so nothing was pulled. Your changes here are safe."
    exit 0
  fi
  files=$(git diff --name-only "$before" HEAD -- . ':!.gitignore' | wc -l | tr -d ' ')
  [ "$files" -gt 0 ] && cosm notify "Git sync: pulled changes to $files $([ "$files" = 1 ] && echo file || echo files)"
fi

outgoing=$(git rev-list --count "$remote/$branch..HEAD" 2>/dev/null || echo 0)
if [ "$outgoing" -gt 0 ]; then
  files=$(git diff --name-only "$remote/$branch" HEAD | wc -l | tr -d ' ')
  git push -q "$remote" "HEAD:$branch" 2>/dev/null || { cosm problem "Git sync: couldn't push to $remote."; exit 0; }
  [ "$COSM_EVENT" = action ] || [ "$files" -gt 0 ] && cosm notify "Git sync: pushed changes to $files $([ "$files" = 1 ] && echo file || echo files)"
fi
[ "$COSM_EVENT" = action ] && [ "$incoming" = 0 ] && [ "$outgoing" = 0 ] && cosm notify "Git sync: up to date"
exit 0
