#!/usr/bin/perl
# Echo: the smallest agent that speaks Cosm's chat protocol. It reads Cosm's inputs, one JSON object per line on stdin,
# and writes events, one per line on stdout (the protocol: Cosm's agents.ts, or the packages skill). A real agent would
# hand the message and $ENV{COSM_RULES} (the rules) to a model here; Echo says back what it got, as a step and a reply.
use strict; use warnings; use JSON::PP;
$| = 1;
my $j = JSON::PP->new->canonical;
sub say_ { print $j->encode(shift), "\n" }
while (my $line = <STDIN>) {
  my $in = eval { $j->decode($line) } or next;
  my $t = $in->{type} // "";
  if ($t eq "hello") {
    say_({ type => "ready", commands => [{ name => "echo:ping", description => "Answers pong" }], models => [{ id => "echo", name => "Echo" }] });
    say_({ type => "model", model => "echo" });
  } elsif ($t eq "message") {
    my $text = $in->{text} // "";
    say_({ type => "step", id => "s1", title => "Read your message", tool => "Echo", input => { text => $text } });
    say_({ type => "step-done", id => "s1", output => length($text) . " characters" });
    my $reply = $text =~ m{^/echo:ping} ? "pong" : "You said: $text";
    say_({ type => "text-start" });
    say_({ type => "text-delta", text => $_ }) for split /(?<= )/, $reply;
    say_({ type => "text", text => $reply });
    say_({ type => "turn-end", text => $reply });
  } elsif ($t eq "stop") {
    say_({ type => "turn-end", text => "" });
  }
}
