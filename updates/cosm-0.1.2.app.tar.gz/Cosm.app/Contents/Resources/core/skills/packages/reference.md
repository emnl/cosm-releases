# cosm.json, every key

A package's `cosm.json` names what it brings. Every key is optional except `name`. Paths are inside the package's folder. The built-in packages (`$COSM_BUILTIN/star-chart`, `gran`, `cosm`, `claude`) are full examples of most keys.

## What it is

```json
{ "name": "Git sync", "description": "One plain sentence on what it does for the user.", "default": "off", "order": 50 }
```

- `name`, `description`: shown in Settings → Packages.
- `default`: `"off"` keeps a built-in package off until switched on. The cosm's own packages start off anyway.
- `order`: where it sits among packages (the built-in ones use 1–20); what the window shows follows this order.

## For the agent

- `rules`: a file of rules added after Cosm's own (default `rules.md`). One `# Heading` with the package's name, then the rules.
- `skills/<name>/SKILL.md`, `commands/<name>.md`: found by folder, loaded like Cosm's own; commands answer to `/cosm:<name>`. A name already taken by a package before it is skipped.
- `cli`: a script asked for any `cosm <lookup>` the engine doesn't know, with the lookup as its arguments. It prints its answer, or exits 64 when the lookup isn't one of its own. It can source the engine's helpers: `. "$COSM_LIB"`.
- `index`: `{"skip": ["03-knowledge/skills/*"]}` keeps pages out of search.

## Scripts and moments

```json
{ "run": "sync.sh", "when": ["open", "every 10", "close"], "options": { "remote": "origin" } }
```

`run` is the script; `when` the moments it runs at:

| Moment | When | What it prints |
|---|---|---|
| `open` | the cosm's window opens, and when the package is switched on | nothing goes anywhere |
| `every N` | every N minutes while the window is open, counted from opening | — |
| `close` | the window closes | — |
| `session-end` | the user closes a session or starts a new one (not when the window closes: the session carries on) | — |
| `session-start` | a session starts, resumes or is compacted | given to the agent: wrap it in a tag of your own, `<habit>…</habit>` |
| `prompt` | each message the user sends | given to the agent with the message; keep it short and print nothing when nothing applies |
| `page-read` | the agent read a page | — |
| `tool-failed` | one of the agent's steps failed | given to the agent |
| `action` | the user picked one of its actions | — |
| `data` | a view, list or reminder asks for data | the data: JSON, or tab-separated lines |

The script runs in the cosm's folder, with no terminal (nothing can ask for a password; git is told not to), stopped after five minutes, one background run of a package at a time. It is run with bash unless it is executable with its own `#!` line. It gets:

- always: `COSM_EVENT` (the moment), `COSM_PACKAGE`, `COSM_PACKAGE_NAME`, `COSM_PACKAGE_DIR`, `COSM_ROOT`, `COSM_LIB`, its options as `OPTION_<NAME>` (`OPTION_REMOTE`), its secrets by name;
- session-start: `COSM_SESSION`, `COSM_SOURCE` (startup, resume, compact, clear), `COSM_SHOWN`;
- prompt: `COSM_PROMPT_FILE` (the message), `COSM_SESSION`, `COSM_SHOWN` (a file of what this session was already shown: add a line for what you show, skip what is there), `COSM_TURN` (a folder the packages answering this message share, in order: Star chart leaves `pages` and `telling.tsv` there);
- page-read: `COSM_PAGE`; tool-failed: `COSM_TOOL`, `COSM_ERROR_FILE`;
- session-end: `COSM_SESSION` and `COSM_TRANSCRIPT` (the session's file);
- action: `COSM_ACTION` (its title), `COSM_PAGE` for a page action;
- data: `COSM_DATA` (the name asked for), `COSM_ARG`.

## Actions

```json
{ "actions": [
  { "title": "Sync now" },
  { "title": "Send to habit", "page": true, "run": "send.sh" },
  { "title": "Recall", "description": "Where things stand", "prompt": "/cosm:recall" }
] }
```

An action is in ⌘K (with `description` under it), or with `"page": true` on a page's right-click menu, given that page. It runs `run` (its own or the package's), or with `prompt` sends that message to the agent; prompt actions are also in the Session menu, as `menu` words them (`"menu": "Write Log"`; `false` leaves one out).

## Secrets

```json
{ "secrets": [{ "name": "HABIT_TOKEN", "label": "Habit token", "agent": false }] }
```

Kept in a file outside the cosm, so it isn't synced or shared; Cosm asks for each in a small window once the package is on. The script gets it as a variable; with `"agent": true` the agent's sessions get it too (from the next session), which also means it can end up in a transcript.

## The frame: what the window shows

All under `"frame"`. The window draws it in its own style; a package says only what goes where.

```json
{ "frame": {
  "sidebar": [
    { "type": "inbox", "id": "inbox", "title": "Inbox", "folder": "01-inbox", "icon": "inbox", "view": "inbox" },
    { "type": "section", "id": "spaces", "title": "Spaces", "folder": "02-spaces", "sort": "recent", "new": { "title": "New Note in This Space", "folder": "notes" } },
    { "type": "section", "id": "knowledge", "title": "Knowledge", "folder": "03-knowledge", "sort": "name", "each": "index" },
    { "type": "list", "id": "tables", "in": "knowledge", "title": "Tables", "data": "tables", "group": "prefix", "view": "tables", "watch": ".cosm/gran.db",
      "item": { "view": "table", "key": "name", "count": "rows", "tip": "doc" } },
    { "type": "link", "title": "At a glance", "icon": "page", "view": "glance" }
  ],
  "footer": [{ "title": "Archive", "icon": "archive", "view": "archive" }],
  "views": { "…": {} },
  "session": { "start": "/cosm:recall", "first": "/cosm:setup", "reflect": "/cosm:reflect", "log": "/cosm:log", "logs": "regex", "quiet": ["/cosm:recall"], "reminder": "review-due" },
  "new": [{ "title": "New Space…", "ask": "New space", "folder": "02-spaces/{name}", "page": "{name}", "template": "templates/space.md" }],
  "notes": "01-inbox",
  "pages": { "names": { "profile.md": "Profile" }, "fixed": ["profile.md"] },
  "home": "profile.md",
  "settings": [{ "section": "You", "label": "Profile", "page": "profile.md", "from": "## Me", "empty": "Not written yet", "hint": "…" }]
} }
```

Sidebar blocks, top to bottom, in package order:

- `inbox`: a folder as one row with how many pages it holds, opening `view`; its items fold under it.
- `section`: a heading that folds, over a folder's items, and over any blocks placed in it (`in`: its `id`). Without a `folder` it is a plain heading over just those blocks: `{"type": "section", "id": "mine", "title": "Emanuel's stuff"}` with `{"type": "link", "in": "mine", …}` under it. `sort`: `recent` (newest first, the latest few and Show all) or `name` (all, alphabetical). `each`: a view each subfolder opens (with the subfolder as its argument) instead of its own page. `new`: what a subfolder's right-click makes inside it.
- `list`: rows from the package's `data` (JSON objects), each opening `item.view` with the row's `item.key` as argument; `group: "prefix"` groups rows sharing a name prefix (`pf_accounts`, `pf_balances`); `in`: the id of a section to sit inside; `watch`: a path under `.cosm/` whose changes redraw it.
- `link`: one row opening a view; with `in`, inside a section.

Any block: `word`, what one page in it is called in the chat's @ menu (`"Space"`; the block's title otherwise); `after` or `before`, the `id` of another block, any package's, to sit right after or before it (`"after": "inbox"`: under Star chart's Inbox; `"before": "spaces"`: between Inbox and Spaces), so a package needn't copy another to find its place. Star chart's ids: `inbox`, `spaces`, `knowledge`; gran's Tables sits in `knowledge`.

When no package gives a folder its place, the sidebar shows the whole folder as a plain tree. `icon`: `inbox`, `archive`, `table`, `page`, or a folder by default. A folder holding a page of its own name opens that page (a hub).

`footer`: small buttons at the sidebar's foot, before Trash and Settings, each opening a view.

`views`, by name (opened from blocks, the footer, crumbs and `trail`):

| type | shows | keys |
|---|---|---|
| `inbox` | a folder's pages, newest first, with their first line; session logs apart | `folder`, `logs` (a regex on names), `button` `{title, prompt}`, `empty` |
| `index` | rows from `data` (name, page, first line, tab-separated), given the folder as `COSM_ARG` | `data`, `purpose` `{folder name: line}` |
| `folders` | a folder's parts, each newest first | `folder`, `empty` |
| `list` | rows from `data`, grouped, each with a line and a count | `data`, `item` `{view, key, line, count, unit}`, `group`, `intro`, `empty` |
| `table` | one table from `data`: `{doc, rows, columns: [{name, type, doc}], newest: [rows]}` | `data`, `named` (the data whose rows name it) |
| `html` | the package's own page, in a sealed frame | `file` |

Any view: `title`, `trail` (crumbs before its title: `"Knowledge"`, or `"Tables|tables"` to link a view), `watch`, `told` (what the agent is told is open: `"the gran table {arg}"`).

`session`: `start`, the message each session opens with; `first`, the one in a new cosm; `reflect` and `log`, the agent header's two buttons (Reflect is also offered when the user leaves a session they said something in); `logs`, which written pages are session logs (a regex on paths); `quiet`, messages that don't count as the user saying something; `reminder`, the name of data that prints `{"text", "button", "prompt"}` or nothing, shown as a line at the top of the chat with Not now.

`new`: File → New … items: asks for a name, makes `page` in `folder` from `template`, with `{name}` and `{today}` filled in. `notes`: the folder New Note writes to. `pages.names`: shown names; `pages.fixed`: pages that can't be renamed or trashed. `home`: the page a new cosm opens on. `settings`: rows in Settings, each showing the first line under `from` on `page`.

## A page of its own (a view of type html)

The file is HTML, shown in a sealed frame: its scripts run, but it can reach nothing of the window or the files. It gets Cosm's colours as CSS variables (`--page`, `--text`, `--muted`, `--faint`, `--line`, `--accent`, `--title` …) and talks to Cosm through `window.cosm`:

- `cosm.data(name, arg)`: the package's data (its script with `COSM_EVENT=data`), a promise of JSON or of lines;
- `cosm.open(path)`: opens a page; `cosm.action(title, page)`: runs one of its actions; `cosm.notify(text)`: a notice;
- `cosm.onchange(fn)`: fn() when the cosm changes, to draw again; `cosm.arg`: the view's argument.

`examples/glance/` is one.

## Colours

```json
{ "theme": { "name": "Dusk", "light": { "accent": "#7a5cc2" }, "dark": { "accent": "#b9a4f0" },
  "terminal": { "light": { "background": "#fafaf8" }, "dark": {} }, "claude": { "light": {}, "dark": {} } } }
```

Tokens, for light and dark: `page`, `side`, `chat`, `card`, `bubble` (surfaces); `text`, `muted`, `faint`; `line`, `line2`, `sel`, `fill`, `fill2`; `accent`, `onaccent`, `title`, `bullet`, `flash`, `selrow`. A token left out keeps the engine's. `terminal`: the agent's own screen's colours (xterm's names: `background`, `foreground`, `cursor`, `black` … `brightWhite`). `claude`: Claude Code's own theme files (`{"name", "base", "overrides"}`), for its screen. With several themes on, Settings → Appearance chooses. Only colours: a theme can't change the frame.

## An agent

```json
{ "agent": { "name": "Echo", "chat": "chat.pl", "screen": "screen.sh" } }
```

`chat`: a command that speaks Cosm's chat protocol, one JSON object per line: it reads inputs on stdin and writes events on stdout. `screen`: a command for the agent's own screen, run in a terminal. Both start in the cosm's folder with `COSM_SESSION`, `COSM_RESUME` (1 when carrying a session on), `COSM_RULES` (a file of all the rules), `COSM_SKILLS` and `COSM_COMMANDS` (folders of every package's skills and commands), and the secrets given to the agent. Settings → Agent chooses among agents; a new one starts with the next session.

Inputs, Cosm → agent: `{"type":"hello"}` (answer with ready), `{"type":"message","text","images":[{media_type, data}]}`, `{"type":"answer","id","allow","always","answers":{question: answer},"message"}`, `{"type":"stop"}`, `{"type":"model","model"}`.

Events, agent → Cosm: `ready` `{commands:[{name, description, hint}], models:[{id, name, description}]}`; `model` `{model}`; `text-start`, `text-delta` `{text}`, `text` `{text}` (a whole reply); `step` `{id, title, write, tool, input, page}` and `step-done` `{id, output, error, refused}`; `permission` `{id, step, title, detail, always}`, `question` `{id, step, questions:[{question, header, multi, options:[{label, description}]}]}`, `plan` `{id, step, plan}`, `cancel` `{id}`; `user` `{text, images, command}` (the session's past, when carried on); `turn-end` `{text, denied:[{step, title}]}`; `note` `{text}`. `examples/echo-agent/` is the smallest one.

## Claude Code's own settings and hooks

- `"claude": {"settings": {"permissions": {...}}}`: added to Claude Code's permissions (lists are joined): `{"permissions": {"allow": ["Bash(git:*)"]}}`. Only permissions: nothing else of Claude Code's settings can be changed this way.
- `claude/hooks.json`: Claude Code hooks of the package's own, in Claude Code's hooks format; the package's folder is `${CLAUDE_PLUGIN_ROOT}/package`.

Both only for Claude Code; prefer a moment, which works for any agent.

## A new cosm

```json
{ "scaffold": { "folders": ["01-inbox", "02-spaces"], "files": { "profile.md": "templates/profile.md" } } }
```

When a folder is made a cosm, each package that is on lays out its folders and copies its files, never over anything there.
