# The engine's library: everything the `cosm` command does itself, and the helpers packages use (a package's script
# sources this file through $COSM_LIB). It runs in the cosm's folder. The engine knows no layout: where things go is
# a package's business (Star chart's, for most cosms).
shopt -s nullglob

# --- pages ---------------------------------------------------------------------------
first_line() { # $1 a page: a skill's description, else the first plain line under its title, markdown marks dropped
  awk 'NR==1 && /^---$/ {fm=1; next} fm && /^---$/ {fm=0; next}
    fm && /^description:/ {sub(/^description:[ \t]*/, ""); gsub(/^["'\'']|["'\'']$/, ""); print; exit}
    fm {next}
    /^[ \t]*$/ || /^#/ || /^\*As of/ || /^>/ || /^[-|][ \t]*$/ {next}
    {print; exit}' "$1" 2>/dev/null |
  sed -E 's/\[\[([^]|]+)\|([^]]+)\]\]/\2/g; s/\[\[([^]]+)\]\]/\1/g; s/\*\*|__|`//g; s/^[-*] (\[.\] )?//' | cut -c1-200; }
# Renames a page and fixes every [[link]] to it, as the app's own rename does: a page with a folder of its own name
# (a space, a person, a company) takes the folder along. $1 the page's path, $2 the new name. Prints the new path.
rename_page() {
  local from="$1" new="$2" dir old to
  case "$from" in /*|*..*) echo "FAIL: give a path inside the cosm"; return ;; esac
  [ -f "$from" ] || { echo "FAIL: no page at $from"; return; }
  case "$new" in ''|*/*|*:*) echo "FAIL: a name can't be empty or hold / or :"; return ;; esac
  dir=$(dirname "$from"); old=$(basename "$from" .md)
  [ "$old" = "$new" ] && { echo "$from"; return; }
  if [ "$(basename "$dir")" = "$old" ] && [ "$dir" != . ]; then
    local nd; nd="$(dirname "$dir")/$new"; [ -e "$nd" ] && { echo "FAIL: $nd already exists"; return; }
    mv "$dir" "$nd" && mv "$nd/$old.md" "$nd/$new.md"; to="$nd/$new.md"
  else
    to="$dir/$new.md"; [ -e "$to" ] && { echo "FAIL: $to already exists"; return; }
    mv "$from" "$to"
  fi
  OLD="$old" NEW="$new" find . -name '*.md' -not -path './.*' -print0 | OLD="$old" NEW="$new" xargs -0 perl -pi -e 's/\[\[\Q$ENV{OLD}\E(?=\]\]|\||#)/[[$ENV{NEW}/g'
  # The app reads this note, so a page open in its window follows the rename.
  mkdir -p .cosm && printf '%s\t%s\n' "${from#./}" "${to#./}" > .cosm/renamed
  echo "${to#./}"; }
# Moves a page or folder to the cosm's trash, as the app's own trash does: at a free name in .trash/, with where it
# came from noted in .trash/.origins.json (so the app's Put back returns it there), and a folder it leaves empty inside
# a space or kind (a space's notes/) removed. $1 the path. Prints where it went.
trash_page() {
  local from="${1%/}" name to n=1 dir
  # Inside the cosm, and not in its hidden folders, except a package of the cosm's own (.cosm/packages/<id>).
  case "$from" in /*|*..*|'') echo "FAIL: give a path inside the cosm"; return ;; .cosm/packages/?*) ;; .*) echo "FAIL: give a path inside the cosm"; return ;; esac
  [ -e "$from" ] || { echo "FAIL: nothing at $from"; return; }
  mkdir -p .trash; name=$(basename "$from")
  to=".trash/$name"
  while [ -e "$to" ]; do n=$((n + 1)); case "$name" in *.*) to=".trash/${name%.*} $n.${name##*.}" ;; *) to=".trash/$name $n" ;; esac; done
  mv "$from" "$to" || { echo "FAIL: could not move $from"; return; }
  KEY="$(basename "$to")" FROM="$from" perl -MJSON::PP -e '
    my $f = ".trash/.origins.json"; my $j = JSON::PP->new->utf8->pretty->canonical;
    my $o = {}; if (open my $h, "<", $f) { local $/; my $t = <$h>; $o = eval { $j->decode($t) } || {}; }
    $o->{$ENV{KEY}} = $ENV{FROM}; open my $w, ">", $f or exit; print $w $j->encode($o);'
  dir=$(dirname "$from")
  while [ "$(printf '%s' "$dir" | tr -cd / | wc -c | tr -d ' ')" -ge 2 ]; do
    [ -z "$(ls -A "$dir" 2>/dev/null | grep -v -x '.DS_Store')" ] || break
    rm -rf "$dir"; dir=$(dirname "$dir")
  done
  # The app reads this note, so a page open in its window gives way to the page that held it.
  mkdir -p .cosm && printf '%s\n' "$from" > .cosm/trashed
  echo "$to"; }
# The app writes the page open in its window to the file named by COSM_OPEN_PAGE.
open_page_path() { [ -n "$COSM_OPEN_PAGE" ] && cat "$COSM_OPEN_PAGE" 2>/dev/null; }
open_page() { local f n; f=$(open_page_path)
  # A package's view (the window writes what its cosm.json "told" says: "the gran table pc_cash").
  case "$f" in view:*) echo "Open in Cosm right now: ${f#view:}"; return ;; esac
  [ -n "$f" ] && { n=${f##*/}; echo "The page open in Cosm right now: [[${n%.md}]] ($f)"; }
  # Text the user has selected on it (the app writes it to COSM_SELECTION): what "this" most likely means.
  [ -n "$COSM_SELECTION" ] && [ -s "$COSM_SELECTION" ] && { echo "Selected on that page:"; echo '<selection>'; head -c 4000 "$COSM_SELECTION"; echo; echo '</selection>'; }; }

# --- search ----------------------------------------------------------------------
# A BM25 index of the vault (SQLite's FTS5, built into the Mac). It is a cache rebuilt from the notes, kept outside
# the vault so cloud sync never copies it: ~/Library/Caches/cosm/<vault id>/. Deleting it loses nothing.
# pages: every page except logs and what packages keep out. logs: '* Log – *.md' files (and '<date>-<time>-log-*.md', the name before 0.4). Kept apart because a log
# mentions everything and would crowd out the pages that hold the state.
cache_dir() { local d; d="$HOME/Library/Caches/cosm/$(md5 -q -s "$PWD")"; mkdir -p "$d/shown" 2>/dev/null; echo "$d"; }
INDEX_V=3 # raise when the index is built differently
FTS_TOK="tokenize = 'unicode61 remove_diacritics 0'"
PAT_SQL="CREATE TEMP TABLE pat AS SELECT DISTINCT word, '\"' || stem || '\"' || CASE WHEN pre = 1 THEN '*' ELSE '' END AS pat FROM pin;"
index_sync() { # bring the index up to date: re-read changed files, drop deleted ones. One run at a time.
  local c; c=$(cache_dir)
  [ -n "$(find "$c/lock" -maxdepth 0 -mmin +1 2>/dev/null)" ] && rmdir "$c/lock" 2>/dev/null
  mkdir "$c/lock" 2>/dev/null || return 0
  # the index's shape or rules changed in this version: start it again
  [ "$(sqlite3 "$c/index.db" 'PRAGMA user_version;' 2>/dev/null)" = "$INDEX_V" ] || rm -f "$c/index.db"
  # Every page in the cosm, except what packages that are on keep out ("index": {"skip": [globs]} in cosm.json).
  local skip=() g id dir on
  while IFS=$'\t' read -r id dir _ on _; do [ "$on" = 1 ] || continue
    while IFS= read -r g; do [ -n "$g" ] && skip+=(-not -path "./$g"); done < <(PKG get "$dir" index.skip)
  done < <(pkg_rows)
  find . -mindepth 1 -type f -name '*.md' -not -path '*/.*' ${skip[@]+"${skip[@]}"} -print0 2>/dev/null |
    xargs -0 stat -f $'%N\t%m' 2>/dev/null | sed 's#^\./##' | grep -v -e '"' > "$c/files.tsv"
  sqlite3 "$c/index.db" >/dev/null 2>&1 <<SQL
.bail on
.timeout 5000
CREATE TABLE IF NOT EXISTS files(path TEXT PRIMARY KEY, mtime INTEGER);
CREATE VIRTUAL TABLE IF NOT EXISTS pages USING fts5(path UNINDEXED, name, lead, body, $FTS_TOK);
CREATE VIRTUAL TABLE IF NOT EXISTS logs USING fts5(path UNINDEXED, name, lead, body, $FTS_TOK);
CREATE TEMP TABLE cur(path TEXT, mtime INTEGER);
.mode tabs
.import "$c/files.tsv" cur
CREATE TEMP TABLE gone AS SELECT path FROM files f WHERE NOT EXISTS (SELECT 1 FROM cur c WHERE c.path = f.path AND c.mtime = f.mtime);
CREATE TEMP TABLE new AS SELECT c.path, c.mtime FROM cur c WHERE NOT EXISTS (SELECT 1 FROM files f WHERE f.path = c.path AND f.mtime = c.mtime);
BEGIN;
DELETE FROM pages WHERE path IN (SELECT path FROM gone);
DELETE FROM logs WHERE path IN (SELECT path FROM gone);
DELETE FROM files WHERE path IN (SELECT path FROM gone);
CREATE TEMP TABLE doc AS
  WITH a0 AS (SELECT path, mtime, CAST(readfile(path) AS TEXT) AS raw FROM new),
       a AS (SELECT path, mtime,
                    CASE WHEN raw LIKE '---' || char(10) || '%' AND instr(substr(raw, 5), char(10) || '---') > 0
                         THEN ltrim(substr(substr(raw, 5), instr(substr(raw, 5), char(10) || '---') + 4), char(10, 13, 32)) ELSE raw END AS body,
                    replace(path, rtrim(path, replace(path, '/', '')), '') AS base FROM a0),
       b AS (SELECT *, substr(base, 1, length(base) - 3) AS name,
                    ltrim(CASE WHEN body LIKE '# %' THEN substr(body, instr(body, char(10)) + 1) ELSE body END, char(10, 13, 32)) AS rest,
                    CASE WHEN instr(body, char(10) || '## Summary') > 0
                         THEN ltrim(substr(body, instr(body, char(10) || '## Summary') + 11), char(10, 13, 32)) END AS summ FROM a)
  SELECT path, mtime, name, body, (name LIKE '% Log – %' OR name GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]-log-*') AS is_log,
         CASE WHEN (name LIKE '% Log – %' OR name GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9]-log-*') AND summ IS NOT NULL
              THEN substr(summ, 1, instr(summ || char(10) || '## ', char(10) || '## ') - 1)
              ELSE substr(rest, 1, instr(rest || char(10), char(10)) - 1) END AS lead FROM b;
INSERT INTO pages(path, name, lead, body) SELECT path, name, substr(trim(lead), 1, 300), body FROM doc WHERE NOT is_log;
INSERT INTO logs(path, name, lead, body) SELECT path, name, substr(trim(lead), 1, 600), body FROM doc WHERE is_log;
INSERT INTO files SELECT path, mtime FROM doc;
COMMIT;
PRAGMA user_version = $INDEX_V;
SQL
  rmdir "$c/lock" 2>/dev/null; return 0
}
index_sync_bg() { ( index_sync >/dev/null 2>&1 & ) ; }
uv_bin() { [ -x "$HOME/.local/bin/uv" ] && echo "$HOME/.local/bin/uv" && return; command -v uv 2>/dev/null; }
stem_lang() { awk '/^## Language/{f=1;next} /^## /{f=0} f && NF {print tolower($1); exit}' profile.md 2>/dev/null | tr -cd 'a-z'; }
# Words of a text, as the index splits them: one per line. $1 file holding the text.
words_of() { sqlite3 :memory: "CREATE VIRTUAL TABLE q USING fts5(x, $FTS_TOK); INSERT INTO q SELECT CAST(readfile('$1') AS TEXT);
  CREATE VIRTUAL TABLE v USING fts5vocab(q, row); SELECT term FROM v;" 2>/dev/null; }
# Search patterns for words on stdin, one "word<TAB>stem<TAB>prefix?" per line (pat_sql makes the FTS pattern): words
# under 3 letters dropped, under 4 searched whole, others as a prefix. With uv, the prefix is the word's stem in English or the profile's language, whichever is shorter.
patterns_of() {
  local uv words stems; words=$(cat); [ -z "$words" ] && return
  uv=$(uv_bin)
  if [ -n "$uv" ]; then
    stems=$(printf '%s\n' "$words" | cached_stems "$uv")
  fi
  if [ -n "$stems" ] && [ "$(printf '%s\n' "$stems" | wc -l)" = "$(printf '%s\n' "$words" | wc -l)" ]; then
    paste <(printf '%s\n' "$words") <(printf '%s\n' "$stems")
  else
    printf '%s\n' "$words" | awk '{print $0 "\t" $0}'
  fi | awk -F'\t' '{w=$1; p=$2; gsub(/"/,"",w); gsub(/"/,"",p)
    if (length(w) < 3) next; if (length(w) < 4) print w "\t" w "\t0"; else { if (length(p) < 3) p=w; print w "\t" p "\t1" } }'
}
# Stems for words on stdin, in order, one per line; the stemmer runs only for words not in the cache.
cached_stems() {
  local c lang words new out; c=$(cache_dir); lang=$(stem_lang); words=$(cat); touch "$c/stems.tsv"
  new=$(printf '%s\n' "$words" | awk -F'\t' -v l="$lang" -v f="$c/stems.tsv" 'FILENAME == f { if ($1 == l) seen[$2] = 1; next } !($0 in seen)' "$c/stems.tsv" -)
  if [ -n "$new" ]; then
    out=$(printf '%s\n' "$new" | "$1" run -q --no-project --python 3.12 --with snowballstemmer python -I -c '
import sys, snowballstemmer as s
langs = ["english"] + [l for l in sys.argv[1:] if l in s.algorithms() and l != "english"]
st = [s.stemmer(l) for l in langs]
for w in sys.stdin.read().split():
    print(w + "\t" + min((x.stemWord(w) for x in st), key=len))' $lang 2>/dev/null) || return
    [ -n "$out" ] && printf '%s\n' "$out" | awk -v l="$lang" '{print l "\t" $0}' >> "$c/stems.tsv"
  fi
  printf '%s\n' "$words" | awk -F'\t' -v l="$lang" -v f="$c/stems.tsv" 'FILENAME == f { if ($1 == l) st[$2] = $3; next } { print (($0 in st) ? st[$0] : $0) }' "$c/stems.tsv" -
}
# Glue words that never count as rare: the 300 most common words of English and of the profile's language, from the
# wordfreq package through uv. Each list is built once per Mac into the cache, in the background the first time it is
# missing; until then (or without uv) the words go unfiltered. A failed build is tried again after a day.
common_words() {
  local c l f; c=$(cache_dir)
  for l in english $(stem_lang); do
    f="$c/common-$l.txt"
    if [ -f "$f" ]; then cat "$f"
    elif [ -n "$(uv_bin)" ] && [ -z "$(find "$f.fail" -mtime -1 2>/dev/null)" ]; then ( build_common "$l" >/dev/null 2>&1 & )
    fi
  done | sort -u
}
build_common() { # $1 a language name as profile.md writes it (lowercase): english, swedish, german …
  local c f uv; c=$(cache_dir); f="$c/common-$1.txt"; uv=$(uv_bin)
  mkdir "$f.lock" 2>/dev/null || return 0
  if "$uv" run -q --no-project --python 3.12 --with wordfreq python -I -c '
import sys
from wordfreq import top_n_list, available_languages
names = {"arabic": "ar", "catalan": "ca", "czech": "cs", "danish": "da", "dutch": "nl", "english": "en", "finnish": "fi",
  "french": "fr", "german": "de", "greek": "el", "hindi": "hi", "hungarian": "hu", "icelandic": "is", "indonesian": "id",
  "italian": "it", "latvian": "lv", "lithuanian": "lt", "norwegian": "nb", "polish": "pl", "portuguese": "pt",
  "romanian": "ro", "russian": "ru", "spanish": "es", "swedish": "sv", "tamil": "ta", "turkish": "tr", "ukrainian": "uk"}
code = names.get(sys.argv[1])
words = top_n_list(code, 300) if code in available_languages() else []
print("\n".join(sorted({w.lower() for w in words if w.isalpha() and len(w) >= 3})))' "$1" > "$f.new" 2>/dev/null
  then mv "$f.new" "$f"; rm -f "$f.fail"; else rm -f "$f.new"; touch "$f.fail"; fi
  rmdir "$f.lock"
}
# Plain search for the agent: $1 table (pages or logs), the rest the words. Best 8, any match.
search() {
  local t="$1" c qf; shift; c=$(cache_dir); index_sync; qf="$c/q.txt"
  printf '%s' "$*" > "$qf"; words_of "$qf" | patterns_of > "$c/pat.tsv"; [ -s "$c/pat.tsv" ] || return
  sqlite3 "$c/index.db" 2>/dev/null <<SQL
CREATE TEMP TABLE pin(word TEXT, stem TEXT, pre INTEGER);
.mode tabs
.import "$c/pat.tsv" pin
$PAT_SQL
.mode list
.separator ""
SELECT path, ' — ', replace(lead, char(10), ' ') FROM $t WHERE $t MATCH (SELECT group_concat(pat, ' OR ') FROM pat)
ORDER BY bm25($t, 0, 10, 4, 1) LIMIT 8;
SQL
}
# For the app's search box: up to 12 pages whose text matches, each as path<TAB>the matching passage, with the matched
# words between \x02 and \x03 (the app shows them in bold). The same index and word rules as search.
find_text() {
  local c qf; c=$(cache_dir); index_sync; qf="$c/find.txt"
  printf '%s' "$*" > "$qf"; words_of "$qf" | patterns_of > "$c/findpat.tsv"; [ -s "$c/findpat.tsv" ] || return
  sqlite3 "$c/index.db" 2>/dev/null <<SQL
CREATE TEMP TABLE pin(word TEXT, stem TEXT, pre INTEGER);
.mode tabs
.import "$c/findpat.tsv" pin
$PAT_SQL
.mode list
.separator ""
SELECT path, char(9), replace(replace(snippet(pages, 3, char(2), char(3), '…', 14), char(10), ' '), char(9), ' ') FROM pages
WHERE pages MATCH (SELECT group_concat(pat, ' OR ') FROM pat)
ORDER BY bm25(pages, 0, 10, 4, 1) LIMIT 12;
SQL
}
# The pages worth attaching to a prompt. $1 file holding the prompt, $2 file of paths already shown (skipped),
# $3 explain (any value): print why each word and page passed or failed instead.
# A page passes when the prompt names it, or when it holds at least 2 of the prompt's rare words (in under a fifth
# of all pages). At most 3; usually none.
relevant_pages() {
  local c; c=$(cache_dir); touch "$2"; common_words > "$c/common.txt"
  words_of "$1" | patterns_of > "$c/pat.tsv"
  sqlite3 "$c/index.db" 2>/dev/null <<SQL
CREATE TEMP TABLE pin(word TEXT, stem TEXT, pre INTEGER);
CREATE TEMP TABLE shown(path TEXT);
CREATE TEMP TABLE common(word TEXT PRIMARY KEY);
.mode tabs
.import "$c/pat.tsv" pin
.import "$c/common.txt" common
$PAT_SQL
.import "$2" shown
CREATE VIRTUAL TABLE temp.q USING fts5(x, $FTS_TOK);
INSERT INTO temp.q SELECT CAST(readfile('$1') AS TEXT);
CREATE TEMP TABLE n AS SELECT count(*) AS n FROM pages;
CREATE TEMP TABLE df AS SELECT word, pat, (SELECT count(*) FROM pages WHERE pages MATCH pat.pat) AS df FROM pat;
CREATE TEMP TABLE rare AS SELECT * FROM df WHERE word NOT IN (SELECT word FROM common) AND df > 0 AND (df * 5 <= (SELECT n FROM n) OR (df = 1 AND (SELECT n FROM n) < 10));
CREATE TEMP TABLE named AS SELECT path FROM pages p
  WHERE length(p.name) >= 3 AND p.name NOT IN ('todo', 'tasks')
    AND EXISTS (SELECT 1 FROM temp.q WHERE q MATCH '"' || replace(p.name, '"', '') || '"');
CREATE TEMP TABLE hits AS SELECT p.path, count(DISTINCT r.pat) AS k FROM rare r, pages p WHERE p.pages MATCH r.pat GROUP BY p.path;
CREATE TEMP TABLE ranked AS
  SELECT path, 0 AS ord, 0.0 AS score FROM named
  UNION ALL
  SELECT path, 1, bm25(pages, 0, 10, 4, 1) FROM pages
   WHERE pages MATCH coalesce((SELECT group_concat(pat, ' OR ') FROM rare), '"cosmnomatch"') AND path IN (SELECT path FROM hits WHERE k >= 2);
.mode list
.separator "\t"
.once "$c/telling.tsv"
SELECT DISTINCT p.word, p.stem, p.pre FROM pin p JOIN df ON df.word = p.word WHERE df.df * 5 <= (SELECT n FROM n);
.separator "\t"
$( if [ -n "$3" ]; then cat <<EXPLAIN
SELECT 'pages in index: ' || n FROM n;
SELECT 'word', 'pattern', 'pages', 'rare' UNION ALL SELECT word, pat, df, CASE WHEN word IN (SELECT word FROM rare) THEN 'yes' WHEN word IN (SELECT word FROM common) THEN 'no (common word)' ELSE 'no' END FROM df;
SELECT 'named in prompt: ' || path FROM named;
SELECT 'rare words held: ' || k || ' ' || path || CASE WHEN k >= 2 THEN '' ELSE '  (needs 2)' END FROM hits ORDER BY k DESC LIMIT 15;
SELECT 'already shown: ' || path FROM shown;
EXPLAIN
fi )
SELECT CASE WHEN '$3' <> '' THEN 'would attach: ' ELSE '' END || r.path, p.name, replace(p.lead, char(10), ' ')
FROM (SELECT path, min(ord) AS ord, min(score) AS score FROM ranked GROUP BY path) r JOIN pages p ON p.path = r.path
WHERE r.path NOT IN (SELECT path FROM shown) ORDER BY r.ord, r.score LIMIT 3;
SQL
}
# --- hooks -----------------------------------------------------------------------
# Claude Code sends each hook a JSON object on stdin; plutil (built into the Mac) reads its fields.
# What a hook prints for a prompt is added to the agent's context. Every hook prints nothing on any failure.
hook_in() { HOOK_IN=$(cat); }
hook_field() { printf '%s' "$HOOK_IN" | plutil -extract "$1" raw -o - - 2>/dev/null; }
session_file() { local s; s=$(hook_field session_id | tr -cd 'A-Za-z0-9-'); echo "$(cache_dir)/shown/${s:-none}"; }

# --- packages ---------------------------------------------------------------------------
# A package adds to Cosm: a folder with a cosm.json, built in ($COSM_BUILTIN/<id>/) or the cosm's own
# (.cosm/packages/<id>/; a copy of a built-in one replaces it). Which are on: .cosm/packages.json. core/lib/pkg.pl reads
# them; this runs them.
PKG() { perl "$(dirname "$COSM_LIB")/pkg.pl" "$@"; }
pkg_rows() { PKG list; }                                   # id dir builtin on name description
pkg_dir() { pkg_rows | awk -F'\t' -v i="$1" '$1 == i { print $2; exit }'; }
pkg_name() { pkg_rows | awk -F'\t' -v i="$1" '$1 == i { print $5; exit }'; }
pkg_on() { pkg_rows | awk -F'\t' -v i="$1" '$1 == i && $4 == 1 { f = 1 } END { exit !f }'; }
pkg_list() { # what `cosm package list` shows: id, on or off, built in or the cosm's own, name — what it does
  pkg_rows | awk -F'\t' '{ printf "%s\t%s\t%s\t%s — %s\n", $1, ($4 ? "on" : "off"), ($3 ? "built in" : "this cosm"), $5, $6 }'; }
pkg_set() { # $1 id, $2 on|off
  case "$2" in on|off) ;; *) echo "FAIL: cosm package on <id> or cosm package off <id>"; return ;; esac
  local d; d=$(pkg_dir "$1")
  [ -n "$d" ] || { echo "FAIL: no package called $1 (a package is a folder .cosm/packages/$1/ with a cosm.json)"; return; }
  PKG get "$d" name >/dev/null 2>&1 || { echo "FAIL: $d/cosm.json is not valid JSON"; return; }
  PKG state "$1" "$2" && echo "OK: $(pkg_name "$1") is $2"
  # Switched on, it starts now (its "open" moment), as from Settings; nothing waits for it.
  [ "$2" = on ] && PKG runs-at "$d" open && ( COSM_FROM_APP=1 pkg_run "$1" open >/dev/null 2>&1 & ); return 0; }
# Runs one package's script for a moment (open, close, every, session-start, session-end, prompt, page-read,
# tool-failed, action, data), in the cosm's folder: no terminal, at most five minutes, one run of a package at a time.
# What it prints goes to stdout (the agent's moments use it); a failure becomes a problem notice.
pkg_run() {
  local id="$1" ev="$2" dir run name lock err rc why
  dir=$(pkg_dir "$id"); [ -n "$dir" ] || { echo "FAIL: no package called $id"; return; }
  name=$(pkg_name "$id")
  # The window runs only packages that are on (it asks for data and actions only of those; this makes sure). By hand,
  # `cosm package run` tries one that is still off, before it is switched on.
  [ -n "$COSM_FROM_APP" ] && ! pkg_on "$id" && { echo "FAIL: $name is off"; return; }
  run=$(PKG script "$dir" "$ev" "${COSM_ACTION:-}")
  case "$run" in ''|/*|*..*) [ "$ev" = action ] || [ "$ev" = data ] && cosm_notice problem "$name: its cosm.json names no script to run" "$name"; return ;; esac
  [ -f "$dir/$run" ] || { cosm_notice problem "$name: $run is missing" "$name"; return; }
  # One run of a background moment at a time: a sync still going is not started again. The agent's moments wait for
  # nothing: they are quick, and run once per message.
  # (A lock the system lets go of when the run ends, however it ends.)
  case "$ev" in open|close|every|session-end|action) lock="$(cache_dir)/run-$id" ;; esac
  err=$(mktemp -t cosm-package)
  # `cosm` itself is on the script's PATH, however the engine was reached.
  ( export PATH="$(cd "$(dirname "$COSM_LIB")/../bin" && pwd):$PATH"
    export COSM_EVENT="$ev" COSM_PACKAGE="$id" COSM_PACKAGE_NAME="$name" COSM_PACKAGE_DIR="$(cd "$dir" && pwd)" COSM_ROOT="$PWD" GIT_TERMINAL_PROMPT=0
    eval "$(PKG vars "$dir")"
    set -- "$dir/$run"; [ -x "$dir/$run" ] || set -- /bin/bash "$dir/$run"
    [ -n "$lock" ] && set -- /usr/bin/lockf -t 0 "$lock" "$@"
    # The script and everything it starts run as one group, stopped together after five minutes (exit 142).
    exec perl -e 'my $t = shift; my $pid = fork // die "cannot run\n";
      if (!$pid) { setpgrp(0, 0); exec @ARGV or die "cannot run $ARGV[0]\n" }
      local $SIG{ALRM} = sub { kill "TERM", -$pid; sleep 2; kill "KILL", -$pid; exit 142 };
      alarm $t; waitpid $pid, 0; exit($? & 127 ? 128 + ($? & 127) : $? >> 8)' "${COSM_RUN_LIMIT:-300}" "$@" ) 2> "$err" < /dev/null
  rc=$?
  # lockf could not take the lock (it says so): a run of this package is still going; this one is left out quietly.
  [ -n "$lock" ] && [ "$rc" = 75 ] && grep -q "already locked" "$err" && { rm -f "$err"; return; }
  if [ "$rc" != 0 ]; then
    why=$(grep -v '^[[:space:]]*$' "$err" | tail -1 | cut -c1-200)
    [ "$rc" = 142 ] && why="it ran for $(( ${COSM_RUN_LIMIT:-300} / 60 )) minutes and was stopped"; [ "$rc" = 142 ] && [ "${COSM_RUN_LIMIT:-300}" -lt 60 ] && why="it ran too long and was stopped"
    # Run by hand (the agent trying it), the failure is said here; from the window, it is a problem notice.
    if [ -n "$COSM_FROM_APP" ] || [ "$ev" = session-start ] || [ "$ev" = prompt ] || [ "$ev" = page-read ] || [ "$ev" = tool-failed ]; then
      cosm_notice problem "$name: ${why:-it stopped with an error ($rc)}" "$name"
    else echo "FAIL: $name: ${why:-it stopped with an error ($rc)}"; fi
  fi
  rm -f "$err"
}
# Every package that is on and runs at the moment, in order. The agent's moments (session-start, prompt, page-read,
# tool-failed) run one after another and what they print goes to the agent; the others run side by side (the app
# starts this without waiting for it).
pkg_event() {
  local ev="$1" id dir
  while IFS=$'\t' read -r id dir _ on _; do
    [ "$on" = 1 ] && PKG runs-at "$dir" "$ev" || continue
    case "$ev" in session-start|prompt|page-read|tool-failed) pkg_run "$id" "$ev" ;; *) pkg_run "$id" "$ev" & ;; esac
  done < <(pkg_rows)
  wait
}
# A lookup the engine doesn't know: each package that is on and has a "cli" is asked in turn; one that doesn't know it
# either exits 64.
pkg_cli() {
  local id dir cli rc
  exec 3<&0   # the caller's input, for the package (the loop reads the list of packages)
  while IFS=$'\t' read -r id dir _ on _; do
    [ "$on" = 1 ] || continue
    cli=$(PKG get "$dir" cli); [ -n "$cli" ] && [ -f "$dir/$cli" ] || continue
    ( export PATH="$(cd "$(dirname "$COSM_LIB")/../bin" && pwd):$PATH" COSM_PACKAGE="$id" COSM_PACKAGE_DIR; COSM_PACKAGE_DIR="$(cd "$dir" && pwd)"; eval "$(PKG vars "$dir")"
      if [ -x "$dir/$cli" ]; then exec "$dir/$cli" "$@"; else exec /bin/bash "$dir/$cli" "$@"; fi ) <&3; rc=$?
    [ "$rc" = 64 ] || { exec 3<&-; return 0; }
  done < <(pkg_rows)
  exec 3<&-
  echo "No lookup called $1. The engine's: rename, trash, search, search-logs, find, index-sync, package, notify, problem; each package that is on adds its own (cosm package list)."
}
cosm_notice() { # $1 notice or problem, $2 the text, $3 who it is from: a line in .cosm/notices, which the window shows
  [ -n "$2" ] || { echo "FAIL: cosm $1 \"what to say\""; return; }
  mkdir -p .cosm
  perl -e 'use JSON::PP; print JSON::PP->new->canonical->encode({kind => $ARGV[0], text => $ARGV[1], from => $ARGV[2], time => time}), "\n"' "$1" "$2" "${3:-${COSM_PACKAGE_NAME:-}}" >> .cosm/notices
}

# --- the agent's moments (the Claude Code adapter's hooks call `cosm hook <moment>`) -------------------------
# Each hook gives JSON on stdin; the engine turns it into plain variables for the packages, so a package's script needs
# no agent's format: COSM_SESSION, COSM_SOURCE (startup, resume, compact, clear), COSM_PROMPT_FILE (the message),
# COSM_PAGE (a page just read), COSM_TOOL and COSM_ERROR_FILE (a failed tool), COSM_SHOWN (a file of what this session
# was already shown: one line per thing, for packages that attach something once per session), COSM_TURN (a folder the
# packages answering this moment share, in order).
hook() {
  local ev="$1" tmp out; hook_in; tmp=$(mktemp -d -t cosm-turn)
  export COSM_SESSION; COSM_SESSION=$(hook_field session_id | tr -cd 'A-Za-z0-9-')
  export COSM_SHOWN COSM_TURN="$tmp"; COSM_SHOWN=$(session_file); touch "$COSM_SHOWN"
  case "$ev" in
    session-start)
      export COSM_SOURCE; COSM_SOURCE=$(hook_field source)
      # A compacted chat forgot what it was shown: it may be shown again.
      [ "$COSM_SOURCE" = compact ] && : > "$COSM_SHOWN"
      find "$(cache_dir)/shown" -type f -mtime +7 -delete 2>/dev/null
      pkg_event session-start; index_sync_bg ;;
    prompt)
      export COSM_PROMPT_FILE="$tmp/prompt.txt"; hook_field prompt > "$COSM_PROMPT_FILE"
      open_page; pkg_event prompt; index_sync_bg ;;
    page-read)
      export COSM_PAGE; COSM_PAGE=$(hook_field tool_input.file_path); COSM_PAGE=${COSM_PAGE#"$PWD"/}
      pkg_event page-read >/dev/null ;;
    tool-failed)
      export COSM_TOOL COSM_ERROR_FILE="$tmp/error.txt"; COSM_TOOL=$(hook_field tool_name); hook_field error > "$COSM_ERROR_FILE"
      out=$(pkg_event tool-failed)
      # Claude Code takes context after a failed tool as JSON.
      [ -n "$out" ] && printf '%s' "$out" | perl -e 'use JSON::PP; local $/; my $t = <STDIN>; print JSON::PP->new->encode({hookSpecificOutput => {hookEventName => "PostToolUseFailure", additionalContext => $t}}), "\n"' ;;
  esac
  rm -rf "$tmp"
}
