#!/usr/bin/perl
# Packages, for the engine's `cosm` command: which there are, which are on, and what their cosm.json says.
# A package is a folder with a cosm.json: the app's built-in ones ($COSM_BUILTIN/<id>/) and the cosm's own
# (.cosm/packages/<id>/, run from the cosm's folder). A cosm's own package with the id of a built-in one replaces it
# (the user's copy). Which are on: .cosm/packages.json, {"<id>": true|false}; a package not named there is on when it
# is built in (unless its cosm.json says "default": "off") and off when it is the cosm's own.
#
#   pkg.pl list                      id, folder, built-in (1/0), on (1/0), name, description; tab-separated, in order
#   pkg.pl get <folder> <key>        a value of its cosm.json (a.b for nested): text as is, a list one item per line,
#                                    an object as JSON; nothing when absent
#   pkg.pl state <id> on|off         switch it (on or off for this cosm)
#   pkg.pl vars <folder>             its options (OPTION_<NAME>) and secrets as shell lines to evaluate
#   pkg.pl runs-at <folder> <moment> exit 0 when its "when" names the moment ("every 10" is the moment "every")
#   pkg.pl script <folder> <moment> [action]   the script to run: an action's own "run", else the package's
use strict; use warnings; use utf8;
use JSON::PP;
use Encode qw(encode_utf8 decode_utf8);
# Folder names and paths stay as the bytes the file system gave; text from cosm.json is encoded as UTF-8 on output.
my $J = JSON::PP->new->utf8->canonical;

sub slurp { my $f = shift; open my $h, "<", $f or return undef; local $/; my $t = <$h>; close $h; $t }
sub manifest { my $d = shift; my $t = slurp("$d/cosm.json") // return undef; my $m = eval { $J->decode($t) }; ref $m eq "HASH" ? $m : undef }
sub state { my $t = slurp(".cosm/packages.json") // return {}; my $s = eval { $J->decode($t) }; ref $s eq "HASH" ? $s : {} }
sub ids_in { my $d = shift; opendir my $h, $d or return (); my @i = grep { !/^\./ && -f "$d/$_/cosm.json" } readdir $h; closedir $h; sort @i }

sub order_of { my $o = shift->{order}; defined $o && !ref $o && $o =~ /^\s*-?\d+(\.\d+)?\s*$/ ? int $o : undef }

sub all {
  my $state = state();
  my (%pkg, @order);
  my $base = $ENV{COSM_BUILTIN} // "";
  for my $id ($base ? ids_in($base) : ()) {
    my $m = manifest("$base/$id") // {};
    $pkg{$id} = { id => $id, dir => "$base/$id", builtin => 1, m => $m, order => order_of($m) // 50 };
  }
  for my $id (ids_in(".cosm/packages")) {
    my $m = manifest(".cosm/packages/$id");
    # Its own "order"; else a copy keeps the built-in one's place, and a package of the cosm's own comes last.
    my $order = order_of($m // {}) // ($pkg{$id} ? $pkg{$id}{order} : 1000);
    # The cosm's own copy of a built-in package takes its place; a cosm.json that can't be read still shows, as broken.
    $pkg{$id} = { id => $id, dir => ".cosm/packages/$id", builtin => 0, copy => $pkg{$id} ? 1 : 0, m => $m // {}, broken => defined $m ? 0 : 1, order => $order };
  }
  for my $p (values %pkg) {
    # Only true or false count; anything else in packages.json is as if it weren't there (as the app reads it).
    my $v = $state->{decode_utf8($p->{id})};
    my $explicit = JSON::PP::is_bool($v) ? $v : undef;
    my $default = ($p->{builtin} || $p->{copy}) && (($p->{m}{default} // "on") ne "off");
    $p->{on} = defined $explicit ? ($explicit ? 1 : 0) : ($default ? 1 : 0);
    $p->{on} = 0 if $p->{broken};
  }
  sort { $a->{order} <=> $b->{order} || $a->{id} cmp $b->{id} } values %pkg;
}

sub value {
  my ($m, $key) = @_;
  my $v = $m;
  for my $k (split /\./, $key) { return undef unless ref $v eq "HASH" && exists $v->{$k}; $v = $v->{$k} }
  $v;
}
sub show {
  my $v = shift; return unless defined $v;
  if (ref $v eq "ARRAY") { print(encode_utf8(ref $_ ? JSON::PP->new->canonical->encode($_) : $_), "\n") for @$v }
  elsif (ref $v eq "HASH") { print encode_utf8(JSON::PP->new->canonical->encode($v)), "\n" }
  elsif (JSON::PP::is_bool($v)) { print(($v ? "true" : "false"), "\n") }
  else { print encode_utf8("$v"), "\n" }
}
sub sq { my $v = shift; $v =~ s/'/'\\''/g; "'$v'" }

my $cmd = shift // "";
if ($cmd eq "list") {
  for my $p (all()) {
    my $line = join "\t", $p->{id}, $p->{dir}, $p->{builtin}, $p->{on}, encode_utf8($p->{m}{name} // decode_utf8($p->{id})), encode_utf8($p->{m}{description} // "");
    $line =~ s/\n/ /g; print "$line\n";
  }
} elsif ($cmd eq "get") {
  my ($dir, $key) = @ARGV; my $m = manifest($dir) // exit 1;
  show(value($m, $key));
} elsif ($cmd eq "state") {
  my ($id, $to) = @ARGV;
  my $s = state(); $s->{decode_utf8($id)} = $to eq "on" ? JSON::PP::true : JSON::PP::false;
  mkdir ".cosm"; open my $h, ">", ".cosm/packages.json.tmp" or die "cannot write .cosm/packages.json\n";
  print $h $J->pretty->encode($s); close $h; rename ".cosm/packages.json.tmp", ".cosm/packages.json";
} elsif ($cmd eq "vars") {
  my $m = manifest(shift) // exit 0;
  my $o = $m->{options} // {};
  for my $k (sort keys %$o) {
    (my $n = uc $k) =~ s/[^A-Z0-9]/_/g;
    my $v = $o->{$k}; $v = ref $v && !JSON::PP::is_bool($v) ? JSON::PP->new->canonical->encode($v) : JSON::PP::is_bool($v) ? ($v ? "true" : "false") : $v // "";
    print "export OPTION_$n=" . sq(encode_utf8($v)) . "\n";
  }
  my %want = map { ((ref $_ ? $_->{name} : $_) // "") => 1 } @{$m->{secrets} // []};
  if (%want && $ENV{COSM_SECRETS} && open my $s, "<", $ENV{COSM_SECRETS}) {
    while (<$s>) { chomp; my ($k, $v) = split /=/, $_, 2; print "export $k=" . sq($v) . "\n" if defined $v && $want{$k} && $k =~ /^[A-Za-z_][A-Za-z0-9_]*$/ }
  }
} elsif ($cmd eq "runs-at") {
  my ($dir, $moment) = @ARGV; my $m = manifest($dir) // exit 1;
  my $w = $m->{when} // []; $w = [$w] unless ref $w;
  exit((grep { (my $x = $_) =~ s/\s+\d+.*$//; $x eq $moment } @$w) ? 0 : 1);
} elsif ($cmd eq "script") {
  my ($dir, $moment, $action) = @ARGV; my $m = manifest($dir) // exit 1;
  my $r = $m->{run} // "";
  my $want = decode_utf8($action // "");
  if ($moment eq "action") { for my $a (@{$m->{actions} // []}) { $r = $a->{run} // $r if ($a->{title} // "") eq $want } }
  print encode_utf8($r), "\n" if $r ne "";
} else {
  print STDERR "pkg.pl list | get | state | vars | runs-at | script\n"; exit 2;
}
