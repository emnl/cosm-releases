# The Claude Code adapter

How the app hands the engine and the packages that are on to Claude Code, which runs unmodified (src-tauri/src/packages.rs, `agent_share`):

- Each time a session starts, the app puts together, per cosm, in its data folder (`agent/<cosm id>/`): one Claude Code
  plugin called `cosm` (`plugin.json`, `hooks.json`, a link to the engine's `bin/`, and links to the engine's skills and
  every package's skills and commands, so commands answer to `/cosm:<name>`), a plugin per package that brings its own
  Claude Code hooks, `rules.md` (the engine's rules, then each package's), and `settings.json` (this folder's settings
  with each package's additions, and the theme for Claude Code's own screen).
- `claude --plugin-dir <plugin> --append-system-prompt-file <rules> --settings <settings>`, in the cosm's folder, with
  `bin/` on the PATH (the agent runs `cosm search …`), `COSM_OPEN_PAGE` naming the file where the app writes the open
  page, `COSM_SECRETS` the cosm's secrets file, and the secrets packages give the agent.
- `hooks.json`: every Claude Code hook calls `cosm hook <moment>` (session-start, prompt, page-read, tool-failed); the
  engine turns the hook's JSON into plain variables and runs the packages at that moment, so packages need no agent's
  format. Context after a failed tool goes back as Claude Code's JSON.
- `settings.json` holds the intents of Cosm's settings in Claude Code's terms: concise answers, Claude's own memory
  off, the commands Cosm runs allowed, sending or deleting mail denied.
- `themes/`: Cosm light and Cosm dark for Claude Code's own screen, used when no theme package brings its own.
- The chat runs Claude Code's streaming mode with `--permission-prompt-tool stdio`; `src/agents.ts` translates it into
  Cosm's own chat protocol, which the chat draws (the same protocol another agent's package speaks itself).
