// Claude Code as the agent, a connector (agent:agents). Its adapter (bin/claude-agent, a program) wraps the unmodified
// Claude Code: its streaming mode as ACP for the chat (each conversation's a process of this package, which Agent
// session speaks with), and Claude Code as it runs in a terminal. Each is started with what every agent gets (Cosm's agent points, read with
// the agent package's share) put in Claude Code's shape here: the run's folder and its MCP file. Claude Code's own hooks
// tell the agent's moments (`cosm claude:hook --run <conversation>`), passed up to Agent session for that conversation.
// This registers it, its settings and its Settings rows.
import type { Cosm } from "cosm";
import type { Server, Share } from "package:agent";
import { homedir } from "node:os";
import { existsSync } from "node:fs";
import { cp, mkdir, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { shape } from "cosm/shape";

/** The programs packages give the agent, as a folder of small scripts by their names, each running its program with
 * its package's variables: the folder its adapter puts first on the agent's PATH (COSM_PROGRAMS_DIR). */
async function programsDir(dir: string, programs: Share["programs"]): Promise<string> {
  const q = (s: string) => `'${s.replaceAll("'", `'\\''`)}'`;
  await rm(dir, { recursive: true, force: true });
  await mkdir(dir, { recursive: true });
  for (const p of programs) {
    const vars = Object.entries(p.env).map(([k, v]) => q(`${k}=${v}`)).join(" ");
    await writeFile(`${dir}/${p.name}`, `#!/bin/sh\nexec env ${vars} ${q(p.program)} "$@"\n`, { mode: 0o755 });
  }
  return dir;
}

/** What another package gives Claude Code alone (its point `claude:config`): permission rules and hooks in Claude Code's
 * own terms; and, from a theme (`agents.claude`, checked as `{theme}`), Claude Code's own colour theme. */
const CONFIG = {
  "type": "object",
  "additionalProperties": false,
  "properties": {
    "allow": {
      "description": "Claude Code permission rules the agent runs without asking, as \"Bash(cosm recipes:*)\".",
      "$ref": "#/$defs/rules"
    },
    "ask": {
      "description": "Claude Code permission rules the agent asks the user about first.",
      "$ref": "#/$defs/rules"
    },
    "deny": {
      "description": "Claude Code permission rules the agent may never use.",
      "$ref": "#/$defs/rules"
    },
    "hooks": {
      "description": "Claude Code's own hooks, in its hooks.json shape: event name \u2192 a list of {matcher?, hooks: [{type, command}]}. ${CLAUDE_PLUGIN_ROOT}/package is the package's folder.",
      "type": "object",
      "additionalProperties": {
        "type": "array",
        "items": {
          "type": "object",
          "required": [
            "hooks"
          ],
          "properties": {
            "matcher": {
              "type": "string"
            },
            "hooks": {
              "type": "array",
              "items": {
                "type": "object",
                "required": [
                  "type"
                ],
                "properties": {
                  "type": {
                    "type": "string"
                  },
                  "command": {
                    "type": "string"
                  }
                }
              }
            }
          }
        }
      }
    },
    "theme": {
      "description": "A theme's own for Claude Code's screen: its name, the preset it starts from and the colours it changes.",
      "type": "object",
      "required": [
        "name",
        "base",
        "overrides"
      ],
      "additionalProperties": false,
      "properties": {
        "name": {
          "type": "string",
          "minLength": 1
        },
        "base": {
          "enum": [
            "light",
            "dark"
          ]
        },
        "overrides": {
          "type": "object",
          "additionalProperties": {
            "type": "string"
          }
        }
      }
    }
  },
  "$defs": {
    "rules": {
      "type": "array",
      "items": {
        "type": "string",
        "minLength": 1
      }
    }
  }
};

/** The MCP servers in an agent's own config file (`{ mcpServers: { name: { command, args, env } | { url | httpUrl, headers } } }`,
 * as Claude Code's .mcp.json and ~/.claude.json and Gemini CLI's settings.json write them), as the agent package's
 * `Server`s. */
function serversIn(o: unknown): Server[] {
  const all = (o as { mcpServers?: Record<string, { command?: string; args?: string[]; env?: Record<string, string>; url?: string; httpUrl?: string; headers?: Record<string, string> }> } | null)?.mcpServers ?? {};
  return Object.entries(all).flatMap(([name, s]): Server[] => s.url || s.httpUrl ? [{ name, url: (s.url ?? s.httpUrl)!, headers: s.headers ?? {} }]
    : s.command ? [{ name, program: s.command, args: s.args ?? [], env: s.env ?? {} }] : []);
}
const readJson = (f: string) => readFile(f, "utf8").then((t) => JSON.parse(t) as unknown, () => null);

export default function (cosm: Cosm) {
  cosm.package.uses("agent");
  cosm.package.uses("agent-session");
  cosm.point.define("config", {
    description: "What a package gives Claude Code alone: permission rules (allow, ask, deny: \"Bash(cosm recipes:*)\") and hooks in Claude Code's own hooks.json shape (${CLAUDE_PLUGIN_ROOT}/package is the package's folder). Read as each session starts.",
    holds: "values",
    shape: CONFIG,
  });
  const adapter = `${cosm.package.folders.package}/bin/claude-agent`;
  /** One use of the adapter: what it printed, as JSON lines. Its context as Cosm gives its programs. */
  async function run(mode: string, input: unknown = {}): Promise<unknown[]> {
    const p = Bun.spawn([adapter, mode], {
      cwd: cosm.package.folders.cosm, stdin: new TextEncoder().encode(JSON.stringify(input)), stdout: "pipe", stderr: "pipe", signal: cosm.signal,
      env: { ...process.env, COSM_PACKAGE: cosm.package.name, COSM_PACKAGE_DIR: cosm.package.folders.package, COSM_DATA_DIR: cosm.package.folders.data,
        COSM_SETTING_OWN_SIGNIN: String((await cosm.setting.get("own-signin")) === true) },
    });
    const [out, err, code] = await Promise.all([new Response(p.stdout).text(), new Response(p.stderr).text(), p.exited]);
    if (code !== 0) throw new Error(err.trim().split("\n").pop() || `claude-agent ${mode} stopped (${code})`);
    return out.split("\n").filter((l) => l.trim()).map((l) => JSON.parse(l));
  }

  /** This cosm's own Claude Code setup (.claude/, .mcp.json: hooks, MCP servers, settings Claude Code loads) and whether
   * it is used on this computer: asked once, the first time a session starts with it there (`ask`), the answer kept in
   * this computer's cache for the cosm. A cosm that had none when first looked at here uses what is added later. */
  const OWN = [".claude", ".mcp.json"];
  const answer = () => `${cosm.package.folders.cache}/own-setup.json`;
  const keep = (use: boolean) => writeFile(answer(), JSON.stringify({ use }));
  async function ownSetup(ask: boolean): Promise<{ files: string[]; use: boolean | null }> {
    const files = OWN.filter((f) => existsSync(`${cosm.package.folders.cosm}/${f}`));
    const kept = await readFile(answer(), "utf8").then((t) => JSON.parse(t).use === true, () => null);
    if (kept !== null) return { files, use: kept };
    if (!files.length) { await keep(true); return { files, use: true }; }
    if (!ask) return { files, use: null };
    const r = await cosm.ui.ask(`This cosm has its own Claude Code setup (${files.join(", ")}). Use it on this computer?`,
      { description: "Its hooks, MCP servers and settings run as Claude Code loads them. Change it later on Claude Code's page in Settings.", choices: ["Use It", "Leave It Out"] });
    if (r === null) return { files, use: false };
    await keep(r === "Use It");
    return { files, use: r === "Use It" };
  }

  /** What every agent gets, in Claude Code's shape, for one conversation's run: a folder of its own (rules.md, skills/
   * linked, commands/ copied as <name>.md, mcp.json in Claude Code's --mcp-config form, steps.json: how each of Cosm's
   * tools reads as a step in the chat), and the variables the adapter reads. */
  async function prepare(session: string): Promise<Record<string, string>> {
    const b = await cosm.call<Share>("agent:share");
    const dir = `${cosm.package.folders.cache}/runs/${session}`;
    await rm(dir, { recursive: true, force: true });
    await mkdir(`${dir}/skills`, { recursive: true });
    await mkdir(`${dir}/commands`, { recursive: true });
    await writeFile(`${dir}/rules.md`, b.instructions.map((i) => i.text.trim()).filter(Boolean).join("\n\n") + "\n");
    // One that can't be taken (gone since) is left out rather than stopping the agent.
    for (const s of b.skills) await symlink(s.path, `${dir}/skills/${s.name}`).catch(() => {});
    for (const c of b.prompts) await cp(c.path, `${dir}/commands/${c.name}.md`, { recursive: true }).catch(() => {});
    const servers = Object.fromEntries(b.mcp.map((s) => [s.name, "url" in s ? { type: "http", url: s.url, headers: s.headers } : { command: s.program, args: s.args, env: s.env }]));
    await writeFile(`${dir}/mcp.json`, JSON.stringify({ mcpServers: servers }, null, 2));
    await writeFile(`${dir}/steps.json`, JSON.stringify(b.tools.filter((t) => t.step).map(({ command, step, inputs }) => ({ command, step, inputs }))));
    return { ...b.secrets, COSM_SHARE_DIR: dir, COSM_MCP_FILE: `${dir}/mcp.json`, COSM_STEPS_FILE: `${dir}/steps.json`,
      COSM_PROGRAMS_DIR: await programsDir(`${dir}/bin`, b.programs),
      COSM_OWN_SETUP: (await ownSetup(true)).use ? "1" : "0" };
  }
  const me = cosm.package.name;
  /** Which of a conversation's processes runs now: its chat (`chat-<session>`) or its terminal (`terminal-<session>`). */
  async function running({ session }: { session: string }) {
    const live = new Set((await cosm.process.list({ package: me })).filter((p) => p.running).map((p) => p.name));
    for (const as of ["chat", "terminal"] as const) if (live.has(`${me}:${as}-${session}`)) return { as, process: `${me}:${as}-${session}` };
    return null;
  }

  cosm.point.add("agent:agents", {
    name: "claude",
    label: "Claude Code",
    prompt: "/cosm:{name}",
    hooks: true,
    // Claude Code's own MCP servers, as `claude mcp list` has them: this cosm's .mcp.json (when its own setup is used
    // here), and the user's and this folder's in ~/.claude.json.
    servers: async () => {
      const home = await readJson(`${process.env.CLAUDE_CONFIG_DIR ?? homedir()}/.claude.json`) as { mcpServers?: unknown; projects?: Record<string, unknown> } | null;
      const own = (await ownSetup(false)).use === true ? serversIn(await readJson(`${cosm.package.folders.cosm}/.mcp.json`)) : [];
      const all = [...own, ...serversIn(home?.projects?.[cosm.package.folders.cosm] ?? null), ...serversIn(home)];
      return all.filter((s, i) => all.findIndex((x) => x.name === s.name) === i);
    },
    // One Claude Code for a conversation at a time: the chat's or the terminal's. Starting one stops the other, which
    // carries the conversation on from Claude Code's own record of it.
    start: async ({ session, as, resume, first }) => {
      const now = await running({ session });
      if (as === "terminal") {
        if (now?.as === "terminal") return { process: `${me}:terminal-${session}` };
        await cosm.process.stop(`chat-${session}`).catch(() => {});
        // In a terminal it starts on Claude Code's own id for the session: the one carried on, else a new one, said.
        const id = resume ?? crypto.randomUUID();
        await cosm.process.start(`terminal-${session}`, { program: "bin/claude-agent", args: ["terminal"], as: "terminal",
          env: { ...(await prepare(session)), COSM_CLAUDE_SESSION: id, ...(resume ? { COSM_RESUME: "1" } : {}), ...(first ? { COSM_FIRST_MESSAGE: first } : {}) } });
        return { process: `${me}:terminal-${session}`, ...(resume ? {} : { agentSession: id }) };
      }
      await cosm.process.stop(`terminal-${session}`).catch(() => {});
      if (now?.as !== "chat") await cosm.process.start(`chat-${session}`, { program: "bin/claude-agent", args: ["chat"], env: await prepare(session) });
      // Its MCP servers are in its MCP file (the adapter gives Claude Code them); none go by ACP.
      return { process: `${me}:chat-${session}` };
    },
    running,
    // The run ends, chat or terminal, and its folder goes with it.
    stop: async ({ session }) => {
      for (const p of [`chat-${session}`, `terminal-${session}`]) await cosm.process.stop(p).catch(() => {});
      await rm(`${cosm.package.folders.cache}/runs/${session}`, { recursive: true, force: true });
    },
    // What each session is (by Claude Code's own id): whether it began, its title, how full, its transcript, what the
    // user said, the commands run.
    sessions: async ({ sessions }) => (await run("sessions", { sessions })) as ({ id: string } & Record<string, unknown>)[],
  });
  // Claude Code's hooks (the adapter writes each conversation's hooks.json to run `cosm claude:hook --run <conversation>`,
  // with Claude's note on stdin): each one of the agent's moments, passed up to Agent session (`agent-session:hook`)
  // for the conversation named, with its data in Cosm's terms, and what the moment's contributions said back in
  // Claude's form. Claude Code's own id for the session comes with every note: at each start (new, resumed, after
  // /clear or /compact) it is told to Agent session (`agent-session:agent-id`), which keeps it to carry the
  // conversation on.
  const EVENTS: Record<string, string> = { SessionStart: "started", UserPromptSubmit: "message.sent", PostToolUse: "file.read",
    PreToolUse: "step.before", PostToolUseFailure: "step.failed", Stop: "turn.ended" };
  cosm.point.add("cosm:commands", { name: "hook",
    description: "Claude Code's hooks, which Claude Code itself runs: tells the agent's moment they are and answers in Claude Code's form. Not for the agent to call.",
    inputs: [{ name: "note", type: "stdin", description: "The hook's JSON, as Claude Code gives it" },
      { name: "run", type: "text", optional: true, description: "The conversation Claude Code was started for, as its hooks file names it (c-7k2p)" }],
    run: async ({ note, run: session }) => {
      const n = JSON.parse(note) as Record<string, any>;
      const event = EVENTS[String(n.hook_event_name)];
      if (!event) return "";
      const t = (n.tool_input ?? {}) as Record<string, unknown>;
      const files = ["file_path", "path", "notebook_path"].map((k) => t[k]).filter((x): x is string => typeof x === "string" && !!x);
      const uses = { commands: typeof t.command === "string" ? [t.command] : [], paths: files };
      const data: Record<string, unknown> = {};
      if (event === "started") data.reason = n.source;
      if (event === "message.sent") {
        data.text = n.prompt;
        // One of the agent's prompts, as Claude Code is given them (/cosm:<name>): by its name.
        const c = /^\/cosm:(\S+)/.exec(String(n.prompt ?? ""));
        if (c) data.prompt = c[1];
      }
      if (event === "file.read") data.path = t.file_path;
      if (event === "step.before") Object.assign(data, { step: n.tool_name, input: n.tool_input ?? null, uses });
      if (event === "step.failed") Object.assign(data, { step: n.tool_name, input: null, uses, error: n.error ?? "" });
      if (event === "turn.ended") Object.assign(data, { stopped: false, transcript: n.transcript_path ?? "" });
      // A hook of a Claude Code Cosm didn't start (no conversation named): nothing to say.
      if (!session) return "";
      if (event === "started" && n.session_id) await cosm.call("agent-session:agent-id", { session, id: String(n.session_id) });
      const r: { said: string; input?: unknown } = await cosm.call("agent-session:hook", { session, event, data });
      // Before a step: what to add, and the input a package changed, which Claude Code uses in its place (no permission
      // decision goes with it, so a changed step goes through the user's permissions as any other).
      if (event === "step.before") {
        const h: Record<string, unknown> = { hookEventName: "PreToolUse" };
        if (r.said) h.additionalContext = r.said;
        if (r.input && typeof r.input === "object") h.updatedInput = r.input;
        return Object.keys(h).length > 1 ? JSON.stringify({ hookSpecificOutput: h }) : "";
      }
      // After a step failed, Claude Code takes what to add as JSON; at the start and with a message, as plain text (with
      // a chat's message, what Cosm gave with it, apart from the words, comes here too).
      if (event === "step.failed") return r.said ? JSON.stringify({ hookSpecificOutput: { hookEventName: "PostToolUseFailure", additionalContext: r.said } }) : "";
      return event === "started" || event === "message.sent" ? r.said : "";
    },
  });

  cosm.point.add("cosm:settings", { name: "own-signin",
    shape: shape.boolean(),
    default: false,
    label: "A sign-in of this cosm's own",
    description: "Sign in to Claude for this cosm only, so work and private use different accounts. It starts without your other Claude Code settings. Off: the Claude Code you already use.",
  });
  cosm.point.add("cosm:settings", { name: "lookups-as-tools",
    shape: shape.boolean(),
    default: false,
    label: "Offer Cosm's lookups as tools",
    description: "Hands the agent Cosm's lookups (search, and what the packages add) as tools of their own, beside the cosm command it uses in its shell. Off: the agent uses the cosm command alone. From the next session.",
  });

  // Its page in Settings: whether Claude Code is installed and signed in, and the step that would help now (Anthropic's
  // installer, Claude Code's own sign-in), run there in a terminal.
  cosm.point.add("cosm:views", { name: "setup", file: "views/setup.html", label: "Claude Code", location: { in: "settings" } });
  cosm.view.export({
    /** Runs a step of its setup (install, sign in, sign out) in a terminal its page draws: its process's name. */
    setup: { input: shape.object({ step: shape.string() }), run: async ({ step }: { step: string }) => {
      await cosm.process.stop("setup").catch(() => {});
      await cosm.process.start("setup", { program: "bin/claude-agent", args: [step === "sign-in" ? "signin" : step === "sign-out" ? "signout" : step], as: "terminal", cols: 100, rows: 14 });
      return `${cosm.package.name}:setup`;
    } },
    /** How Claude Code stands here: `{ready: true | false | null, line, description?, items}` (`items`: the steps that
     * would help now: install, sign-in, sign-out). */
    status: { changes: { events: ["setting.changed"] }, run: async () => (await run("ready"))[0] },
    /** This cosm's own Claude Code setup: its files and whether it is used here (null: not asked yet). */
    ownSetup: () => ownSetup(false),
    /** Uses this cosm's own Claude Code setup here, or leaves it out. */
    useOwnSetup: async ({ use }: { use: boolean }) => { await keep(use === true); },
  });
}
