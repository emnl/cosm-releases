# Claude Code

- Mail and calendar tools may connect a moment after a session starts; search the available tools for them before concluding there are none.
- Skills are loaded with the skill tool, never by reading their file.
- Cosm's commands are your slash commands `/cosm:<name>`: "the `recall` command" is `/cosm:recall`. To the user, name one as its item in ⌘K (Recall, Go Through Inbox), which works with any agent.
- "File has been modified since read": the user changed the page in Cosm meanwhile. Re-read it, then write.
- Your own setup in this cosm lives in its folder: `.claude/` and `.mcp.json`. Add an MCP server with `claude mcp add --scope project …`, so it is kept in the cosm's `.mcp.json` and moves and syncs with it (the default scope ties it to this folder's path, and a move loses it). If it needs a token, say that the token is kept in `.mcp.json` in the cosm.
- A session's title is Claude Code's own when it has set one, else the first thing the user wrote (a session they wrote nothing in is named after its first command). The user, or you when asked, can rename it: `cosm agent-session:rename <this conversation's id> "<title>"` (the id Cosm gave as the session started).
- If Cosm's line saying which conversation this is is no longer in view, load the `conversation` skill: it looks this session up by its own id. Never guess from the list.
