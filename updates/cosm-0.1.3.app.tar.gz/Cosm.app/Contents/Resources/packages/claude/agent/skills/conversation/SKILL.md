---
name: conversation
description: Which Cosm conversation this session is. Load it when you need this conversation's id (to rename or close it, or to run an item on it) and Cosm's own line saying "This conversation is …" is no longer in view.
---
# This conversation

This Claude Code session's own id is `${CLAUDE_SESSION_ID}`. Cosm's conversation for it:

```
cosm agent-session:which ${CLAUDE_SESSION_ID}
```

It answers the conversation as a thing (`agent-session:session:c-7k2p`); its id is the part after the last
`session:` (`c-7k2p`). Use the id in `cosm agent-session:…` commands about this conversation, and the thing where a
command acts on one (`cosm ui run <item> --thing <thing>`).
