# The Claude Code adapter

How the engine and the packages that are on reach Claude Code, which runs unmodified. As a session starts, this
package's main.ts reads what every agent gets from the agent package's points (its `share`, `cosm.call("agent:share")`: `agent:instructions`,
`/commands`, `/skills`, `/tools`, `/mcp`, `/secrets`) into a folder of the run's own in its cache (`rules.md`, `skills/`,
`commands/`, `mcp.json`, `steps.json`; `$COSM_SHARE_DIR`); this package's program (package-src/claude) turns it into
Claude Code's shape there as it starts:

- One Claude Code
  plugin called `cosm` (`plugin.json`, `hooks.json`, a link to the engine's `bin/`, and links to the engine's skills and
  every package's skills and commands, so commands answer to `/cosm:<name>`), a plugin per package that gives Claude
  Code hooks of its own (`cosm.point.add("claude:config", {name, hooks})` in its main.ts, written as that plugin's
  `hooks/hooks.json`, with `package` a link to the package's folder), `rules.md` (Cosm's instructions, then each
  package's `agent/instructions.md`), and `settings.json` (this folder's settings
  with each package's additions, and the theme for Claude Code's own screen).
- `claude --plugin-dir <plugin> [--mcp-config $COSM_MCP_FILE] --append-system-prompt-file <rules> --settings <settings>`,
  in the cosm's folder, with `bin/` on the PATH (the agent runs `cosm index search …`), and the secrets packages give the
  agent (`agent:secrets`).
  `COSM_MCP_FILE` is Cosm's MCP servers in Claude Code's own format (`cosm mcp` as `cosm`, and
  each package's own server); the cosm server's tools are allowed as `cosm …` commands are.
- `hooks.json`: every Claude Code hook runs `cosm claude:hook --run {conversation}` (the adapter fills in the
  conversation the run is for: its share folder's name, Agent session's id), this package's own command (main.ts),
  which turns Claude's hook JSON into the agent's moments and passes them up to Agent session (`agent-session:hook`,
  for that conversation; at each start Claude Code's own id for the session goes with `agent-session:agent-id`), which has them fired (`agent:started`, `agent:message.sent`, `agent:file.read`, `agent:step.before`,
  `agent:step.failed`, and Stop as `agent:turn.ended`), and the answer back into Claude's terms; the engine gives each package's handler the event's fields as one JSON object, so packages need no agent's format. Context after a failed tool goes back as Claude Code's JSON.
- `settings.json` holds the intents of Cosm's settings in Claude Code's terms: concise answers, Claude's own memory
  off, the commands Cosm runs allowed, sending or deleting mail denied. Each package that is on adds to the permission
  lists with `cosm.point.add("claude:config", {name, allow: […], ask: […], deny: […]})` in its main.ts, read from
  `cosm point read claude:config --json` (as in effect); the point's shape (main.ts, `CONFIG`) says what it takes.
- `steps.json`: how each of Cosm's tools reads as a step in the chat (its `step`), which the program's ACP side shows
  for a `cosm …` command the agent runs; a tool without one reads "Ran <tool>".
- `themes/`: Cosm light and Cosm dark for Claude Code's own screen, used when the chosen theme brings none of its own
  (`"agents": {"claude": {"name", "base", "overrides"}}` in a theme's file, read from `cosm ui theme list --json`).
- The chat runs Claude Code's streaming mode with `--permission-prompt-tool stdio`; the package's program
  (`package-src/claude/src/acp.rs`) translates it into ACP, the Agent Client Protocol Cosm's chat speaks, both ways.
  It starts the unmodified `claude` command: no Agent SDK, no other adapter.
