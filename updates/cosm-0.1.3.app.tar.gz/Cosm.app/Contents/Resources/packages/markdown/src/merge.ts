// Markdown's merge: three versions of a page (the one both started from, the window's, the one now on disk) by lines.
// Changes to different lines are both kept, and so are changes that only touch (an edit and a line added right after
// it); lines both sides added at the same place are both kept, the window's first. Only where both changed the same
// lines is it a clash, and then nothing is merged: Cosm asks the user which to keep.

/** A change from the base: base lines [start, end) replaced by `lines` (an insertion when start == end). */
interface Hunk { start: number; end: number; lines: string[] }
const adds = (h: Hunk) => h.start === h.end;

/** Past this many line pairs to compare, a merge isn't tried (a huge file changed in its middle on both sides). */
const MOST = 4_000_000;

/** What changed from a to b, as hunks over a; null when it is too big to work out. */
function hunks(a: string[], b: string[]): Hunk[] | null {
  // The same at the start and at the end needn't be compared.
  let pre = 0;
  while (pre < a.length && pre < b.length && a[pre] === b[pre]) pre++;
  let suf = 0;
  while (suf < a.length - pre && suf < b.length - pre && a[a.length - 1 - suf] === b[b.length - 1 - suf]) suf++;
  const a2 = a.slice(pre, a.length - suf), b2 = b.slice(pre, b.length - suf);
  const n = a2.length, m = b2.length;
  if (n === 0 && m === 0) return [];
  if (n * m > MOST) return null;
  // Longest common subsequence of the middle, from the end.
  const w = m + 1;
  const t = new Uint32Array((n + 1) * w);
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) {
    t[i * w + j] = a2[i] === b2[j] ? t[(i + 1) * w + j + 1] + 1 : Math.max(t[(i + 1) * w + j], t[i * w + j + 1]);
  }
  const out: Hunk[] = [];
  let i = 0, j = 0, cur: Hunk | null = null;
  while (i < n || j < m) {
    if (i < n && j < m && a2[i] === b2[j]) { if (cur) { out.push(cur); cur = null; } i++; j++; continue; }
    cur ??= { start: pre + i, end: pre + i, lines: [] };
    if (j < m && (i >= n || t[i * w + j + 1] >= t[(i + 1) * w + j])) { cur.lines.push(b2[j]); j++; } else { i++; cur.end = pre + i; }
  }
  if (cur) out.push(cur);
  return out;
}

/** Whether two changes are to the same lines. Changes that only touch are not; additions at the same place are kept
 * together (both stay) rather than clashing. */
function overlap(a: Hunk, b: Hunk): boolean {
  if (adds(a) && adds(b)) return a.start === b.start;
  if (adds(a)) return b.start < a.start && a.start < b.end;
  if (adds(b)) return a.start < b.start && b.start < a.end;
  return a.start < b.end && b.start < a.end;
}

/** The merge: the text, or null when both changed the same lines (or it is too big to tell). */
export function merge3(base: string, mine: string, theirs: string): string | null {
  if (mine === base || theirs === mine) return theirs;
  if (theirs === base) return mine;
  const b = base.split("\n");
  const h1 = hunks(b, mine.split("\n")), h2 = hunks(b, theirs.split("\n"));
  if (!h1 || !h2) return null;
  // Every change, the window's first at a place, in order; groups of those that overlap, across both sides.
  const all: [boolean, Hunk][] = [...h1.map((h) => [true, h] as [boolean, Hunk]), ...h2.map((h) => [false, h] as [boolean, Hunk])];
  all.sort((x, y) => x[1].start - y[1].start || x[1].end - y[1].end || Number(!x[0]) - Number(!y[0]));
  const out: string[] = [];
  let at = 0;
  for (let i = 0; i < all.length;) {
    const group = [all[i]];
    let j = i + 1;
    while (j < all.length && group.some(([, g]) => overlap(g, all[j][1]))) { group.push(all[j]); j++; }
    const start = Math.min(...group.map(([, h]) => h.start)), end = Math.max(...group.map(([, h]) => h.end));
    out.push(...b.slice(at, start));
    const side = (m: boolean) => {
      const r: string[] = [];
      let k = start;
      for (const [, h] of group.filter(([x]) => x === m)) { r.push(...b.slice(k, h.start), ...h.lines); k = h.end; }
      return r.concat(b.slice(k, end));
    };
    const hasMine = group.some(([m]) => m), hasTheirs = group.some(([m]) => !m);
    if (hasMine && hasTheirs) {
      const a = side(true), t = side(false), same = a.join("\n") === t.join("\n");
      // Both added lines at the same place: both stay, the window's first (once, when they are the same).
      if (group.every(([, h]) => adds(h))) out.push(...a, ...(same ? [] : t));
      else if (!same) return null;
      else out.push(...a);
    } else out.push(...side(hasMine));
    at = end;
    i = j;
  }
  out.push(...b.slice(at));
  return out.join("\n");
}
