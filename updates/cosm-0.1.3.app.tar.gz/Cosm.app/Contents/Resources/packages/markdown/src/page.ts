// What Markdown knows of a page's text: where its code is (by the same parser family as its editor, remark's), its
// [[links]] outside code, its text without front matter, its lead and its first line.
import { fromMarkdown } from "mdast-util-from-markdown";
import { gfmFromMarkdown } from "mdast-util-gfm";
import { gfm } from "micromark-extension-gfm";

/** What a [[link]] can't carry in a page's name: [ and ] end it, # names a heading, ^ a block. */
export const FORBIDDEN = ["[", "]", "#", "^"];

/** Where a page's code is, as [start, end) offsets: fenced and indented blocks and `inline code`. */
function codeRanges(raw: string): [number, number][] {
  const out: [number, number][] = [];
  const walk = (n: any) => {
    if ((n.type === "code" || n.type === "inlineCode") && n.position) { out.push([n.position.start.offset, n.position.end.offset]); return; }
    for (const c of n.children ?? []) walk(c);
  };
  walk(fromMarkdown(raw, { extensions: [gfm()], mdastExtensions: [gfmFromMarkdown()] }));
  return out;
}

/** Every [[link]] outside code: where it is, the name it links to (its target before | or #, without .md), and the
 * target as written. [[Name]], [[Name|shown]], [[Name#heading]], ![[file.png]], [[Name\|shown]] in a table; front
 * matter too. */
export function linkSpans(raw: string): { at: number; target: string; name: string }[] {
  const code = codeRanges(raw);
  const inCode = (i: number) => code.some(([s, e]) => i >= s && i < e);
  const out: { at: number; target: string; name: string }[] = [];
  for (let i = raw.indexOf("[["); i >= 0; i = raw.indexOf("[[", i + 2)) {
    if (inCode(i)) continue;
    const close = raw.indexOf("]]", i + 2);
    if (close < 0) break;
    const inner = raw.slice(i + 2, close);
    if (inner.includes("\n") || inner.includes("[")) continue;
    const cut = Math.min(...["|", "#"].map((m) => inner.indexOf(m)).filter((x) => x >= 0), inner.length);
    let target = inner.slice(0, cut);
    if (target.endsWith("\\")) target = target.slice(0, -1);
    const name = target.trim().replace(/\.md$/, "");
    if (name) out.push({ at: i + 2, target, name });
  }
  return out;
}

/** The names a page links to, in the order written. */
export const links = (raw: string) => linkSpans(raw).map((l) => l.name);

/** The page with every link to the old name naming the new one, as Obsidian reads them: [[Old]], [[old]],
 * [[some/path/Old]], [[Old.md]]; the link keeps its path, its ending and its alias. Links inside code are left. */
export function renamed(raw: string, oldName: string, newName: string): string {
  const old = oldName.toLowerCase();
  let out = "", from = 0;
  for (const l of linkSpans(raw)) {
    const slash = l.target.lastIndexOf("/");
    const dir = l.target.slice(0, slash + 1), file = l.target.slice(slash + 1);
    const md = file.endsWith(".md") ? ".md" : "";
    if (file.slice(0, file.length - md.length).toLowerCase() !== old) continue;
    out += raw.slice(from, l.at) + dir + newName + md;
    from = l.at + l.target.length;
  }
  return out + raw.slice(from);
}

/** The file's name without its folder and its ending. */
export function stem(p: string): string {
  const b = p.split("/").pop() ?? p;
  return b.endsWith(".md") ? b.slice(0, -3) : b;
}

/** The text after front matter: a first line "---" up to the next line that is "---". */
function stripFront(raw: string): string {
  if (!raw.startsWith("---\n")) return raw;
  const end = raw.slice(4).split("\n");
  let at = 4;
  for (const l of end) {
    if (l.trimEnd() === "---") return raw.slice(at + l.length + 1).replace(/^[\n ]+/, "");
    at += l.length + 1;
  }
  return raw;
}

/** A page's text without front matter, and its lead: the first line under a `# ` title, or the first paragraph of the
 * section `## <section>` when the page has one. */
export function text(raw: string, section?: string): { body: string; lead: string } {
  const body = stripFront(raw.replaceAll("\r\n", "\n"));
  let lead: string | undefined;
  if (section) {
    const lines = body.split("\n");
    const at = lines.findIndex((l) => l.trimEnd() === `## ${section}`);
    if (at >= 0) {
      const after = lines.slice(at + 1);
      const s = after.findIndex((l) => l.trim() !== "");
      const para: string[] = [];
      for (const l of s >= 0 ? after.slice(s) : []) { if (!l.trim() || l.startsWith("## ")) break; para.push(l); }
      lead = para.join("\n");
    }
  }
  if (lead === undefined) {
    const rest = body.startsWith("# ") ? (body.includes("\n") ? body.slice(body.indexOf("\n") + 1) : "") : body;
    lead = rest.replace(/^[\n\r ]+/, "").split("\n")[0] ?? "";
  }
  return { body, lead: lead.trim() };
}

/** A page's first line that says something: a skill's description, else its first plain line under its title, marks
 * dropped, at most 200 characters; "" when it has none. */
export function firstLine(raw: string): string {
  const lines = raw.replaceAll("\r\n", "\n").split("\n");
  let fm = false, found: string | undefined;
  for (const [i, line] of lines.entries()) {
    if (i === 0 && line === "---") { fm = true; continue; }
    if (fm && line === "---") { fm = false; continue; }
    if (fm && line.startsWith("description:")) {
      found = line.slice("description:".length).replace(/^[ \t]+/, "").replace(/^["']/, "").replace(/["']$/, "");
      break;
    }
    if (fm || /^[ \t]*$/.test(line)) continue;
    if (line.startsWith("#") || line.startsWith("*As of") || line.startsWith(">")) continue;
    if (/^[-|][ \t]*$/.test(line)) continue;
    found = line;
    break;
  }
  if (found === undefined) return "";
  const s = found.replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g, "$2").replace(/\[\[([^\]]+)\]\]/g, "$1").replace(/\*\*|__|`/g, "").replace(/^[-*] (\[.\] )?/, "");
  return [...s].slice(0, 200).join("");
}
