// Markdown: what a markdown page is. Its kind (page) and editor (views/page), what search reads of it, its links as
// facts, how two versions of it merge, links kept right when pages move, and names a [[link]] can carry.
import type { Cosm } from "cosm";
import { merge3 } from "./src/merge.ts";
import { FORBIDDEN, firstLine, links, renamed, stem, text } from "./src/page.ts";
import { shape } from "cosm/shape";

export default function (cosm: Cosm) {
  const read = async (p: string) => { try { return await cosm.file.read(p); } catch { return ""; } };

  cosm.point.add("cosm:views", { name: "page", file: "views/page/index.html", input: "file" });
  // ⌘K's "Find a Page": pages by name as the user types (those starting with it first), then pages whose text matches,
  // each with the passage. The palette holds only what packages put there.
  cosm.point.add("cosm:items", { name: "find-page", label: "Find a Page", content: { description: "Pages by name, then by what they say" }, location: { in: "palette" }, find: async ({ query }) => {
    const q = query.trim();
    if (!q) return [];
    const like = q.toLowerCase().replaceAll("'", "''").replace(/[%_]/g, "");
    const named = await cosm.index.query(`SELECT thing, name FROM things WHERE kind = 'markdown:page' AND lower(name) LIKE '%${like}%' ORDER BY (lower(name) LIKE '${like}%') DESC, modified DESC LIMIT 8`).catch(() => []);
    const folder = (p: string) => p.split("/").slice(0, -1).join(" › ") || "Page";
    const rows = named.map((r) => ({ label: String(r["name"]), description: folder(String(r["thing"])), action: { open: String(r["thing"]) } }));
    if (q.length < 3) return rows;
    const seen = new Set(named.map((r) => String(r["thing"])));
    // A passage as it reads: the page's marks dropped, the matched words unmarked.
    const plain = (t: string) => t.replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g, "$2").replace(/\[\[|\]\]/g, "").replace(/\*\*|__|`/g, "")
      .replace(/(^|\s)#{1,6}\s/g, "$1").replace(/(^|\s)[-*] (\[[ x]\] )?/g, "$1").replace(/[\u0002\u0003]/g, "").replace(/\s+/g, " ").trim();
    const hits = await cosm.index.search(q, { kind: "markdown:page", passages: true }).catch(() => []);
    for (const h of hits.filter((x) => !seen.has(x.thing)).slice(0, 8)) rows.push({ label: stem(h.thing), description: plain(h.passage ?? h.lead ?? ""), action: { open: h.thing } });
    return rows;
  } });
  cosm.point.add("cosm:settings", { name: "spellcheck",
    shape: shape.boolean(),
    default: true,
    label: "Spell check",
    description: "Spelling underlined as you write, with suggestions on a right-click. Nothing is corrected for you.",
  });

  cosm.point.add("cosm:kinds", { name: "page", match: "**/*.md", label: "Note", view: "page", merge: ({ base, mine, theirs }) => merge3(base, mine, theirs),
    // What search reads: the text without front matter, the first line under the title as the lead.
    text: ({ things }) => Promise.all(things.map(async (thing) => {
      const t = text(await read(thing));
      return { thing, name: stem(thing), lead: t.lead, text: t.body };
    })),
    // Its [[links]], outside code, as facts.
    facts: async ({ things }) => Object.fromEntries(await Promise.all(things.map(async (t) => [t, { links: links(await read(t)).map((to) => ({ to })) }] as const))),
  });

  // A page's name can't hold a character a [[link]] can't carry.
  const checkName = (e: { path: string; to?: string }) => {
    const name = stem(e.to ?? e.path);
    const bad = FORBIDDEN.filter((c) => name.includes(c));
    if (!bad.length) return undefined;
    const said = bad.length === 1 ? bad[0] : `${bad.slice(0, -1).join(" ")} or ${bad[bad.length - 1]}`;
    return { stop: `A page's name can't hold ${said}: a [[link]] to it would break. Use other characters.` };
  };
  cosm.on("file.moved.before", checkName, { kind: "page" });
  cosm.on("file.created.before", checkName, { kind: "page" });

  // After files moved or were renamed: every [[link]] to an old name names the new one, in every page outside hidden
  // folders. A page is linked by its name ([[Acme deal]]); any other file by its name with its ending ([[scan.png]]).
  cosm.on("file.moved", async (e) => {
    const name = (p: string) => { const b = p.split("/").pop() ?? p; return b.endsWith(".md") ? b.slice(0, -3) : b; };
    const pairs = e.moves.map((m) => [name(m.from), name(m.to)] as const).filter(([o, n]) => o && o !== n);
    if (!pairs.length) return;
    const rename = (text: string) => pairs.reduce((t, [o, n]) => (t.toLowerCase().includes(o.toLowerCase()) ? renamed(t, o, n) : t), text);
    for (const p of await cosm.file.list("**/*.md")) {
      // Only pages that link to an old name are changed, each through Cosm so a page open with typing in it loses nothing.
      const text = await read(p);
      if (rename(text) !== text) await cosm.file.change(p, rename);
    }
  });

  // For other packages and the agent: what a page says first, and what search reads of it.
  cosm.point.add("cosm:commands", { name: "first-line", description: "A page's first line that says something: a skill's description, else the first plain line under its title, marks dropped.",
    inputs: [{ name: "page", label: "The page's path" }], run: async ({ page }) => {
      if ((await cosm.file.stat(page)) === null) throw new Error(`no page ${page}`);
      return firstLine(await read(page));
    } });
  /** First lines of many pages at once: [{path, line}], as first-line gives them. */
  const firstLines = ({ pages }: { pages: string[] }) => Promise.all(pages.map(async (path) => ({ path, line: firstLine(await read(path)) })));
  cosm.point.add("cosm:commands", { name: "first-lines", description: "First lines of many pages at once: [{path, line}], as first-line gives them.",
    inputs: [{ name: "pages", label: "The pages' paths", type: "list" }], run: firstLines });
  /** What search reads of markdown pages: their text without front matter, the lead (the first line under the title,
   * or the first paragraph of `lead-section` when the page has one). */
  const mdText = (a: { things: string[]; "lead-section"?: string }) =>
    Promise.all(a.things.map(async (thing) => { const t = text(await read(thing), a["lead-section"]); return { thing, name: stem(thing), lead: t.lead, text: t.body }; }));
  cosm.point.add("cosm:commands", { name: "md-text", description: "What search reads of markdown pages: [{thing, name, lead, text}]: the text without front matter, the lead the first line under the title, or with lead-section the first paragraph of that section when the page has one (a log's Summary).",
    inputs: [{ name: "lead-section", label: "The section whose first paragraph is the lead", optional: true }, { name: "things", label: "The pages' paths", type: "list" }],
    run: (a) => mdText(a) });
  // Its API for other packages: what search reads of pages (a package indexing pages its own way, Search hints), and
  // pages' first lines (Star chart's rows).
  cosm.package.export({ mdText, firstLines });
  // What its page asks of it: when any package last asked to drop the selection (`deselect`,
  // kept in its storage, so a sleep doesn't lose it: the page drops its selection as it changes), the spell check
  // setting, and which page a [[Name]] means. The page publishes its selection itself.
  cosm.on("*:deselect", () => cosm.storage.set("deselected", Date.now()));
  return cosm.view.export({
    deselected: { description: "When a deselect was last heard: the page drops its selection as it changes.", changes: { storage: "deselected" }, run: async () => (await cosm.storage.get<number>("deselected")) ?? 0 },
    spellcheck: { changes: { events: ["setting.changed"] }, run: async () => (await cosm.setting.get("spellcheck").catch(() => true)) !== false },
    which: { description: "The page a [[Name]] means, nearest to `from` first.", changes: { files: "**" },
      run: ({ name, from }: { name: string; from?: string }) => cosm.file.which(name, { kind: "markdown:page", ...(from ? { from } : {}) }) },
  });
}
