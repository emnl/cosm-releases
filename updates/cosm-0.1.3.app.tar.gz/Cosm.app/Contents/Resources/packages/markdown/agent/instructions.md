# Markdown

Pages are markdown files.

- Pages link each other by name: `[[Anna Berg]]`. Inside pages, links stay `[[Name]]`; in replies, a page is a link to its path (Cosm's rules).
- `cosm file move` fixes every `[[link]]` to a page given a new name; links are by name, so a move to another folder keeps them working.
- A page's links are facts in the index (`links`): `cosm index facts "<page>"` shows what it links to and which pages link to it; `cosm index find links="<name>"` lists every page linking to one. A link inside a code block isn't one.
