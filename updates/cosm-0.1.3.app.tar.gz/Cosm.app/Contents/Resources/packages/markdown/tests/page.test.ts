import { expect, test } from "bun:test";
import { merge3 } from "../src/merge.ts";
import { firstLine, links, renamed, text } from "../src/page.ts";

test("links outside code", () => {
  const page = "---\nowner: [[Anna Berg]]\n---\n# Hiring\nMet [[Erik|E.]] about [[Q4 plan#Budget]] and ![[chart.png]].\n" +
    "Write `[[Not a link]]` like this, or ``a `[[x]]` b``.\n```\n[[In a fence]]\n```\n~~~md\n[[Also fenced]]\n~~~\n" +
    "| a | [[Table link\\|shown]] |\n[[Old.md]] [[]] [[a [[b]]\n";
  expect(links(page)).toEqual(["Anna Berg", "Erik", "Q4 plan", "chart.png", "Table link", "Old", "b"]);
});

test("a renamed page's links", () => {
  const page = "See [[Old]], [[old|it]], [[notes/Old#Top]], [[Old.md]] and [[Older]].\n`[[Old]]` stays.\n";
  expect(renamed(page, "Old", "New")).toBe("See [[New]], [[New|it]], [[notes/New#Top]], [[New.md]] and [[Older]].\n`[[Old]]` stays.\n");
});

test("text and lead", () => {
  expect(text("---\na: 1\n---\n# Title\n\nThe lead line.\nMore.")).toEqual({ body: "# Title\n\nThe lead line.\nMore.", lead: "The lead line." });
  expect(text("# Log\n## Summary\n\nWe met.\nIt went well.\n\n## Notes\nx", "Summary").lead).toBe("We met.\nIt went well.");
});

test("first line", () => {
  expect(firstLine("---\ndescription: \"Does things\"\n---\n# X\n")).toBe("Does things");
  expect(firstLine("# Title\n\n- [ ] **Call** [[Anna Berg|Anna]] about `x`\n")).toBe("Call Anna about x");
});

test("merge", () => {
  expect(merge3("a\nb\nc", "A\nb\nc", "a\nb\nC")).toBe("A\nb\nC");
  expect(merge3("a\nb\nc\nd", "a\nB\nc\nd", "a\nb\nC\nd")).toBe("a\nB\nC\nd");
  expect(merge3("t\n\np1\n\np2\n", "t\n\np1 edited\n\np2\n", "t\n\np1\nnew\n\np2\n")).toBe("t\n\np1 edited\nnew\n\np2\n");
  expect(merge3("a\nb\nc", "a\nc", "a\nb\nC")).toBe("a\nC");
  expect(merge3("a\n", "a\nx\n", "a\ny\n")).toBe("a\nx\ny\n");
  expect(merge3("a\n", "a\nx\n", "a\nx\n")).toBe("a\nx\n");
  expect(merge3("a\nb\nc", "a\nmine\nc", "a\ntheirs\nc")).toBeNull();
  expect(merge3("a\nb\nc\nd", "a\nB C\nd", "a\nb\nnew\nc\nd")).toBeNull();
  const base = Array.from({ length: 20000 }, (_, i) => `line ${i}\n`).join("");
  const t = Date.now();
  const got = merge3(base, base.replace("line 10\n", "line ten\n"), base.replace("line 19990\n", "line nineteen thousand\n"))!;
  expect(got.includes("line ten") && got.includes("line nineteen thousand")).toBe(true);
  expect(Date.now() - t).toBeLessThan(500);
});
