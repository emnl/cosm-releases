// Markdown's page in the window (headless, `cosm/test`): a page shows its file, typing saves it, a change made
// elsewhere arrives and merges with the typing, a clash asks, ⌘F finds.
import { describe, expect, test } from "bun:test";
import { testCosm } from "cosm/test";

const PAGE = "# Acme deal\n\nAnnual licence, 240 seats.\n\n- Send the order form\n- Agree the cap\n";
const page = async () => {
  const c = await testCosm({ files: { "Acme.md": PAGE } });
  const w = await c.window();
  await c.run("ui", "open", "Acme.md");
  await c.run("ui", "wait", "--text", "240 seats", "--view", "markdown:page", "--timeout", "30");
  const ref = /textbox[^\n]*\[ref=([a-z]+\d+)\]/.exec(await c.run("ui", "outline", "markdown:page"))?.[1] ?? "";
  return { c, w, ref };
};

describe("Markdown's page", () => {
  test("shows its file, and what is typed is saved to it", async () => {
    const { c, ref } = await page();
    await using _ = c;
    expect(ref).not.toBe("");
    await c.run("ui", "click", ref);
    await c.run("ui", "type", ref, "Typed here. ");
    await c.until(() => c.read("Acme.md")!.includes("Typed here."), { what: "the typing saved" });
  }, 60000);

  test("a change made elsewhere shows on the open page", async () => {
    const { c } = await page();
    await using _ = c;
    c.write("Acme.md", PAGE + "- Book the signing call\n");
    expect(await c.run("ui", "wait", "--text", "Book the signing call", "--view", "markdown:page")).toContain("OK");
  }, 60000);

  test("typing and a change made elsewhere on another line are merged, both kept", async () => {
    const { c, ref } = await page();
    await using _ = c;
    await c.run("ui", "click", ref);
    await c.run("ui", "type", ref, "Mine. ");
    // The typing is at the end of the last line (where the click put the cursor); the change elsewhere is on another.
    c.write("Acme.md", PAGE.replace("240 seats", "250 seats"));
    await c.until(() => { const t = c.read("Acme.md")!; return t.includes("Mine") && t.includes("250 seats"); }, { seconds: 10, what: "both changes in the file" });
  }, 60000);

  test("⌘F finds on the page and says when nothing matches", async () => {
    const { c, w, ref } = await page();
    await using _ = c;
    await c.run("ui", "click", ref);
    await w.keys("Meta+f");
    const out = await c.run("ui", "outline", "markdown:page");
    const find = /textbox "Find[^\n]*\[ref=([a-z]+\d+)\]/.exec(out)?.[1] ?? /searchbox[^\n]*\[ref=([a-z]+\d+)\]/.exec(out)?.[1];
    expect(find).toBeTruthy();
    await c.run("ui", "type", find!, "seats");
    expect(await c.run("ui", "wait", "--text", "1 of 1", "--view", "markdown:page", "--timeout", "5")).toContain("OK");
  }, 60000);

  test("one line edited: only that line changes in the file", async () => {
    const { c, ref } = await page();
    await using _ = c;
    await c.run("ui", "click", ref);
    await c.run("ui", "type", ref, "x");
    await c.until(() => c.read("Acme.md") !== PAGE, { what: "the edit saved" });
    const was = PAGE.split("\n"), now = c.read("Acme.md")!.split("\n");
    expect(now.length).toBe(was.length);
    expect(now.filter((l, i) => l !== was[i]).length).toBe(1);
  }, 60000);
});
