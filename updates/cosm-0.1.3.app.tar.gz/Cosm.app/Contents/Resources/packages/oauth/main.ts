// OAuth: signing in to outside services for packages. It fills the shared point cosm-points:sign-in; a package asks
// the user's default sign-in for a token, giving the provider's details:
//
//   const signIn = await cosm.point.default("cosm-points:sign-in");
//   const token = await signIn?.token({ provider: "Microsoft", authorize, token, client, scopes: ["Mail.Read"] });
//
// The agent asks the same through its tool, `cosm oauth:token`.
//
// An MCP server that wants a sign-in (the MCP spec's OAuth) needs only its address: `server({ url, label })` finds its
// sign-in server, registers Cosm there (dynamic client registration: nothing set up by the user or by us), and signs
// in the same way. The MCP library does the protocol; this package keeps what it hands over.
//
// The first time, the user is asked; their browser opens the provider's page, and the answer is caught on 127.0.0.1
// (the authorization code flow with PKCE: no client secret). The tokens are kept in this package's storage and renewed
// with the refresh token, with which packages use each; the user can sign out on its Settings page.
import type { Cosm } from "cosm";
import { auth, type OAuthClientProvider } from "@modelcontextprotocol/sdk/client/auth.js";
import type { OAuthClientInformationMixed, OAuthTokens } from "@modelcontextprotocol/sdk/shared/auth.js";

interface Kept { provider: string; client: string; scopes: string[]; access: string; refresh?: string; expires: number; since: string;
  /** The packages that asked for it. */
  users?: string[] }

/** An MCP server's sign-in, by its address: Cosm as registered there, the tokens as the library gave them (both kept
 * unchanged: they carry the sign-in server they belong to), the port its answer comes back to (registered with it). */
interface KeptServer { label: string; client?: OAuthClientInformationMixed; tokens?: OAuthTokens; expires?: number; port?: number; since?: string; users?: string[] }

/** Past this, a sign-in that wasn't finished in the browser is given up. */
const WAIT = 5 * 60_000;

export default function (cosm: Cosm) {
  const all = async () => (await cosm.storage.get<Record<string, Kept>>("tokens")) ?? {};
  const keep = async (key: string, k: Kept | null) => {
    const t = await all();
    if (k) t[key] = k; else delete t[key];
    await cosm.storage.set("tokens", t);
  };

  /** What a sign-in is asked: the provider's details. Who asks is the call's context (`by`), kept with the tokens it uses. */
  type Ask = { provider: string; authorize: string; token: string; client: string; scopes: string[] };
  /** A token for it: the one kept, renewed when it has run out, or after the user signs in. */
  async function tokenFor(a: Ask, by: string): Promise<string> {
    const scopes = [...a.scopes].sort();
    const key = `${a.provider}|${a.client}|${scopes.join(" ")}`;
    // Which packages use it: a package that asks is added (a shell or the window asking by hand isn't one).
    const asker = by && by !== "shell" && by !== "window" && by !== "outside" ? [by] : [];
    const users = (k?: Kept) => [...new Set([...(k?.users ?? []), ...asker])].sort();
    const kept = (await all())[key];
    if (kept && asker.length && !kept.users?.includes(asker[0]!)) await keep(key, { ...kept, users: users(kept) });
    if (kept && kept.expires > Date.now() + 60_000) return kept.access;
    if (kept?.refresh) {
      const got = await exchange(a.token, { grant_type: "refresh_token", refresh_token: kept.refresh, client_id: a.client, scope: scopes.join(" ") }).catch(() => null);
      if (got) { await keep(key, { ...kept, ...tokens(got, kept.refresh), users: users(kept) }); return got.access_token; }
    }
    const yes = await cosm.ui.ask(`Sign in to ${a.provider}?`, {
      description: `A package needs your ${a.provider} account (${scopes.join(", ")}). Your browser opens ${a.provider}'s own page; Cosm never sees your password.`,
      choices: ["Sign in"],
    });
    if (yes !== "Sign in") throw new Error(`not signed in to ${a.provider}: the user cancelled`);
    const got = await signIn(a.authorize, a.token, a.client, scopes);
    await keep(key, { provider: a.provider, client: a.client, scopes, ...tokens(got), since: new Date().toISOString().slice(0, 10), users: users() });
    return got.access_token;
  }
  /** Signs out of a provider: its tokens forgotten. */
  async function signOut({ provider }: { provider: string }): Promise<string> {
    const t = await all();
    const gone = Object.keys(t).filter((k) => t[k].provider.toLowerCase() === provider.toLowerCase());
    const s = await servers();
    const goneServers = Object.keys(s).filter((u) => s[u].label.toLowerCase() === provider.toLowerCase() && s[u].tokens);
    if (!gone.length && !goneServers.length) throw new Error(`not signed in to ${provider}`);
    for (const k of gone) delete t[k];
    await cosm.storage.set("tokens", t);
    // An MCP server's registration stays: only its tokens go, so signing in again needs no new registration.
    for (const u of goneServers) s[u] = { ...s[u], tokens: undefined, expires: undefined, since: undefined };
    if (goneServers.length) await cosm.storage.set("servers", s);
    return `Signed out of ${provider}.`;
  }

  const servers = async () => (await cosm.storage.get<Record<string, KeptServer>>("servers")) ?? {};
  const keepServer = async (url: string, k: KeptServer | null) => {
    const t = await servers();
    if (k) t[url] = k; else delete t[url];
    await cosm.storage.set("servers", t);
  };
  /** A token for an MCP server, by its address: the one kept while it lasts, else renewed, else after the user signs in. */
  async function serverToken({ url, label }: { url: string; label?: string }, by: string): Promise<string> {
    const asker = by && by !== "shell" && by !== "window" && by !== "outside" ? [by] : [];
    let kept: KeptServer = (await servers())[url] ?? { label: label ?? new URL(url).host };
    if (asker.length && !kept.users?.includes(asker[0]!)) { kept = { ...kept, users: [...new Set([...(kept.users ?? []), ...asker])].sort() }; await keepServer(url, kept); }
    if (kept.tokens?.access_token && (kept.expires ?? 0) > Date.now() + 60_000) return kept.tokens.access_token;
    // The answer comes back to 127.0.0.1 on the port Cosm registered with; when that port is taken now, Cosm registers
    // again on another.
    let listener: ReturnType<typeof listen> | null = null;
    try {
      listener = listen(kept.port);
      if (listener.port !== kept.port) { kept = { ...kept, port: listener.port, client: undefined }; await keepServer(url, kept); }
      let verifier = "", to: URL | null = null;
      const state = b64url(crypto.getRandomValues(new Uint8Array(16)));
      const provider: OAuthClientProvider = {
        get redirectUrl() { return `http://127.0.0.1:${listener!.port}/callback`; },
        get clientMetadata() { return { client_name: "Cosm", redirect_uris: [`http://127.0.0.1:${listener!.port}/callback`], grant_types: ["authorization_code", "refresh_token"], response_types: ["code"], token_endpoint_auth_method: "none" }; },
        state: () => state,
        clientInformation: () => kept.client,
        saveClientInformation: async (c) => { kept = { ...kept, client: c }; await keepServer(url, kept); },
        tokens: () => kept.tokens,
        saveTokens: async (t) => { kept = { ...kept, tokens: t, expires: Date.now() + (t.expires_in ?? 3600) * 1000, since: kept.since ?? new Date().toISOString().slice(0, 10) }; await keepServer(url, kept); },
        redirectToAuthorization: (u) => { to = u; },
        saveCodeVerifier: (v) => { verifier = v; },
        codeVerifier: () => verifier,
        invalidateCredentials: async (what) => {
          if (what === "all" || what === "client") kept = { ...kept, client: undefined, tokens: undefined };
          if (what === "tokens") kept = { ...kept, tokens: undefined };
          await keepServer(url, kept);
        },
      };
      if (await auth(provider, { serverUrl: url }) === "AUTHORIZED") return kept.tokens!.access_token;
      const yes = await cosm.ui.ask(`Sign in to ${kept.label}?`, {
        description: `A package wants to use ${kept.label} (${new URL(url).host}). Your browser opens ${kept.label}'s own page; Cosm never sees your password.`,
        choices: ["Sign in"],
      });
      if (yes !== "Sign in") throw new Error(`not signed in to ${kept.label}: the user cancelled`);
      browser(String(to));
      const code = await listener.answer(state);
      if (await auth(provider, { serverUrl: url, authorizationCode: code }) !== "AUTHORIZED") throw new Error(`${kept.label} didn't finish the sign-in`);
      return kept.tokens!.access_token;
    } finally {
      listener?.stop();
    }
  }
  /** The catch on 127.0.0.1: the browser's answer from the sign-in page, on the port asked for when it's free. */
  function listen(port?: number) {
    let done!: (code: string) => void, failed!: (e: Error) => void, want = "";
    const answered = new Promise<string>((res, rej) => { done = res; failed = rej; });
    const fetch = (req: Request) => {
      const u = new URL(req.url);
      if (u.pathname !== "/callback") return new Response("", { status: 404 });
      if (u.searchParams.get("state") !== want) return new Response("This sign-in isn't Cosm's.", { status: 400 });
      const err = u.searchParams.get("error");
      if (err) failed(new Error(`${err}: ${u.searchParams.get("error_description") ?? "the sign-in was refused"}`)); else done(u.searchParams.get("code") ?? "");
      return new Response(SIGNED_IN, { headers: { "content-type": "text/html; charset=utf-8" } });
    };
    let server: ReturnType<typeof Bun.serve>;
    try { server = Bun.serve({ hostname: "127.0.0.1", port: port ?? 0, fetch }); }
    catch { server = Bun.serve({ hostname: "127.0.0.1", port: 0, fetch }); }
    return {
      port: server.port as number,
      answer(state: string) {
        want = state;
        const timer = setTimeout(() => failed(new Error("the sign-in wasn't finished in the browser in time")), WAIT);
        cosm.signal.addEventListener("abort", () => failed(new Error("the sign-in was abandoned")));
        return answered.finally(() => clearTimeout(timer));
      },
      stop: () => server.stop(true),
    };
  }

  // The shared sign-in point: what other packages ask, through the user's default.
  cosm.point.add("cosm-points:sign-in", { name: "oauth", label: "OAuth", token: (a: Ask, { by }: { by: string }) => tokenFor(a, by), server: (a: { url: string; label?: string }, { by }: { by: string }) => serverToken(a, by), signOut });

  cosm.point.add("cosm:commands", { name: "token",
    description: "An access token for an outside service: the one kept, renewed when it has run out, or, the first time, after the user signs in on the provider's page in their browser.",
    inputs: [
      { name: "provider", label: "Who signs in", description: "as the user knows it: Microsoft, Google" },
      { name: "authorize", label: "The provider's authorization address" },
      { name: "token", label: "The provider's token address" },
      { name: "client", label: "The app's client id" },
      { name: "scopes", label: "What it may do", type: "list" },
    ],
    run: (a, { by }) => tokenFor(a, by),
  });

  /** Everything the user is signed in to, by the name they know it by: providers, and MCP servers by their label. */
  async function signIns(): Promise<{ name: string; line: string; users: string[] }[]> {
    const ks = Object.values(await all());
    const out = [...new Set(ks.map((k) => k.provider))].map((p) => {
      const of = ks.filter((k) => k.provider === p);
      return { name: p, users: [...new Set(of.flatMap((k) => k.users ?? []))], line: of.map((k) => `${p} (${k.scopes.join(", ")}), since ${k.since}`).join("\n") };
    });
    for (const [url, k] of Object.entries(await servers())) if (k.tokens) out.push({ name: k.label, users: k.users ?? [], line: `${k.label} (MCP server ${new URL(url).host}), since ${k.since}` });
    return out;
  }
  const usedBy = (u: string[]) => (u.length ? `, used by ${u.join(", ")}` : "");
  cosm.point.add("cosm:commands", { name: "signed-in", description: "What the user is signed in to (services and MCP servers), since when, and which packages use each.", run: async () =>
    (await signIns()).flatMap((s) => s.line.split("\n").map((l) => `${l}${usedBy(s.users)}`)) });
  cosm.point.add("cosm:commands", { name: "sign-out", description: "Signs out of a provider or an MCP server, by its name: its tokens are forgotten, and the next use signs in again.", inputs: [{ name: "provider", label: "Who" }],
    run: ({ provider }) => signOut({ provider }) });

  // Its Settings row: what the user is signed in to, beside Sign Out….
  cosm.point.add("cosm:items", { name: "signed-in", label: "Sign Out…", location: { in: "settings" },
    content: { changes: { storage: ["tokens", "servers"] }, run: async () => {
      const ss = await signIns();
      if (!ss.length) return null;
      // Each with the packages that use it.
      return { description: `Signed in to ${ss.map((s) => (s.users.length ? `${s.name}, used by ${s.users.join(", ")}` : s.name)).join("; ")}.` };
    } },
    action: async () => {
      const which = await cosm.ui.ask("Sign out of which?", { choices: [...new Set((await signIns()).map((s) => s.name))] });
      if (!which) return;
      return signOut({ provider: which });
    } });

  /** The sign-in itself: the provider's page in the browser, its answer caught on 127.0.0.1, the code exchanged. */
  async function signIn(authorize: string, tokenUrl: string, client: string, scopes: string[]) {
    const verifier = b64url(crypto.getRandomValues(new Uint8Array(32)));
    const challenge = b64url(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(verifier))));
    const state = b64url(crypto.getRandomValues(new Uint8Array(16)));
    const listener = listen();
    try {
      const redirect = `http://127.0.0.1:${listener.port}/callback`;
      const url = new URL(authorize);
      for (const [k, v] of Object.entries({ response_type: "code", client_id: client, redirect_uri: redirect, scope: scopes.join(" "), state, code_challenge: challenge, code_challenge_method: "S256" })) url.searchParams.set(k, v);
      browser(url.toString());
      const code = await listener.answer(state);
      return await exchange(tokenUrl, { grant_type: "authorization_code", code, redirect_uri: redirect, client_id: client, code_verifier: verifier });
    } finally {
      listener.stop();
    }
  }
}

/** What the browser shows once the sign-in came back. */
const SIGNED_IN = "<!doctype html><title>Signed in</title><p style=\"font: 15px system-ui; margin: 3em\">Signed in. You can close this tab and go back to Cosm.</p>";

interface Got { access_token: string; refresh_token?: string; expires_in?: number }
/** A token request (a form, as OAuth has it); what the provider answered, or its error. */
async function exchange(url: string, form: Record<string, string>): Promise<Got> {
  const r = await fetch(url, { method: "POST", headers: { "content-type": "application/x-www-form-urlencoded", accept: "application/json" }, body: new URLSearchParams(form) });
  const v: any = await r.json().catch(() => ({}));
  if (!r.ok || !v.access_token) throw new Error(`the provider refused: ${v.error_description ?? v.error ?? r.status}`);
  return v;
}
const tokens = (g: Got, refresh?: string) => ({ access: g.access_token, refresh: g.refresh_token ?? refresh, expires: Date.now() + (g.expires_in ?? 3600) * 1000 });
const b64url = (b: Uint8Array) => Buffer.from(b).toString("base64url");
/** Opens an address in the user's browser: $BROWSER when set (the usual way to name one), else the system's own. */
function browser(url: string) {
  const cmd = process.env.BROWSER || (process.platform === "darwin" ? "open" : process.platform === "win32" ? "explorer" : "xdg-open");
  Bun.spawn([cmd, url], { stdout: "ignore", stderr: "ignore" });
}
