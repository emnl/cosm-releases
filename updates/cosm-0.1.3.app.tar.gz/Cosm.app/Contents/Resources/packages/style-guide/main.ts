// Style guide: one view built only from Cosm's kit, showing each of its patterns with the markup that draws it, for
// whoever writes a view. Off by default; switched on in Settings → Packages to browse, and by the visual tests.
import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:views", { name: "guide", file: "views/guide.html", label: "Style guide" });
  cosm.point.add("cosm:items", { name: "open", label: "Open Style Guide", location: { in: "palette" }, action: { open: "style-guide:guide" } });
}
