// Agent schedules: the agent doing something at set times without being asked. Each page in the cosm's `schedules` folder
// is one: its `when` at the top (Cosm's clock's words: `weekly mon 08:00`, `daily 07:30`, `every 2h`, `today 13:00`),
// what the agent is to do under it. When it is due, Cosm wakes this package, which starts a session titled after the
// page with the page's words as its first message. A session that stops to ask (a step to allow, a question) waits
// for the user, with a notice.
//
// The pages are read as this package registers, so a page added, changed or removed registers it again (Cosm counts
// what a package reads of the cosm as it registers towards what it registered).
import type { Cosm } from "cosm";

const FOLDER = "schedules";
/** A clock, drawn as Cosm's own icons are (Cosm has none). */
const CLOCK = `<svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13"><circle cx="6.5" cy="6.5" r="5" fill="none" stroke="currentColor" stroke-width="1.2"/><path d="M6.5 3.8v2.9l1.9 1.2" fill="none" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const TEMPLATE = `---
when: weekly mon 08:00
---

What the agent should do, as you would ask it in a chat.
`;

/** A page's `when`, the agent it names (when it names one) and what the agent is to do. */
export function readPage(text: string): { when?: string; agent?: string; prompt: string } {
  const m = /^---\n([\s\S]*?)\n---\n?/.exec(text);
  const head = m?.[1] ?? "";
  const field = (k: string) => new RegExp(`^${k}:\\s*(.+?)\\s*$`, "m").exec(head)?.[1]?.replace(/^["']|["']$/g, "");
  return { when: field("when"), agent: field("agent"), prompt: text.slice(m?.[0].length ?? 0).trim() };
}

/** A page's title: its file's name. */
const titleOf = (path: string) => path.split("/").pop()!.replace(/\.md$/, "");
/** A schedule's name from a page's: lowercase words joined by dashes (Cosm's part names). */
const nameOf = (path: string) => titleOf(path).toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "schedule";

export default async function (cosm: Cosm) {
  cosm.package.uses("agent-session");
  cosm.point.add("cosm:kinds", { name: "schedule", extends: "markdown:page", match: `${FOLDER}/*.md`, label: "Schedule", template: TEMPLATE });
  cosm.point.add("cosm:items", { name: "new", label: "New Schedule…", content: { icon: CLOCK, description: "Something the agent does at set times: when, and what" },
    action: { new: { kind: "agent-schedules:schedule", folder: FOLDER, name: "{name}", question: "What is the schedule called?" } }, location: [{ in: "palette" }, { in: "menu-bar", menu: "File" }] });

  // One schedule a page that says when.
  const taken = new Set<string>();
  for (const path of await cosm.file.list(`${FOLDER}/*.md`)) {
    const { when } = readPage(await cosm.file.read(path));
    if (!when) { cosm.log(`${path}: no when at its top (when: daily 08:00), so it doesn't run`); continue; }
    let name = nameOf(path);
    for (let i = 2; taken.has(name); i++) name = `${nameOf(path)}-${i}`;
    taken.add(name);
    cosm.point.add("cosm:schedules", { name, when, description: titleOf(path), run: () => run(path) });
  }

  /** A page due: a session titled after it, its words the first message (read now: the page as it is). */
  async function run(path: string) {
    const { prompt, agent } = readPage(await cosm.file.read(path));
    if (!prompt) { cosm.log(`${path}: nothing under its when for the agent to do`); return; }
    const title = titleOf(path);
    const session = await cosm.call<string>("agent-session:start", { first: prompt, title, ...(agent ? { agent } : {}) });
    await waitsForTheUser(session, title);
  }

  /** Followed until its first turn ends: when the agent stops to ask, the user is told where (once). */
  async function waitsForTheUser(session: string, title: string) {
    let told = false, done = false;
    let stop = () => {};
    stop = await cosm.stream.subscribe(`agent-session:${session}`, (items, { closed }) => {
      for (const it of items as { type?: string }[]) {
        if (!told && (it.type === "permission" || it.type === "question" || it.type === "plan")) {
          told = true;
          void cosm.ui.notify(`The schedule ${title} waits for your answer: its session is in the session list.`);
        }
        if (it.type === "turn-end") done = true;
      }
      if (done || closed) { done = true; stop(); }
    });
    if (done) stop();
  }
}
