// Gemini CLI as the agent, a connector (agent:agents). It speaks ACP itself (gemini --acp): each conversation's chat is
// a process of this package, which Agent session speaks with; Agent session fires the agent's events from what it
// says (it has no hooks). Gemini CLI takes no instructions as it starts, so Cosm's go with a new conversation's first
// message, with where Cosm's commands are (it knows them by no name of its own). Its adapter (bin/gemini-agent) starts
// it where the user said its own setup in the cosm may be used, in the cosm's colours, and runs it in a terminal; this
// registers it, its setting and its Settings rows.
import type { Cosm } from "cosm";
import type { Server, Share } from "package:agent";
import { homedir } from "node:os";
import { existsSync } from "node:fs";
import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import { shape } from "cosm/shape";

/** The programs packages give the agent, as a folder of small scripts by their names, each running its program with
 * its package's variables: the folder its adapter puts first on the agent's PATH (COSM_PROGRAMS_DIR). */
async function programsDir(dir: string, programs: Share["programs"]): Promise<string> {
  const q = (s: string) => `'${s.replaceAll("'", `'\\''`)}'`;
  await rm(dir, { recursive: true, force: true });
  await mkdir(dir, { recursive: true });
  for (const p of programs) {
    const vars = Object.entries(p.env).map(([k, v]) => q(`${k}=${v}`)).join(" ");
    await writeFile(`${dir}/${p.name}`, `#!/bin/sh\nexec env ${vars} ${q(p.program)} "$@"\n`, { mode: 0o755 });
  }
  return dir;
}

/** The MCP servers in an agent's own config file (`{ mcpServers: { name: { command, args, env } | { url | httpUrl, headers } } }`,
 * as Claude Code's .mcp.json and ~/.claude.json and Gemini CLI's settings.json write them), as the agent package's
 * `Server`s. */
function serversIn(o: unknown): Server[] {
  const all = (o as { mcpServers?: Record<string, { command?: string; args?: string[]; env?: Record<string, string>; url?: string; httpUrl?: string; headers?: Record<string, string> }> } | null)?.mcpServers ?? {};
  return Object.entries(all).flatMap(([name, s]): Server[] => s.url || s.httpUrl ? [{ name, url: (s.url ?? s.httpUrl)!, headers: s.headers ?? {} }]
    : s.command ? [{ name, program: s.command, args: s.args ?? [], env: s.env ?? {} }] : []);
}
const readJson = (f: string) => readFile(f, "utf8").then((t) => JSON.parse(t) as unknown, () => null);

export default function (cosm: Cosm) {
  cosm.package.uses("agent");
  /** This cosm's own Gemini CLI setup (.gemini/, .env) and whether it is used on this computer, which Gemini CLI needs
   * to run here at all (it runs only in a folder it trusts): asked once, the first time a session starts with it there
   * (`ask`), the answer kept in this computer's cache for the cosm. A cosm that had none when first looked at here uses
   * what is added later (the theme this package writes into .gemini/). */
  const OWN = [".gemini", ".env"];
  const answer = () => `${cosm.package.folders.cache}/own-setup.json`;
  const keep = (use: boolean) => writeFile(answer(), JSON.stringify({ use }));
  async function ownSetup(ask: boolean): Promise<{ files: string[]; use: boolean | null }> {
    const files = OWN.filter((f) => existsSync(`${cosm.package.folders.cosm}/${f}`));
    const kept = await readFile(answer(), "utf8").then((t) => JSON.parse(t).use === true, () => null);
    if (kept !== null) return { files, use: kept };
    if (!files.length) { await keep(true); return { files, use: true }; }
    if (!ask) return { files, use: null };
    const r = await cosm.ui.ask(`This cosm has its own Gemini CLI setup (${files.join(", ")}). Use it on this computer?`,
      { description: "Gemini CLI runs only in a folder whose setup it uses: left out, it doesn't run here. Change it later on Gemini CLI's page in Settings.", choices: ["Use It", "Leave It Out"] });
    if (r === null) return { files, use: false };
    await keep(r === "Use It");
    return { files, use: r === "Use It" };
  }
  /** What Gemini CLI's adapter is told of it: 1 used, 0 left out, empty not asked yet. */
  const ownEnv = async (ask: boolean) => { const u = (await ownSetup(ask)).use; return { COSM_OWN_SETUP: u === true ? "1" : u === false ? "0" : "" }; };
  /** Cosm's instructions and its commands, by name and file: what Gemini CLI gets before a new conversation's first message. */
  async function rules(): Promise<string> {
    const b = await cosm.call<Share>("agent:share");
    const text = b.instructions.map((i) => i.text.trim()).filter(Boolean).join("\n\n");
    const commands = b.prompts.map((c) => `- ${c.name}: ${c.path}`).join("\n");
    return `${text}\n\nCosm's commands are files, one each: when a message says "Run Cosm's command <name>.", read that file and do what it says.\n${commands}`;
  }
  const me = cosm.package.name;
  /** Which of a conversation's processes runs now: its chat (`chat-<session>`) or its terminal (`terminal-<session>`). */
  async function running({ session }: { session: string }) {
    const live = new Set((await cosm.process.list({ package: me })).filter((p) => p.running).map((p) => p.name));
    for (const as of ["chat", "terminal"] as const) if (live.has(`${me}:${as}-${session}`)) return { as, process: `${me}:${as}-${session}` };
    return null;
  }
  /** What its programs get: the secrets packages give the agent, and whether the cosm's own setup is used. */
  const given = async (env: Record<string, string>) => {
    const b = await cosm.call<Share>("agent:share");
    return { ...b.secrets, ...(await ownEnv(true)), COSM_PROGRAMS_DIR: await programsDir(`${cosm.package.folders.cache}/programs`, b.programs), ...env };
  };
  cosm.point.add("agent:agents", {
    name: "gemini",
    label: "Gemini CLI",
    prompt: "Run Cosm's command {name}.",
    // Gemini CLI's own MCP servers: this cosm's .gemini/settings.json, then the user's.
    servers: async () => {
      const all = [...serversIn(await readJson(`${cosm.package.folders.cosm}/.gemini/settings.json`)), ...serversIn(await readJson(`${homedir()}/.gemini/settings.json`))];
      return all.filter((s, i) => all.findIndex((x) => x.name === s.name) === i);
    },
    // One Gemini CLI for a conversation at a time, as a chat or in a terminal: starting one stops the other.
    start: async ({ session, as, resume, first }) => {
      const now = await running({ session });
      // In a terminal (`terminal-<session>`), which Agent terminal draws; a new conversation's opening message goes with
      // the rules before it.
      if (as === "terminal") {
        if (now?.as === "terminal") return { process: `${me}:terminal-${session}` };
        await cosm.process.stop(`chat-${session}`).catch(() => {});
        const file = `${cosm.package.folders.cache}/rules-${session}.md`;
        await Bun.write(file, await rules());
        await cosm.process.start(`terminal-${session}`, { program: "bin/gemini-agent", args: ["terminal"], as: "terminal",
          env: await given({ COSM_RULES_FILE: file, ...(resume ? { COSM_RESUME: "1" } : {}), ...(first ? { COSM_FIRST_MESSAGE: first } : {}) }) });
        return { process: `${me}:terminal-${session}` };
      }
      await cosm.process.stop(`terminal-${session}`).catch(() => {});
      if (now?.as !== "chat") await cosm.process.start(`chat-${session}`, { program: "bin/gemini-agent", args: ["chat"], env: await given({}) });
      // Cosm's own lookups as tools only while the setting says so; the agent uses the cosm command in its shell. Gemini
      // CLI takes no instructions as it starts: Cosm's go with a new conversation's first message.
      const all = (await cosm.call<Share>("agent:share")).mcp;
      const mcp = (await cosm.setting.get("lookups-as-tools")) === true ? all : all.filter((s) => s.name !== "cosm");
      return { process: `${me}:chat-${session}`, mcp, rules: await rules() };
    },
    running,
    // Its program ends, chat or terminal, and the rules written for its terminal go with it.
    stop: async ({ session }) => {
      for (const p of [`chat-${session}`, `terminal-${session}`]) await cosm.process.stop(p).catch(() => {});
      await rm(`${cosm.package.folders.cache}/rules-${session}.md`, { force: true });
    },
  });
  cosm.point.add("cosm:settings", { name: "lookups-as-tools",
    shape: shape.boolean(),
    default: false,
    label: "Offer Cosm's lookups as tools",
    description: "Hands the agent Cosm's lookups (search, and what the packages add) as tools of their own, beside the cosm command it uses in its shell. Off: the agent uses the cosm command alone. From the next session.",
  });
  // Its page in Settings: whether Gemini CLI is installed, signed in and trusted here, and the step that would help now
  // (Google's npm package, Gemini CLI's own sign-in), run there in a terminal.
  cosm.point.add("cosm:views", { name: "setup", file: "views/setup.html", label: "Gemini CLI", location: { in: "settings" } });
  cosm.view.export({
    /** Runs a step of its setup (install, sign in, sign out) in a terminal its page draws: its process's name. */
    setup: { input: shape.object({ step: shape.string() }), run: async ({ step }: { step: string }) => {
      await cosm.process.stop("setup").catch(() => {});
      await cosm.process.start("setup", { program: "bin/gemini-agent", args: [step === "sign-in" ? "signin" : step], as: "terminal", cols: 100, rows: 14 });
      return `${cosm.package.name}:setup`;
    } },
    /** How Gemini CLI stands here: `{ready: true | false | null, line, description?, items}` (`items`: the steps that
     * would help now: install, sign-in). */
    status: { changes: { events: ["setting.changed"] }, run: async () => {
      const p = Bun.spawn([`${cosm.package.folders.package}/bin/gemini-agent`, "ready"], { cwd: cosm.package.folders.cosm, stdin: "ignore", stdout: "pipe", stderr: "pipe", signal: cosm.signal,
        env: { ...process.env, COSM_PACKAGE: cosm.package.name, COSM_PACKAGE_DIR: cosm.package.folders.package, COSM_ROOT_DIR: cosm.package.folders.cosm, ...(await ownEnv(false)) } });
      const [out, code] = await Promise.all([new Response(p.stdout).text(), p.exited]);
      if (code !== 0) throw new Error(`gemini-agent ready stopped (${code})`);
      return JSON.parse(out.trim().split("\n").pop() || "null");
    } },
    /** This cosm's own Gemini CLI setup: its files and whether it is used here (null: not asked yet). */
    ownSetup: () => ownSetup(false),
    /** Uses this cosm's own Gemini CLI setup here, or leaves it out. */
    useOwnSetup: async ({ use }: { use: boolean }) => { await keep(use === true); },
  });
}
