// Shared points: places no single feature package owns, which several packages may fill and
// others use. A point is added here only when it has both a filler and a user.
//
//   sign-in   how a package gets a token for an outside service (a mail package's Microsoft account). OAuth fills
//             it; a better sign-in package adds to the same point and the user picks it (Settings → General →
//             Defaults). A package needing a sign-in asks the user's default:
//
//               const t = await (await cosm.point.default("cosm-points:sign-in"))?.token({ provider: "Microsoft",
//                 authorize, token, client, scopes: ["Mail.Read"] });
//
//             An MCP server that wants a sign-in needs only its address: server({ url, label }) (MCP client asks it).
//
// Turning the filler off leaves the point here; another filler takes over, or the asking package says it needs one.
import type { Cosm } from "cosm";
import { shape } from "cosm/shape";

export default function (cosm: Cosm) {
  cosm.point.define("sign-in", {
    label: "Sign-in",
    description: "Signs in to an outside service for a package: token({provider, authorize, token, client, scopes}) gives an access token (asking the user to sign in the first time), server({url, label}) the same for an MCP server by its address alone (the MCP spec's sign-in, registering Cosm there), signOut({provider}) forgets one by its name. provider is the service's name as the user knows it; authorize and token its OAuth addresses; client the app's client id; scopes what the token may do.",
    holds: "functions",
    uses: "one",
    shape: shape.object({ label: shape.string() }),
    functions: ["token", "server", "signOut"],
  });
}
