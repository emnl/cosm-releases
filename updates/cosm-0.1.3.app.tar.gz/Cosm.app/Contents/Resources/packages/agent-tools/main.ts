// Agent tools: what the agent needs to read and make Word, Excel, PowerPoint and PDF files, and to change someone
// else's in place. It gives the agent uv (with uvx), which runs the Python libraries the tools skill names, and
// OfficeCLI; each is fetched the first time it runs (bin/get: pinned, its checksum checked) and kept in this package's
// cache. The skill (agent/skills/tools) says which tool for which file.
import type { Cosm } from "cosm";

const PROGRAMS = ["uv", "uvx", "officecli"] as const;

export default function (cosm: Cosm) {
  for (const name of PROGRAMS) cosm.point.add("agent:programs", { name, program: `bin/${name}` });

  return cosm.package.export({
    /** A program of this package's, for another package that needs it: its full path and the variables it runs with. */
    program: {
      description: "One of this package's programs (uv, uvx, officecli), for a package that runs it: {program, env}.",
      run: async ({ name }: { name: string }) => {
        if (!(PROGRAMS as readonly string[]).includes(name)) throw new Error(`Agent tools has no program called ${name} (${PROGRAMS.join(", ")})`);
        const p = await cosm.package.program(`bin/${name}`);
        return { program: p.program, env: Object.fromEntries(Object.entries(p.env).filter(([k]) => k.startsWith("COSM_"))) };
      },
    },
  });
}
