---
name: tools
description: How to read and make Word, Excel, PowerPoint and PDF files and read web pages on this computer — which tool to use for each file type, and the exact command. Use before opening, converting or creating any such file.
---
# Tools

What this computer has, and the right tool for each file type.

`uv`, `uvx` and `officecli` are on the path (this package's): the first use of each fetches it once, in a few seconds.

Every command below runs as `uv run -q --no-project --python 3.12 --with <package> python -c "<code>"` (or `uvx … ` where shown). Write longer code to a file in a new `mktemp -d` folder and run it with `python -I` (never from `~/Downloads`, where a stray file could be imported).

## Reading

| File | Use |
|---|---|
| PDF | read it directly, page by page (a scan is read as an image); for tables, `pdfplumber`: `pdfplumber.open(f).pages[i].extract_tables()` |
| Word (.docx) | `pypandoc_binary`: `pypandoc.convert_file(f, 'gfm', extra_args=['--track-changes=all'])` (keeps headings, lists and tables, and shows tracked changes as marked insertions and deletions) |
| Excel (.xlsx) | `openpyxl`: `load_workbook(f, data_only=True)`, then each sheet's rows |
| PowerPoint (.pptx) | `python-pptx`: each slide's shapes with a text frame |
| Web page | the agent's own web fetch; if that fails, markitdown on the URL (below) |
| Anything else (.epub, .html, an odd format) | `uvx --python 3.12 --from 'markitdown[docx,xlsx,pptx,pdf]' markitdown <file or URL>` |

## Making

| File | Use |
|---|---|
| Word | write markdown, then `pypandoc.convert_file('x.md', 'docx', outputfile='x.docx')` |
| PDF | for anything with layout, make the Word file and ask the user to export it as PDF; for a plain text document, `reportlab` |
| Excel | `openpyxl`: `Workbook()`, append rows, `save()` |
| PowerPoint | `python-pptx`: one slide per section, title and bullet text |


## Changing a file someone else made

Keep its formatting. `officecli` changes only what it is told, in place, and keeps everything else (styles, formulas,
dropdowns, shapes): address a part by its path and set it, e.g. `officecli set budget.xlsx /Sheet1/B12 --prop value=4200`,
`officecli set memo.docx /body --find "Q3" --replace "Q4"` (matches across Word's split text runs); `officecli get
<file> <path>` reads a part first, and `officecli --help` and `officecli <verb> --help` say the rest. It keeps a file
open in the background between commands: `officecli close <file>` before another program reads it. Save to a copy in
`~/Downloads` with `-edited` in the name unless told to change the file itself.

Without officecli: open the file itself with `openpyxl`, `python-pptx` or `python-docx` and change only the cells, text or slides asked for, then save it as a new file in `~/Downloads` with `-edited` in the name. Never rebuild it from a conversion: that loses styles, formulas and layout.
- Excel: load without `data_only` (with it, saving turns every formula into a fixed value). `openpyxl` drops dropdowns, conditional formatting and shapes: if the file has them, say so before changing it.
- Word: change text inside its runs, never `paragraph.text` (that drops bold and other formatting).

## What every Mac has

- Images: `sips` resizes and converts (`sips -s format jpeg photo.heic --out photo.jpg`, `sips -Z 1600 big.png`).
- A file's details: `mdls <file>` (dates, where it was downloaded from, page count); `mdfind -name "<words>"` and
  `mdfind "<words>"` find files by name or content anywhere on the Mac, as Spotlight does.
- Word to text without uv: `textutil -convert txt -stdout <file>`.
