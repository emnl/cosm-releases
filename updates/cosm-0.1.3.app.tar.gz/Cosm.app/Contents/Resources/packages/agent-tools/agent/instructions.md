## Tools

Use what this computer already has (`curl`, `unzip`, `find`, `grep`, `textutil` on a Mac, reading PDFs and images directly), plus `uv`, `uvx` and `officecli`, which this package puts on the path. Never install anything without asking. For reading or making Word, Excel, PowerPoint and PDF files, and for reading web pages, load the tools skill first.
