// Agent chat: a conversation with an agent as a chat (views/chat, built from package-src/agent-chat), placed in Agent
// session's holder, which has the session's header, its list and its menu of what packages place there. What the user
// selects in an editor shows as a chip, whose ✕ is its `deselect` event.
import type { Cosm } from "cosm";
import { shape } from "cosm/shape";

export default function (cosm: Cosm) {
  cosm.package.uses("agent");
  cosm.package.uses("agent-session");
  cosm.point.add("cosm:views", { name: "chat", file: "views/chat/index.html", label: "Chat", icon: "chat", input: "thing", location: { in: "agent-session:holder" } });
  cosm.point.add("cosm:events", { name: "deselect", description: "The user dropped the selection the chat was to send (the chip's ✕): editors drop it too." });
  cosm.point.add("cosm:settings", { name: "text-size",
    shape: shape.enum(["smaller", "standard", "larger"]),
    default: "standard",
    label: "Chat text",
    description: "How large the chat's messages are, next to the text size in Settings → Appearance.",
  });

  // What its chat asks of the cosm (a view reaches the cosm only through its package): Agent session's calls (the broker: start, send, answer,
  // cancel, set), the conversation's stream handed to it, the agents that are on, the cosm's pages by name, what went with each session's message, its own
  // setting. What an editor selects the chat's view reads itself, from what
  // the editor's view published.
  // What went with each message ("Brought along"), in the session's storage (Agent session's, gone with the session):
  // by the message's id, the package that said so (its second word on a message replaces its first).
  type Brought = Record<string, Record<string, unknown[]>>;
  cosm.on("*:context.sent", async (d, ctx) => {
    const { message, session } = d as { message?: unknown; session?: unknown };
    if (typeof session !== "string" || !session || typeof message !== "string") return;
    const things = ((d as { things?: unknown[] }).things ?? []).map((t: any) => ({ name: t?.name, path: t?.path, kind: t?.kind, ...(t?.view ? { view: t.view } : {}) }));
    const all = ((await cosm.call("agent-session:storage-get", { session, key: "brought" })) as Brought | null) ?? {};
    (all[message] ??= {})[ctx.package] = things;
    await cosm.call("agent-session:storage-set", { session, key: "brought", value: all });
  });
  type Pass = Record<string, unknown>;
  return cosm.view.export({
    textSize: { changes: { events: ["setting.changed"] }, run: async () => { const s = await cosm.setting.get("text-size"); return typeof s === "string" ? s : null; } },
    agents: { description: "The agents that are on.", changes: { events: ["package.changed"] }, run: () => cosm.call("agent:list") },
    start: (input: Pass) => cosm.call("agent-session:start", input),
    send: (input: Pass) => cosm.call("agent-session:send", input),
    /** The messages sent to the session that haven't gone to its agent yet (Agent session's), oldest first. */
    waiting: { description: "The messages waiting to go to the session's agent.", changes: { events: ["agent-session:waiting"] },
      run: ({ session }: { session: string }) => (session ? cosm.call("agent-session:waiting", { session }) : []) },
    unsend: (input: Pass) => cosm.call("agent-session:unsend", input),
    answer: (input: Pass) => cosm.call("agent-session:answer", input),
    cancel: (input: Pass) => cosm.call("agent-session:cancel", input),
    set: (input: Pass) => cosm.call("agent-session:set", input),
    conversation: { description: "A conversation as Agent session keeps it: its agent, its agent's package.", run: (input: Pass) => cosm.call("agent-session:get", input) },
    /** The conversation's stream (Agent session's, `agent-session:<id>`), handed to the view: the window follows it
     * for the chat, so this package may sleep while it shows. */
    stream: { description: "The conversation's stream, handed to the chat.", run: ({ session }: { session: string }) => cosm.stream.pass(`agent-session:${session}`) },
    deselect: { description: "The chip's ✕: every editor drops the selection.", run: () => cosm.emit("deselect") },
    brought: { description: "What went with each of a session's messages, by the message's id: each package's things.", changes: { events: ["agent-session:storage.changed"] },
      run: async ({ session }: { session: string }) => (session ? ((await cosm.call("agent-session:storage-get", { session, key: "brought" })) as Brought | null) : null) ?? {} },
    pages: { description: "The cosm's files by the names Cosm shows them under.", changes: { files: "**" }, run: async () => {
      type N = { name: string; path: string; folder: boolean; children?: N[] };
      const out: { name: string; path: string }[] = [];
      const walk = (ns: N[]) => { for (const n of ns) { if (n.folder) walk(n.children ?? []); else out.push({ name: n.name, path: n.path }); } };
      walk((await cosm.file.tree()) as N[]);
      return out;
    } },
    pageText: { description: "A page's text, to send along whole (@name).", run: ({ path }: { path: string }) => cosm.file.read(path) },
    which: { description: "The file a [[Name]] means, nearest to `from` first.", changes: { files: "**" },
      run: ({ name, from }: { name: string; from?: string }) => cosm.file.which(name, from ? { from } : {}) },
  });
}
