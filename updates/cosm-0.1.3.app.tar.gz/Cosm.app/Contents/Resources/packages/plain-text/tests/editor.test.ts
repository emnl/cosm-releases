// Plain text's editor in the window (headless): .txt and .json open in it, and what is typed is saved as typed.
import { describe, expect, test } from "bun:test";
import { testCosm } from "cosm/test";

describe("Plain text", () => {
  for (const [file, text] of [["notes.txt", "Call with Anna on Monday\n"], ["settings.json", '{\n  "theme": "dark"\n}\n']] as const) {
    test(`opens ${file} and saves what is typed`, async () => {
      await using c = await testCosm({ files: { [file]: text } });
      await c.window();
      await c.run("ui", "open", file);
      await c.run("ui", "wait", "--view", "plain-text:editor", "--timeout", "30");
      const ref = /textbox[^\n]*\[ref=([a-z]+\d+)\]/.exec(await c.run("ui", "outline", "plain-text:editor"))?.[1] ?? "";
      await c.run("ui", "click", ref);
      await c.run("ui", "type", ref, "!");
      await c.until(() => c.read(file)!.includes("!"), { what: "the typing saved" });
      expect(c.read(file)!.replace("!", "")).toBe(text);
    }, 60000);
  }
});
