import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  // Text files, shown in this package's editor (views/editor.html).
  cosm.point.add("cosm:views", { name: "editor", file: "views/editor/index.html", input: "file" });
  cosm.point.add("cosm:kinds", { name: "text", match: "**/*.{txt,json}", label: "Text file", view: "editor" });
  // What its editor asks of it: when any package last asked to drop the selection
  // (`deselect`, kept in its storage, so a sleep doesn't lose it: the editor drops its selection as it changes). The
  // editor publishes its selection itself.
  cosm.on("*:deselect", () => cosm.storage.set("deselected", Date.now()));
  return cosm.view.export({
    deselected: { changes: { storage: "deselected" }, run: async () => (await cosm.storage.get<number>("deselected")) ?? 0 },
  });
}
