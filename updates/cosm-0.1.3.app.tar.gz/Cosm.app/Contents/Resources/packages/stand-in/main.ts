import type { Cosm } from "cosm";
import type { Share } from "package:agent";

export default function (cosm: Cosm) {
  cosm.package.uses("agent");
  // A connector (agent:agents): its chat is a program that speaks ACP (bin/chat), run as one of this package's
  // processes, which Agent session speaks with; in a terminal it is a terminal agent (bin/agent), which takes typing.
  // Canned replies, nothing spent; off until switched on, then chosen in Settings → General → Defaults.
  const me = cosm.package.name;
  /** Which of a conversation's processes runs now: its chat (`chat-<session>`) or its terminal (`terminal-<session>`). */
  async function running({ session }: { session: string }) {
    const live = new Set((await cosm.process.list({ package: me })).filter((p) => p.running).map((p) => p.name));
    for (const as of ["chat", "terminal"] as const) if (live.has(`${me}:${as}-${session}`)) return { as, process: `${me}:${as}-${session}` };
    return null;
  }
  /** The cosm's own commands, as a real agent offers them: each prompt by its name, with its description. */
  async function commands() {
    const said = async (path: string) => (await Bun.file(path).text().catch(() => "")).match(/^description:\s*(.+)$/m)?.[1]?.trim() ?? "";
    return Promise.all((await cosm.call<Share>("agent:share")).prompts.map(async (p) => ({ name: `cosm:${p.name}`, description: await said(p.path) })));
  }
  cosm.point.add("agent:agents", { name: "stand-in", label: "Stand-in agent", prompt: "/cosm:{name}",
    // One program for a conversation at a time, as a chat or in a terminal: starting one stops the other.
    start: async ({ session, as, first }) => {
      const now = await running({ session });
      const other = as === "terminal" ? "chat" : "terminal";
      await cosm.process.stop(`${other}-${session}`).catch(() => {});
      if (now?.as !== as) {
        if (as === "terminal") await cosm.process.start(`terminal-${session}`, { program: "bin/agent", as: "terminal", env: first ? { COSM_FIRST_MESSAGE: first } : {} });
        else await cosm.process.start(`chat-${session}`, { program: "bin/chat", env: { COSM_COMMANDS: JSON.stringify(await commands()) } });
      }
      return { process: `${me}:${as}-${session}` };
    },
    running,
    stop: async ({ session }) => { for (const p of [`chat-${session}`, `terminal-${session}`]) await cosm.process.stop(p).catch(() => {}); },
  });
}
