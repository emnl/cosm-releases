// Tables: a table made with its exec command, read back with query, and shown in its view (headless window).
import { describe, expect, test } from "bun:test";
import { testCosm } from "cosm/test";

const MAKE = `CREATE TABLE card_expenses(paid_on DATE, paid_to TEXT, amount_sek INTEGER);
INSERT INTO table_docs VALUES ('card_expenses', '', 'Card expenses on the company card.
Grain: one row per payment.
Scope: [[Personal]]'), ('card_expenses', 'paid_on', 'The day it was paid'), ('card_expenses', 'paid_to', 'Who was paid'), ('card_expenses', 'amount_sek', 'SEK, a flow');
INSERT INTO card_expenses VALUES ('2026-10-24', 'Pressbyrån', 49), ('2026-10-23', 'SJ', 1240);`;

describe("Tables", () => {
  test("a table made with exec is listed and read back", async () => {
    await using c = await testCosm();
    await c.run("tables:exec", MAKE);
    expect(await c.run("tables:list")).toContain("card_expenses");
    expect(await c.run("tables:query", "SELECT sum(amount_sek) AS total FROM card_expenses")).toContain("1289");
  });

  test("its view shows the rows, and a [[link]] in its description opens the page", async () => {
    await using c = await testCosm({ files: { "Personal.md": "# Personal\n" }, packages: ["markdown"] });
    await c.run("tables:exec", MAKE);
    await c.window();
    await c.run("ui", "open", "tables:table", "tables:table:card_expenses");
    const out = (await c.run("ui", "wait", "--text", "Pressbyrån", "--view", "tables:table", "--timeout", "30"), await c.run("ui", "outline", "tables:table"));
    expect(out).toContain("SJ");
    const ref = /link "Personal"[^\n]*\[ref=([a-z]+\d+)\]/.exec(out)?.[1];
    expect(ref).toBeTruthy();
    await c.run("ui", "click", ref!);
    await c.until(async () => (await c.run("ui", "shown", "centre")).includes("Personal.md"), { what: "Personal.md open" });
  }, 60000);
});
