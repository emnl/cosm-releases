// Tables: the user's tables in one SQLite database in its data folder in the cosm (.cosm/data/tables/tables.db: it
// syncs with the cosm).
// table_docs describes every table and column: a table's row has col '' and holds "Grain: one row per …", "Scope:
// [[Page]]" (the page that names the table) and "Queries: …" (words someone asking about it would use). After every
// write each table is copied to <its data folder>/tables/<table>.csv: a copy the user can open, and the way back if the
// database breaks. The agent works through the tools; the pages through the functions exposed to them.
import type { Cosm } from "cosm";
import { Database } from "bun:sqlite";
import { existsSync, mkdirSync, readdirSync, renameSync, readFileSync, statSync, writeFileSync } from "node:fs";
import { relative, resolve } from "node:path";

const DOCS = "CREATE TABLE IF NOT EXISTS table_docs(tbl TEXT NOT NULL, col TEXT NOT NULL DEFAULT '', doc TEXT NOT NULL, PRIMARY KEY (tbl, col));";
/** The tables a user keeps: not SQLite's own, not table_docs, not the scratch tables (tmp_…). */
const USER = "type IN ('table','view') AND name NOT LIKE 'sqlite_%' AND name <> 'table_docs' AND name NOT LIKE 'tmp\\_%' ESCAPE '\\'";
/** Past this many rows a query is cut, so the agent counts and sums in SQL instead of reading rows. */
const MOST = 200;

type Row = Record<string, unknown>;

export default function (cosm: Cosm) {
  // Its own data folder, never .cosm/ itself.
  const data = cosm.package.folders.data;
  const file = `${data}/tables.db`;
  // One connection to read with, kept, opened again when the file was made or replaced.
  let held: { db: Database; ino: number } | null = null;
  const reading = () => {
    if (!existsSync(file)) return null;
    const ino = statSync(file).ino;
    if (!held || held.ino !== ino) { held?.db.close(); held = { db: new Database(file, { readonly: true }), ino }; }
    return held.db;
  };
  const writing = () => { mkdirSync(data, { recursive: true }); const db = new Database(file); db.run(DOCS); return db; };
  const names = (db: Database) => db.query(`SELECT name FROM sqlite_master WHERE ${USER} ORDER BY name`).all().map((r: any) => r.name as string);
  const docOf = (db: Database, t: string, col = "") => (db.query("SELECT doc FROM table_docs WHERE tbl = ? AND col = ?").get(t, col) as any)?.doc as string | undefined;
  /** A table's name as SQL may hold it: letters, digits and _ only, and one that is there. */
  const named = (db: Database, t: string) => {
    if (!/^[A-Za-z0-9_]+$/.test(t) || !db.query("SELECT 1 FROM sqlite_master WHERE type IN ('table','view') AND name = ?").get(t)) {
      throw new Error(`no table called ${t} (the tables: ${names(db).join(", ")})`);
    }
    return t;
  };

  // --- what the agent reads and writes -----------------------------------------------------------------------------------

  cosm.point.add("cosm:commands", { name: "list", step: "Read your tables", description: "Every table with its description.", run: () => {
    const db = reading();
    if (!db) return "No tables yet.";
    const scratch = db.query("SELECT name FROM sqlite_master WHERE type = 'table' AND name LIKE 'tmp\\_%' ESCAPE '\\' ORDER BY name").all().map((r: any) => r.name);
    const lines = names(db).map((t) => `${t} — ${(docOf(db, t) ?? "NO DESCRIPTION").replaceAll("\n", " · ")}`);
    return [...(scratch.length ? [`Scratch: ${scratch.join(", ")}`] : []), ...lines];
  } });

  cosm.point.add("cosm:commands", { name: "describe", step: "Read your tables", description: "A table's description, every column with its type and meaning, and its key.",
    inputs: [{ name: "table", label: "The table's name" }], run: ({ table }) => {
      const db = reading();
      if (!db) return "No tables yet.";
      const t = named(db, table);
      const cols = db.query(`SELECT c.name, c.type, c.pk, d.doc FROM pragma_table_info(?) c LEFT JOIN table_docs d ON d.tbl = ? AND d.col = c.name ORDER BY c.cid`).all(t, t) as any[];
      return [docOf(db, t) ?? `NO DESCRIPTION for ${t}`, ...cols.map((c) => `- ${c.name} (${c.type || "any"}${c.pk > 0 ? ", key" : ""}) — ${c.doc ?? "NO DESCRIPTION"}`)];
    } });

  cosm.point.add("cosm:commands", { name: "query", step: "Read your tables", description: `Reads with one SELECT, shown as a table; more than ${MOST} rows are cut with a notice, so count and sum in SQL rather than reading rows.`,
    inputs: [{ name: "sql", label: "A SELECT statement" }], run: ({ sql }) => {
      const db = reading();
      if (!db) return "No tables yet.";
      const q = db.query(sql);
      const rows = q.values() as unknown[][];
      return markdown(q.columnNames, rows.slice(0, MOST)) + (rows.length > MOST ? `\n(cut: ${rows.length} rows, only the first ${MOST} shown; count and sum in SQL instead of reading rows)` : "");
    } });

  cosm.point.add("cosm:events", { name: "changed", description: "The tables changed (a write through exec or import): views showing them read them again." });
  cosm.point.add("cosm:commands", { name: "exec", step: "Updated a table", description: "Any SQL, several statements, all or nothing (no BEGIN or COMMIT: it adds them); then the CSV copies in the package's data folder and a check of the descriptions (tables skill).",
    inputs: [{ name: "sql", label: "SQL statements" }], run: ({ sql }) => {
      const db = writing();
      try {
        db.run("PRAGMA foreign_keys = ON");
        try { db.transaction(() => db.run(sql))(); } catch (e: any) { throw new Error(`nothing written: ${e.message}`); }
        void cosm.emit("changed");
        return after(db);
      } finally { db.close(); }
    } });

  cosm.point.add("cosm:commands", { name: "import", step: "Updated a table", description: "Adds the rows of a CSV file (header row = column names) to a table, all or nothing, empty cells as NULL; a tmp_ table that doesn't exist is made from the header (all columns text).",
    inputs: [{ name: "table", label: "The table's name" }, { name: "file", label: "The CSV file's path" }], run: ({ table, file: csv }) => {
      const path = resolve(cosm.package.folders.cosm, csv);
      if (!existsSync(path)) throw new Error(`no file ${csv}`);
      const [head, ...rows] = parseCsv(readFileSync(path, "utf8"));
      const cols = (head ?? []).map((c) => c.replace(/[^A-Za-z0-9_]/g, "")).filter(Boolean);
      if (!/^[A-Za-z0-9_]+$/.test(table)) throw new Error(`no table called ${table}`);
      const db = writing();
      try {
      const there = !!db.query("SELECT 1 FROM sqlite_master WHERE name = ?").get(table);
      if (!there && !table.startsWith("tmp_")) throw new Error(`no table ${table} (make it with tables:exec first)`);
      try {
        db.transaction(() => {
          if (!there) db.run(`CREATE TABLE "${table}" (${cols.map((c) => `"${c}" TEXT`).join(", ")})`);
          const ins = db.prepare(`INSERT INTO "${table}" (${cols.map((c) => `"${c}"`).join(", ")}) VALUES (${cols.map(() => "?").join(", ")})`);
          // A new scratch table keeps every cell as written; an existing table takes an empty cell as NULL.
          for (const r of rows) ins.run(...cols.map((_, i) => (there ? (r[i] === "" || r[i] === undefined ? null : r[i]) : (r[i] ?? ""))));
        })();
      } catch (e: any) { throw new Error(`nothing written: ${e.message}`); }
      void cosm.emit("changed");
      if (!there) return `IMPORTED ${rows.length} rows into new scratch table ${table} (all columns text)`;
      return [`IMPORTED ${rows.length} rows into ${table}`, ...after(db)];
      } finally { db.close(); }
    } });

  /** After a write: a dropped table's last copy kept in dropped/ of the data folder, every table checked for what the
   * tables skill asks, the copies written again (in the background). */
  function after(db: Database): string[] {
    const out: string[] = [];
    const dir = `${data}/tables`;
    mkdirSync(dir, { recursive: true });
    const kept = new Set(names(db));
    for (const f of readdirSync(dir).filter((f) => f.endsWith(".csv") && f !== "table_docs.csv")) {
      const t = f.slice(0, -4);
      if (kept.has(t)) continue;
      mkdirSync(`${data}/dropped`, { recursive: true });
      renameSync(`${dir}/${f}`, `${data}/dropped/${t} ${today()}.csv`);
      out.push(`REMOVED table ${t} (its last export is in ${relative(cosm.package.folders.cosm, data)}/dropped/)`);
    }
    const tables = db.query(`SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' AND name <> 'table_docs' AND name NOT LIKE 'tmp\\_%' ESCAPE '\\' ORDER BY name`).all().map((r: any) => r.name as string);
    const views = names(db);
    const problems: string[] = [];
    for (const t of views) { const d = docOf(db, t) ?? ""; if (!(d.includes("Grain:") && d.includes("Scope:"))) problems.push(`MISSING DESCRIPTION table ${t}`); }
    for (const t of tables) {
      const cols = db.query("SELECT name, pk FROM pragma_table_info(?)").all(t) as any[];
      if (!cols.some((c) => c.pk > 0)) problems.push(`NO KEY table ${t}`);
      if (!cols.some((c) => c.name === "source")) problems.push(`NO SOURCE COLUMN table ${t}`);
    }
    for (const t of tables) for (const c of db.query("SELECT name FROM pragma_table_info(?)").all(t) as any[]) if (docOf(db, t, c.name) === undefined) problems.push(`MISSING DESCRIPTION column ${t}.${c.name}`);
    for (const t of tables) if (!db.query("SELECT 1 FROM pragma_table_list WHERE name = ? AND strict = 1").get(t)) problems.push(`NOT STRICT table ${t}`);
    out.push(...problems, problems.length ? "WRITTEN, but fix the lines above in this session (tables skill, Making a table)" : "OK");
    setTimeout(() => copies(), 0);
    return out;
  }

  /** A CSV copy of every table and of table_docs, each written whole before it replaces the old one. */
  function copies() {
    const db = reading();
    if (!db) return;
    const dir = `${data}/tables`;
    mkdirSync(dir, { recursive: true });
    const write = (name: string, sql: string) => {
      const q = db.query(sql);
      writeFileSync(`${dir}/${name}.csv.new`, toCsv(q.columnNames, q.values() as unknown[][]));
      renameSync(`${dir}/${name}.csv.new`, `${dir}/${name}.csv`);
    };
    for (const t of names(db)) write(t, `SELECT * FROM "${t}"`);
    write("table_docs", "SELECT * FROM table_docs ORDER BY tbl, col");
  }

  // --- for the pages ------------------------------------------------------------------------------------------------------

  /** The tables: [{name, doc, rows}]. */
  const all = () => {
    const db = reading();
    if (!db) return [];
    return names(db).map((name) => ({ name, doc: docOf(db, name) ?? null, rows: (db.query(`SELECT count(*) AS n FROM "${name}"`).get() as any).n as number }));
  };
  /** One table: {doc, rows, columns: [{name, type, doc}], newest: its newest 200 rows}. */
  const table = ({ table }: { table: string }) => {
      const db = reading();
      if (!db) return {};
      const t = named(db, table);
      const newest = (() => { try { return db.query(`SELECT * FROM "${t}" ORDER BY rowid DESC LIMIT ${MOST}`).all(); } catch { return db.query(`SELECT * FROM "${t}" LIMIT ${MOST}`).all(); } })();
      return { doc: docOf(db, t) ?? null, rows: (db.query(`SELECT count(*) AS n FROM "${t}"`).get() as any).n, newest,
        columns: (db.query("SELECT c.name, c.type, d.doc FROM pragma_table_info(?) c LEFT JOIN table_docs d ON d.tbl = ? AND d.col = c.name ORDER BY c.cid").all(t, t)) };
  };
  // Its views' functions, read again when the database changes (its journal too); one table is other packages' too.
  const changes = { data: "tables.db*" };
  cosm.package.export({ table });
  cosm.view.export({
    /** The file a [[Name]] in a table means. */
    which: { changes: {}, run: ({ name }: { name: string }) => cosm.file.which(name) },
    tables: { run: all, changes },
    table: { run: table, changes },
    /** The list page's rows: each table by its name as it reads ("card_expenses" is "Card expenses"), its description's
     * first line under it and how many rows at the right; tables sharing a prefix ("pf_accounts", "pf_balances") under
     * that prefix as a heading (PF), named without it; alphabetical, the ones alone first. */
    rows: { changes, run: () => {
      const list = all();
      const count: Record<string, number> = {};
      for (const t of list) { const m = /^([^_]+)_/.exec(t.name); if (m) count[m[1]] = (count[m[1]] ?? 0) + 1; }
      const alone: Row[] = [];
      const groups: Record<string, Row[]> = {};
      for (const t of list) {
        const line = (t.doc ?? "").split(/\n|(?<=\.)\s+(?=(?:Grain|Scope|Queries):)/).find((l) => /\S/.test(l) && !/^(Grain|Scope|Queries):/.test(l));
        const r: Row = { open: "tables:table", arg: `tables:table:${t.name}`, right: t.rows === 1 ? "1 row" : `${t.rows} rows`, ...(line ? { line } : {}) };
        const m = /^([^_]+)_(.+)$/.exec(t.name);
        if (m && count[m[1]] >= 2) (groups[m[1].toUpperCase()] ??= []).push({ ...r, label: words(m[2]), group: m[1].toUpperCase() });
        else alone.push({ ...r, label: words(t.name) });
      }
      const abc = (a: Row, b: Row) => String(a.label).toLowerCase().localeCompare(String(b.label).toLowerCase());
      return [...alone.sort(abc), ...Object.keys(groups).sort().flatMap((g) => groups[g].sort(abc))];
    } },
  });

  // --- the tables as things of the cosm ---------------------------------------------------------------------------------

  cosm.point.add("cosm:views", { name: "tables", file: "views/tables.html", label: "Tables", icon: "table" });
  cosm.point.add("cosm:views", { name: "table", file: "views/table.html", label: "Table", icon: "table", input: "thing" });
  cosm.point.add("cosm:items", { name: "tables", label: "Tables", content: { icon: "table", description: "Every table the agent keeps" }, action: { open: "tables:tables" },
    location: { in: "file-tree:tree" } });
  // Each table a thing for the index: its description with its columns as its lead, every doc as its text; listed again
  // when the database changes.
  cosm.point.add("cosm:kinds", { name: "table", label: "Table", view: "table", watch: relative(cosm.package.folders.cosm, file), items: () => {
    const db = reading();
    if (!db) return [];
    return names(db).map((t) => {
      const cols = (db.query("SELECT name FROM pragma_table_info(?)").all(t) as any[]).map((c) => c.name).join(", ");
      const docs = (db.query("SELECT doc FROM table_docs WHERE tbl = ?").all(t) as any[]).map((d) => d.doc).join(" ").replaceAll("\n", " ");
      return { key: t, name: t, lead: `${(docOf(db, t) ?? "").replaceAll("\n", " · ")} (columns: ${cols})`, text: docs };
    });
  } });
}

/** A table's name as it reads: "card_expenses" is "Card expenses", a unit at its end in brackets ("amount_sek": "Amount (SEK)"). */
function words(n: string): string {
  let unit = "";
  const m = /_(sek|usd|eur|gbp|nok|dkk|pct|kg|km)$/i.exec(n);
  if (m) { unit = m[1].toLowerCase() === "pct" ? "%" : m[1].toUpperCase(); n = n.slice(0, m.index); }
  const t = n.replaceAll("_", " ").trim();
  return t.charAt(0).toUpperCase() + t.slice(1) + (unit ? ` (${unit})` : "");
}

/** Rows as a Markdown table, as sqlite3 -markdown prints them. */
function markdown(cols: string[], rows: unknown[][]): string {
  const cell = (v: unknown) => (v === null || v === undefined ? "" : String(v)).replaceAll("|", "\\|").replaceAll("\n", " ");
  return [`| ${cols.join(" | ")} |`, `|${cols.map(() => "---").join("|")}|`, ...rows.map((r) => `| ${r.map(cell).join(" | ")} |`)].join("\n");
}

function toCsv(cols: string[], rows: unknown[][]): string {
  const cell = (v: unknown) => { const s = v === null || v === undefined ? "" : String(v); return /[",\n\r]/.test(s) ? `"${s.replaceAll('"', '""')}"` : s; };
  return [cols, ...rows].map((r) => r.map(cell).join(",")).join("\n") + "\n";
}

/** CSV as RFC 4180 has it: quoted cells with "" for a quote, a line break inside quotes kept. */
function parseCsv(t: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [], cell = "", quoted = false;
  for (let i = 0; i < t.length; i++) {
    const c = t[i];
    if (quoted) {
      if (c === '"' && t[i + 1] === '"') { cell += '"'; i++; }
      else if (c === '"') quoted = false;
      else cell += c;
    } else if (c === '"') quoted = true;
    else if (c === ",") { row.push(cell); cell = ""; }
    else if (c === "\n" || c === "\r") { if (c === "\r" && t[i + 1] === "\n") i++; row.push(cell); rows.push(row); row = []; cell = ""; }
    else cell += c;
  }
  if (cell !== "" || row.length) { row.push(cell); rows.push(row); }
  return rows.filter((r) => r.some((c) => c !== ""));
}

function today(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
