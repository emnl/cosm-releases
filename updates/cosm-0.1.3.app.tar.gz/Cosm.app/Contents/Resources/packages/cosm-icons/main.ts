// Cosm icons: Cosm's own icons, each kept as SVG text in icons.json and added to Cosm's icons here. Another package
// adds its own the same way, or stands in for one of these (`cosm part replace`).
import type { Cosm } from "cosm";
import icons from "./icons.json";

export default function (cosm: Cosm) {
  for (const [name, svg] of Object.entries(icons as Record<string, string>)) cosm.point.add("cosm:icons", { name, svg });
}
