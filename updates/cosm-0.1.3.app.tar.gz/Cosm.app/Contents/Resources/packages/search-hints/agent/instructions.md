## Search hints

Below a message, `<search-hints>` holds things in this cosm that may bear on it, one tag per kind (`<markdown:page>`, `<tables:table>`), each line its name, path, first line, the message's words it holds and when it last changed. They are chosen by the message's words, not read for you: read one before relying on it, and search when none fits. A short message, or one about nothing in the cosm, gets none; each thing comes once per session, and one you have read doesn't come again.
