// Search hints: with each message, the things in the cosm's ordinary search that bear on it, as hints for the agent
// ("read one before relying on it"). It reranks what the index retrieves by its own evidence, keeps what it hinted at
// in each session's storage and its floor in its own, and says what it brought with its event context.sent (the chat
// shows it as "Brought along"). What a package keeps out of ordinary search is that package's own: never seen here.
import type { Cosm, Retrieved } from "cosm";

/** The least evidence the best thing must have for any hint, until calibrated. */
const FLOOR = 1.0;
/** How many hints go with one message, at most. */
const MOST = 3;

/** A thing that may bear on a message: how many of its words it holds, its evidence, its bm25 (lower is better). */
interface Cand { thing: string; name: string; lead: string; kind: string; k: number; ev: number; bm: number; named: boolean; held: string[]; inName: Set<string> }
/** How a message meets ordinary search: what the index holds, each word's count, the candidates best first. */
interface Weighed { total: number; words: Retrieved["words"]; cands: Cand[] }

/** How much a word counts: near 1 on one thing of the cosm, near 0 on all of them. */
function weight(total: number, count: number): number {
  if (total < 1 || count < 1) return 0;
  return Math.max(0, Math.log((total + 1) / (count + 0.5))) / Math.log(total + 1);
}

export default function (cosm: Cosm) {
  cosm.package.uses("agent-session");
  /** A calibration running now: one at a time. */
  let calibrating = false;
  cosm.point.add("cosm:events", { name: "context.sent", description: "what went with a message: {session, message, things: [{name, path, kind}]} (session: Agent session's id; message: its id)" });

  /** Every thing holding two or more of the message's words, or one in its name, is a candidate (a thing the message
   * names is apart: it is always hinted at); its evidence is the sum of its words' weights, double in its name. */
  async function weigh(text: string): Promise<Weighed> {
    const r = await cosm.index.retrieve(text);
    const count = new Map(r.words.map((w) => [w.word, w.count]));
    const cands = r.things.flatMap((t) => {
      const inName = new Set(t.inName);
      if (!t.named && t.words.length < 2 && inName.size === 0) return [];
      const ev = t.words.reduce((s, w) => s + weight(r.total, count.get(w) ?? 0) * (inName.has(w) ? 2 : 1), 0);
      return [{ thing: t.thing, name: t.name, lead: t.lead, kind: t.kind ?? "", k: t.words.length, ev, bm: t.bm25, named: t.named, held: t.words, inName }];
    });
    return { total: r.total, words: r.words, cands };
  }

  /** The floor and how it was set: calibrated (in its storage), else its own. */
  async function floor(): Promise<[number, string]> {
    const v = await cosm.storage.get<{ value: number; how: string }>("floor");
    return typeof v?.value === "number" ? [v.value, v.how] : [FLOOR, "its own, not calibrated yet"];
  }

  /** The hints: what the message names, then the best candidate if it reaches the floor, and more up to MOST that
   * score at least half as well. */
  function pick(w: Weighed, shown: Set<string>, fl: number): [Cand[], Map<string, string>] {
    const why = new Map<string, string>();
    const out = w.cands.filter((c) => c.named && !shown.has(c.thing));
    const of = w.cands.filter((c) => !c.named);
    const best = of.find((c) => !shown.has(c.thing));
    if (best) {
      if (best.ev < fl) why.set(best.thing, "best, but under the floor");
      else for (const c of of) {
        if (out.length >= MOST) break;
        if (shown.has(c.thing) || out.some((x) => x.thing === c.thing)) continue;
        if (c.thing === best.thing || (best.bm < 0 && c.bm / best.bm >= 0.5)) out.push(c); else why.set(c.thing, "under half the best");
      }
    }
    return [out, why];
  }

  /** A session's own keys, in its storage (Agent session's): gone with the session. */
  const kept = (session: string) => ({
    get: async <T>(key: string) => (await cosm.call("agent-session:storage-get", { session, key })) as T | null,
    set: (key: string, value: unknown) => cosm.call("agent-session:storage-set", { session, key, value }),
    delete: (key: string) => cosm.call("agent-session:storage-delete", { session, key }),
  });
  /** What it hinted at in a session, and what the agent read there: never hinted at again in it. */
  const seen = async (session: string) => new Set((await kept(session).get<string[]>("seen")) ?? []);
  async function mark(session: string | undefined, things: string[]) {
    if (!session || !things.length) return;
    const s = await seen(session);
    for (const t of things) s.add(t);
    await kept(session).set("seen", [...s]);
  }

  // --- with each message -----------------------------------------------------------------------------------------

  cosm.point.add("agent:message", { name: "hints", run: async ({ text, session, message }: { text: string; session?: string; message?: string }) => {
    // A short message ("ok", "go on") brings no hints.
    if ([...text].length < 20) { await told(session, message, []); return; }
    const shown = session ? await seen(session) : new Set<string>();
    // The page open now (the view with a file used last, in any pane, as Open file tells it with the message): never
    // hinted at.
    const open = (await cosm.ui.shown()).filter((s) => s.path).sort((a, b) => b.used.localeCompare(a.used))[0]?.path;
    if (open) shown.add(open);
    const w = await weigh(text);
    const [hints] = pick(w, shown, (await floor())[0]);
    await mark(session, hints.map((c) => c.thing));
    await told(session, message, hints);
    // The floor again when the cosm has grown or shrunk by a twentieth since it was set, in the background.
    const at = (await cosm.storage.get<number>("calibrated-at")) ?? 0;
    if (!calibrating && (at === 0 || Math.abs(w.total - at) > at / 20)) void calibrate();
    return hints.length ? await block(hints) : undefined;
  } });

  // A file the agent read is never hinted at again in its session; a compacted session forgets what it was shown.
  cosm.on("agent:file.read", async ({ path, session }: { path?: unknown; session?: string }) => { if (typeof path === "string") await mark(session, [path]); });
  cosm.on("agent:started", async ({ reason, session }: { reason?: string; session?: string }) => { if (reason === "compact" && session) await kept(session).delete("seen"); });

  /** The hints as the agent gets them (its rules say what they are): one tag per kind, as Cosm names kinds
   * (`<markdown:page>`), each line the thing's name, path and first line, the message's words it holds, and when it
   * last changed. */
  async function block(hints: Cand[]): Promise<string> {
    const list = hints.map((c) => `'${c.thing.replaceAll("'", "''")}'`).join(", ");
    const changed = new Map((await cosm.index.query(`SELECT thing, modified FROM things WHERE thing IN (${list})`))
      .map((r) => [String(r.thing), new Date(Number(r.modified) * 1000).toISOString().slice(0, 10)]));
    const kinds = [...new Set(hints.map((c) => c.kind))];
    let out = "<search-hints>\n";
    for (const k of kinds) {
      const tag = k || "other";
      out += `<${tag}>\n`;
      for (const c of hints.filter((c) => c.kind === k)) {
        const lead = c.lead ? ` — ${c.lead.replaceAll("\n", " ")}` : "";
        const words = c.held.map((w) => (c.inName.has(w) ? `${w} (in its name)` : w));
        const matched = words.length ? ` · matched: ${words.join(", ")}` : "";
        const when = changed.has(c.thing) ? ` · changed ${changed.get(c.thing)}` : "";
        out += `- [[${c.name}]] (${c.thing})${lead}${matched}${when}\n`;
      }
      out += `</${tag}>\n`;
    }
    return out + "</search-hints>";
  }

  /** Tells who listens what went with the message, by its id and its session's (the chat: "Brought along"). */
  const told = (session: string | undefined, message: string | undefined, of: Cand[]) =>
    cosm.emit("context.sent", { ...(session ? { session } : {}), ...(message ? { message } : {}), things: of.map((c) => ({ name: c.name, path: c.thing, kind: c.kind })) });

  // --- explaining and calibrating ----------------------------------------------------------------------------------

  cosm.point.add("cosm:commands", { name: "explain",
    description: "What a message would bring as hints, and why: the floor, each word's weight, the candidates and the hints.",
    inputs: [{ name: "message", label: "Message", type: "list" }],
    run: async ({ message }) => {
      const w = await weigh(message.join(" "));
      const [fl, how] = await floor();
      const [hints, why] = pick(w, new Set(), fl);
      let out = `items in index: ${w.total}\nfloor: ${fl.toFixed(2)} (${how})\nword\tform\tfound in\tweight\n`;
      for (const x of w.words) out += `${x.word}\t${x.form}\t${x.count}\t${weight(w.total, x.count).toFixed(2)}\n`;
      for (const c of w.cands.filter((c) => c.named)) out += `named in the message: ${c.thing}\n`;
      for (const c of w.cands.filter((c) => !c.named).slice(0, 12)) {
        const r = hints.some((h) => h.thing === c.thing) ? "hint" : why.get(c.thing) ?? "the best is under the floor";
        out += `candidate: ${c.k} words, evidence ${c.ev.toFixed(2)}, bm25 ${c.bm.toFixed(2)}: ${c.thing} (${r})\n`;
      }
      for (const c of hints) out += `would attach: ${c.thing}\t${c.name}\n`;
      return out;
    },
  });

  cosm.point.add("cosm:commands", { name: "calibrate",
    description: "Sets the floor again: every page's first line should find its page, the everyday messages nothing.",
    run: async () => { await calibrate(); return (await floor())[1]; },
  });

  /** Sets the floor from a test of the cosm itself: every page's first line should find that page, and the everyday
   * messages (its everyday/ folder, one a line) should find nothing. The floor keeps the most of the first and the
   * fewest of the second, a first one missed counting double, between 0.6 and 3. */
  async function calibrate() {
    if (calibrating) return;
    calibrating = true;
    try { await calibrateNow(); } finally { calibrating = false; }
  }
  async function calibrateNow() {
    // When it was set, whatever comes of it: a cosm too small to calibrate on keeps the default floor, and isn't tried
    // again with every message, only once it has grown by a twentieth.
    const total = (await cosm.index.retrieve("calibrate the floor")).total;
    await cosm.storage.set("calibrated-at", Math.max(total, 1));
    const everyday: string[] = [];
    for (const f of new Bun.Glob("*.txt").scanSync(`${cosm.package.folders.package}/everyday`)) {
      everyday.push(...(await Bun.file(`${cosm.package.folders.package}/everyday/${f}`).text()).split("\n").map((l) => l.trim()).filter((l) => l && !l.startsWith("#")));
    }
    if (!everyday.length) return;
    const leads = (await cosm.index.query("SELECT thing, lead FROM things WHERE length(lead) >= 20 ORDER BY thing LIMIT 300")).map((r) => [String(r.thing), String(r.lead)] as const);
    // A probe like a real message about the page: its first line's three most telling words, counted when it singles
    // the page out (the best candidate, ahead of the next). A page out of ordinary search never comes first: left out.
    const pos: number[] = [];
    for (const [p, l] of leads) {
      const whole = await weigh(l);
      const ws = whole.words.map((x) => [x.word, weight(whole.total, x.count)] as const).filter(([, v]) => v > 0).sort((a, b) => b[1] - a[1]);
      if (ws.length < 2) continue;
      const a = await weigh(ws.slice(0, 3).map(([x]) => x).join(" "));
      if (a.cands.some((c) => c.named && c.thing === p)) continue;
      const of = a.cands.filter((c) => !c.named);
      if (of[0]?.thing !== p || (of[1] && of[1].bm <= of[0].bm + 1e-9)) continue;
      pos.push(of[0].ev);
    }
    const neg: number[] = [];
    for (const m of everyday) neg.push((await weigh(m)).cands.find((c) => !c.named)?.ev ?? 0);
    if (!pos.length) return;
    const steps = [...pos, ...neg].map((v) => v + 0.001).concat(0.6).sort((a, b) => a - b).filter((f) => f >= 0.6 && f <= 3);
    let best: [number, number] = [FLOOR, -Infinity];
    for (const f of steps) {
      // A page missed counts double an everyday message let through: a missed page costs the agent a search, an extra
      // one only a line.
      const score = 2 * (pos.filter((e) => e >= f).length / pos.length) - neg.filter((e) => e >= f).length / neg.length;
      if (score >= best[1]) best = [f, score];
    }
    const kept = pos.filter((e) => e >= best[0]).length;
    const passed = neg.filter((e) => e >= best[0]).length;
    const how = `calibrated on ${leads.length} pages: ${kept} of ${pos.length} first lines find their page, ${passed} of ${neg.length} everyday messages find one`;
    await cosm.storage.set("floor", { value: Math.round(best[0] * 1000) / 1000, how });
  }
}
