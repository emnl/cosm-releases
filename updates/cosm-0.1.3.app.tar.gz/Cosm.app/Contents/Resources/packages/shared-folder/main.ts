// Shared Folders: folders outside the cosm (a shared Google Drive folder, ~/Documents/Company) connected by name and
// worked on where they live: Cosm is one more way into them, never their owner. One sidebar row and its view: the
// connected folders, Add Folder… (Drive's folders offered first), each browsed a level at a time, a file opened in Cosm
// when one of its kinds shows it, else as a card with Open in its own app. Connecting is the engine's (`cosm root …`, cosm.root): this
// package only shows it. Nothing in a folder is read until the user browses it or opens a file; none is searched.
import type { Cosm } from "cosm";
import { readdir, stat } from "node:fs/promises";
import { homedir } from "node:os";
import { join } from "node:path";

/** Where the Mac keeps cloud drives' folders (Google Drive, Dropbox, OneDrive): offered first. */
const CLOUD = join(homedir(), "Library/CloudStorage");
/** A level with more than this many entries is shown in pages. */
const PAGE = 300;

type Row = { name: string; path: string; folder: boolean; size: number; modified: number };

export default function (cosm: Cosm) {
  cosm.point.add("cosm:views", { name: "folders", file: "views/folders.html", label: "Shared Folders", icon: "folder" });
  cosm.point.add("cosm:items", { name: "open", label: "Shared Folders", content: { icon: "folder" },
    action: { open: "shared-folder:folders" }, location: { in: "file-tree:tree" } });

  // A connected folder opened anywhere (a page's path in the toolbar, the agent's `cosm ui open @company/Board`): shown here.
  cosm.on("folder.opened", (e) => { const folder = String((e as { folder?: string }).folder ?? ""); if (/^@[\p{L}\p{N}-]+(\/|$)/u.test(folder)) void cosm.ui.open("shared-folder:folders", folder); });

  /** The levels a view shows, watched, with how to stop. */
  const watching = new Map<string, () => Promise<void>>();

  /** One level of a connected folder (`@company/Board`), folders first, then by name; `limit` entries at most. */
  async function level({ path, limit = PAGE }: { path: string; limit?: number }) {
    if (!path) return null;
    const at = await cosm.root.path(path);
    const entries = (await readdir(at, { withFileTypes: true })).filter((e) => !e.name.startsWith("."));
    entries.sort((a, b) => Number(b.isDirectory()) - Number(a.isDirectory()) || a.name.localeCompare(b.name));
    const rows: Row[] = await Promise.all(entries.slice(0, limit).map(async (e) => {
      const s = await stat(join(at, e.name)).catch(() => null);
      return { name: e.name, path: `${path}/${e.name}`, folder: e.isDirectory(), size: s?.size ?? 0, modified: Math.floor((s?.mtimeMs ?? 0) / 1000) };
    }));
    return { rows, total: entries.length };
  }

  /** Cloud drives on this Mac and their folders not connected yet, a drive a group named by its service and account
   * (`Google Drive · anna@acme.com`): Google Drive's My Drive and each shared drive, Dropbox's and OneDrive's own. */
  async function suggestions() {
    const connected = new Set((await cosm.root.list()).map((r) => r.path));
    const groups: { label: string; folders: { name: string; path: string }[] }[] = [];
    for (const d of (await readdir(CLOUD).catch(() => [] as string[])).sort()) {
      if (d.startsWith(".")) continue;
      // The folder's name is the service, then the account (`GoogleDrive-anna@acme.com`, `OneDrive-Acme`).
      const [service, ...rest] = d.split("-");
      const label = [service!.replace(/([a-z])([A-Z])/g, "$1 $2"), rest.join("-")].filter(Boolean).join(" · ");
      const folders: { name: string; path: string }[] = [];
      if (d.startsWith("GoogleDrive-")) {
        folders.push({ name: "My Drive", path: join(CLOUD, d, "My Drive") });
        for (const s of (await readdir(join(CLOUD, d, "Shared drives")).catch(() => [] as string[])).sort()) if (!s.startsWith(".")) folders.push({ name: s, path: join(CLOUD, d, "Shared drives", s) });
      } else folders.push({ name: label, path: join(CLOUD, d) });
      const left = folders.filter((f) => !connected.has(f.path));
      if (left.length) groups.push({ label, folders: left });
    }
    return groups;
  }

  // Its view's functions.
  return cosm.view.export({
    roots: { description: "The connected folders.", changes: { events: ["root.changed"] }, run: () => cosm.root.list() },
    level: { description: "One level of a connected folder, folders first.", changes: { files: "@*/**" }, run: level },
    suggestions: { description: "Cloud drives' folders on this Mac, not connected yet.", changes: { events: ["root.changed"] }, run: suggestions },
    /** The level the view shows, watched while it does (a change there loads `level` again); `null`: none. */
    watch: async ({ path }: { path: string | null }) => {
      for (const [p, stop] of watching) if (p !== path) { watching.delete(p); await stop(); }
      if (path && !watching.has(path)) watching.set(path, await cosm.root.watch(path));
    },
    /** Connects a folder: one the view offered, or one the user chooses. */
    add: async ({ path }: { path?: string } = {}) => {
      const f = path ?? await cosm.ui.ask("Choose a folder to connect", { answer: "folder" });
      if (!f) return null;
      const r = await cosm.root.add(f);
      return r;
    },
    remove: async ({ id, name }: { id: string; name: string }) => {
      const yes = await cosm.ui.ask(`Remove ${name} from Cosm?`, { description: "Its files stay where they are. You can connect it again any time.", choices: ["Remove", "Cancel"] });
      if (yes !== "Remove") return false;
      await cosm.root.remove(id);
      return true;
    },
    locate: async ({ id, name }: { id: string; name: string }) => {
      const f = await cosm.ui.ask(`Where is ${name} on this Mac?`, { answer: "folder" });
      if (!f) return null;
      const r = await cosm.root.locate(id, f);
      return r;
    },
  });
}
