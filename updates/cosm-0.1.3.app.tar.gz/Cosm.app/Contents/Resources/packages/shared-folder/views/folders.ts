// Shared Folders' view: the connected folders, each browsed a level at a time (the level shown is watched while it
// is: a change there shows by itself), Add Folder… with the Mac's cloud drives offered first, and Remove or Locate…
// on each. A file opens as any file does (`open`): in Cosm when one of its kinds shows it, else a card with Open in its
// own app.
import { html, live, show, state, view } from "cosm/view";
import type { ApiOf } from "cosm";
import type main from "../main.ts";

const cosm = view<ApiOf<typeof main>>();
const roots = live(cosm.main.roots);
const offered = live(cosm.main.suggestions);
/** The level shown (`@company/Board`), or none: the list of folders. It is the view's argument: a row opens this
 * view on a folder (a list's rows open, they hold no handlers of their own), so back and forward work as anywhere. */
const limit = state(300);
const at = state<string | null>(cosm.view.arg || null);
cosm.on("view.opened", ({ arg }: { arg?: string | null }) => { if ((arg || null) !== at.value) { limit.value = 300; at.value = arg || null; } });
// Opened with nothing (the sidebar's row from inside a folder), or put away: the folders' list, as it starts.
cosm.on("view.closed", () => { if (at.value !== null) { limit.value = 300; at.value = null; } });
const level = live(cosm.main.level, () => ({ path: at.value ?? "", limit: limit.value }));

// The level shown is watched while it is, and only it.
at.subscribe(() => { void cosm.main.watch({ path: at.value }).catch(() => {}); });
addEventListener("pagehide", () => { void cosm.main.watch({ path: null }); });

const VIEW = "shared-folder:folders";
const size = (n: number) => n < 1024 ? `${n} B` : n < 1024 ** 2 ? `${Math.round(n / 1024)} KB` : `${(n / 1024 ** 2).toFixed(1)} MB`;
const when = (s: number) => (s ? new Date(s * 1000).toISOString().slice(0, 16) : "");
const tried = async (f: () => Promise<unknown>) => { try { await f(); } catch (e) { await cosm.ui.notify(e instanceof Error ? e.message : String(e), { as: "problem" }); } };

show("#root", () => {
  if (at.value) {
    const l = level.value;
    return html`
      <main class="cosm-page-body cosm-stack">
        ${level.status === "loading" ? html`<div aria-hidden="true"><div class="cosm-skeleton line"></div><div class="cosm-skeleton line"></div></div>`
        : level.status === "failed" && !l ? html`<div class="cosm-empty" role="status"><p class="cosm-empty-title">Can't open this folder</p><p class="cosm-empty-line">${level.error?.message}</p></div>`
        : !l?.rows.length ? html`<div class="cosm-empty"><p class="cosm-empty-line">This folder is empty.</p></div>`
        : html`<cosm-list>${l.rows.map((r) => r.folder
            ? html`<cosm-item label=${r.name} icon="folder" open=${VIEW} arg=${r.path}></cosm-item>`
            : html`<cosm-item label=${r.name} open=${r.path} line=${size(r.size)} date=${when(r.modified)}></cosm-item>`)}</cosm-list>
          ${l.total > l.rows.length ? html`<p class="cosm-caption">${l.rows.length} of ${l.total} shown. <button class="cosm-button small" @click=${() => { limit.value += 300; }}>Show more</button></p>` : ""}`}
      </main>`;
  }
  const list = roots.value ?? [];
  const more = offered.value ?? [];
  return html`
    <header class="cosm-page-head">
      <div><h1 class="cosm-page-title">Shared Folders</h1>
        <p class="cosm-caption">Folders outside your cosm, opened where they live. Saving goes straight to the folder, and Drive or Dropbox syncs it as always. They aren't searched or in the file tree.</p></div>
      <div class="cosm-page-head-actions"><button class="cosm-button primary" @click=${() => tried(() => cosm.main.add({}))}>Add Folder…</button></div>
    </header>
    <main class="cosm-page-body cosm-stack">
      ${roots.status === "loading" ? html`<div aria-hidden="true"><div class="cosm-skeleton line"></div></div>`
      : !list.length ? html`<div class="cosm-empty"><p class="cosm-empty-line">No folders connected yet.</p></div>`
      : html`<cosm-list>${list.map((r) => html`
          <cosm-item label=${r.name} icon="folder" line=${r.reachable ? `@${r.id}` : `Can't be reached${r.path ? `: ${r.path}` : " on this Mac"}`} open=${r.reachable ? VIEW : ""} arg=${r.reachable ? `@${r.id}` : ""}>
            ${r.reachable ? "" : html`<button slot="actions" class="cosm-button small" @click=${(e: Event) => { e.stopPropagation(); void tried(() => cosm.main.locate({ id: r.id, name: r.name })); }}>Locate…</button>`}
            <button slot="actions" class="cosm-button small" @click=${(e: Event) => { e.stopPropagation(); void tried(() => cosm.main.remove({ id: r.id, name: r.name })); }}>Remove</button>
          </cosm-item>`)}</cosm-list>`}
      ${more.map((g) => html`<div class="cosm-label-head">${g.label}</div>
        <cosm-list>${g.folders.map((f) => html`
          <cosm-item label=${f.name} icon="folder">
            <button slot="actions" class="cosm-button small" @click=${() => tried(() => cosm.main.add({ path: f.path }))}>Connect</button>
          </cosm-item>`)}</cosm-list>`)}
    </main>`;
});
