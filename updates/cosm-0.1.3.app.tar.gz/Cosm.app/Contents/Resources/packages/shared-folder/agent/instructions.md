# Shared Folders

Shared Folders is the user's place for connected folders: a row in the sidebar whose view lists them, connects one (cloud drives' folders offered first) and browses each a level at a time. Point the user there to connect, remove or find one again.
