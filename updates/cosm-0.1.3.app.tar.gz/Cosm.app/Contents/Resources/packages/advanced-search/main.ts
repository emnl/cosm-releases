// Advanced search: each word's form for the index (Snowball's stemmers), the small words of a language ("glue words",
// Snowball's stop words, in glue/) left out, and words found inside longer ones; and which languages the cosm's pages
// are written in.
import type { Cosm } from "cosm";
import { existsSync, readdirSync, readFileSync, statSync, writeFileSync } from "node:fs";
import snowball from "snowball-stemmers";
import { shape } from "cosm/shape";

/** The languages it has stemmers and glue words for. */
const LANGS = ["arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian", "italian", "norwegian",
  "portuguese", "romanian", "russian", "spanish", "swedish", "tamil", "turkish"];

export default function (cosm: Cosm) {
  const glueOf = (l: string) => {
    const f = `${cosm.package.folders.package}/glue/${l}.txt`;
    return existsSync(f) ? readFileSync(f, "utf8").split(/\s+/).filter(Boolean) : [];
  };
  const glue = new Map(LANGS.map((l) => [l, new Set(glueOf(l))]));
  /** Each language's glue words no other language has: how a language is told in a page. */
  const owners = new Map<string, number>();
  for (const s of glue.values()) for (const w of s) owners.set(w, (owners.get(w) ?? 0) + 1);
  const unique = new Map([...glue].map(([l, s]) => [l, [...s].filter((w) => owners.get(w) === 1)]));

  cosm.point.add("cosm:settings", { name: "languages",
    shape: shape.string(),
    default: "auto",
    label: "Languages",
    description: "The languages your pages are written in, for word forms and glue words: auto finds them from your pages; or name them, as english swedish.",
    question: "Which languages are your pages written in?",
    current: () => languages(),
  });

  /** The languages to use: those the setting names, or the ones found in the pages for "auto". */
  async function languages(): Promise<string[]> {
    const named = String((await cosm.setting.get("languages")) ?? "").split(/[ ,]/).map((s) => s.trim().toLowerCase()).filter((s) => LANGS.includes(s));
    return [...new Set(named.length ? named : detect())].sort();
  }

  /** The languages the cosm's pages are written in: each whose own glue words are common enough (below); English when
   * none is. Read from the pages themselves (not the index, which depends on it), kept in the cache, and found again
   * only while the cosm is small (under 5 000 words) and its pages change in number, so a grown cosm's languages stay
   * put and its index isn't rebuilt for a passing change. */
  let lately: { at: number; langs: string[] } | null = null;
  function detect(): string[] {
    // Not looked for again within a few seconds: each batch of new words asks.
    if (lately && Date.now() - lately.at < 10_000) return lately.langs;
    const langs = detectNow();
    lately = { at: Date.now(), langs };
    return langs;
  }
  function detectNow(): string[] {
    const cached = `${cosm.package.folders.cache}/languages`;
    const pages = pageFiles(cosm.package.folders.cosm);
    let before: string[] = [];
    if (existsSync(cached)) {
      const [w, n, l] = readFileSync(cached, "utf8").trimEnd().split("\t", 3);
      if (l !== undefined) {
        if (Number(w) >= 5000 || n === String(pages.length)) return l.split(" ");
        before = l.split(" ");
      }
    }
    const counts = new Map<string, number>();
    let total = 0;
    for (const p of pages) {
      for (const t of readFileSync(p, "utf8").toLowerCase().split(/[^\p{L}\p{N}]+/u)) { if (!t) continue; total++; counts.set(t, (counts.get(t) ?? 0) + 1); }
    }
    const found: string[] = [];
    if (total > 0) {
      for (const l of LANGS) {
        // At least 0.6 % of the words, from at least 6 different words of its own (a few Italian "per" and "come" in
        // English text are not Italian); a language found before stays down to 0.3 % and 4 words. Measured on real
        // cosms: Swedish 0.98 % / 7 words in a small mostly English cosm, noise at most 0.84 % / 4.
        const own = (unique.get(l) ?? []).map((w) => counts.get(w) ?? 0).filter((c) => c > 0);
        const n = own.reduce((a, b) => a + b, 0);
        const enough = before.includes(l) ? n * 1000 >= total * 3 && own.length >= 4 : n * 1000 >= total * 6 && own.length >= 6;
        if (enough) found.push(l);
      }
    }
    found.sort();
    if (!found.length) found.push("english");
    writeFileSync(cached, `${total}\t${pages.length}\t${found.join(" ")}\n`);
    return found;
  }

  /** A word's form: nothing for a glue word of one of the languages; else the shortest of its stems in them and, for a
   * word of 7 letters or more, the word less its last 2 (an ending the stemmer keeps: "stämman" stems to itself; cut,
   * it meets "stämmor" and "stämma", which stem to "stämm"). */
  cosm.point.add("cosm:stems", { name: "stems", compounds: true, stems: async ({ words }) => {
    const langs = await languages();
    const stemmers = langs.map((l) => snowball.newStemmer(l));
    const gl = new Set(langs.flatMap((l) => [...(glue.get(l) ?? [])]));
    return words.map((w) => {
      if (gl.has(w)) return "";
      const len = (s: string) => [...s].length;
      let best = w;
      for (const s of stemmers) { const x = s.stem(w); if (len(x) < len(best)) best = x; }
      const n = len(w);
      if (n >= 7 && n - 2 < len(best)) best = [...w].slice(0, n - 2).join("");
      return len(best) < 3 ? w : best;
    });
  } });

  cosm.point.add("cosm:commands", { name: "languages", description: "The languages search uses for word forms and glue words: those the setting names, or for auto the ones found in the pages.", run: () => languages() });
}

/** Every page of the cosm: Markdown files outside hidden folders. */
function pageFiles(dir: string, out: string[] = []): string[] {
  for (const e of readdirSync(dir)) {
    if (e.startsWith(".")) continue;
    const p = `${dir}/${e}`;
    const s = statSync(p, { throwIfNoEntry: false });
    if (s?.isDirectory()) pageFiles(p, out); else if (s?.isFile() && e.endsWith(".md")) out.push(p);
  }
  return out;
}
