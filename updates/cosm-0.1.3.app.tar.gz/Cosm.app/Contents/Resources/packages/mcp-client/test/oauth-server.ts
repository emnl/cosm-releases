// A small MCP server over HTTP that wants a sign-in (the MCP spec's OAuth), for trying MCP client with OAuth without any
// outside service: it says where its sign-in server is (itself), lets a client register, sends the browser straight
// back with a code, and answers MCP's calls only with the token it gave. Prints its port; counts what it was asked on
// stderr (`registered`, `token <grant>`).
const TOKEN = "t1";
let base = "";
const json = (v: unknown, status = 200) => new Response(JSON.stringify(v), { status, headers: { "content-type": "application/json" } });
const server = Bun.serve({ hostname: "127.0.0.1", port: 0, async fetch(req) {
  const u = new URL(req.url);
  if (u.pathname === "/.well-known/oauth-protected-resource" || u.pathname === "/.well-known/oauth-protected-resource/mcp")
    return json({ resource: `${base}/mcp`, authorization_servers: [base] });
  if (u.pathname === "/.well-known/oauth-authorization-server")
    return json({ issuer: base, authorization_endpoint: `${base}/authorize`, token_endpoint: `${base}/token`, registration_endpoint: `${base}/register`,
      response_types_supported: ["code"], grant_types_supported: ["authorization_code", "refresh_token"], code_challenge_methods_supported: ["S256"], token_endpoint_auth_methods_supported: ["none"] });
  if (u.pathname === "/register") { console.error("registered"); return json({ ...(await req.json()), client_id: "cosm-1" }, 201); }
  if (u.pathname === "/authorize") {
    const back = new URL(u.searchParams.get("redirect_uri")!);
    back.searchParams.set("code", "c1");
    back.searchParams.set("state", u.searchParams.get("state") ?? "");
    return Response.redirect(back.toString(), 302);
  }
  if (u.pathname === "/token") {
    const f = new URLSearchParams(await req.text());
    console.error(`token ${f.get("grant_type")}`);
    if (f.get("grant_type") === "authorization_code" && f.get("code") === "c1" && f.get("code_verifier") && f.get("client_id") === "cosm-1")
      return json({ access_token: TOKEN, refresh_token: "r1", expires_in: 3600, token_type: "Bearer" });
    return json({ error: "invalid_grant" }, 400);
  }
  if (u.pathname === "/mcp") {
    if (req.headers.get("authorization") !== `Bearer ${TOKEN}`)
      return new Response("", { status: 401, headers: { "www-authenticate": `Bearer resource_metadata="${base}/.well-known/oauth-protected-resource"` } });
    if (req.method !== "POST") return new Response("", { status: 405 });
    const m = await req.json();
    if (m.id === undefined) return new Response("", { status: 202 });
    const result = m.method === "initialize"
      ? { protocolVersion: m.params.protocolVersion, capabilities: { tools: {} }, serverInfo: { name: "notes", version: "1.0.0" } }
      : m.method === "tools/list" ? { tools: [{ name: "find", description: "Finds a note.", inputSchema: { type: "object", properties: {} } }] }
      : m.method === "tools/call" ? { content: [{ type: "text", text: "found it" }] } : {};
    return json({ jsonrpc: "2.0", id: m.id, result });
  }
  return new Response("", { status: 404 });
} });
base = `http://127.0.0.1:${server.port}`;
console.log(server.port);
