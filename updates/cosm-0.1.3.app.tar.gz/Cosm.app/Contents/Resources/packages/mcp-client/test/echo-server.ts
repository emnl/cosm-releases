// A small MCP server over stdio, for trying the MCP package without any outside code: `add` answers data
// (structuredContent), `hello` text, `fail` an error.
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

const server = new McpServer({ name: "echo", version: "1.0.0" });
server.registerTool("add", { description: "Adds two numbers.", inputSchema: { a: z.number(), b: z.number() }, outputSchema: { sum: z.number() } },
  async ({ a, b }) => ({ content: [{ type: "text", text: String(a + b) }], structuredContent: { sum: a + b } }));
server.registerTool("hello", { description: "Says hello.", inputSchema: { name: z.string() } }, async ({ name }) => ({ content: [{ type: "text", text: `Hello, ${name}!` }] }));
server.registerTool("fail", { description: "Always fails." }, async () => ({ content: [{ type: "text", text: "it failed on purpose" }], isError: true }));
console.error("echo server ready");
await server.connect(new StdioServerTransport());
