// MCP client: packages use outside MCP servers. The servers are the agent's (every one Cosm gives it, `agent:mcp`, and those it
// has from its own setup, as its connector says: Claude Code's `claude mcp add`, Gemini CLI's settings) and any a package adds to `mcp-client:servers` (a program on this Mac
// speaking MCP on its stdin and stdout, or an address over HTTP); any package then lists their tools and calls them
// through this one (`cosm.call("mcp-client:call", { server, tool, args })`), so a view or a button reaches what the agent
// reaches in its chat.
// Connections are made on first use and kept while the package runs; it stops with them when nothing needs it.
//
// A server over HTTP that wants the user's sign-in (the MCP spec's OAuth) gets it through the user's default sign-in
// (cosm-points:sign-in, OAuth's), by its address alone: the token comes back and the connection is made again with it.
import type { Cosm } from "cosm";
import { UnauthorizedError } from "@modelcontextprotocol/sdk/client/auth.js";
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioClientTransport } from "@modelcontextprotocol/sdk/client/stdio.js";
import { StreamableHTTPClientTransport } from "@modelcontextprotocol/sdk/client/streamableHttp.js";

/** A server as a package adds it: a program (with its arguments and variables), or an address (with headers); `from`
 * where it was found (a package's name, `the agent`, `.mcp.json`). */
type Server = { name: string; label?: string; program?: string; args?: string[]; env?: Record<string, string>; url?: string; headers?: Record<string, string>; from?: string };

export default function (cosm: Cosm) {
  cosm.package.uses("agent");
  cosm.package.uses("cosm-points", { if: "on" });
  cosm.point.define("servers", {
    description: "An MCP server packages can call: { name, label?, program, args?, env? } (a program on this Mac, its path in full or on the PATH, speaking MCP on stdin and stdout) or { name, label?, url, headers? } (over HTTP).",
    label: "MCP servers", holds: "values",
  });

  const open = new Map<string, Promise<Client>>();
  /** Every server: the packages' (`mcp-client:servers`), then what Cosm gives the agent, then each agent's own; a name taken earlier is
   * left out. Cosm's own server (`cosm`) isn't one: a package reaches Cosm directly. */
  async function servers(): Promise<(Server & { package: string })[]> {
    const out: (Server & { package: string })[] = ((await cosm.point.read<Server>("mcp-client:servers")) as (Server & { package: string })[]).map((s) => ({ ...s, from: s.package }));
    const add = (s: Server & { package: string }) => { if (s.name !== "cosm" && !out.some((x) => x.name === s.name)) out.push(s); };
    try {
      const share = await cosm.call<{ mcp: Server[] }>("agent:share");
      for (const s of share.mcp ?? []) add({ ...s, package: "agent", from: "the agent" });
    } catch (e) { cosm.log(`the agent's servers weren't read: ${e instanceof Error ? e.message : e}`); }
    // What each agent has from its own setup (its connector says: Claude Code's .mcp.json and ~/.claude.json, Gemini
    // CLI's settings.json).
    for (const a of await cosm.point.read<{ label: string; servers?: () => Promise<Server[]> }>("agent:agents").catch(() => [])) {
      if (typeof a.servers !== "function") continue;
      try { for (const s of await a.servers()) add({ ...s, package: a.package, from: a.label }); }
      catch (e) { cosm.log(`${a.label}'s servers weren't read: ${e instanceof Error ? e.message : e}`); }
    }
    return out;
  }
  async function server(name: string) {
    const all = await servers();
    const s = all.find((x) => x.name === name) ?? all.find((x) => `${x.package}:${x.name}` === name);
    if (!s) throw new Error(`no MCP server called ${name} (${all.map((x) => x.name).join(", ") || "none added"}: cosm mcp-client:servers)`);
    return s;
  }
  /** Whether what a server said means it wants a sign-in. */
  const wantsSignIn = (e: unknown) => e instanceof UnauthorizedError || (e as { code?: unknown })?.code === 401 || /\b401\b|unauthori[sz]ed/i.test(e instanceof Error ? e.message : String(e));
  /** A token for a server that wants a sign-in, from the user's default sign-in. */
  async function signIn(s: Server): Promise<string> {
    const by = await cosm.point.default<{ server?: (a: { url: string; label?: string }) => Promise<string> }>("cosm-points:sign-in").catch(() => null);
    if (typeof by?.server !== "function") throw new Error(`${s.label ?? s.name} wants a sign-in, and no sign-in package that signs in to MCP servers is on (OAuth does)`);
    return by.server({ url: s.url!, label: s.label ?? s.name });
  }
  /** A connection to it: made once, made again when it went (its program ended, the address closed). A server over
   * HTTP that wants a sign-in is connected again with the token the user's sign-in gives. */
  function client(s: Server): Promise<Client> {
    const had = open.get(s.name);
    if (had) return had;
    const made = (async () => {
      // A server that wanted a sign-in before gets its token from the start.
      const signs = (await cosm.storage.get<string[]>("signs-in")) ?? [];
      if (s.url && signs.includes(s.url)) return connect(s, await signIn(s));
      try { return await connect(s); }
      catch (e) {
        if (!s.url || !wantsSignIn(e) || Object.keys(s.headers ?? {}).some((h) => h.toLowerCase() === "authorization")) throw e;
        const c = await connect(s, await signIn(s));
        await cosm.storage.set("signs-in", [...new Set([...signs, s.url])]);
        return c;
      }
    })();
    open.set(s.name, made);
    made.catch(() => open.delete(s.name));
    return made;
  }
  async function connect(s: Server, token?: string): Promise<Client> {
    const c = new Client({ name: "cosm", version: "0.1.0" });
    const headers = { ...(s.headers ?? {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) };
    const t = s.url ? new StreamableHTTPClientTransport(new URL(s.url), { requestInit: { headers } })
      : new StdioClientTransport({ command: s.program!, args: s.args ?? [], env: { ...(process.env as Record<string, string>), ...(s.env ?? {}) }, stderr: "pipe" });
    // What a program says on stderr goes to this package's log (why it didn't start, its warnings).
    if (t instanceof StdioClientTransport) t.stderr?.on("data", (b: Buffer) => { for (const l of String(b).split("\n")) if (l.trim()) cosm.log(`${s.name}: ${l.trim()}`); });
    c.onclose = () => open.delete(s.name);
    c.onerror = (e) => cosm.log(`${s.name}: ${e.message}`);
    try { await c.connect(t, { signal: AbortSignal.timeout(20_000) }); }
    catch (e) {
      if (wantsSignIn(e) && !token) throw e;
      throw new Error(`${s.label ?? s.name} didn't connect: ${e instanceof Error ? e.message : String(e)}`);
    }
    return c;
  }
  /** Something done with a server's connection; when its token ran out meanwhile, the connection is made again (the
   * sign-in renews it) and it is done once more. */
  async function using<T>(name: string, run: (c: Client) => Promise<T>): Promise<T> {
    const s = await server(name);
    try { return await run(await client(s)); }
    catch (e) {
      if (!s.url || !wantsSignIn(e)) throw e;
      open.delete(s.name);
      return run(await client(s));
    }
  }
  cosm.on("package.stopping", async () => { for (const c of open.values()) await (await c.catch(() => null))?.close().catch(() => {}); });

  /** Its tools: name, what it does, and its input's shape. */
  async function tools({ server: name }: { server: string }) {
    return using(name, async (c) => {
      const out: { name: string; description?: string; inputSchema: unknown }[] = [];
      let cursor: string | undefined;
      do { const r = await c.listTools(cursor ? { cursor } : {}); out.push(...r.tools.map((t) => ({ name: t.name, description: t.description, inputSchema: t.inputSchema }))); cursor = r.nextCursor; } while (cursor);
      return out;
    });
  }
  /** One of its tools, called: its answer as the server gives it (content, structuredContent when it gives data,
   * isError). */
  async function call({ server: name, tool, args }: { server: string; tool: string; args?: Record<string, unknown> }) {
    return using(name, (c) => c.callTool({ name: tool, arguments: args ?? {} }, undefined, { signal: cosm.signal, timeout: 60_000 }));
  }
  const list = async () => (await servers()).map((s) => ({ name: s.name, label: s.label ?? s.name, from: s.from ?? s.package, how: s.url ? s.url : [s.program, ...(s.args ?? [])].join(" ") }));
  cosm.package.export({ servers: list, tools, call });

  // The agent's and the shell's.
  cosm.point.add("cosm:commands", { name: "servers", description: "The MCP servers packages can call: name, where it comes from (a package, the agent, .mcp.json), how it is reached.",
    run: async () => (await list()).map((s) => `${s.name}\t${s.from}\t${s.how}`).join("\n") || "none" });
  cosm.point.add("cosm:commands", { name: "tools", description: "An MCP server's tools: name and what it does.", inputs: [{ name: "server", label: "Server" }],
    run: async ({ server: s }: { server: string }) => (await tools({ server: s })).map((t) => `${t.name}\t${(t.description ?? "").split("\n")[0]}`).join("\n") });
  cosm.point.add("cosm:commands", { name: "call", description: "Calls an MCP server's tool with its arguments as JSON ('{\"q\": \"…\"}'); prints its answer: its data when it gives some, else its text.",
    inputs: [{ name: "server", label: "Server" }, { name: "tool", label: "Tool" }, { name: "args", label: "Arguments (JSON)", optional: true }],
    run: async ({ server: s, tool, args }: { server: string; tool: string; args?: string }) => {
      const r = await call({ server: s, tool, args: args ? JSON.parse(args) : {} }) as { content?: { type: string; text?: string }[]; structuredContent?: unknown; isError?: boolean };
      const text = (r.content ?? []).map((c) => (c.type === "text" ? c.text : `[${c.type}]`)).join("\n");
      if (r.isError) throw new Error(text || "the tool failed");
      return r.structuredContent ?? text;
    } });
}
