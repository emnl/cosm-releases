---
description: A short note for whoever gave you Cosm — what worked, what went wrong, what felt awkward — shown before it's sent
---
# Feedback

1. Run `cosm feedback:material`: who it goes to (`giver`), the pilot's day, the lines noted and the packages' errors since the last note.
2. Draft a short note to the giver, in the user's voice and language, at most about 15 lines:
   - **Used:** what the user did with Cosm since the last note (from this conversation and what you know of their work here).
   - **Went wrong:** each error that matters, in plain words (which part, what happened, when); several of the same as one line.
   - **Felt awkward:** from the lines noted, and anything the user said in passing.
   - Leave out a part with nothing in it. No page's contents without asking.
3. Show it, then ask: "Send this to <giver>, or change something?" Change it as they say and show it again.
4. Only on their yes to that text: `cosm feedback:send "<the note>"`, then say it was sent. On a no, leave it: nothing is sent.

With nothing noted, no errors and nothing to say, tell the user so and ask whether there's anything they want <giver> to know.
