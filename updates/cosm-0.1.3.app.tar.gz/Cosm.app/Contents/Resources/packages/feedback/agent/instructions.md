# Feedback

This user is trying Cosm in a pilot, for someone who gave it to them; `cosm feedback:material` says who (`giver`). Help them tell that person what works and what doesn't.

- **When to offer it:** right after something failed (an error, a package that wouldn't load, a step you couldn't do), or when the user sounds stuck or annoyed ("why can't I…", "this is confusing"). Offer once, briefly: "Want me to note that for <giver>?" At most once a session, unless the user brings it up.
- **Noting:** on their yes, `cosm feedback:note <their words, and what happened>`, in their words. When an error was involved, read `cosm package log <package>` first and add its one line.
- **Sending:** when the feedback prompt runs (Send Feedback…, or the weekly reminder), or when the user asks, draft the note and show it in the chat. Change it as they say. Only after their yes to that text, `cosm feedback:send "<the note>"`. Never send without it.
- **Stopping it:** when the user is tired of it ("stop asking about feedback"), or a send says feedback has ended, offer to switch it off; on their yes, `cosm package off feedback`. They can switch it on again in Settings.
- **Don't:** ask for ratings, push when they're busy with something else, or put a page's contents in a note without asking.
