// Feedback, for a pilot: the user (or the agent, when they say so) notes what went wrong or felt awkward on a page of
// its own, Feedback.md; on days 1, 7 and 30 of the pilot and weekly after, and whenever the user asks (Send Feedback…
// in the session's ✦ menu), the agent drafts a short note from those lines, the packages' errors since the last one and
// what it knows, shows it, and sends it only on the user's yes. Sending posts it to the address set for the pilot
// (its setting address) with the pilot's key (its secret key, sent as a bearer token), as JSON:
// {from, to, cosm, text, notes, errors, days, sent}; whoever gave Cosm reads it there.
import type { Cosm } from "cosm";
import { shape } from "cosm/shape";

const PAGE = "Feedback.md";
const today = () => new Date().toISOString().slice(0, 10);
/** Now in the user's own time with its offset, as ISO 8601: `2026-11-06T17:23:42+01:00`. */
const isoHere = () => {
  const d = new Date(), p = (n: number) => String(Math.trunc(Math.abs(n))).padStart(2, "0"), off = -d.getTimezoneOffset();
  return `${stamp().replace(" ", "T")}${off >= 0 ? "+" : "-"}${p(off / 60)}:${p(off % 60)}`;
};
/** Now as the package logs write it (local time): `2026-11-06 15:39:31`. */
const stamp = () => { const d = new Date(), p = (n: number) => String(n).padStart(2, "0"); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`; };
const daysBetween = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / 86_400_000);

export default function (cosm: Cosm) {
  cosm.package.uses("agent-session", { if: "on" });
  cosm.point.add("cosm:settings", { name: "giver", shape: shape.string(), default: "", label: "Who it goes to",
    description: "The name of whoever gave you Cosm, as the agent says it: \"Want me to note that for Anna?\"" });
  cosm.point.add("cosm:settings", { name: "address", shape: shape.string(), default: "", label: "Where it goes",
    description: "The web address feedback is sent to, as whoever gave you Cosm set it up." });
  cosm.point.add("cosm:settings", { name: "from", shape: shape.string(), default: "", label: "From",
    description: "Your name, as it goes with each note: who it's from." });
  cosm.point.add("cosm:secrets", { name: "key", label: "Feedback key", description: "The key that lets your notes in, from whoever gave you Cosm." });

  const giver = async () => (await cosm.setting.get<string>("giver")) || "whoever gave you Cosm";
  /** The day the pilot started here: the first day this package ran. */
  const since = async () => {
    const s = await cosm.storage.get<string>("since");
    if (s) return s;
    await cosm.storage.set("since", today());
    return today();
  };

  /** A line on the feedback page, dated, in the user's words. */
  async function note(words: string) {
    const w = words.trim().replace(/\s+/g, " ");
    if (!w) throw new Error("nothing to note");
    const head = `# Feedback for ${await giver()}\n\nWhat went wrong or felt awkward, noted as it happened; sent with Send Feedback.\n\n`;
    const was = (await cosm.file.stat(PAGE)) ? await cosm.file.read(PAGE) : head;
    // The lines as a list under the page's words: a blank line before the first.
    const listed = /^- \d{4}-\d{2}-\d{2} /m.test(was);
    await cosm.file.write(PAGE, `${was.replace(/\n*$/, listed ? "\n" : "\n\n")}- ${today()} ${w}\n`);
    return `Noted for ${await giver()}.`;
  }

  /** What a note to the giver is drafted from: the lines noted and the packages' errors since the last one sent. */
  async function material() {
    // Since the last note sent: its time, and how many lines the page had noted then.
    // Before the first note, from the day the pilot started here.
    const sent = (await cosm.storage.get<{ at: string; lines: number }>("sent")) ?? { at: `${await since()} 00:00:00`, lines: 0 };
    const notes = ((await cosm.file.stat(PAGE)) ? await cosm.file.read(PAGE) : "").split("\n")
      .filter((l) => /^- \d{4}-\d{2}-\d{2} /.test(l)).map((l) => l.slice(2)).slice(sent.lines);
    const errors: string[] = [];
    const sh = (args: string[]) => { const r = Bun.spawnSync(["cosm", ...args], { cwd: process.env.COSM_ROOT_DIR ?? process.cwd() }); return r.exitCode === 0 ? r.stdout.toString() : ""; };
    const list = JSON.parse(sh(["package", "list", "--json"]) || "[]") as { name: string; label: string; on: boolean }[];
    for (const p of list.filter((x) => x.on)) {
      const lines = sh(["package", "log", p.name, "--all"]).split("\n");
      lines.forEach((l, i) => {
        if (!/^\d{4}-\d{2}-\d{2} .*  (threw|exit \d+)  /.test(l) || l.slice(0, 19) <= sent.at) return;
        const why = lines[i + 1]?.startsWith("    ") ? ` — ${lines[i + 1].trim().slice(0, 160)}` : "";
        errors.push(`${p.label}: ${l.slice(0, 16)} ${l.slice(21).split("  ")[0]} failed${why}`);
      });
    }
    const all = ((await cosm.file.stat(PAGE)) ? await cosm.file.read(PAGE) : "").split("\n").filter((l) => /^- \d{4}-\d{2}-\d{2} /.test(l)).length;
    return { giver: await giver(), days: daysBetween(await since(), today()) + 1, since: sent.at.slice(0, 10), notes, errors: errors.slice(-20), lines: all };
  }

  /** Whether whoever gave Cosm still wants feedback (the address answers {wanted}); unknown (no address, offline):
   * taken as yes, so a pilot isn't asked to switch it off over a dropped connection. */
  async function wanted(): Promise<boolean> {
    const address = (await cosm.setting.get<string>("address"))?.trim();
    if (!address) return true;
    const key = await cosm.secret.get("key").catch(() => null);
    try {
      const r = await fetch(address, { headers: key ? { authorization: `Bearer ${key}` } : {}, signal: AbortSignal.timeout(10_000) });
      return r.ok ? (await r.json() as { wanted?: boolean }).wanted !== false : true;
    } catch { return true; }
  }
  /** Feedback no longer wanted: the user is asked once whether to switch this package off. */
  async function ended() {
    if (await cosm.storage.get<boolean>("asked-ended")) return;
    await cosm.storage.set("asked-ended", true);
    const who = await giver();
    const a = await cosm.ui.ask(`${who} has ended feedback. Switch Feedback off?`, { description: "No more notes are sent or drafted. You can switch it on again in Settings.", choices: ["Keep It", "Switch Off"] });
    if (a === "Switch Off") Bun.spawnSync(["cosm", "package", "off", cosm.package.name], { cwd: process.env.COSM_ROOT_DIR ?? process.cwd() });
  }

  /** The note, sent to the pilot's address after the user's yes. */
  async function send(text: string) {
    const address = (await cosm.setting.get<string>("address"))?.trim();
    if (!address) throw new Error("no address to send feedback to: set Where it goes on Feedback's page in Settings");
    if (!text.trim()) throw new Error("nothing to send");
    const m = await material();
    const key = await cosm.secret.get("key").catch(() => null);
    const r = await fetch(address, { method: "POST", headers: { "content-type": "application/json", ...(key ? { authorization: `Bearer ${key}` } : {}) },
      body: JSON.stringify({ from: (await cosm.setting.get<string>("from")) ?? "", to: m.giver, cosm: (process.env.COSM_ROOT_DIR ?? process.cwd()).split("/").pop(), text: text.trim(), notes: m.notes, errors: m.errors, days: m.days, sent: isoHere() }),
      signal: AbortSignal.timeout(20_000) });
    if (r.status === 410) { void ended(); throw new Error(`it wasn't sent: ${await giver()} has ended feedback (offer to switch Feedback off: cosm package off feedback)`); }
    if (r.status === 401 || r.status === 403) throw new Error("it wasn't sent: the address refused the Feedback key (set it on Feedback's page in Settings)");
    if (!r.ok) throw new Error(`it wasn't sent: the address answered ${r.status}`);
    await cosm.storage.set("sent", { at: stamp(), lines: m.lines });
    return `Sent to ${m.giver}.`;
  }

  cosm.point.add("cosm:commands", { name: "note", step: "Noted feedback", description: "Adds a dated line to the feedback page, in the user's words: what went wrong or felt awkward.",
    inputs: [{ name: "words", label: "What to note", type: "list" }], run: ({ words }: { words: string[] }) => note(words.join(" ")) });
  cosm.point.add("cosm:commands", { name: "material", step: "Gathered feedback", description: "What a feedback note is drafted from, as JSON: who it goes to, the pilot's day, the lines noted and the packages' errors since the last note sent.",
    run: async () => JSON.stringify(await material(), null, 2) });
  cosm.point.add("cosm:commands", { name: "wanted", description: "Whether whoever gave Cosm still wants feedback: yes, or no once they've ended it (then offer to switch Feedback off).",
    run: async () => ((await wanted()) ? "yes" : "no") });
  cosm.point.add("cosm:commands", { name: "send", step: "Sent feedback", description: "Sends a feedback note the user said yes to, to the pilot's address. Only after the user's yes to that text.",
    inputs: [{ name: "text", label: "The note", type: "list" }], run: ({ text }: { text: string[] }) => send(text.join(" ")) });

  /** The feedback prompt, in the conversation it was chosen in, else the one on screen used last, else a new one. */
  const SESSION = "agent-session:session:";
  const conversation = (thing?: string | null) => (thing?.startsWith(SESSION) && !thing.endsWith(":") ? thing.slice(SESSION.length) : undefined);
  const draft = async (session?: string) => {
    const onScreen = (await cosm.ui.shown().catch(() => [])).map((x) => ({ id: conversation(x.arg), used: x.used })).filter((x) => x.id).sort((a, b) => b.used.localeCompare(a.used))[0]?.id;
    let s = session || onScreen;
    if (!s) { s = String(await cosm.call("agent-session:start", { title: "Feedback" })); await cosm.ui.open("agent-session:holder", SESSION + s); }
    await cosm.call("agent-session:send", { session: s, message: { prompt: "feedback:feedback" } });
  };
  cosm.point.add("cosm:items", { name: "send", label: "Send Feedback…", content: { description: "A short note for whoever gave you Cosm" },
    action: ({ thing }) => draft(conversation(thing)), location: [{ in: "agent-session:holder" }, { in: "palette" }] });

  // Days 1, 7 and 30 of the pilot, then weekly: the agent drafts one, in a conversation of its own.
  cosm.point.add("cosm:schedules", { name: "draft", when: "daily 10:00", description: "On days 1, 7 and 30 of the pilot, then weekly, the agent drafts a feedback note",
    run: async () => {
      const d = daysBetween(await since(), today()) + 1;
      if (![1, 7, 30].includes(d) && !(d > 30 && (d - 30) % 7 === 0)) return;
      if ((await cosm.storage.get<string>("drafted")) === today()) return;
      if (!(await wanted())) { await ended(); return; }
      await cosm.storage.set("drafted", today());
      const s = String(await cosm.call("agent-session:start", { title: "Feedback" }));
      await cosm.call("agent-session:send", { session: s, message: { prompt: "feedback:feedback" } });
    } });
}
