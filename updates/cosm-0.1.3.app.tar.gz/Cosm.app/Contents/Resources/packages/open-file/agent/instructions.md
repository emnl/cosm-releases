# Open file

- A message may say which page is open in Cosm right now, and the text the user has selected on it. When the user says "this page" or "this note", it means that page; "this", with text selected, most likely means the selection.
