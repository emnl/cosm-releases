import { expect, test } from "bun:test";
import { told } from "../main.ts";

const shown = { pane: "right" as const, view: "markdown:page", label: "Page", arg: "notes/a.md", name: "a", path: "notes/a.md", used: "2026-10-30T09:00:00Z" };
const sel = (text: string | null, from?: number, to?: number) => ({ text, from, to });

test("what the agent is told", () => {
  expect(told(shown, sel("## Open\n- one", 7, 8))).toContain("Selected on that page, lines 7–8:\n<selection>\n## Open\n- one\n</selection>");
  expect(told(shown, sel("Q3", 12, 12))).toContain("Selected on that page, line 12:\n<selection>\nQ3\n");
  expect(told(shown, sel("Q3"))).toContain("Selected on that page:\n<selection>\nQ3\n");
  const long = told(shown, sel("x".repeat(5000), 1, 240))!;
  expect(long).toContain("Selected on that page, lines 1–240 (too long to include; read them from the file)");
  expect(long).not.toContain("xxxx");
  expect(told(shown, null)).toBe("The page open in Cosm right now: a (notes/a.md)");
  expect(told(shown, sel(null))).toBe("The page open in Cosm right now: a (notes/a.md)");
  expect(told({ pane: "left", view: "tables:table", label: "Table", arg: "tables:table:expenses", name: "expenses", used: "2026-10-30T09:00:00Z" }, null)).toBeUndefined();
  expect(told(undefined, null)).toBeUndefined();
});
