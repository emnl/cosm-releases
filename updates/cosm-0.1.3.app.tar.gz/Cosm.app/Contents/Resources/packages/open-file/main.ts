// Open file: with each message, tells the agent which file the user is working on in Cosm and the text they selected
// in it, so "this page" and "this" mean something. The file is the one shown by the view with a file used last; the
// selection is what that view published about itself (its `selection` fact): nothing is kept here.
import type { Cosm, Shown } from "cosm";

/** Past this many characters a selection goes as its lines only, for the agent to read from the file. */
const SELECTION_MOST = 4000;

/** A selection as an editor publishes it: the text, and its lines (1-based). */
type Selected = { text: string | null; from?: number; to?: number };

export default function (cosm: Cosm) {
  cosm.point.add("agent:message", { name: "open-file", run: async () => {
    const shown = (await cosm.ui.shown()).filter((s) => s.path).sort((a, b) => b.used.localeCompare(a.used))[0];
    return told(shown, (shown?.facts?.selection as Selected | undefined) ?? null);
  } });
}

/** What the agent is told: the file by its name and path, and the selection in it; nothing when no file is shown. */
export function told(shown: Shown | undefined, s: Selected | null): string | undefined {
  if (!shown?.path) return undefined;
  return [`The page open in Cosm right now: ${shown.name ?? shown.path} (${shown.path})`, selection(s)].filter(Boolean).join("\n");
}

/** How a selection is told: its lines and its text, or its lines only when it is long. */
function selection(s: Selected | null): string | undefined {
  if (!s?.text || !s.text.trim()) return undefined;
  const lines = s.from && s.to ? (s.from === s.to ? `, line ${s.from}` : `, lines ${s.from}–${s.to}`) : "";
  if ([...s.text].length > SELECTION_MOST) {
    return lines ? `Selected on that page${lines} (too long to include; read them from the file)` : "Selected on that page: a long passage (too long to include)";
  }
  return `Selected on that page${lines}:\n<selection>\n${s.text}\n</selection>`;
}
