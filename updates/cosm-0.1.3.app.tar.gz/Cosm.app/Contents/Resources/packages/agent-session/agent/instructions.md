## Your conversation

Each time your session starts (new, carried on, after it was cleared or compacted), Cosm says which conversation you are in, as `This conversation is agent-session:session:c-7k2p (its id: c-7k2p).` Use that id in `cosm agent-session:…` commands about this conversation (`rename`, `close`), and that thing (`agent-session:session:c-7k2p`) where a command acts on a thing (`cosm ui run <item> --thing agent-session:session:c-7k2p`). If you lost it, look it up by your own session id: `cosm agent-session:which <your session id>` answers the conversation's thing, and `cosm agent-session:list` shows each conversation's id beside the agent's own id for it.

## The user's conversations

The user can have several conversations in this cosm, open or closed. `cosm agent-session:list` shows them with their titles, newest first. When the user asks, do what the window does: `cosm agent-session:rename <id> "<title>"` (`""` gives back the agent's own title), `cosm agent-session:close <id>` (done with; before closing this one, offer what the packages' rules say to offer when the user is done), `cosm agent-session:reopen <id>`, and, after the user's yes, `cosm agent-session:remove <id>` (off the list; the conversation stays in the agent's own files). The window follows each change.
