// Agent session's ACP client: the Agent Client Protocol (v1,
// agentclientprotocol.com: JSON-RPC over the agent's stdin and stdout), spoken with one conversation's program through
// the official library (`@agentclientprotocol/sdk`, its stable entry point), as Zed does. One connection a
// conversation, so two conversations on one connector never share request ids or state. Agent session feeds it the
// program's output (its stream, `<connector>:<process>`, a line at a time: `read`) and writes what it sends to the
// program (`process.write`); what the agent says comes out as the chat's own events (`CosmEvent`), in order.
//
// Cosm, as the client, asks: initialize, session/new or session/load, session/prompt, session/cancel,
// session/set_config_option (the model, and the effort: a select of category thought_level). It answers:
// session/request_permission (Allow, Allow for this session, Deny; a step of kind switch_mode is a plan to approve),
// elicitation/create in form mode (questions with options). It reads session/update: agent_message_chunk,
// user_message_chunk (a session's past), tool_call, tool_call_update, available_commands_update, config_option_update,
// usage_update; and $/cancel_request. Cosm's own extension, under _meta.cosm: "refused" on a tool_call_update (a step
// refused for want of the user's OK), "covers" on an allow_always option (what it allows).
import type { CosmEvent, Json, Model, Q, ToolContent } from "./events.ts";
import type { Server } from "package:agent";
import * as ACP from "@agentclientprotocol/sdk";

/** What the chat tells the agent, as steps with the agent's program. */
export type Input =
  /** Once started: initialize, then the session, new or carried on. */
  | { type: "hello"; cwd: string; /** The agent's own id, to carry it on (`resume`). */ session: string; resume: boolean; /** ACP's mcpServers for session/new and session/load. */ mcpServers?: unknown[] }
  /** `context`: what Cosm gives the agent with it (what agent:message's contributions said, for an agent whose own hooks don't tell it). */
  | { type: "message"; text: string; images?: { media_type: string; data: string }[]; context?: string;
      /** Cosm's instructions, before a new conversation's first message, for an agent that takes none as it starts. */ rules?: string }
  | { type: "answer"; id: string; allow: boolean; always?: boolean; answers?: Record<string, string>; message?: string }
  | { type: "stop" }
  | { type: "model"; model: string }
  | { type: "effort"; effort: string };

/** How Cosm reaches an ACP agent: each line of its output read, each input written (what it says goes to `emit`). */
export type Link = { read: (line: string) => void; write: (input: Input) => Promise<void>;
  /** The agent is gone (it didn't start, or it stopped): nothing waits on it, and writing says why. */
  abort: (why: string) => void };

const str = (v: unknown) => (typeof v === "string" ? v : "");

/** What a tool call's content holds, in the chat's terms (terminals, which Cosm doesn't offer, are left out). */
function contentOf(c: unknown): ToolContent[] | undefined {
  if (!Array.isArray(c)) return undefined;
  return (c as Json[]).flatMap((x): ToolContent[] => {
    if (x["type"] === "diff") return [{ type: "diff", path: str(x["path"]), oldText: typeof x["oldText"] === "string" ? x["oldText"] : null, newText: str(x["newText"]) }];
    if (x["type"] === "content") { const b = (x["content"] ?? {}) as Json; return b["type"] === "text" ? [{ type: "text", text: str(b["text"]) }] : b["type"] === "image" ? [{ type: "text", text: "(an image)" }] : []; }
    return [];
  });
}

const WRITES = new Set(["edit", "delete", "move"]);

/**
 * The protocol with one ACP agent, through the official ACP library (`@agentclientprotocol/sdk`): `send` takes each
 * line for the agent's stdin, `read` each line of its stdout, and what the agent says comes out to `emit` as the
 * chat's own events, in order.
 */
export function link(sendLine: (line: string) => unknown, emit: (events: CosmEvent[]) => void): Link {
  let incoming!: ReadableStreamDefaultController<ACP.AnyMessage>;
  const readable = new ReadableStream<ACP.AnyMessage>({ start(c) { incoming = c; } });
  const writable = new WritableStream<ACP.AnyMessage>({ async write(m) { await sendLine(JSON.stringify(m)); } });
  let session = "";
  // Messages wait until the session is there (session/new or session/load answered, either way).
  let isReady: () => void = () => {};
  const ready = new Promise<void>((r) => { isReady = r; });
  let gone = "";
  /** What the agent asked and waits on (a permission, a plan, a form), to answer in its terms. */
  const asked = new Map<string, { kind: "permission" | "plan" | "question"; options?: Json[]; keys?: [string, string, boolean][]; answer: (r: unknown) => void }>();
  /** Everything still asked is over (the turn ended, it was stopped): answered as cancelled, as ACP asks. */
  const cancelAll = (): CosmEvent[] => {
    const out = [...asked.keys()].map((id): CosmEvent => ({ type: "cancel", id }));
    for (const [, a] of asked) a.answer(a.kind === "question" ? { action: "cancel" } : { outcome: { outcome: "cancelled" } });
    asked.clear();
    return out;
  };
  /** A question of the agent's, held until the user answers it (or the agent takes it back). */
  const ask = (key: string, signal: AbortSignal, a: Omit<Parameters<typeof asked.set>[1], "answer">, events: CosmEvent[]) => new Promise<unknown>((resolve) => {
    asked.set(key, { ...a, answer: resolve });
    signal.addEventListener("abort", () => { if (asked.delete(key)) emit([{ type: "cancel", id: key }]); });
    emit(events);
  });

  // The turn: its reply as it builds up, the steps seen (for their titles), the steps refused without asking.
  let reply = "", message = "";
  const titles = new Map<string, string>();
  let refused: { step: string; title: string }[] = [];
  // A user message of the session's past, gathered from its chunks until something else comes.
  let user: { id: string; text: string; images: string[] } | null = null;
  let userN = 0;
  const flush = (): CosmEvent[] => {
    if (!user) return [];
    const u = user; user = null;
    // What Cosm added to a message (its context block) is not what the user said.
    const text = u.text.replace(/\n*<context from="cosm">[\s\S]*?<\/context>/g, "").replace(/\n*<rules from="cosm">[\s\S]*?<\/rules>/g, "").trim();
    // A prompt sent by its name reads as `/<name>` (`/cosm:<name>`): its name.
    const prompt = /^\/(?:[\w-]+:)?([\w-]+)\s*$/.exec(text)?.[1];
    return [{ type: "user", text, images: u.images.length ? u.images : undefined, ...(prompt ? { prompt } : {}) }];
  };
  /** The model and effort options the agent offers (config options of category "model" and "thought_level"). */
  let modelOption = "", effortOption = "";
  const values = (o: Json): Model[] => ((o["options"] ?? []) as Json[]).flatMap((x) => (Array.isArray(x["options"]) ? (x["options"] as Json[]) : [x]))
    .map((x) => ({ id: str(x["value"]), name: str(x["name"]), description: str(x["description"]) || undefined }));
  const models = (opts: unknown): CosmEvent[] => {
    const all = Array.isArray(opts) ? (opts as Json[]) : [];
    const m = all.find((o) => o["category"] === "model" && o["type"] === "select");
    const e = all.find((o) => o["category"] === "thought_level" && o["type"] === "select");
    if (!m) return [];
    modelOption = str(m["id"]); effortOption = e ? str(e["id"]) : "";
    return [{ type: "models", current: str(m["currentValue"]), models: values(m), effort: e ? { current: str(e["currentValue"]), levels: values(e) } : undefined }];
  };

  const onUpdate = (u: Json): CosmEvent[] => {
    const kind = str(u["sessionUpdate"]);
    if (kind === "user_message_chunk") {
      const c = (u["content"] ?? {}) as Json, id = str(u["messageId"]) || `u${userN}`;
      const out = user && user.id !== id ? flush() : [];
      if (!user) { user = { id, text: "", images: [] }; userN++; }
      if (c["type"] === "text") user.text += str(c["text"]);
      if (c["type"] === "image") user.images.push(`data:${str(c["mimeType"])};base64,${str(c["data"])}`);
      return out;
    }
    const out = flush();
    switch (kind) {
      case "agent_message_chunk": {
        const c = (u["content"] ?? {}) as Json;
        if (c["type"] !== "text") return out;
        const id = str(u["messageId"]) || "m";
        if (id !== message) { message = id; reply = ""; out.push({ type: "text-start", id }); }
        reply += str(c["text"]);
        out.push({ type: "text-delta", text: str(c["text"]) });
        return out;
      }
      case "tool_call": {
        message = "";
        const id = str(u["toolCallId"]), title = str(u["title"]);
        titles.set(id, title);
        const path = str(((u["locations"] ?? []) as Json[])[0]?.["path"]);
        out.push({ type: "step", id, title, name: str(u["name"]) || undefined, kind: str(u["kind"]) || "other", write: WRITES.has(str(u["kind"])), content: contentOf(u["content"]), path: path || undefined });
        if (u["status"] === "completed" || u["status"] === "failed") out.push({ type: "step-done", id, content: contentOf(u["content"]), error: u["status"] === "failed" });
        return out;
      }
      case "tool_call_update": {
        const id = str(u["toolCallId"]), status = str(u["status"]);
        if (status !== "completed" && status !== "failed") return out;
        const isRefused = ((u["_meta"] as Json | undefined)?.["cosm"] as Json | undefined)?.["refused"] === true;
        if (isRefused && !refused.some((r) => r.step === id)) refused.push({ step: id, title: titles.get(id) ?? "a step" });
        out.push({ type: "step-done", id, content: contentOf(u["content"]), error: status === "failed", refused: isRefused });
        return out;
      }
      case "available_commands_update":
        out.push({ type: "commands", commands: ((u["availableCommands"] ?? []) as Json[]).map((c) => ({ name: str(c["name"]), description: str(c["description"]), hint: str((c["input"] as Json | undefined)?.["hint"]) || undefined })) });
        return out;
      case "config_option_update": return [...out, ...models(u["configOptions"])];
      case "usage_update": { const size = Number(u["size"]), used = Number(u["used"]); if (size > 0) out.push({ type: "usage", used, size }); return out; }
    }
    return out;
  };

  const app = ACP.client({ name: "cosm" })
    .onNotification("session/update", ({ params }) => emit(onUpdate(params.update as unknown as Json)))
    // A step to allow, or a plan to approve (a step of kind switch_mode).
    .onRequest("session/request_permission", async ({ params, requestId, signal }) => {
      const p = params as unknown as Json, key = String(requestId);
      const tc = (p["toolCall"] ?? {}) as Json, options = (p["options"] ?? []) as Json[];
      const step = str(tc["toolCallId"]) || undefined;
      const text = (contentOf(tc["content"]) ?? []).flatMap((c) => (c.type === "text" ? [c.text] : [])).join("\n");
      if (tc["kind"] === "switch_mode") return await ask(key, signal, { kind: "plan", options }, [{ type: "plan", id: key, step, plan: text }]) as ACP.RequestPermissionResponse;
      const always = options.find((o) => o["kind"] === "allow_always");
      const covers = str(((always?.["_meta"] as Json | undefined)?.["cosm"] as Json | undefined)?.["covers"]);
      return await ask(key, signal, { kind: "permission", options }, [{ type: "permission", id: key, step, title: str(tc["title"]) || titles.get(step ?? "") || "A step", detail: text || undefined, always: always ? covers || str(always["name"]) : undefined }]) as ACP.RequestPermissionResponse;
    })
    // Questions with options (a form).
    .onRequest("elicitation/create", async ({ params, requestId, signal }) => {
      const p = params as unknown as Json, key = String(requestId);
      if (p["mode"] !== "form") return { action: "decline" } as ACP.CreateElicitationResponse;
      const schema = (p["requestedSchema"] ?? {}) as Json, props = (schema["properties"] ?? {}) as Record<string, Json>;
      const keys: [string, string, boolean][] = [];
      const questions: Q[] = Object.entries(props).map(([k, f]) => {
        const multi = f["type"] === "array";
        const titled = (multi ? (f["items"] as Json | undefined)?.["anyOf"] : f["oneOf"]) as Json[] | undefined;
        const plain = (multi ? (f["items"] as Json | undefined)?.["enum"] : f["enum"]) as string[] | undefined;
        const question = str(f["description"]) || str(f["title"]) || k;
        keys.push([k, question, multi]);
        return { question, header: str(f["title"]) || undefined, multi,
          options: titled ? titled.map((o) => ({ label: str(o["const"]), description: str(o["description"]) || undefined })) : (plain ?? []).map((v) => ({ label: v })) };
      });
      return await ask(key, signal, { kind: "question", keys }, [{ type: "question", id: key, step: str(p["toolCallId"]) || undefined, questions: questions.length ? questions : [{ question: str(p["message"]), options: [] }] }]) as ACP.CreateElicitationResponse;
    });
  const conn = app.connect({ readable, writable });
  const agent = conn.agent;
  const failed = (e: unknown) => (e instanceof Error ? e.message : String((e as Json | undefined)?.["message"] ?? e));

  const read = (line: string) => {
    if (!line.trim()) return;
    try { incoming.enqueue(JSON.parse(line) as ACP.AnyMessage); } catch { /* not a message: an agent's stray output */ }
  };

  const write = async (input: Input) => {
    if (gone && input.type !== "hello") throw new Error(`${gone}: start a new session to go on.`);
    switch (input.type) {
      case "hello": {
        let canLoad = false;
        try {
          const init = await agent.request("initialize", { protocolVersion: ACP.PROTOCOL_VERSION, clientCapabilities: { elicitation: { form: {} } } as ACP.ClientCapabilities, clientInfo: { name: "cosm", title: "Cosm", version: "1" } });
          canLoad = init.agentCapabilities?.loadSession === true;
        } catch (e) { isReady(); emit([{ type: "note", text: `The agent didn't start: ${failed(e)}` }]); return; }
        const params = { cwd: input.cwd, mcpServers: (input.mcpServers ?? []) as ACP.McpServer[] };
        if (input.resume && canLoad) {
          session = input.session;
          try {
            const r = await agent.request("session/load", { ...params, sessionId: input.session });
            isReady();
            emit([...flush(), ...models((r as Json | undefined)?.["configOptions"]), { type: "loaded" }, { type: "started", resumed: true }]);
          } catch (e) { isReady(); emit([...flush(), { type: "note", text: `The session couldn't be carried on: ${failed(e)}` }]); }
          return;
        }
        try {
          const r = await agent.request("session/new", params) as ACP.NewSessionResponse;
          session = r.sessionId;
          isReady();
          // The agent's own id for the conversation, for Agent session to keep and give back to carry it on.
          emit([...(session ? [{ type: "agent-session" as const, id: session }] : []), ...models((r as unknown as Json)["configOptions"]),
            ...(input.resume ? [{ type: "note" as const, text: "This agent can't carry a session on, so this is a new one." }] : []), { type: "started" as const, resumed: false }]);
        } catch (e) { isReady(); emit([{ type: "note", text: `The session didn't start: ${failed(e)}` }]); }
        return;
      }
      case "message": {
        await ready;
        reply = ""; message = ""; refused = [];
        const prompt = [...(input.rules ? [{ type: "text" as const, text: `<rules from="cosm">\n${input.rules}\n</rules>` }] : []), ...(input.images ?? []).map((p) => ({ type: "image" as const, mimeType: p.media_type, data: p.data })), ...(input.text ? [{ type: "text" as const, text: input.text }] : []),
          ...(input.context ? [{ type: "text" as const, text: `<context from="cosm">\n${input.context}\n</context>` }] : [])];
        // The turn runs on; its end comes as an event.
        void agent.request("session/prompt", { sessionId: session, prompt }).then(
          (r) => emit([...flush(), ...cancelAll(), { type: "turn-end", text: reply, denied: refused, stopped: (r as ACP.PromptResponse).stopReason === "cancelled" }]),
          (e) => emit([...flush(), ...cancelAll(), { type: "note", text: failed(e) }, { type: "turn-end", text: "" }]));
        return;
      }
      case "stop":
        await ready;
        // Stopping answers what the agent still waits on as cancelled, as ACP asks.
        emit(cancelAll());
        await agent.notify("session/cancel", { sessionId: session });
        return;
      case "model": case "effort": {
        await ready;
        const option = input.type === "model" ? modelOption : effortOption;
        if (!option) return;
        try {
          const r = await agent.request("session/set_config_option", { sessionId: session, configId: option, value: input.type === "model" ? input.model : input.effort } as ACP.SetSessionConfigOptionRequest);
          emit(models((r as unknown as Json)["configOptions"]));
        } catch (e) { emit([{ type: "note", text: failed(e) }]); }
        return;
      }
      case "answer": {
        const a = asked.get(input.id);
        if (!a) return;
        asked.delete(input.id);
        if (a.kind === "question") {
          if (!input.allow) { a.answer({ action: "decline" }); return; }
          // The chat's answers by question, back to the form's fields: several choices for a field that takes several.
          const content = Object.fromEntries((a.keys ?? []).map(([k, q, multi]) => { const v = input.answers?.[q] ?? ""; return [k, multi ? v.split(", ").filter(Boolean) : v]; }));
          a.answer({ action: "accept", content });
          return;
        }
        const want = !input.allow ? "reject_once" : input.always ? "allow_always" : "allow_once";
        const opt = (a.options ?? []).find((o) => o["kind"] === want) ?? (a.options ?? []).find((o) => String(o["kind"]).startsWith(input.allow ? "allow" : "reject"));
        a.answer(opt ? { outcome: { outcome: "selected", optionId: opt["optionId"] } } : { outcome: { outcome: "cancelled" } });
        return;
      }
    }
  };
  const abort = (why: string) => { if (gone) return; gone = why; isReady(); emit(cancelAll()); conn.close(new Error(why)); };
  return { read, write, abort };
}

/** The MCP servers for the agent's session, in ACP's shape (`mcpServers`). */
export const servers = (all: Server[]) => all.map((s) => "url" in s
  ? { type: "http", name: s.name, url: s.url, headers: Object.entries(s.headers).map(([name, value]) => ({ name, value })) }
  : { name: s.name, command: s.program, args: s.args, env: Object.entries(s.env).map(([name, value]) => ({ name, value })) });
