// Agent session: the cosm's conversations with its agents, the broker between the packages and the connectors
// (the one place every package goes through to start, send to and stop a conversation), and the right pane's
// holder for one. Its list (in its data folder) holds each conversation by an id of its own (`c-7k2p`), made with it, before its agent has one: the agent it runs on, the agent's
// own id for it (kept when the agent makes or changes one), when it started, whether it was closed and the user's title.
// The views that show a conversation place themselves in the holder (Agent chat's chat, Agent terminal's terminal); it
// shows one at a time, with the list, how full it is, a new one and closing. Which of a conversation's programs runs (a
// chat, or the agent in a terminal) is never kept here: its connector says (`running`), as it knows its own processes.
//
// The broker: packages start, send to, answer, cancel, set, stop and close conversations only through its exports
// (`agent-session:start`, `send` …). It has the conversation's connector (a contribution to `agent:agents`) start and
// stop its program, and is the ACP client itself (acp.ts, one connection a conversation): it reads the chat program's
// output from its stream and writes to the program (`process.write`); a conversation running in its terminal it types
// into. It holds what is sent while the agent answers. Before a message goes out it asks the agent package what
// packages add (`agent:fire`, the points `agent:start`, `agent:message`, `agent:step`, `agent:failed`). What the agent
// says (through ACP, or its own hooks through its connector: `hook`) it writes to the conversation's stream under its
// id (`agent-session:<id>`, which Agent chat hands its view), and has the agent package fire the moments
// (`agent:started`, `agent:message.sent` …) with the conversation's id as `session` in their data. Nothing it holds of
// a connection is pretended across a gap: items of the program's output lost, or this package's code starting again
// while the program ran, end the turn as interrupted, with a note, and stop the program; the next message carries the
// conversation on (`session/load` where the agent can).
//
// Its events: `started` (a conversation joined the list), `closed.before` (about to close: a handler may keep it open,
// `{stop}`), `closed`, `removed`; each with `{session}`.
//
// A conversation is a thing of its kind `session` (`agent-session:session:<id>`): what the holder and the views placed
// in it are given, what an item chosen on one gets (`thing`), and what `cosm.ui.shown` says is on screen.
import type { Contribution, Cosm, OpenStream } from "cosm";
import { rename as move } from "node:fs/promises";
import type { CosmEvent } from "./events.ts";
import type { Agent, AgentAnswer, Running, Started } from "package:agent";
import { link, servers, type Link } from "./acp.ts";
// The chat's vocabulary, for the packages and views that read or write a conversation's stream.
export type * from "./events.ts";

/** A conversation on the list: its agent (the name it is reached by in `agent:agents`) and the agent's own id for it;
 * `used` and `size`: how full its context was at its last turn's end, as its agent said. */
type Row = { id: string; agent: string; agentSession?: string; started: string; closed?: string; title?: string; used?: number; size?: number };
/** A row as its views and the shell get it: with the agent's own title, and how full it is (`tokens` of `size`). */
type Shown = Row & { active: boolean; agentTitle?: string; tokens?: number; model?: string };
/** What a moment's contributions said back (`agent:fire`); as a session starts, also the messages they give it to send
 * first (`send`). */
type Said = { said: string; input?: unknown; send?: unknown[] };
/** A conversation's chat whose program runs now, in memory while it does (held: this package's code keeps running);
 * whether the program still runs is its connector's to say, so a run whose program is gone is ended where it is met.
 * `busy`: a turn runs, what is sent waits (`waiting`), in order; `release`: while it starts, what is sent waits, and
 * the messages the start's contributions give go first (`early`); `said`: what the moments' contributions said since the last message, to go with the
 * next; `given`, `message`: for an agent whose hooks take them, the context and the id of the message just sent;
 * `answered`: told the turn's end of the message just sent, when its sender waits for it (the shell's `send`), and
 * `asking`: every sender that waits, told when the program ends before their turn does. */
type Run = { id: string; agent: Contribution<Agent>; stream?: OpenStream; queue: Promise<void>; hold: { release(): void };
  busy: boolean; waiting: Queued[]; release?: () => void; early: Queued[];
  /** The messages sent that haven't gone yet (waiting on the turn, or on the start), as the chat shows them. */
  pending: Pending[];
  said: string[]; given?: string; message?: string; steps: Map<string, string>; usage?: { used: number; size: number };
  answered?: (turn: Turn) => void; asking: Set<(turn: Turn) => void>; note?: string;
  /** What the agent asks now and waits on, oldest first, by its id. */
  open: Map<string, Asked>;
  /** Its program (`<connector>:<process>`), when that one started, and the ACP connection with it (acp.ts); `rules`:
   * Cosm's instructions, still to go with the first message; `unfollow`: stops reading its output. */
  process?: string; started?: number; link?: Link; rules?: string; unfollow?: () => void;
  /** The agent said its session is there (`began`); its program ended (`gone`); it was ended on purpose, nothing
   * more to say of it (`quiet`); its end was told (`ended`). */
  began?: boolean; gone?: boolean; quiet?: boolean; ended?: boolean;
  /** The model and effort the user chose last for its agent were given it, once its offer came. */
  picked?: boolean };
/** What sends a waiting message, with its id. */
type Queued = (() => Promise<void>) & { id?: string };
/** A message sent that hasn't gone to the agent yet: its id (the one it keeps once it goes), its words, who sent it. */
export type Pending = { id: string; text: string; images?: string[]; prompt?: string; by?: string };
/** What lasts across this package's code starting again, by conversation: its chat's program, when that one started,
 * and whether a turn runs. Read as the code starts, to stop what it can no longer speak with. */
type Kept = Record<string, { process: string; started: number; turn?: boolean }>;
/** How a turn ended, for whoever waits on it: the agent's reply, whether the user stopped it, or why there was none; or
 * what the agent asked (a step to allow, a plan, questions), which ends the wait: the turn waits on an answer. */
type Turn = { text: string; stopped?: boolean; failed?: string; asked?: Asked };
/** What the agent asks and waits on: a step to allow, a plan to approve, questions. */
type Asked = Extract<CosmEvent, { type: "permission" | "plan" | "question" }>;

export default function (cosm: Cosm) {
  cosm.package.uses("agent");
  cosm.point.add("cosm:views", { name: "holder", file: "views/holder.html", label: "Agent session", input: "thing", location: { in: "right-pane" } });
  // Its place: the views that show a session (a chat, the agent's terminal: `location: { in: "agent-session:holder" }`),
  // one at a time in its <cosm-place>, and the icons in its header (items placed here with an icon).
  cosm.point.define("holder", { description: "Views that show a session, one at a time (a view's location), and buttons in the session's header (an item with an icon).", holds: "values" });
  cosm.point.add("cosm:events", { name: "started", description: "A conversation joined the list: {session}." });
  cosm.point.add("cosm:events", { name: "closed.before", description: "A conversation is about to close: {session}. Return {stop: why} to keep it open." });
  cosm.point.add("cosm:events", { name: "closed", description: "A conversation was closed: {session}." });
  cosm.point.add("cosm:events", { name: "waiting", description: "The messages waiting to go to a conversation's agent changed: {session}. Read them with waiting." });
  cosm.point.add("cosm:events", { name: "removed", description: "A conversation was taken off the list: {session}." });
  cosm.point.add("cosm:events", { name: "storage.changed", description: "A package's key in a conversation's storage changed: {session, package, key}." });

  const file = `${cosm.package.folders.data}/conversations.json`;
  const read = async (): Promise<Row[]> => { try { return (await Bun.file(file).json()) as Row[]; } catch { return []; } };
  // Its kind: the conversations on the list, opened in the holder; kept out of search.
  cosm.point.add("cosm:kinds", { name: "session", label: "Session", view: "holder", search: false,
    items: async () => (await read()).map((r) => ({ key: r.id, name: r.title ?? r.id })) });
  const KIND = "agent-session:session:";
  /** A conversation as a thing, and the conversation a thing is (none for another kind's, or one not started). */
  const thingOf = (id: string) => KIND + id;
  const idOf = (thing?: string) => (thing?.startsWith(KIND) && !thing.endsWith(":") ? thing.slice(KIND.length) : "");
  /** Changes, one at a time: each reads what the last wrote, written whole (a file beside it, renamed over it), so a
   * read never meets half a list. Past 500, the oldest closed conversations leave it, as if removed (`gone`). */
  const MOST = 500;
  let queue: Promise<unknown> = Promise.resolve();
  const change = <T>(f: (all: Row[]) => T | Promise<T>): Promise<T> => {
    let dropped: string[] = [];
    const run = queue.then(async () => {
      const all = await read();
      const out = await f(all);
      for (let i = 0; all.length - dropped.length > MOST && i < all.length; i++) if (all[i].closed) dropped.push(all[i].id);
      const kept = all.filter((r) => !dropped.includes(r.id));
      await Bun.write(`${file}.new`, JSON.stringify(kept, null, 2));
      await move(`${file}.new`, file);
      return out;
    });
    queue = run.catch(() => {});
    return run.then(async (out) => { for (const id of dropped) await gone(id); return out; });
  };
  const find = (all: Row[], id: string) => {
    const r = all.find((x) => x.id === id);
    if (!r) throw new Error(`no conversation ${id} (cosm agent-session:list)`);
    return r;
  };
  /** The agent's own id for a conversation, kept to give back when it is carried on. */
  const agentId = (session: string, id: string) => change((all) => { const x = all.find((y) => y.id === session); if (x) x.agentSession = id; });
  /** A new conversation's id: short, and none on the list has it. */
  const newId = (all: Row[]) => {
    for (;;) { const id = `c-${Math.random().toString(36).slice(2, 6).padEnd(4, "0")}`; if (!all.some((r) => r.id === id)) return id; }
  };

  // --- the connectors ------------------------------------------------------------------------------------------------

  /** A connector by the name it is reached by (as `agent:list` gives it). */
  async function connector(name: string): Promise<Contribution<Agent>> {
    const all = await cosm.point.read<Agent>("agent:agents");
    const a = all.find((x) => x.as === name) ?? all.find((x) => `${x.package}:${x.name}` === name);
    if (!a) throw new Error(`no agent called ${name} is on (${all.map((x) => x.as).join(", ") || "none is"})`);
    return a;
  }
  /** What happened, told to the agent package (`agent:fire`), the conversation's id as its session: what its points'
   * contributions said comes back. */
  const fire = async (event: string, data: Record<string, unknown>): Promise<Said> => {
    try { return await cosm.call<Said>("agent:fire", { event, data }); } catch (e) { cosm.log(`${event}: ${e instanceof Error ? e.message : e}`); return { said: "" }; }
  };

  // --- what runs now -------------------------------------------------------------------------------------------------

  /** The chats running (what is sent while the agent answers waits in them). */
  const runs = new Map<string, Run>();
  /** Which of a conversation's programs runs now, as its connector says: none when it says nothing (it is off). */
  const runningOf = async (id: string, a: Contribution<Agent>): Promise<Running | null> => {
    try { return (await a.running({ session: id })) ?? null; } catch (e) { cosm.log(`${id}: ${e instanceof Error ? e.message : e}`); return null; }
  };
  /** A conversation's connector, as it is now (switched off and on again since, it is the new one). */
  const connectorOf = async (id: string) => connector(find(await read(), id).agent);
  const make = (id: string, agent: Contribution<Agent>): Run => {
    const r: Run = { id, agent, queue: Promise.resolve(), hold: cosm.package.keep(`the conversation ${id}`), busy: false, waiting: [], early: [], pending: [], said: [], steps: new Map(), asking: new Set(), open: new Map() };
    runs.set(id, r);
    return r;
  };
  const drop = (r: Run) => { if (runs.get(r.id) === r) runs.delete(r.id); r.hold.release(); };
  /** A run is over (its program ended, or is found gone): what is sent now is refused, whoever waits is told, and its
   * stream says so and closes. */
  const over = async (r: Run, why?: string) => {
    if (r.ended) return;
    r.ended = true;
    drop(r);
    r.unfollow?.();
    r.link?.abort("The agent stopped");
    await keepRun(r.id, null, r.started);
    for (const f of [...r.asking]) f({ text: "", failed: r.note ?? why ?? "the agent stopped" });
    r.release = undefined; r.waiting = []; r.early = []; r.answered = undefined;
    if (r.pending.length) { r.pending = []; void tellWaiting(r); }
    if (why) await (await stream(r)).write({ type: "note", text: why });
    if (r.stream) await r.stream.close();
  };
  /** The chat run of a conversation, true to its connector: one whose program is gone (its connector was switched off,
   * or the program ended unheard) is ended here. A run still starting is trusted: its program may not be there yet. */
  const chatOf = async (id: string, on: Running | null) => {
    const r = runs.get(id);
    if (r && !r.release && on?.as !== "chat") { await later(r, () => over(r, "The agent stopped.")); return undefined; }
    return r;
  };
  /** The messages waiting in a conversation changed: whoever shows them reads them again (`waiting`). */
  const tellWaiting = (r: Run) => cosm.emit("waiting", { session: r.id });
  /** In order, one conversation at a time: what comes is handled after what came before. */
  const later = (r: Run, f: () => Promise<void>) => { r.queue = r.queue.then(f).catch((e) => cosm.log(`${r.id}: ${e instanceof Error ? e.message : e}`)); return r.queue; };
  /** The ACP connection of a conversation's chat that runs now. */
  const linkOf = (id: string) => {
    const r = runs.get(id);
    if (!r?.link || r.gone) throw notRunning(id);
    return r.link;
  };
  /** What is kept of a chat's program (null: nothing), for the code starting again. Only the same program's entry
   * goes (`started`), so an older run's end never takes a newer one's. */
  const keepRun = (id: string, entry: Kept[string] | null, started?: number) => cosm.storage.update<Kept>("runs", (all) => {
    const next = { ...(all ?? {}) };
    if (entry) next[id] = entry; else if (started === undefined || next[id]?.started === started) delete next[id];
    return next;
  });
  /** Typed into a conversation's terminal as the user types: the words, then Enter a moment later (in one burst an
   * agent like Claude Code takes it as a paste and holds it). */
  const type = async (process: string, text: string) => {
    await cosm.process.write(process, text);
    await new Promise((r) => setTimeout(r, 100));
    await cosm.process.write(process, "\r");
  };
  /** Its program stops, as its connector stops it, and is waited for (a moment at most). */
  const stopProgram = async (id: string, a: Contribution<Agent>) => {
    await a.stop({ session: id });
    for (let i = 0; i < 40 && (await runningOf(id, a)); i++) await new Promise((r) => setTimeout(r, 100));
  };
  const stopped = (code?: number) => (!code ? "The agent stopped." : `The agent stopped (exit code ${code}).`);
  const notRunning = (id: string) => new Error(`the conversation ${id} isn't running: carry it on first (agent-session:start {"session": "${id}"})`);
  const stream = async (r: Run) => (r.stream ??= await cosm.stream.open(r.id, { keep: 20000 }));

  /** A conversation started, new (its agent the one named, else the cosm's: asked once when several and none set) or
   * carried on (`session`), as a chat or in its agent's terminal, with a first message: its id. A new one joins the
   * list at once, before its agent has an id for it. Started as a chat while it runs in its terminal, the connector
   * moves it (Claude Code runs a conversation once: the terminal stops). */
  /** Starts under way, by conversation and how: one asked again meanwhile (two views asking at once) waits for it,
   * never starting the agent's program twice. */
  const starting = new Map<string, Promise<string>>();
  function start(input: { agent?: string; session?: string; as?: "chat" | "terminal"; first?: string; title?: string } = {}): Promise<string> {
    if (!input.session || input.first) return startNow(input);
    const key = `${input.session}\n${input.as ?? "chat"}`;
    const had = starting.get(key);
    if (had) return had;
    const p = startNow(input).finally(() => starting.delete(key));
    starting.set(key, p);
    return p;
  }
  async function startNow({ agent: name, session, as = "chat", first, title }: { agent?: string; session?: string; as?: "chat" | "terminal"; first?: string; title?: string } = {}): Promise<string> {
    let id = session ?? "", a: Contribution<Agent> | null;
    if (session) {
      const row = await change((all) => { const r = find(all, session); delete r.closed; return r; });
      a = await connector(row.agent);
    } else {
      a = name ? await connector(name) : await cosm.point.default<Agent>("agent:agents");
      if (!a) throw new Error("No agent is on: switch one on in Settings → Packages.");
      const agent = a.as;
      id = await change((all) => { const n = newId(all); all.push({ id: n, agent, started: new Date().toISOString(), ...(title?.trim() ? { title: title.trim() } : {}) }); return n; });
      await cosm.emit("started", { session: id });
    }
    try { return await run(id, a, { as, first, carried: !!session }); }
    catch (e) {
      // A new one that didn't start leaves nothing: off the list again, its stream closed.
      if (!session) await forget(id).catch((x) => cosm.log(`${id}: taking it off the list: ${x instanceof Error ? x.message : x}`));
      throw e;
    }
  }
  /** A conversation's program started (or found running), as a chat or in its agent's terminal: its id. */
  async function run(id: string, a: Contribution<Agent>, { as, first, carried }: { as: "chat" | "terminal"; first?: string; carried: boolean }): Promise<string> {
    const resume = (await read()).find((x) => x.id === id)?.agentSession;
    // The agent in a terminal: its connector's process (one program a conversation: the chat's stops).
    if (as === "terminal") {
      const got = await a.start({ session: id, as, ...(resume ? { resume } : {}), ...(first ? { first } : {}) });
      if (got?.agentSession) await agentId(id, got.agentSession);
      return id;
    }
    const on = await runningOf(id, a);
    const was = await chatOf(id, on);
    if (was) { was.agent = a; if (first) await send({ session: id, message: first }, { by: "window" }); return id; }
    // Its chat runs, but no connection here speaks with it (this package's code started again since): stopped, and
    // started anew, carried on, rather than spoken with half-known.
    if (on?.as === "chat") await stopProgram(id, a);
    const r = make(id, a);
    await stream(r);
    // Until the agent says it has started: what is sent waits, and what packages send then goes first.
    r.busy = true;
    r.release = () => { r.release = undefined; r.busy = false; r.waiting = [...r.early, ...r.waiting]; r.early = []; void r.waiting.shift()?.(); };
    try {
      const got = await a.start({ session: id, as, ...(resume ? { resume } : {}) });
      if (!got?.process) throw new Error(`${a.label} didn't say which program runs the chat`);
      await speak(r, got, resume);
    } catch (e) {
      r.quiet = true;
      r.unfollow?.(); r.link?.abort("The agent didn't start");
      drop(r);
      await keepRun(id, null, r.started);
      if (r.stream) await r.stream.close().catch(() => {});
      throw e;
    }
    if (first) void send({ session: id, message: first }, { by: "window" }).catch((e) => cosm.log(`${id}: ${e instanceof Error ? e.message : e}`));
    // A new one is the one shown last from now on.
    if (!carried) await show(id);
    return id;
  }

  /** A chat's program, spoken with: its output read from its stream (kept from its first byte, so nothing it said
   * before this is lost), the ACP connection made (one of this conversation's own), and the agent's session made or
   * carried on. Fails when the program ends before the agent's session is there. */
  async function speak(r: Run, got: Started, resume?: string) {
    const process = got.process;
    r.process = process;
    r.started = (await cosm.process.list()).find((p) => p.name === process)?.started ?? 0;
    if (!resume && got.rules) r.rules = got.rules;
    if (got.agentSession) await agentId(r.id, got.agentSession);
    r.link = link((line) => cosm.process.write(process, `${line}\n`), (events) => {
      if (events.some((e) => e.type === "started")) r.began = true;
      void later(r, () => handle(r, events));
    });
    await keepRun(r.id, { process, started: r.started });
    r.unfollow = await cosm.stream.subscribe(process, (items, { closed, code, missed }) => {
      if (missed) void lost(r, missed);
      else if (!r.quiet) for (const l of items) r.link?.read(String(l));
      if (closed) ended(r, code);
    });
    await r.link.write({ type: "hello", cwd: cosm.package.folders.cosm, session: resume ?? "", resume: !!resume, mcpServers: servers(got.mcp ?? []) });
    if (r.gone && !r.began) throw new Error(`The agent's program ended as it started: ${process}'s log may say why.`);
  }

  /** A chat's program ended (its output's stream closed): the connection goes, whoever waits is told why, the run is
   * over (what is sent now is refused until it is carried on) and the conversation's stream closes. */
  function ended(r: Run, code?: number) {
    if (r.gone) return;
    r.gone = true;
    r.link?.abort("The agent stopped");
    void later(r, async () => {
      if (!r.quiet) await handle(r, [{ type: "note", text: stopped(code) }]);
      await over(r);
    });
  }

  /** Part of what the program said was lost before it was read (a gap in its output's numbers): the connection can't
   * be trusted on, so the turn ends as interrupted, with a note, and the program stops; the next message carries the
   * conversation on. */
  async function lost(r: Run, missed: number) {
    if (r.quiet) return;
    r.quiet = true;
    r.link?.abort("Part of what the agent said was lost");
    await later(r, async () => {
      const turn = r.busy && !r.release;
      await handle(r, [{ type: "note", text: `${missed} of the agent's messages were lost before Cosm read them, so it stopped the agent${turn ? " and this turn" : ""}: send again to carry the conversation on.` },
        ...(turn ? [{ type: "turn-end" as const, text: "", stopped: true }] : [])]);
    });
    await stopProgram(r.id, r.agent).catch(() => {});
  }

  /** To a conversation's agent: a text (a string, or `{text, images?, context?}`), or one of the agent's prompts by name
   * (`{prompt: "<package>:<name>"}`, in full or as it is reached), refused when the cosm leaves it out. While the agent
   * answers, it waits and goes when the turn ends; while the conversation starts, it waits behind the messages the
   * start's contributions give (`first`: agent:start's answers), whoever sends it. A conversation of which nothing runs
   * (Cosm started again since, its agent stopped) is carried on first, so a sender never has to. As it goes: shown in
   * the stream as the user's, the message's moment told (agent:message: what packages add goes with it), and typed to the agent. */
  async function send({ session, message }: { session: string; message: unknown }, { by, answered, first }: { by?: string; answered?: (turn: Turn) => void; first?: boolean } = {}): Promise<string> {
    const agent = await connectorOf(session);
    let on = await runningOf(session, agent);
    let r = await chatOf(session, on);
    // Nothing of it runs, or its chat runs with no connection here to speak with it: carried on first, here.
    if (!r && on?.as !== "terminal") {
      await start({ session });
      on = await runningOf(session, agent);
      r = await chatOf(session, on);
      if (!r && on?.as !== "terminal") throw notRunning(session);
    }
    if (r) r.agent = agent;
    let m: any = typeof message === "string" ? { text: message } : message;
    if (!m || typeof m !== "object") throw new Error("a message is a text, {text} or {prompt}");
    let prompt: string | undefined;
    if (typeof m.prompt === "string") {
      const prompts = await cosm.point.read("agent:prompts");
      const c = prompts.find((x) => `${x.package}:${x.name}` === m.prompt) ?? prompts.find((x) => x.as === m.prompt);
      if (!c) throw new Error(`${m.prompt} isn't one of the agent's prompts (left out, or no such prompt)`);
      prompt = c.as;
    }
    const text = prompt ? (agent.prompt ?? "/{name}").replaceAll("{name}", prompt) : String(m.text ?? "");
    const given = typeof m.context === "string" ? m.context : "";
    // Its id, made as it is sent (or given by the sender, to know it again): kept with it while it waits, then in the
    // stream and in message.sent, so what a package keeps about this message (what went with it) can name it.
    const id = typeof m.id === "string" && /^[A-Za-z0-9_-]{1,64}$/.test(m.id) ? m.id : `m-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    const images = (Array.isArray(m.images) ? m.images : []).map((i: unknown): { media_type: string; data: string } => {
      if (typeof i !== "string") return i as { media_type: string; data: string };
      const [, media_type = "image/png", data = ""] = /^data:([^;]+);base64,(.*)$/s.exec(i) ?? [];
      return { media_type, data };
    });
    // It runs in its terminal: typed in there as it is (an agent's own hooks tell the moment).
    if (!r) { await type(on!.process, text); return id; }
    const run = r;
    // Whoever waits for the turn's end is told once: at the end, or when it can't come.
    const told = answered && ((t: Turn) => { if (run.asking.delete(told!)) answered(t); });
    if (told) run.asking.add(told);
    const go = async () => {
      run.busy = true;
      run.answered = told; run.note = undefined;
      if (run.pending.some((p) => p.id === id)) { run.pending = run.pending.filter((p) => p.id !== id); void tellWaiting(run); }
      await later(run, async () => { await (await stream(run)).write({ type: "user", id, text, images: images.length ? images.map((i: { media_type: string; data: string }) => `data:${i.media_type};base64,${i.data}`) : undefined, ...(prompt ? { prompt } : {}) }); });
      const said = run.agent.hooks ? "" : (await fire("message.sent", { session, message: id, text, ...(prompt ? { prompt } : {}) })).said;
      const context = [...run.said.splice(0), given, said].filter(Boolean).join("\n\n");
      // The agent's hooks take it apart from the message (its hook on the message asks for it); else it goes in it.
      if (run.agent.hooks) { run.given = context; run.message = id; }
      if (!run.link || !run.process) throw notRunning(session);
      // A turn runs from here until its end (kept, for this package's code starting again meanwhile).
      await keepRun(session, { process: run.process, started: run.started ?? 0, turn: true });
      const rules = run.rules; run.rules = undefined;
      await run.link.write({ type: "message", text, images: images.length ? images : undefined, context: !run.agent.hooks && context ? context : undefined, rules });
    };
    // A hand-over that failed: no turn runs, so the next message waiting goes.
    const failed = () => { run.busy = false; run.answered = undefined; void run.waiting.shift()?.(); };
    /** It waits: shown as waiting until it goes. */
    const wait = () => { run.pending.push({ id, text, ...(images.length ? { images: images.map((i: { media_type: string; data: string }) => `data:${i.media_type};base64,${i.data}`) } : {}), ...(prompt ? { prompt } : {}), ...(by ? { by } : {}) }); void tellWaiting(run); };
    const queued: Queued = () => go().catch((e) => {
      failed();
      const why = e instanceof Error ? e.message : String(e);
      cosm.log(`${session}: ${why}`);
      told?.({ text: "", failed: why });
    });
    queued.id = id;
    if (run.release && first) { run.early.push(queued); wait(); return id; }
    if (run.busy) {
      // The shell waits for its own turn: never behind one that runs (the agent sending to its own conversation would
      // wait on itself), so it is refused then.
      if (told && !run.release) { run.asking.delete(told); throw new Error(`the conversation ${session} is answering now: send again once its turn has ended`); }
      run.waiting.push(queued); wait(); return id;
    }
    try { await go(); }
    catch (e) { if (told) run.asking.delete(told); failed(); throw e; }
    return id;
  }

  /** The shell's send: carried on first when nothing of it runs (as a chat), sent, and waited on until the agent's turn
   * ends (its reply), the agent asks something (what, and how to answer), or its program ends (why). Refused while a
   * turn runs. Running in its terminal: typed in there, nothing to wait on. */
  async function ask(session: string, text: string): Promise<string> {
    const on = await runningOf(session, await connectorOf(session));
    if (on?.as === "terminal") { await send({ session, message: text }, { by: "shell" }); return "typed into its terminal"; }
    const turn = await new Promise<Turn>((resolve, reject) => { send({ session, message: text }, { by: "shell", answered: resolve }).catch(reject); });
    if (turn.failed) throw new Error(turn.failed);
    if (turn.asked) return asking(session, turn.asked);
    return turn.stopped ? (turn.text ? `${turn.text}\n(stopped)` : "(stopped)") : turn.text;
  }

  /** What the agent asks, for the shell: the question, and the commands that answer it. */
  function asking(session: string, q: Asked): string {
    const cmd = (answer: string) => `cosm agent-session:answer ${session} ${/^[\w-]+$/.test(answer) ? answer : `'${answer.replaceAll("'", "'\\''")}'`}`;
    if (q.type === "permission") return [`The agent asks to go on with a step: ${q.title}`, ...(q.detail ? [q.detail] : []), "",
      `Allow it: ${cmd("allow")}`, ...(q.always ? [`Allow ${q.always} from now on: ${cmd("always")}`] : []), `Refuse it: ${cmd("deny")}`].join("\n");
    if (q.type === "plan") return [`The agent asks to go ahead with its plan:`, q.plan, "", `Go ahead: ${cmd("allow")}`, `Not yet: ${cmd("deny")}`].join("\n");
    const lines = q.questions.flatMap((x) => [x.question, ...x.options.map((o) => `  - ${o.label}${o.description ? `: ${o.description}` : ""}`)]);
    const one = q.questions.length === 1;
    const example = one ? (q.questions[0]!.options[0]?.label ?? "your answer") : JSON.stringify(Object.fromEntries(q.questions.map((x) => [x.question, x.options[0]?.label ?? "…"])));
    return [`The agent asks:`, ...lines, "",
      `Answer (${one ? "a choice, or words of your own" : "each question's answer, by its question"}${q.questions.some((x) => x.multi) ? `; several choices joined by ", "` : ""}): ${cmd(example)}`, `Decline: ${cmd("deny")}`].join("\n");
  }

  /** The shell's answer to what the agent asks in a conversation (`cosm agent-session:answer`): to its oldest open
   * question, or the one named (`id`, as its stream gives it). A step: allow, always (allow it from now on, when
   * offered) or deny. A plan: allow (go ahead) or deny. Questions: deny declines; else the answer to the only question
   * (a choice's label or words of the user's own), or, with several, a JSON object of each question's answer. */
  async function answerFromShell(session: string, said: string, id?: string): Promise<string> {
    const r = runs.get(session);
    const open = r ? [...r.open.values()] : [];
    if (!open.length) throw new Error(`the agent in ${session} isn't asking anything now`);
    const q = id ? open.find((x) => x.id === id) : open[0];
    if (!q) throw new Error(`no open question ${id} in ${session} (open: ${open.map((x) => x.id).join(", ")})`);
    const word = said.trim();
    let answer: AgentAnswer;
    if (word === "deny") answer = { id: q.id, allow: false };
    else if (q.type !== "question") {
      if (!["allow", "always"].includes(word)) throw new Error(`answer a ${q.type === "plan" ? "plan with allow or deny" : `step with allow, ${q.always ? "always or " : ""}deny`}`);
      if (word === "always" && (q.type !== "permission" || !q.always)) throw new Error("this one can't be allowed from now on: allow or deny");
      answer = { id: q.id, allow: true, ...(word === "always" ? { always: true } : {}) };
    } else if (q.questions.length === 1) answer = { id: q.id, allow: true, answers: { [q.questions[0]!.question]: word } };
    else {
      let all: Record<string, string>;
      try { all = JSON.parse(word); } catch { throw new Error(`the agent asks ${q.questions.length} questions: answer each, as {"<question>": "<answer>"}`); }
      answer = { id: q.id, allow: true, answers: all };
    }
    await linkOf(session).write({ type: "answer", ...answer });
    r?.open.delete(q.id);
    return q.type === "question" ? "answered" : answer.allow ? "allowed" : "refused";
  }

  /** A path inside the cosm, as the chat shows it: relative to the cosm's folder (a page's path); one outside, whole. */
  const inside = (path: string) => (path.startsWith(`${cosm.package.folders.cosm}/`) ? path.slice(cosm.package.folders.cosm.length + 1) : path);
  const within = (e: CosmEvent): CosmEvent => {
    if (e.type !== "step" && e.type !== "step-done") return e;
    const content = e.content?.map((x) => (x.type === "diff" ? { ...x, path: inside(x.path) } : x));
    return e.type === "step" ? { ...e, ...(e.path ? { path: inside(e.path) } : {}), content } : { ...e, content };
  };

  /** What the agent said in a conversation's chat (its ACP connection's events), in order, inside the run's queue:
   * written to the conversation's stream, and told as the moments they are; what the moments' contributions say goes
   * to the agent with the next message. */
  /** The model and the effort the user chose last, by agent (`chosen` in storage): a new conversation starts on them. */
  type Chosen = Record<string, { model?: string; effort?: string }>;
  async function chosenAgain(run: Run, e: Extract<CosmEvent, { type: "models" }>) {
    const agent = find(await read(), run.id).agent;
    const want = ((await cosm.storage.get<Chosen>("chosen")) ?? {})[agent];
    if (!want || !run.link) return;
    const model = want.model && want.model !== e.current && e.models.some((m) => m.id === want.model) ? want.model : undefined;
    const effort = want.effort && e.effort && want.effort !== e.effort.current && e.effort.levels.some((l) => l.id === want.effort) ? want.effort : undefined;
    if (!model && !effort) return;
    try {
      if (model) await run.link.write({ type: "model", model });
      if (effort) await run.link.write({ type: "effort", effort });
      // What the chat shows: the choice as it is now.
      await (await stream(run)).write({ ...e, current: model ?? e.current, ...(e.effort ? { effort: { ...e.effort, current: effort ?? e.effort.current } } : {}) });
    } catch (x) { cosm.log(`${run.id}: the model chosen last wasn't taken: ${x instanceof Error ? x.message : x}`); }
  }

  async function handle(run: Run, events: CosmEvent[]) {
    const session = run.id;
    events = events.map(within);
    const shown = events.filter((e) => e.type !== "agent-session");
    if (shown.length) await (await stream(run)).write(...shown);
    const keep = (s: Said) => { if (!run.agent.hooks && s.said) run.said.push(s.said); };
    for (const e of events) {
      // The agent's own id for the conversation, given back to carry it on.
      if (e.type === "agent-session") await agentId(session, e.id);
      // It started: what the start's contributions say goes with the first message, what they send goes first.
      else if (e.type === "started") {
        const s = await fire("started", { session, reason: e.resumed ? "resume" : "startup" });
        if (s.said) run.said.push(s.said);
        for (const m of s.send ?? []) await send({ session, message: m }, { by: "agent-session", first: true }).catch((x) => cosm.log(`${session}: ${x instanceof Error ? x.message : x}`));
        run.release?.();
      }
      // It didn't start: nothing waits on it. A note that comes with its start (an agent that can't carry a
      // conversation on says so, then starts anew) leaves the start to release it, so what the start's contributions
      // send still waits (sent from inside this queue, it would wait on itself).
      else if (e.type === "note") { run.note = e.text; if (!events.some((x) => x.type === "started")) run.release?.(); }
      // The agent asks (a step, a plan, questions): whoever waits for the turn hears it now, as the turn waits on an
      // answer.
      else if (e.type === "permission" || e.type === "plan" || e.type === "question") { run.open.set(e.id, e); const a = run.answered; run.answered = undefined; a?.({ text: "", asked: e }); }
    else if (e.type === "cancel") run.open.delete(e.id);
      else if (e.type === "usage") run.usage = { used: e.used, size: e.size };
      // What the agent offers: the model and effort the user chose last for this agent, when it offers them, again.
      else if (e.type === "models" && !run.picked) { run.picked = true; await chosenAgain(run, e); }
      else if (e.type === "turn-end") {
        // How full it is, as its agent said: kept on the list (the holder's gauge).
        const u = run.usage;
        if (u) await change((all) => { const x = all.find((y) => y.id === session); if (x) { x.used = u.used; x.size = u.size; } });
        // A turn the user stopped is told here for every agent: an agent's own hooks don't run then.
        if (!run.agent.hooks || e.stopped) await fire("turn.ended", { session, text: e.text ?? "", stopped: !!e.stopped, ...(u ?? {}) });
        run.busy = false;
        run.open.clear();
        const answered = run.answered;
        run.answered = undefined;
        answered?.({ text: e.text ?? "", ...(e.stopped ? { stopped: true } : {}), ...(!e.text && run.note ? { failed: run.note } : {}) });
        if (run.process && !run.gone) await keepRun(session, { process: run.process, started: run.started ?? 0 });
        void run.waiting.shift()?.();
      } else if (!run.agent.hooks && e.type === "step") {
        const tool = e.name ?? e.kind ?? "other";
        run.steps.set(e.id, tool);
        if (e.kind === "read" && e.path) await fire("file.read", { session, path: e.path });
        keep(await fire("step.before", { session, step: tool, ...(e.path ? { file: e.path } : {}) }));
      } else if (!run.agent.hooks && e.type === "step-done" && e.error && !e.refused) {
        const why = (e.content ?? []).flatMap((x) => (x.type === "text" ? [x.text] : [])).join("\n");
        keep(await fire("step.failed", { session, step: run.steps.get(e.id) ?? "other", text: why }));
      }
    }
  }

  /** A moment the agent's own hooks told (Claude Code's, through its connector), for the conversation its program was
   * started for (`session`: the connector writes it into its hooks): told to the agent package with the conversation's
   * id. With a message, what went with it apart from the user's words comes back too, and its id goes in the moment. */
  async function hook({ session, event, data = {} }: { session: string; event: string; data?: Record<string, unknown> }): Promise<Said> {
    const row = (await read()).find((x) => x.id === session);
    if (!row) return { said: "" };
    const r = runs.get(row.id);
    // A chat's start is told from its chat, before any message (its connector says whether the chat is what runs); a
    // start inside it (cleared, compacted) only its agent's hooks tell, and what goes to the agent goes back with them.
    if (event === "started" && !(["clear", "compact"] as unknown[]).includes(data.reason) && r && (await runningOf(row.id, r.agent))?.as === "chat") return { said: "" };
    const d: Record<string, unknown> = { ...data, session: row.id };
    let given = "";
    if (event === "message.sent" && r) {
      if (r.message) d.message = r.message;
      given = r.given ?? ""; r.given = undefined;
    }
    const { send: give, ...s } = await fire(event, d);
    // A terminal's start (its hooks tell it): what the start's contributions give is typed in once the hook is answered.
    for (const m of give ?? []) void send({ session: row.id, message: m }, { by: "agent-session" }).catch((x) => cosm.log(`${row.id}: ${x instanceof Error ? x.message : x}`));
    return event === "message.sent" ? { ...s, said: [given, s.said].filter(Boolean).join("\n\n") } : s;
  }

  /** The list, newest first, with what each agent keeps of its own (title; how full when no turn told it). */
  async function list(): Promise<Shown[]> {
    const all = (await read()).reverse();
    const byAgent = new Map<string, Row[]>();
    for (const r of all) (byAgent.get(r.agent) ?? byAgent.set(r.agent, []).get(r.agent)!).push(r);
    const said = new Map<string, Record<string, unknown>>();
    await Promise.all([...byAgent].map(async ([agent, rows]) => {
      try {
        const a = await connector(agent);
        const ids = rows.slice(0, 50).flatMap((r) => (r.agentSession ? [r.agentSession] : []));
        if (!a.sessions || !ids.length) return;
        for (const s of await a.sessions({ sessions: ids })) {
          const row = rows.find((r) => r.agentSession === String(s.id));
          if (row) said.set(row.id, s);
        }
      } catch { /* its connector is off, or says nothing */ }
    }));
    return all.map((r) => {
      const s = said.get(r.id) ?? {};
      return { ...r, active: !r.closed, agentTitle: typeof s.title === "string" ? s.title : undefined,
        tokens: r.used ?? (typeof s.tokens === "number" ? s.tokens : undefined), size: r.size ?? (typeof s.size === "number" ? s.size : undefined),
        model: typeof s.model === "string" ? s.model : undefined };
    });
  }
  /** Its program ends (chat or terminal); the conversation stays on the list, open. */
  async function stop(session: string) {
    // The chat's run is over once its program has ended (its stream closes then).
    const a = await connectorOf(session).catch(() => null);
    await a?.stop({ session });
  }
  /** Closes one: unless a handler keeps it open (`closed.before`), its run ends and it is marked closed. */
  async function close(session: string): Promise<{ kept?: string }> {
    const r = find(await read(), session);
    if (r.closed) return {};
    const asked = await cosm.emit("closed.before", { session });
    if (asked.stop) return { kept: asked.stop };
    await stop(session).catch(() => { /* not running */ });
    await change((all) => { find(all, session).closed = new Date().toISOString(); });
    await cosm.emit("closed", { session });
    return {};
  }
  /** Open again (its run starts when the user types in it). */
  const reopen = (session: string) => change((all) => { delete find(all, session).closed; });
  /** Off the list (the agent's own record of it stays): an open one is closed first. */
  async function remove(session: string): Promise<{ kept?: string }> {
    const c = await close(session);
    if (c.kept) return c;
    await forget(session);
    return {};
  }
  /** Off the list, then gone. */
  async function forget(session: string) {
    await change((all) => { const i = all.findIndex((r) => r.id === session); if (i >= 0) all.splice(i, 1); });
    await gone(session);
  }
  /** Off the list already: its stream ends (one still open: a closed one isn't opened again only to close it), its
   * storage goes, and it is told (`removed`), the last two whatever the stream does. */
  async function gone(session: string) {
    try {
      const name = `${cosm.package.name}:${session}`;
      if ((await cosm.stream.list({ package: cosm.package.name })).some((s) => s.name === name && s.open)) await (await cosm.stream.open(session)).close();
    } catch (e) { cosm.log(`${session}: its stream: ${e instanceof Error ? e.message : e}`); }
    for (const k of await cosm.storage.list()) if (k.startsWith(`${session}/`)) await cosm.storage.delete(k);
    await cosm.emit("removed", { session });
  }
  /** The user's own title ("" gives the agent's back). */
  const rename = (session: string, title: string) => change((all) => { const r = find(all, session); if (title.trim()) r.title = title.trim(); else delete r.title; });
  /** The conversation shown last (what the holder shows when it is given none), and the holder telling it. */
  const shown = async () => ((await cosm.storage.get<string>("shown-session")) ?? "");
  const show = (session: string) => cosm.storage.set("shown-session", session);

  type S = { session: string };
  const sessionKey = (session: string, by: string, key: string) => `${session}/${by}:${key}`;
  // The broker, for every package: conversations are started, sent to and ended only here.
  cosm.package.export({
    /** A new conversation (or one carried on: `session`), its id back: `first` sent as its first message, `title` its
     * title on the list (a new one). */
    start: (input: { agent?: string; session?: string; as?: "chat" | "terminal"; first?: string; title?: string } = {}) => start(input),
    /** Which of a conversation's programs runs now (a chat, or its agent in a terminal), as its connector says: with its
     * process's full name (what Agent terminal draws); null when none runs. */
    running: async ({ session }: S) => runningOf(session, await connectorOf(session)),
    /** To a conversation's agent; its message's id back (the one it has in the stream once it goes). */
    send: (input: S & { message: unknown }, ctx: { by: string }) => send(input, ctx),
    /** The messages sent to a conversation that haven't gone yet, oldest first (told by `waiting` as they change). */
    waiting: ({ session }: S) => runs.get(session)?.pending ?? [],
    /** A waiting message taken back before it goes, by its id; false when it has gone already (or never waited). */
    unsend: ({ session, id }: S & { id: string }) => {
      const r = runs.get(session);
      if (!r?.pending.some((p) => p.id === id)) return false;
      r.waiting = r.waiting.filter((f) => f.id !== id); r.early = r.early.filter((f) => f.id !== id);
      r.pending = r.pending.filter((p) => p.id !== id); void tellWaiting(r);
      return true;
    },
    /** A conversation's storage, for any package: small things a package keeps about one conversation, gone when the
     * conversation leaves the list. Each package has its own keys (kept here as `<session>/<package>:<key>`). */
    "storage-get": async ({ session, key }: S & { key: string }, { by }: { by: string }) => (await cosm.storage.get(sessionKey(session, by, key))) ?? null,
    "storage-set": async ({ session, key, value }: S & { key: string; value: unknown }, { by }: { by: string }) => {
      find(await read(), session);
      await cosm.storage.set(sessionKey(session, by, key), value);
      await cosm.emit("storage.changed", { session, package: by, key });
    },
    "storage-delete": async ({ session, key }: S & { key: string }, { by }: { by: string }) => {
      await cosm.storage.delete(sessionKey(session, by, key));
      await cosm.emit("storage.changed", { session, package: by, key });
    },
    /** What the agent asked (a step, a plan, a form), answered by the id in its stream. */
    answer: async ({ session, answer }: S & { answer: AgentAnswer }) => { await linkOf(session).write({ type: "answer", ...answer }); runs.get(session)?.open.delete(answer.id); },
    /** Its turn stops; the conversation goes on. */
    cancel: async ({ session }: S) => { await linkOf(session).write({ type: "stop" }); },
    /** The model or the effort, among what the agent offers. */
    set: async ({ session, model, effort }: S & { model?: string; effort?: string }) => {
      const l = linkOf(session);
      if (model) await l.write({ type: "model", model });
      if (effort) await l.write({ type: "effort", effort });
      // Kept for its agent: the next conversation with it starts on them.
      const agent = find(await read(), session).agent;
      const all = (await cosm.storage.get<Chosen>("chosen")) ?? {};
      all[agent] = { ...all[agent], ...(model ? { model } : {}), ...(effort ? { effort } : {}) };
      await cosm.storage.set("chosen", all);
    },
    stop: ({ session }: S) => stop(session),
    close: ({ session }: S) => close(session),
    /** A conversation as the list keeps it, with its agent's package. */
    get: async ({ session }: S) => { const row = find(await read(), session); return { ...row, package: (await connector(row.agent).catch(() => null))?.package ?? row.agent }; },
    hook,
    /** A connector says the agent's own id for a conversation is now another (a fresh start in its terminal, which only
     * its hooks see): kept, and given back to carry the conversation on. */
    "agent-id": async ({ session, id }: S & { id: string }) => { find(await read(), session); if (id) await agentId(session, id); },
  });

  // This code starting again while a conversation's chat program ran (its code changed, or it crashed): the connection
  // with it went with the old code, and none is pretended. The turn that ran ends as interrupted, with a note; the
  // program stops; the next message carries the conversation on (session/load where the agent can). At Cosm's start
  // no program outlives the last run, so what was kept goes.
  cosm.on("package.started", async ({ reason }) => {
    const kept = (await cosm.storage.get<Kept>("runs")) ?? {};
    if (!Object.keys(kept).length) return;
    await cosm.storage.delete("runs");
    if (reason === "startup") return;
    const procs = await cosm.process.list();
    for (const [session, k] of Object.entries(kept)) {
      const p = procs.find((x) => x.name === k.process);
      if (!p?.running || p.started !== k.started || runs.has(session)) continue;
      const row = (await read()).find((r) => r.id === session);
      const s = await cosm.stream.open(session, { keep: 20000 });
      await s.write({ type: "note", text: `Cosm's part that speaks with the agent started again${k.turn ? " while it worked" : ""}, so it stopped the agent: send again to carry the conversation on.` },
        ...(k.turn ? [{ type: "turn-end", text: "", stopped: true }] : []));
      if (k.turn) await fire("turn.ended", { session, text: "", stopped: true });
      const a = row ? await connector(row.agent).catch(() => null) : null;
      try { await a?.stop({ session }); } catch (e) { cosm.log(`${session}: ${e instanceof Error ? e.message : e}`); }
      await s.close();
    }
  });
  // The agent learns which conversation it is in at each start (for its own `cosm agent-session:rename <id>` and the like): said as
  // the conversation starts.
  // Once a start (new, carried on, after a clear or a compaction), never with an ordinary message.
  cosm.point.add("agent:start", { name: "session", run: ({ session }: { session?: string }) => (session ? `This conversation is ${thingOf(session)} (its id: ${session}).` : "") });

  // Its views' functions, each taking one object (its input).
  // The list follows its own events and a turn ending (a title, how full); the agents, packages switched on or off.
  const listChanges = { events: ["agent-session:started", "agent-session:closed", "agent-session:removed", "agent:turn.ended"] };
  cosm.view.export({ list: { run: list, changes: listChanges }, start: (input: { agent?: string } = {}) => start({ agent: input.agent }), close: ({ session }: S) => close(session),
    reopen: ({ session }: S) => reopen(session), remove: ({ session }: S) => remove(session),
    rename: ({ session, title }: S & { title: string }) => rename(session, title), shown, show: ({ session }: S) => show(session),
    agents: { description: "The agents that are on.", changes: { events: ["package.changed"] }, run: () => cosm.call("agent:list") },
    /** Which of the views placed in the holder it shows, as kept. */
    shownView: { changes: {}, run: async () => (await cosm.storage.get<string>("shown")) ?? "" },
    keepShownView: ({ view }: { view: string }) => cosm.storage.set("shown", view) });
  // In ⌘K and the menu bar's Session menu (its own).
  const both = [{ in: "palette" }, { in: "menu-bar", menu: "Session" }];
  cosm.point.add("cosm:items", { name: "new", label: "New Session", content: { description: "A new session with the agent: it starts with your first message" }, location: both, keys: "CmdOrCtrl+Alt+N",
    action: async () => { await cosm.ui.open("agent-session:holder", thingOf(await start())); } });
  cosm.point.add("cosm:items", { name: "close", label: "Close Session", content: { description: "Done with the session shown (packages may ask something first)" }, location: both,
    action: async () => { const s = await shown(); if (!s || s.endsWith(":")) return "No session is open."; const r = await close(s); return r.kept ? `It stays open: ${r.kept}` : undefined; } });

  // On a problem Cosm shows (a notice, a part changed since it was overridden): ask the agent about it, in the
  // conversation it was chosen in, else the one on screen used last, else a new one.
  cosm.point.add("cosm:items", { name: "ask", label: "Ask the Agent", content: { description: "The agent looks into it" }, location: { in: "notice" },
    action: async ({ text, package: about, thing }) => {
      let s = idOf(thing) || (await cosm.ui.shown()).map((x) => ({ id: idOf(x.arg), used: x.used })).filter((x) => x.id).sort((a, b) => b.used.localeCompare(a.used))[0]?.id;
      if (!s) s = await start();
      const prompt = `${about ? `The package ${about} reported a problem` : "A problem came up"}: ${text ?? ""} Can you look into it, and offer to fix it?`;
      // Carried on only when nothing of it runs: running in its terminal, it is typed in there.
      if (!(await runningOf(s, await connectorOf(s)))) await start({ session: s });
      await send({ session: s, message: prompt }, { by: "window" });
    } });

  // The shell's (and the agent's): the same, by the conversation's id.
  const text = (s: Shown) => `${s.id}\t${s.active ? "open" : "closed"}\t${s.title ?? s.agentTitle ?? "New session"}\t${s.agentSession ?? ""}`;
  const id = { name: "session", type: "text" as const, description: "The conversation's id, as cosm agent-session:list gives it (c-7k2p)" };
  cosm.point.add("cosm:commands", { name: "new", description: "Starts a new session with the cosm's agent now: its id.", run: () => start() });
  cosm.point.add("cosm:commands", { name: "list", description: "The cosm's conversations with its agents, newest first: id, open or closed, title, and the agent's own id for it.", run: async () => (await list()).map(text).join("\n") });
  cosm.point.add("cosm:commands", { name: "close", description: "Closes a conversation (a package may keep it open first: it says why).", inputs: [id], run: async ({ session }) => { const r = await close(session); return r.kept ? `kept open: ${r.kept}` : "closed"; } });
  cosm.point.add("cosm:commands", { name: "reopen", description: "Opens a closed conversation again.", inputs: [id], run: async ({ session }) => { await reopen(session); return "open"; } });
  cosm.point.add("cosm:commands", { name: "remove", description: "Takes a conversation off the list (closing it first); the agent's own record of it stays.", inputs: [id], run: async ({ session }) => { const r = await remove(session); return r.kept ? `kept open: ${r.kept}` : "removed"; } });
  cosm.point.add("cosm:commands", { name: "send", description: "Sends a message to a conversation (carried on first when it isn't running) and waits for the agent's turn to end: prints its reply, `(stopped)` after it when the user stopped the turn; fails with why when the agent couldn't answer. When the agent asks something first (a step, a plan, questions), prints it and the command that answers it. Refused while a turn of the conversation runs. A conversation running in its terminal gets the text typed in, and nothing is waited for.",
    inputs: [id, { name: "text", type: "text", description: "The message, as the user would type it" }], run: ({ session, text }) => ask(session, text) });
  cosm.point.add("cosm:commands", { name: "answer", description: "Answers what the agent asks in a conversation (as `cosm agent-session:send` prints it): its oldest open question, or the one `--id` names. A step: allow, always (allow it from now on, when offered) or deny. A plan: allow (go ahead) or deny. A question: a choice's label or words of your own (several questions: {\"<question>\": \"<answer>\"}), or deny to decline. The turn goes on.",
    inputs: [id, { name: "answer", type: "text", description: "allow, always, deny, or the answer to a question" }, { name: "id", type: "text", optional: true, description: "Which open question, by its id in the conversation's stream (the oldest when not given)" }],
    run: ({ session, answer, id: which }) => answerFromShell(session, answer, which) });
  cosm.point.add("cosm:commands", { name: "which", description: "The conversation an agent's own session id belongs to (its thing, agent-session:session:<id>): how an agent that lost its conversation's id finds it again.",
    inputs: [{ name: "agent", type: "text", description: "The agent's own id for its session (Claude Code's session id)" }],
    run: async ({ agent }) => {
      const row = (await read()).filter((r) => r.agentSession === agent).pop();
      if (!row) throw new Error(`no conversation has the agent's id ${agent} (cosm agent-session:list shows each one's)`);
      return thingOf(row.id);
    } });
  cosm.point.add("cosm:commands", { name: "rename", description: "Names a conversation (an empty title gives the agent's back).", inputs: [id, { name: "title", type: "text", optional: true }], run: async ({ session, title }) => { await rename(session, title ?? ""); return "named"; } });
}
