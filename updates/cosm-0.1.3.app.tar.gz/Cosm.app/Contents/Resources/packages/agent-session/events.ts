// The chat's own vocabulary: what a conversation's stream (`agent-session:<id>`) holds, one item each, which Agent
// session writes from what the agent says (through its ACP connection, acp.ts) and Agent chat draws. Types only, with no imports, so a view's build can take them too (Agent chat's, by its own
// path to this file); a package imports them as Agent session's (`import type { CosmEvent } from "package:agent-session"`).

export type Json = Record<string, unknown>;
export type Command = { name: string; description: string; hint?: string };
export type Model = { id: string; name: string; description?: string };
export type Q = { question: string; header?: string; multi?: boolean; options: { label: string; description?: string }[] };
/** What a step shows when opened: an edit as a diff, or text. */
export type ToolContent = { type: "diff"; path: string; oldText: string | null; newText: string } | { type: "text"; text: string };
export type CosmEvent =
  | { type: "commands"; commands: Command[] }
  /** The model choice, and the effort (thought level) when the agent offers one. */
  | { type: "models"; models: Model[]; current: string; effort?: { current: string; levels: Model[] } }
  | { type: "text-start"; id: string } | { type: "text-delta"; text: string }
  | { type: "step"; id: string; title: string; name?: string; write?: boolean; kind?: string; content?: ToolContent[]; page?: string; path?: string }
  | { type: "step-done"; id: string; content?: ToolContent[]; error?: boolean; refused?: boolean }
  | { type: "permission"; id: string; step?: string; title: string; detail?: string; always?: string }
  | { type: "question"; id: string; step?: string; questions: Q[] }
  | { type: "plan"; id: string; step?: string; plan: string }
  | { type: "cancel"; id: string }
  /** What the user said; `name`, one of Cosm's commands by name. */
  | { type: "user"; /** The message's id, made as it is sent: what is kept about a message names it. A message
      * of the past the agent replays has none. */ id?: string; text: string; images?: string[]; /** Sent as one of the agent's prompts, by its name. */ prompt?: string }
  | { type: "usage"; used: number; size: number }
  /** The session is there, new or carried on (agent:start's moment). */
  | { type: "started"; resumed: boolean }
  /** The session's past has been drawn (session/load answered). */
  | { type: "loaded" }
  /** The agent's own id for the session, made or changed (Agent session keeps it; not in the stream). */
  | { type: "agent-session"; id: string }
  | { type: "turn-end"; text?: string; denied?: { step?: string; title: string }[]; stopped?: boolean }
  | { type: "note"; text: string };
