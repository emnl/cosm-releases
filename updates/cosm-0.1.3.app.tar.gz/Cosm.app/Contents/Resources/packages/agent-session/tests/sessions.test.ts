// Agent session with the stand-in agent (nothing spent): conversations by command, a message sent and answered, and
// the holder in the window showing the conversation in Agent chat.
import { describe, expect, test } from "bun:test";
import { testCosm } from "cosm/test";

const agentCosm = async () => {
  const c = await testCosm({ packages: ["stand-in", "agent-chat"] });
  await c.run("setting", "default", "agent:agents", "stand-in");
  return c;
};

describe("Agent session", () => {
  test("a conversation started, listed, answered and removed, by command", async () => {
    await using c = await agentCosm();
    const id = (await c.run("agent-session:new")).trim();
    expect(id).toMatch(/^c-/);
    expect(await c.run("agent-session:list")).toContain(id);
    expect((await c.run("agent-session:send", "--session", id, "--text", "Hello there")).length).toBeGreaterThan(0);
    await c.run("agent-session:remove", "--session", id);
    expect(await c.run("agent-session:list")).not.toContain(id);
  }, 60000);

  test("in the window, the holder shows the conversation in the chat, a message once with the agent's answer", async () => {
    await using c = await agentCosm();
    const id = (await c.run("agent-session:new")).trim();
    await c.window();
    await c.run("ui", "open", "agent-session:holder", `agent-session:session:${id}`);
    await c.run("ui", "wait", "--view", "agent-chat:chat", "--timeout", "30");
    const box = /textbox "Message input"[^\n]*\[ref=([a-z]+\d+)\]/.exec(await c.run("ui", "outline", "agent-chat:chat"))?.[1] ?? "";
    expect(box).not.toBe("");
    await c.run("ui", "type", box, "What is open on Acme?");
    await c.run("ui", "press", box, "Enter");
    await c.run("ui", "wait", "--text", "What is open on Acme?", "--view", "agent-chat:chat");
    const out = await c.run("ui", "outline", "agent-chat:chat");
    expect(out.split("What is open on Acme?").length - 1).toBe(1);
  }, 90000);
});
