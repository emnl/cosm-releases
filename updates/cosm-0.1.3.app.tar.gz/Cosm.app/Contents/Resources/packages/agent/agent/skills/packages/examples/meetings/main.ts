import type { Cosm, Facts } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:kinds", { name: "meeting", extends: "markdown:page", match: "meetings/**/*.md", label: "Meeting note",
    // Each [[Name]] on the Attendees line as an attendee; the date in the file's name as the day it was held.
    facts: meetingFacts });
  async function meetingFacts({ things }: { things: string[] }) {
    const out: Record<string, Facts> = {};
    for (const path of things) {
      const text = await cosm.file.read(path).catch(() => "");
      const line = text.split("\n").find((l) => l.startsWith("Attendees:")) ?? "";
      const facts: Facts = { attendee: [...line.matchAll(/\[\[([^\]|#]+)/g)].map((m) => ({ to: m[1] })) };
      const day = /^\d{4}-\d{2}-\d{2}/.exec(path.split("/").pop() ?? "")?.[0];
      if (day) facts.held = { date: day };
      out[path] = facts;
    }
    return out;
  }
}
