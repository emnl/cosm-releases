// Dusk: one dark theme, kept in a JSON file and added to Cosm's themes.
import type { Cosm, Theme } from "cosm";
import dusk from "./themes/dusk.json";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:themes", { name: "dusk", ...(dusk as Theme) });
}
