// Short catch-up: Star chart's /recall, shorter. The package's own agent/prompts/recall.md takes the place of Star
// chart's (made with `cosm part replace star-chart:agent/prompts/recall short-catch-up`). cosm.lock keeps the
// fingerprint of Star chart's recall as it was when taken, so Cosm says when Star chart changes it.
import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.part.override("star-chart:agent/prompts/recall", { file: "agent/prompts/recall.md" });
}
