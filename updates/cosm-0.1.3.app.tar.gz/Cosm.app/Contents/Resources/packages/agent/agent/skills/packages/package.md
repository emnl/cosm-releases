# The package: cosm.json, main.ts, settings, versions and checking

A package is a folder, run as it is: `cosm.json` says who it is, `main.ts` registers everything it adds, and its
content is files in folders found by their names. This page covers the folder, `cosm.json`, `main.ts` and what
registering means, the packages it uses, settings, secrets and presets, libraries, what a package keeps, versions,
and `cosm package check`. What each other call does is on its topic page (SKILL.md, Where to look next).

## Where packages live

| Where | What | On at first |
|---|---|---|
| built in (each one's folder: `cosm package list`) | the packages shipped with Cosm; never edited where they are | when Cosm's own list says so (below) |
| `.cosm/packages/<name>/` | the cosm's own: built here, added from a repo, or a copy of a built-in one (which then takes its place in this cosm) | off until switched on |
| a folder on this computer | `cosm package add <folder>`: used where it is, for working on a package | off until switched on |

Which are on: `.cosm/packages.json`, `{"<name>": true | false}`; `cosm package on|off <name>`. A package with parts switched
off has an object instead, `{"star-chart": {"on": true, "off": ["agent/skills/email"]}}` (changing-packages.md). Which
built-in packages start on is Cosm's, not the package's: the list `defaults.json` beside the built-in packages (Gemini
CLI and the stand-in agent start off). Nothing a package says decides it.

The cosm's own packages came with the folder, so they run only once the user trusts the cosm on this computer (`cosm
trust` says the answer; the user sets it in Settings → General). Until then `cosm package check` says its code hasn't
run, and `cosm package on` refuses: say where to trust it, never set it yourself. A package from a repo is copied into
`.cosm/packages/<name>/`, and where it came from is kept in `.cosm/sources.json` (SKILL.md, Packages from elsewhere).

## The folder

| File or folder | What it is | Page |
|---|---|---|
| `cosm.json` | who the package is | below |
| `main.ts` | everything it adds, registered (the entry: Cosm reads only what it imports) | below |
| `package.json`, `bun.lock` | the libraries it uses, when it uses any | below |
| `cosm.lock` | the fingerprints of the parts it overrides; Cosm writes it | changing-packages.md |
| `agent/instructions.md` | what the agent should know while this package is on: one `# Heading` with the package's label, then the rules | agents.md |
| `agent/prompts/<name>.md` | the agent's prompts, sent by name | agents.md |
| `agent/skills/<name>/SKILL.md` | skills for the agent | agents.md |
| `AGENTS.md` | how to work on the package's code, as in any project: it doesn't reach the agent in a cosm | |
| `<owner>/<point>/` | files that add to another package's point (Points, below) | |
| `views/<name>.html`, `views/<name>/index.html` | a view's page by habit (added to `cosm:views` with its `file`), written with Cosm's kit (a view built with its own scripts goes in a folder) | views.md |
| `bin/` | programs it runs itself (an agent's adapter, an MCP server, a step shown in a terminal) | agents.md |

Each content file is a **part** of the package, named by its path without its ending (`agent/instructions`,
`agent/prompts/recall`, `agent/skills/email`, `views/inbox`); what `main.ts` registers by name is a part too (`items/review`). The user's
leave-outs and other packages' overrides name parts (changing-packages.md); `cosm part list <name>` lists them.
Anything else in the folder (`README.md`, `src/`, `tests/`) is the author's to arrange: Cosm reads only `main.ts` and
what it imports.

## cosm.json

Who the package is, and nothing else. Every key it held before is registered in `main.ts` now.

```json
{
  "name": "journal",
  "label": "Journal",
  "description": "Sends a page to your online journal.",
  "version": "1.0.0",
  "cosm": ">=1.0"
}
```

| Key | Type | Meaning |
|---|---|---|
| `name` | kebab-case, required | Its identity: lowercase letters, digits and `-`. The folder it is kept in has the same name (`check` says when they differ). Two packages of one name clash. Not `cosm`, which is Cosm's own. |
| `label` | text | How the user reads its name, in Settings → Packages: one or two words. Default: the name. |
| `description` | text | One plain sentence on what it does for the user. No selling ("your own", "as X ships it"), no instructions, nothing about how it works inside or where it sits in the window. |
| `version` | `"1.2.0"` | Shown with where it came from, and when updating. Publish versions as GitHub releases, or as `v1.2.0` tags in another git repo. |
| `cosm` | `">=major.minor"`, required | The version of Cosm's API it is written for: `">=1.0"` (Versions, below). |

A key that isn't one is an error with the closest one (`"lable" isn't a key. Did you mean "label"?`). `cosm schema`
prints `cosm.json`'s schema.

## main.ts

A default-exported function, given `cosm`. It registers what the package adds; the types come with Cosm (`import type
{ Cosm } from "cosm"`; nothing is installed for them):

```ts
import type { Cosm } from "cosm";
import { shape } from "cosm/shape";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:views", { name: "tree", file: "views/tree.html", label: "Files", location: { in: "left-pane" } });
  cosm.point.add("cosm:items", { name: "trash", label: "Trash", content: { icon: "trash" }, action: { open: "file-tree:trash" }, location: { in: "file-tree:tree" } });
  cosm.point.add("cosm:settings", { name: "others", shape: shape.boolean(), default: true, label: "Show other files" });
}
```

(File tree's, shortened.) What registers, and where each is explained:

| Call | Adds | Page |
|---|---|---|
| `cosm.on(event, handler, {kind?})`, `cosm.point.add("cosm:events", { name: name, description})` | what it does on an event; what its own events mean | events.md |
| `cosm.point.add` to `cosm:views`, `cosm:items`; `cosm.view.export`, `cosm.package.export` | views, everything clickable, the functions its own views call, the API other packages call | views.md |
| `cosm.point.add` to `cosm:kinds` (with `text`, `facts`), `cosm:stems`, `cosm:skip` | kinds of things the cosm holds, and what the index reads of them | files-and-kinds.md |
| `cosm.point.add` to `cosm:schedules` | what it does at set times (`daily 08:00`), Cosm waking it | events.md |
| `cosm.point.define`, `cosm.point.add` | a point others add to; a contribution to a point | below, Points |
| `cosm.point.add` to `cosm:commands`, `agent:mcp`, `agent:secrets`, `agent:programs` and `agent:agents` | commands on Cosm's command line (the agent's tools), MCP servers, secrets and programs for the agent; an agent it runs | agents.md |
| `cosm.point.add` to `cosm:settings`, `cosm:secrets`; `cosm.setting.preset` | settings, values for other packages' settings, secrets | below |
| `cosm.part.override(part, {file} \| {value})` | taking the place of another package's part | changing-packages.md |

**Registering** happens only while the function runs: Cosm loads `main.ts` at startup in the package's own worker, runs
the default function (it may be `async`; Cosm waits for it), and keeps what it registered. A registering call made
later (in a timer, in a handler) throws: "call it in main.ts's default function, not later". While it registers it
only declares: asking Cosm then (`cosm.file.read`, `cosm.index.find` …) throws, since the answer could wait on this very
load. Its own settings are the exception: `cosm.setting.get("<name>")` answers once the setting is added (the values
come with the load), and when one it read changes, Cosm loads `main.ts` again. Cosm loads packages side by side in the background; one that takes long is listed as loading meanwhile, and one
that hasn't registered in 30 seconds is stopped (its log says so). So decide what to add at
load time, from the package's own files or settings; what changes while running is data (a content function, the rows
an exported function gives, storage).

The same load, without running any handler, is how `cosm package check` and Settings learn what a package adds. So
the function registers and returns: work that runs on its own (a sync every few minutes) starts in `package.started`
and stops with `cosm.package.signal` or in `package.stopping` (events.md, A package's life); work that is pointless
without a window starts on `window.opened` and stops on `window.closed` (`examples/git-sync/` syncs the cosm with git
as the window opens and closes, and from ⌘K).

**The functions it registers** (handlers, tools, labels, exported functions) run in its worker, in Bun, and may be async.
One rule for all of them:

| | |
|---|---|
| in | one object with named fields (`{ things }`, the event's data, the clicked file, a tool's args), so Cosm can add a field later |
| out | the thing asked for, bare: a label, the texts, a tool's answer |
| nothing | `undefined` or `null` says nothing: no label, carry on, no text for the agent |
| a string | text for whoever reads it: the agent after a session or message event, the user for a tool, a notice for an item's function |
| `{ stop }` | the one decision, only on the before-events (events.md) |
| a throw | the one failure; Cosm says it to each caller in its own form, writes it to the package's log, and never takes it as a decision |

Every call has `cosm.signal`, which fires when no one waits on it any more (the user pressed Skip, the agent
interrupted the tool, the package restarted). Pass it on (`fetch(url, { signal: cosm.signal })`, `Bun.spawn`): a late
write can overwrite what the user did meanwhile.

A call may take as long as it needs; Cosm sets no limit. What it watches is the package's thread: code that holds it
(a loop that never awaits) leaves every call to the package waiting, so after 3 s the window says the package isn't
responding, and after 30 s Cosm restarts it (five times in 3 minutes, and it stays stopped until the user restarts
it). Long work that computes awaits now and then, or runs as its own program (`cosm.process`, below).

`cosm.log(…)` and `console.log` write to the package's log (`cosm package log <name>`).

A system program is run with Bun where it is used (`Bun.spawn`, Bun's `$`), in the cosm's folder with `cosm` on its
`PATH`. Prefer a library (below): a program the user's computer lacks fails there.

A program that runs for long (an agent, a watcher, a server) or that a view shows in a terminal is started with
`cosm.process.start(name, {program, args, as})`: Cosm runs it apart from the package's code, so it goes on while the
code loads again, its views close or the window closes, and ends when the package stops it, it exits, the package is
switched off or removed, the user stops it, or Cosm quits. Its full name is `<package>:<name>`.

```ts
await cosm.process.start("sync", { program: "bin/sync", args: ["--watch"] });   // as: "lines", the default
// Its stdout is a stream of the package's named as it is, a line an item, kept from its first byte; stderr goes to the log.
await cosm.stream.subscribe("sync", (lines, { closed, code }) => { /* a few lines at a time; at its end, how it ended */ });
cosm.on("process.exited", ({ name, code }) => { /* it ended */ });
await cosm.process.write("sync", "status\n");
```

A `lines` program's output is a stream (below) named as the program, `<package>:<name>`: what it wrote before anyone
read it is kept (the latest 10,000 lines), numbered from 1 each time it starts, closed after its last line with its
exit code. Any package may follow it by name; the engine writes it, never a package, and no view is handed it.

`as: "terminal"` runs it in a terminal (`cols`, `rows`), for a view that attaches (`<cosm-terminal process="…">`);
the package hears `process.attached` and `process.detached` (`{name, attached}`) as views come and go, and decides
itself when one nobody watches should stop. Starting a name that runs already is an error: attach to it, or stop it
first. `cosm process list | stop | attach | write` reach them from the shell.

A package that has something for others to follow as it happens (a conversation, a sync's progress) opens a stream:
`const s = await cosm.stream.open("progress")`, then `s.write(item)` and at the end `s.close()` (closing it again does nothing, so cleanup on two paths is safe). Any package's main.ts
follows it (any package's stream, by its full name) with `cosm.stream.subscribe("<package>:progress", (items, { closed, missed }) => …)`: what Cosm kept
of it first (the latest 1000, or `keep`), then what comes, in order, a few items at a time; `missed` says how many were
lost before these (more came than it kept before they were read). Cosm keeps it while the package's code loads again,
and closes it with the package. A view gets a stream only from its package: a view function returns
`cosm.stream.pass("<package>:progress")`, a handle, and the view subscribes to that (views.md); the window it is in is
then sent that stream's items, while the package may sleep.

## Points

A **point** is a place one package defines and others add to: the sections of today's note, the ways to sign in, the
fixers run on a page before it is saved. Cosm collects what adds to it (the **contributions**), in its package order,
leaves out what the cosm switched off, puts an override in its base's place, checks each against the point's shape,
and hands them to whoever reads the point. The package that defines a point decides what it is for and reads it; the
others only add.

```ts
import { shape } from "cosm/shape";

// daily-note's main.ts: the point, and what it does with it.
cosm.point.define("sections", {
  description: "A section for today's note: its title, and a function giving its text.",
  holds: "functions",
  shape: shape.object({ title: shape.string() }),   // its data: cosm/shape, a schema library or JSON Schema
  functions: ["text"],                       // the functions each contribution has beside it
});
cosm.on("window.opened", async () => {
  let page = "";
  for (const s of await cosm.point.read("sections")) page += `## ${s.title}\n${await s.text()}\n`;
  await cosm.file.write(`Today.md`, page);
});

// a calendar package's main.ts: a contribution, by its name.
cosm.point.add("daily-note:sections", { name: "calendar", title: "Today", text: () => todaysEvents() });
```

| `cosm.point.define(name, {…})` | |
|---|---|
| `description` | What it is for: the agent reads it when it writes a contribution (`cosm point list`). |
| `holds` | `files` (each package's folder `<owner>/<point>/`: every file or folder there is one; what is read as a file, a skill or a prompt), `values` or `functions` (added in code). |
| `shape` | What a contribution's data must be: plain JSON Schema, most simply written with Cosm's `cosm/shape` (`import { shape } from "cosm/shape"`: `shape.string()`, `shape.number({ min, max })`, `shape.boolean()`, `shape.enum([…])`, `shape.array(…)`, `shape.object({…})` with `shape.optional(…)` for a key it may leave out, `shape.record(…)`, `shape.unknown()`; each takes a `description`), which also gives TypeScript the type it takes (`Infer<typeof s>`). A schema library with the Standard JSON Schema interface (zod, ArkType: the package's own, `bun add zod`) works too, at the cost of loading it in the package's worker. Cosm takes the JSON Schema from it and checks every contribution, in code or a file; one that doesn't fit is left out, said in its package's log and by `cosm package check`. Data only: what JSON Schema can't hold (a function, a date, a transform) is refused when the point is defined. |
| `functions` | For a point holding functions: the functions each contribution has beside its data (`["text"]`), checked to be there and to be functions. |
| `uses` | `all` (the default): every contribution, together. `one`: one at a time, with the user's default; the others stay usable (a package may name the one it needs). |
| `label` | Its name as the user reads it, for a point used one at a time (Settings: "Sign-in: OAuth ▾"). |

| Reading | |
|---|---|
| `await cosm.point.read("<owner>:<point>")` | Every contribution, `[{package, name, as, path?, by?, …}]`: whose it is, its name, the name it is reached by, its file (a point holding files), the package overriding it (`by`), and what it is, its functions callable (they run in the package that added them). A bare name is the package's own point. Views read points the same way. |
| `await cosm.point.default("<owner>:<point>")` | For a `uses: "one"` point: the contribution used now, or null when nothing adds to it. With several and no default set, Cosm asks the user once and keeps the answer; with no window open, the first in package order. |
| `cosm point list`, `cosm point read <point>`, `cosm point default <point>` | the same from the shell; `cosm setting default <point> <package>` sets the user's default (on their word), `default` takes it away. Kept in `.cosm/settings.json` → `"default": {"<owner>:<point>": "<package>"}`. |

**Names.** A contribution's full name is `<package>:<name>`, which can't clash; it is reached by its own name while no
earlier package in Cosm's order has one the same, else by its full name (`as`). Nothing is dropped or numbered.
**Each contribution is a part** of the package that adds it, named by where it is defined: `<owner>/<point>/<name>`
(`star-chart:daily-note/sections/due`), so the user can switch it off or another package override it
(changing-packages.md). A point needs both a filler and a reader: define one only when a package will read it. Cosm's
own points are listed by `cosm point list` under `cosm:`.

**Types for those who add.** A package can give the packages that add to its points its types: it exports them from
its main.ts and adds its points to Cosm's typed map there, and an adding package imports them, types only:

```ts
// daily-note's main.ts
export interface Section { title: string; text: () => string | Promise<string> }
declare module "cosm" { interface PointTypes { "daily-note:sections": { name: string } & Section } }

// the calendar package's main.ts
import type { Section } from "package:daily-note";   // types only: nothing of daily-note's loads here
cosm.point.add("daily-note:sections", { name: "calendar", title: "Today", text: () => todaysEvents() });  // checked
```

`package:<name>` names a package's main.ts, for `import type` only: a package's code runs in its own worker, so
another's can't be imported (`cosm package check` refuses it); call what it exports instead (`cosm.call`). The `agent`
package gives its types this way (`Agent`, `Share`, `Mcp`: agents.md).

**Shared points** no single feature package owns live in the built-in package `cosm-points`, which only defines them;
a point is added there when it has both a filler and a user. The first is `cosm-points:sign-in` (functions, one at a
time): OAuth fills it, and a package that needs a token for an outside service asks the user's default, never a named
package, so a better sign-in package can take its place:

```ts
const signIn = await cosm.point.default("cosm-points:sign-in");
if (!signIn) throw new Error("This needs a sign-in package: switch OAuth on in Settings → Packages.");
const token = await signIn.token({ provider: "Microsoft", authorize, token: tokenUrl, client, scopes: ["Mail.Read"], package: cosm.package.name });
```

## The packages it uses

There is no list of packages a package needs: Cosm works out which it uses from what `main.ts` registers. A package is
used when the package names one of its things it can't do without: a kind it extends, or narrows an item or a handler
to (`markdown:page`); a command it sends (`star-chart:recall`); a kind a new file is made of; a view it opens
(`{ open: "tables:tables" }`); one of its events it handles (`agent-session:removed`); a part it overrides; settings it
presets. Settings shows "Uses Markdown", and `cosm package on` refuses while one it uses is off ("To do uses markdown:
switch it on first"). Not uses: an item placed in another package's view (not shown while that one is off) and a
kind's view of another package's (its files show as a card meanwhile).

A call made only while running (`cosm.call("tables:table", { table: "expenses" })`) isn't seen at load: while that package is off or
missing, the call fails with a plain line in the package's log. Handle the failure where the call is made.

## Settings

What the user can set for the package in this cosm, shown on the package's page in Settings. Its `shape` says the values
it takes, written as a point's shape is (below, Points): `cosm/shape`, a schema library's, or JSON Schema.

```ts
import { shape } from "cosm/shape";

cosm.point.add("cosm:settings", { name: "address", shape: shape.string(), default: "", label: "Journal address", description: "Where pages are sent.",
  question: "What is your journal's address?" });
cosm.point.add("cosm:settings", { name: "private", shape: shape.boolean(), default: true, label: "Send as private" });
cosm.point.add("cosm:settings", { name: "wait", shape: shape.number({ min: 5, max: 120 }), default: 30, label: "Wait for the journal",
  description: "Seconds before giving up on sending." });
```

| Key | Meaning |
|---|---|
| (the name) | The setting's name, kebab-case. |
| `shape` | The values it takes, and so the control Settings draws: `shape.string()` a text field (the default), `shape.boolean()` a switch, `shape.enum(["a", "b"])` a choice, `shape.number({ min: 5, max: 120 })` a number field with its bounds, `shape.string({ format: "font" })` a font on this computer by its family name (`"SF Mono"`), an object (`shape.record(shape.unknown())`) a JSON value set by presets and `cosm setting set`, never drawn. `cosm setting set` refuses a value outside it. |
| `default` | Its value while nothing sets it. |
| `label` | Its name in Settings (without one, its name as written). |
| `description` | The line under it. |
| `question` | Asked when the package is switched on, while the cosm hasn't set it (`cosm setting unasked` lists them). |
| `current` | A function giving the value in use, shown beside it, when the setting's value is a choice like `auto` (Advanced search's languages: "auto (english, swedish)"). |
| `hidden` | `true`: kept out of Settings; still listed and set with `cosm setting`. |

| Where | How it is read |
|---|---|
| `main.ts` and its views | `await cosm.setting.get("wait")`: its own by name, another package's as `<package>:<name>`, Cosm's own as `cosm:<name>` (`cosm:new`). A switch is a boolean, a number a number, `null` when it has no value. |
| the agent | `cosm setting list [<package>] [--json]`; `cosm setting set <package> <setting> <value>` (`default` takes the value away); `cosm setting unasked [<package>]` |
| the file | `.cosm/settings.json` → `"packages": {"<package>": {"<setting>": value}}` |

**Layers**, lowest first: the setting's `default`, a package's preset (below), the user's value for every cosm
(`~/.cosm/settings.json`, the same shape), this cosm's (`.cosm/settings.json`, what `cosm setting set` writes). A
value its shape doesn't take (a switch that isn't `true` or `false`, a choice not among its values, a number out of
bounds) counts as not set. A setting is a part like any contribution (`settings/<name>`): a cosm can leave it out, and
another package can override it (changing-packages.md); a preset is the way to give it another value.

**Cosm's own settings** are listed and set the same way, under the name `cosm` (`cosm setting list cosm`): `text-font`,
`code-font`, `text-size` (10 to 32), `theme` (`<package>:<theme>`), `instructions` (Cosm's own instructions to the
agent, on or off), and two a layout package presets: `start` (the
file a new cosm opens) and `new` (what ⌘N makes and where, `{"kind": "<package>:<kind>", "folder": "<folder>"}`). The agent a new session starts with isn't a setting: it is the default of Cosm's point `agent:agents`
(`cosm setting default agent:agents <package>`, Settings → General → Defaults).

## Secrets

What the user pastes in, by name: a token, a key. Cosm asks for each in a small window of its own once the package is
on, and keeps them in `.cosm/secrets.env`, each package's under its own name (two packages' `token` are two secrets).

```ts
cosm.point.add("cosm:secrets", { name: "token", label: "Journal token", description: "From the journal's account page." });
// …in a function that needs it:
const token = await cosm.secret.get("token"); // null until the user has given it
```

`label` and `description` are shown where Cosm asks for it. `cosm.secret.get` reads only the package's own secrets.
The agent's sessions get one only when the package says so with `cosm.point.add("agent:secrets", { name })` (agents.md), which also means
it can end up in a transcript. Never ask for a secret in the chat, never read the secrets file, never print or log one,
and never write one into a file in the cosm (only Cosm writes `.cosm/secrets.env`, when the user gives one in its window). A package that needs a
secret can't be tried fully until it is on and the user has entered it; say so, and throw a plain line while it is
missing (`"no journal token yet: Cosm asks for it in its window"`).

## Presets

Values a package suggests for settings it doesn't own, by their owner: `cosm` for Cosm's own, a package's name for
its. A preset sits below the user's own values (Layers, above): it decides only while the user hasn't.

```ts
cosm.setting.preset("cosm", { start: "profile.md", new: { kind: "markdown:page", folder: "inbox" } });
```

Star chart presets `start` and `new` this way: a new cosm opens its profile, and ⌘N makes a page in the inbox. The check
refuses a preset of the package's own setting (set its `default`), a setting the owner doesn't have, or a value it
doesn't take, and warns while the owner is off. Two packages presetting one setting to different values is a tie the
user settles (`cosm setting prefer presets:<owner>:<setting> <package>`, changing-packages.md); until then the setting
keeps its own default.

## Libraries

A package that uses libraries from npm has a `package.json` with only `dependencies` (and Bun's `trustedDependencies`,
below), and a `bun.lock`; its name and version stay in `cosm.json`. Add one with `bun add <library>` in the package's
folder, which writes both. Advanced search's:

```json
{ "dependencies": { "@types/snowball-stemmers": "0.6.2", "snowball-stemmers": "0.6.0" } }
```

Cosm installs the lockfile's libraries when a package is added or updated, into its own cache on this computer: the
package's `node_modules` is a link there, so a folder that is synced or kept in git carries only `package.json` and
`bun.lock`. Bun runs a library's install script only when `trustedDependencies` names it; `check` says when one needs
it.

A tool the package needs comes as a library too: first a WebAssembly or plain-JS version (`ffmpeg.wasm`, `pdf.js`),
else an npm package carrying the program for each platform. Then it works on every computer the cosm is opened on.

## What a package keeps

| | Where | For |
|---|---|---|
| `cosm.storage` | the cosm's state for it, by key (`get`, `set`, `delete`, `list`; JSON values) | small values between runs: what it last told, a sync's cursor; one session's under keys of its own (`<session>/<key>`) |
| `cosm.package.folders.data` | `.cosm/data/<package>/`: lasts and syncs with the cosm | files of its own (a database, an export) |
| `cosm.package.folders.cache` | this computer only; deleted and rebuilt at will, never synced | what can be made again |
| `cosm.package.folders.package` | its own folder: read its files there, never write | its content (`glue/english.txt`) |
| `await cosm.package.file.read(path)` | one of its own files, by its path in the package, as text (`{ bytes: true }`: bytes); one read while `main.ts` registers counts as its code, so a change to it loads the package again | an icon, a template (`await cosm.package.file.read("templates/article.md")`) |
| `cosm.package.folders.cosm` | the cosm's folder | `node:fs` on the package's own data; the cosm's files go through `cosm.file` (files-and-kinds.md) |

What `main.ts` reads of the cosm while it registers (`cosm.file.read`, `cosm.file.list`) counts towards what it
registered, as its own files do: a file it read changes, or one its glob matches is added, changed or removed, and it
registers again. Agent schedules registers one schedule a page in `schedules/` this way.

`data` and `cache` are made the first time they are asked for. `cosm storage get|set|delete|list --package <name>`
reads and sets storage by hand.

Its code runs as one file: each time the saved `main.ts` loads, Cosm builds it and what it imports (its own files and
its libraries) into `.code/` in its cache, and that file is what starts the package every time after. So
`import.meta.dir` and `import.meta.url` name that copy: reach its own files through `cosm.package.folders.package` or
`cosm.package.file.read`. An error's stack still names the lines of the saved files.

**Where a package puts the user's files.** A package knows no other's layout: Star chart's `inbox` is Star chart's,
and another layout, or none, may be on. A package that makes files names a folder of its own, after what it holds
(`Reading list/`), made when it first writes there, or a setting when the user may want it elsewhere; puts what is for
the user to sort where ⌘N puts a new page (`await cosm.setting.get("cosm:new")`, its `folder`); or asks the user, and
says where it put things. A layout drawing only its sections (Star chart's) doesn't show a folder of the package's own
at the root: give the package an item into `file-tree:tree` opening its view (views.md).

## Versions

`"cosm": ">=1.0"` is the version of Cosm's API the package is written for. This Cosm offers 1.0 (`cosm version` says
which). A later minor only adds, so a package written for 1.0 runs on 1.3.

| A package says | This Cosm (1.0) |
|---|---|
| `">=1.0"` | reads it |
| `">=1.1"` or higher in major 1 | refuses it: "update Cosm to use this package" |
| `">=2.0"` | refuses it: another major is another API; update Cosm |
| `">=0.9"` | refuses it: update the package |
| `"1.0"`, a number, or no `cosm` | refuses it, saying to set `"cosm": ">=1.0"` |

A refused package shows as broken in `cosm package list` and Settings → Packages, with the reason.

**A package's own names are its public surface.** Other packages name its kinds, views, events, commands and tools
(`markdown:page`, `file-tree:tree`, `search-hints:context.sent`, `star-chart:recall`, `cosm tables:query`), and the
user's associations, answers to ties, leave-outs and overrides name its parts (`star-chart:items/review`,
`star-chart:agent/prompts/recall`). A renamed one breaks what named it: to an override or a leave-out, a part renamed is a
part removed. Keep them, and name every item, so it is a part others can name.

## Checking

`cosm package check <name>` reads a package as the engine and the window read it: its `cosm.json`, its folders, and
`main.ts` loaded without running a handler, with TypeScript's checker run over it. Without a name, every package that
is on and the cosm's own. It exits 1 when anything is wrong. It runs no handler or tool: try those by hand (SKILL.md,
Trying a change).

| Mark | Means |
|---|---|
| `✗` | Wrong; fix it. A key `cosm.json` doesn't have; a type error (`types: main.ts:7:40: …`); `main.ts` as saved not loading; a library imported that `package.json` doesn't name; a name that isn't kebab-case, or the folder's name not the package's; a view it names that isn't there; a place that isn't one; an event that isn't one; a preset Cosm can't take. |
| `!` | Something Cosm settles, or that does nothing for now: a tie with another package (who gives it until the user chooses); a package it names that is off; no `bun.lock`; a library whose install script isn't trusted; an item without a name; a command or skill whose name is taken; the cosm not trusted, so its code wasn't checked. |
| `✓` | What it brings, as the engine takes it: its code, tools, views, items, kinds, the events it runs at, what it gives the agent, its presets and themes, each override in effect; and `Takes effect:` when (now, next message, from its next run, next session). |

A wrong one:

```
todo — To do (on)
  ✗ types: main.ts:7:40: Property 'lst' does not exist on type 'Files'. Did you mean 'list'?
  ✗ ui.items[0] (show).location: "pallete" isn't a place. Did you mean "palette"?
  ✓ its code: main.ts
  ✓ tools: cosm todo:list
  ✓ views: list
  ✓ 1 item in the window
  Takes effect: now
```

A type error doesn't stop the code loading: the package runs, and fails where the error is. Fix every type error.

**When the saved main.ts doesn't load** (it throws while loading, a syntax error), the last version that loaded runs on,
so the user keeps the package's items, views and handlers. Everything the agent reads says so: `check` (`✗ its main.ts
as saved is NOT running, it doesn't load: <why>`), a note above every tool's answer, the package log, and `stale` in
`cosm package list --json`. It stays so when its worker stops and starts again, or Cosm starts again: each tries the
saved main.ts first, and the last version that loaded runs while that doesn't load. A package that can't run at
all (its libraries didn't install, it never loaded) isn't started; its Settings page says "Not running. Ask the agent
to look at it.", and its log says why.

**Checkpoints**: each time a package of the cosm's own (its folder in `.cosm/packages`) changes (its files, once quiet
a moment, a view's included) or loads its code, Cosm keeps a copy of it (its files, not what it stores), the last 20,
on this computer only. `cosm package history <name>` lists them, newest first, with the files each changed and whether
its code loaded (`changed, didn't load`: not one to go back to); `cosm package restore <name> <n>` puts one back (the
code as it is now kept first, so that can be undone too) and it loads again. When the user says "go back", or a change
went wrong past fixing, restore rather than rewrite from memory.

**The package log**: `cosm package log <name>` shows its last runs, one line each (when, what, how it ended, how
long), with what it wrote and each failure's stack under it. A run of the same call that went well is folded into one
line with how many and how long (a view's live calls would fill it otherwise); what went wrong is always shown whole.
`--all` prints the whole log as kept (about 200 KB a package), for grep. Its views write there too, each line named by the view
(`view tasks:board: …`): what a view logs with `cosm.log`, and what its scripts throw that nothing catches (a sealed
view's browser hides the words of an error thrown straight in a script; one in a promise, or in a handler the view gave
`cosm.on`, keeps them):

```
2026-10-30 23:08:33  read (off)  ok  10 ms
2026-10-30 23:08:33  types  ok  577 ms
2026-10-30 23:08:33  loaded  ok  8 ms
2026-10-30 23:08:33  tool open  ok  15 ms
```

Check again after each fix, after every change, and before switching a package on.
