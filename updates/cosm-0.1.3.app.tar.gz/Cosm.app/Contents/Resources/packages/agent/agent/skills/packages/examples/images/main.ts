// Images: a kind for image files, a view that shows one, and what the index reads of them (their names, so search
// finds a picture by what it is called).
import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:views", { name: "image", file: "views/image.html", label: "Image", input: "file" });
  cosm.point.add("cosm:kinds", { name: "image", match: "**/*.{png,PNG,jpg,JPG,jpeg,JPEG,gif,GIF,webp,WEBP}", label: "Image", view: "image", text: "name" });
}
