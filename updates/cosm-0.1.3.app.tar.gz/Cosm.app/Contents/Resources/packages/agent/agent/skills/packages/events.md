# Events: when something happens

The user asks for something to happen at a moment: "when I save a recipe, update the shopping list", "start every
session with what's due", "ask me to write a standup note before I close", "refuse a meeting note without a date in its
name", "sync every ten minutes", "tell the other packages when a list is made". Each is a handler: an event, and what to
do, registered in `main.ts` with `cosm.on`. A package may also fire events of its own (`cosm.emit`), which other
packages hear; a view follows them through a live value (Events and views, below).

## cosm.on

`cosm.on(name, handler, options?)`, called in `main.ts`'s default function (never later: registering is done when it
returns). The handler is a function given two things, the event's data and its context, and may be async:

```ts
cosm.on("file.saved", async ({ paths }, { by }) => {
  if (by === "outside") return;          // only what was saved through Cosm
  for (const path of paths) cosm.log("saved", path);
}, { kind: "recipe" });
```

- **The data** is exactly what the event was fired with: its own keys, below for each event.
- **The context** is the same for every event: `{name, package, by}`. Everything else the event says is in its data.

| Context | Is |
|---|---|
| `name` | The event's name: `file.saved`, or a package's own as `recipes:list.made`. |
| `package` | Who fired it: `cosm` for Cosm's own, else the package (the name's prefix). |
| `by` | Who caused it: `window` (the user in the window), `shell` (a person's terminal), a package's name (its code wrote the file, or fired the event, or a program it runs did: the agent's own `cosm` commands give its connector's, `claude`), or `outside` (a change Cosm only saw on disk: another app, the agent's own file edits, git, a sync). |

Data uses one key per thing: `path` for one file, `paths` for several, `moves: [{from, to}]` for files that moved, and
`session` for the conversation an event is about (Agent session's id: Cosm itself keeps no conversations, so the
agent's events and Agent session's carry it in their data, and only there). Register several handlers for one event, or one handler for several; each runs.

**What a handler returns** is its answer where the event takes one, and nothing otherwise:

| It returns | Where |
|---|---|
| nothing (`undefined`, `null`) | carry on, nothing said |
| a string | dropped (shown only when run by hand): what goes to the agent is a contribution to the agent's points (agents.md) |
| `{stop: "<why>"}` | refuses the change, on a before-event (Cosm's, or a package's `<name>.before`, such as `agent-session:closed.before`) |
| `{text}`, `{to}`, `{input}` | changes what is about to happen (below) |
| a throw | a failure: it goes to the package's log (`cosm package log`); never taken as a no |

Each package that is on runs its own handlers. One the cosm leaves out doesn't, and one another package overrides runs
the override (changing-packages.md: a package's handlers for one event are the part `on/<event>`). `file.moved` and
the before-events run one package after another, in Cosm's order; the others side by side. No handler has a time
limit; one the user waits on (a before-event) can be skipped in the window after about a second, and the change goes on
without its answer.

### Narrowing: `{kind}`

`options` has one key, `kind`: a file event's handler then runs only for that kind's files (and the kinds extending
it; another package's kind as `package:kind`). It is given only those, and isn't called when there are none. It is
taken on the file events, `file.moved` (read by where each file went) and the before-events; `cosm package check`
refuses it anywhere else. Narrow every file handler you can: `file.saved` comes with every save, and the window saves
as the user types (`check` warns of a `file.saved.before` handler without a kind).

```ts
cosm.on("file.moved", async ({ moves }) => { /* only meetings that moved, by where they went */ }, { kind: "meeting" });
```

## Cosm's events

| Event | When | Its data | What it may return |
|---|---|---|---|
| `window.opened` | The first window opens on the cosm (once however many), and whenever the package's code loads while one is open (switched on, edited, restarted): a timer started here starts again | `{}` | — |
| `window.closed` | The last window on the cosm closes | `{}` | — |
| `package.started` | A worker of the package's code starts (only its own handlers hear it): its first in this run of Cosm (`startup`), switched on (`on`), its code changed or it was restarted (`reload`), a new version (`update`), started again for a call or an event after its worker slept or ended (`wake`); never when its main.ts is only read (a check, Settings). A package's code runs only when something needs it: its variables last one worker, so one-time work checks its storage first; a call waits for these handlers | `reason` | — |
| `package.stopping` | Before the package's own code stops: idle (`idle`), switched off (`off`), loaded again (`reload`, the new code runs already), a new version (`update`), removed (`removed`), Cosm stopping (`quit`). `cosm.package.signal` is aborted first; its handlers have 3 seconds, then its worker ends with what is left (timers, sockets) | `reason` | — |
| `file.saved` | Files of the cosm that were there already changed, by anyone (the user, the agent, the file manager, a sync), gathered until the cosm is quiet for two seconds | `paths` | — |
| `file.created` | Files were made, gathered the same way: a new file fires this, not `file.saved` (a note the agent writes in one go is only `file.created`); handle both to see every write | `paths` | — |
| `file.moved` | Files got a new name or folder: `cosm file move`, a rename in the window, or one made outside Cosm (known by the file's identity); a folder's files each | `moves` (`[{from, to}]`) | — |
| `file.trashed` | Files went to the cosm's trash (`cosm file trash`, or in the window) | `paths` | — |
| `file.removed` | Files were deleted outside Cosm (the file manager, `rm`, git) | `paths` | — |
| `file.opened` | The user opened a file in the window | `paths` | — |

- **Paths** are from the cosm's root, never a hidden file (a name starting with `.`). A change the package itself made through
  Cosm (`cosm.file.write`, `change`, `move`, `trash`) isn't told to it, so a handler that fixes a page doesn't set
  itself off; everything else is, the user's saves while it ran included. A file it writes another way (Bun's `fs`)
  comes back to it as anyone's.
- **What happens in a session** is the `agent` package's, whichever agent runs (agents.md): to answer it (text for the
  agent, a step's input changed), add to its points `agent:start`, `agent:message`, `agent:step`, `agent:failed`; to
  only hear of it, its events `agent:started`, `agent:message.sent`, `agent:file.read`, `agent:step.before`,
  `agent:step.failed`, `agent:turn.ended`.
- **A session's events** carry it in their data (`{session}`, Agent session's id); a package keeps something for that session in the
  session's storage (`agent-session:storage-set`, files-and-kinds.md), gone with the session.
- **The list of sessions** is Agent session's: `agent-session:started`, `agent-session:closed.before` (a handler may
  keep it open), `agent-session:closed`, `agent-session:removed`, and `agent-session:storage.changed` (agents.md).

The engine's change events, `setting.changed`, `ui.changed`, `package.changed` and `kind.changed`, are heard in main.ts as in views, with the new value in their data (below, Events in views); a
package rebuilding something when one of its settings changes listens to `setting.changed`.

## Before a change: refusing it

`file.moved.before`, `file.trashed.before`, `file.saved.before` and `file.created.before` come before the change, while
it can still be stopped. Only a function takes them. It gets what is about to happen and returns nothing to let it
through, or `{stop: "<why>"}` with the reason in plain words, which whoever asked is shown (the window as a notice, the
agent's `cosm file move` as its failure):

| Event | Its data | It may also return |
|---|---|---|
| `file.moved.before` | `path`, `kind` (its kind, or null), `to` (the new path) | `{to}`: where it goes instead, a path in the cosm (only for a file that moves alone; one moving with its folder goes with it) |
| `file.trashed.before` | `path`, `kind` | — |
| `file.saved.before`, `file.created.before` | `path`, `kind`, `text` (what it would hold) | `{text}`: what to write instead |

Handlers run one after another in Cosm's order; each gets the change as the one before left it, and the first stop
ends the rest and the change. One that throws, or that the user skips, counts as yes. It stops only what goes through
the engine (a move, a save from the window, `cosm.file.write`, `cosm` commands); a file written straight to disk is seen
afterwards: then the save's handlers get the new text, a stop is a problem in the window naming the file and the
reason, and a `{text}` is written over it.

Star chart keeps the user's profile where it and the agent read it, whoever asks:

```ts
cosm.point.add("cosm:kinds", { name: "profile", extends: "markdown:page", match: "/profile.md", label: "Profile", search: false });
const stays = () => ({ stop: "The profile stays at the top of the cosm as profile.md: Star chart and the agent read it there." });
cosm.on("file.moved.before", stays, { kind: "profile" });
cosm.on("file.trashed.before", stays, { kind: "profile" });
```

A guard on a path is this: a kind that names it, and these two handlers. Markdown refuses a page name a `[[link]]` can't
carry the same way, on `file.moved.before` and `file.created.before` narrowed to `page`, reading `to ?? path`.

## A session's start and close

- **`agent:start`**, the agent package's point: a session began. Each contribution's `run` is called for every `reason`,
  and text it returns goes to the agent with the first message. One that returns `{send: message}` (a text or `{prompt}`)
  has that sent first, before anything else sent to the session, the user's first message too: Star chart's `recall` opens each new session with
  Recall (Setup in a cosm with no profile yet). Each contribution is a part the user leaves out, or overrides, to have it
  gone (changing-packages.md).
- **`agent-session:closed.before`**: the user is closing a session (Agent session's). A handler may keep it open by
  returning `{stop}`. Star chart asks, unless Reflect ran in the session:

```ts
cosm.on("agent-session:closed.before", async ({ session }) => {
  if (!session || (await cosm.call("agent-session:storage-get", { session, key: "reflected" }))) return;
  const yes = await cosm.ui.ask("Reflect before you go?", { description: "…", choices: ["Reflect", "Close"] });
  if (yes !== "Reflect") return;
  await cosm.call("agent-session:send", { session, message: { prompt: "reflect" } });
  return { stop: "Reflecting first" };
});
```

## Events of its own

A package fires events other packages hear (and views, through their live values). It says what each means with `cosm.event` (for `cosm help` and
other packages' authors), and fires it by its short name with `cosm.emit`, its data one object:

```ts
cosm.point.add("cosm:events", { name: "list.made", description: "A shopping list was made: {path}." });
// …
await cosm.emit("list.made", { path: "recipes/Shopping.md" });
```

Others hear it as `<package>:<event>`, or from any package as `*:<event>`; the context's `package` says whose it was:

```ts
cosm.on("recipes:list.made", async ({ path }) => { /* … */ });
cosm.on("*:context.sent", async (data, { package: from }) => { /* Search hints', or any other package's context.sent */ });
```

A package fires only its own. The agent fires one by its full name, `cosm emit recipes:list.made '{"path": "…"}'`.
Nothing waits: `emit` returns at once, every package that is on with a handler runs side by side, and there is no
queue (an event is heard by whoever listens when it fires). What its handlers return is dropped. `check` warns of a
handler for a package's event that no package that is on describes. The data is the firing package's own, so it says
what it is about in full, with the same keys Cosm uses (`path`, `paths`, `moves`), and `session` for the conversation it
is about.

One named `<name>.before` is about to happen, as Cosm's own before-events: its handlers run one after another, any of
them can stop it (`return { stop: "why" }`), and `emit` waits and answers what the first stop said (`{stop}`), else
`{}`. The package then goes ahead or doesn't. Agent session's `closed.before` is one: Star chart keeps a conversation
open to reflect first.

```ts
const r = await cosm.emit("closed.before", { session });
if (r.stop) return; // kept open
```

`cosm help` lists every event the packages that are on describe. Among the built-ins: Agent chat's `deselect` (asking
the editors to drop their selection), Agent session's `started`, `closed` and `removed`. Cosm's own `folder.opened`
(`{folder}`) is how a folder is opened: a click in the tree, a toolbar's path, the agent's `cosm ui open <folder>`;
Star chart answers it with the folder's page. One is shared by convention: `context.sent`, `{session, message, things: [{name, path, kind}]}`,
fired by a package that sent the agent things from the cosm with a message (Search hints does; `message` is the
message's id, which `agent:message.sent` and so every "with each message" contribution gets); Agent chat keeps them by
message and shows every package's as one "Brought along" line under it.

**What is true now is not an event.** An event says something happened; what holds now has an owner who keeps it. A
view's own state (an editor's selection) the view publishes about itself, `cosm.view.publish({ selection })`, and
others read it on that view's entry of `cosm.ui.shown()` (views.md, What is on screen). What a package must still know
later it keeps in `cosm.storage`. Neither is rebuilt by keeping the last of an event in a variable: a package's code
runs only while something needs it, and its variables go when it sleeps.

## Events and views

A view hears no package's events, nor Cosm's changes, itself: `main.ts` does, and a view follows what they change
through a live value (views.md, Live data). A view function names the events that make its answer stale in its
`changes`, and every view showing it loads it again when one fires:

```ts
// main.ts: what went with each message (any package's context.sent), kept in its storage, and the view function its
// views keep live.
cosm.on("*:context.sent", async ({ session, message, things }, { package: from }) => {
  const all = (await cosm.storage.get<Record<string, unknown>>("brought")) ?? {};
  await cosm.storage.set("brought", { ...all, [`${session}/${message}/${from}`]: things });
});
return cosm.view.export({ brought: { changes: { storage: "brought" }, run: async () => (await cosm.storage.get("brought")) ?? {} } });
```

```ts
// the view
const brought = live(cosm.main.brought);
show("#brought", () => Object.keys(brought.value ?? {}).length);
```

To tell others what the user did in a view, the view calls a function of its package's that emits it. What a view
knows about itself (a selection) it publishes instead (`cosm.view.publish`). A view hears directly only its own events from the window (`view.opened`, `view.closed`,
`view.focus`, `view.find`, `view.rename`), `theme.changed` and `ui.changed` (views.md).

The engine's change events, heard in `main.ts`, each carry the new value so nothing needs reading again:

| Event | Its data |
|---|---|
| `ui.changed` | `{shown}`: every view on screen, as `cosm.ui.shown()` gives them; or `{items}`: the names of items whose labels changed, `["*"]` when packages changed. |
| `setting.changed` | `{package, name, value, scope}` for each setting that changed (with `current` when only the value in use changed) (`scope`: `cosm` or `user`); `{scope}` alone when one of the user's choices changed (a layout, an association) |
| `package.changed` | `{package}` when one package changed (its files, on or off), `{}` when the list did |
| `kind.changed` | `{kind}`: a kind's items changed |
| `folder.opened` | `{folder}`: a folder was opened (`cosm.ui.open`) |
| `process.started`, `process.exited` | `{name, package}`, `{name, package, code}`: a package's long-running program started or ended (`cosm.process`). Its own package hears `process.exited` as `{name, code}`, and alone hears `process.attached` and `process.detached` (`{name, attached}`). A `lines` program's output is a stream, not an event (package.md) |

## A package's life

One rule: **register in main.ts, start in `package.started`, clean up in `package.stopping` only what lives outside
Cosm.**

```
 switched on / Cosm starts
        │
  main.ts runs           registers views, items, tools, points, handlers; starts nothing
        │                (cosm package check and Settings also run this part)
        ▼
  package.started        {reason: startup | on | reload | update | wake}: timers, connections, syncs
        │   window.opened / window.closed: only work that is pointless without a window
        │   each call's cosm.signal: fires when no one waits on that call
        ▼
  package.stopping       {reason: off | reload | update | removed | quit | idle}; cosm.package.signal already aborted; 3 s
        ▼
  worker ends            what is left (timers, sockets) ends with it
```

On a reload the new code already runs when the old hears `reload`. `quit` is Cosm's engine stopping (its idle stop,
`cosm serve stop`, a newer build); closing the window is `window.closed`.

A package's code runs only while something needs it: a call, an event it listens for, a process it started. Idle, its
worker stops (`idle`) and starts again for the next call (`wake`), so what its code keeps in variables lasts one worker,
and what must last goes in `cosm.storage`. Work that goes on where Cosm can't see it (a socket, a timer, a watch) holds
the worker with `cosm.package.keep(why)` until it ends; Settings → Packages and `cosm package running` show each hold
with its reason.

## Keeping time

Something to do at set times is a schedule: `cosm.point.add("cosm:schedules", { name, when, run })`, and Cosm runs
`run` when it is due, waking the package for it, so the package keeps no timer and sleeps in between. `when` is on
this computer's clock: `every 10m` (or `2h`, `1d`: that long after it ran last), `daily 08:00`, `weekly mon 08:00`, or
once: `2026-11-07 13:00`, `today 13:00`, `tomorrow 13:00` (of the day Cosm first sees it). Schedules run only while Cosm
runs, and one due while it was closed runs once at its next start: `run` is given `{name, when, due}`, `due` the time
it was due. A schedule doesn't keep Cosm running. `cosm schedule list` shows each with when it ran and runs next; a
`when` Cosm can't read is said there and in the package's log.

```ts
cosm.point.add("cosm:schedules", { name: "digest", when: "daily 08:00", description: "Writes the morning digest",
  run: async ({ due }) => { await writeDigest(); cosm.log(`digest for ${due}`); } });
// A look that depends on the day: worked out again with an event the package fires at midnight.
cosm.point.add("cosm:schedules", { name: "new-day", when: "daily 00:00", run: () => cosm.emit("new-day", {}) });
```

Work more often than a minute, or only while a window is open, is the package's own timer: it runs only while its
worker does, so the package holds its worker for as long as the timer should run (`cosm.package.keep`), from its code
starting to its stopping (with or without a window), or only while a window is open when the work is for one:

```ts
cosm.on("package.started", () => {
  const held = cosm.package.keep("syncs every 10 minutes");
  const timer = setInterval(() => void sync(), 10 * 60_000);
  cosm.package.signal.addEventListener("abort", () => { clearInterval(timer); held.release(); });
});
```

## Trying a handler

`cosm package try event <package> <event> '<data>'` runs one package's handlers for an event, the data given as one JSON word
(an agent's event names its conversation there too, `{"session": "c-7k2p", …}`), and prints what each returns, or `FAIL:` with the reason. The
package must be on. A handler whose `kind` left none of the files given is said, not run silently
(`! Standups: none of the files is a standups:meeting, so its handler didn't run`):

```sh
cosm package try event standups window.opened
cosm package try event standups file.saved '{"paths": ["notes/Plan.md"]}'
cosm package try event standups file.moved '{"moves": [{"from": "notes/Old.md", "to": "notes/New.md"}]}'
cosm package try event standups file.created.before '{"path": "meetings/Board.md", "kind": "standups:meeting", "text": ""}'
```

When `main.ts` as saved doesn't load, the run says so and uses the last version that did: fix it first (`cosm package
check`). `cosm package event <event> [-- <file>…]` fires one of Cosm's events
for every package that is on, as the window does: `cosm package event file.moved -- a.md b.md c.md d.md` gives
`moves: [{from: a.md, to: b.md}, {from: c.md, to: d.md}]`. A before-event is the engine's to ask, never fired this
way: try its handler with `cosm package try event`.

## Patterns

- **Handing work to the agent from a file event.** A file event is about no conversation, so its handler has none to
  talk to. Note what is to do (`cosm.storage.set("pending", […])`), and hand it over at the next session's start or
  message, a contribution to `agent:start` or `agent:message` returning it for the agent (`<meetings>3 new action items in inbox/…</meetings>`)
  and clears it. Or have the user's files carry it: a line the agent's instructions (`agent/instructions.md`) tell it to look for.
- **The window saves as the user types.** `file.saved` comes every few seconds while a page is edited, so a handler
  that derives something from a page (a list, a summary page) writes it from the whole page each time, never by adding
  to what it wrote before: run twice on the same text, it gives the same file. Narrow it by `kind`, keep it quick, and
  write only when the result changed (so it doesn't fire `file.saved` for nothing). Its own writes through Cosm aren't
  told to it. Handle `file.created` with the same function: a new page fires only that.
- **Changing a page that may be open.** Write through `cosm.file.change(path, fn)`, not `write`: when the user typed
  meanwhile, `fn` runs again on the newest text (Markdown's link fixer on `file.moved` does).
- **Handing something over once** (action items into the inbox). Rewriting from the whole note would bring a page back
  after the user sorted it away. Keep in the package's storage what was handed over (`{"<note>": ["<item>", …]}`):
  while the handed-over page is still where it was put, rewrite it from the note; once the user moved or trashed it,
  those items count as sorted, and only items added to the note later come again.
- **Recognising another layout's files.** A package can't know where another layout keeps meeting notes (Star chart's
  are under `spaces/<space>/notes/`), and a kind's `match` is fixed: recognise them by their content instead,
  a handler narrowed to `markdown:page` that looks for its mark (a `## Action items` heading) and leaves every other
  page alone. Use a folder glob only for a folder the package owns.
- **Where its files go.** A package names folders of its own (`Reading list/`), or a setting the user sets; for "the
  inbox", read Cosm's `new` setting, the folder ⌘N makes pages in, which a layout presets (Star chart's is `inbox`).
  Never another package's folder names (package.md).

## A complete example

`standups`: meeting notes live in `meetings/`, named by their date first. A new session hears today's meetings; one
named without a date is refused; closing a session asks whether to write today's standup note, which the package's
command `standup` has the agent write; and it tells other packages when a meeting note was made.

`cosm.json`:

<!-- example: standups/cosm.json -->
```json
{
  "name": "standups",
  "label": "Standups",
  "description": "Meeting notes named by their date, today's meetings told to the agent, and a standup note before you close.",
  "version": "1.0.0",
  "cosm": ">=1.0"
}
```

`main.ts`:

<!-- example: standups/main.ts -->
```ts
// Standups: meeting notes named by their date, today's told to the agent, a standup note before closing.
import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.package.uses("agent-session");
  cosm.point.add("cosm:kinds", { name: "meeting", extends: "markdown:page", match: "meetings/*.md", label: "Meeting note" });
  cosm.point.add("cosm:events", { name: "written", description: "A meeting note was made: {path}." });
  const today = () => new Date().toISOString().slice(0, 10);

  // A new session hears today's meeting notes.
  cosm.point.add("agent:start", { name: "today", run: async () => {
    const notes = await cosm.file.list(`meetings/${today()}*.md`);
    if (notes.length) return `<standups>Meeting notes today:\n${notes.join("\n")}\n</standups>`;
  } });

  // A meeting note's name starts with its date.
  const dated = ({ path, to }: { path: string; to?: string }) => {
    const name = (to ?? path).split("/").pop() ?? "";
    if (!/^\d{4}-\d{2}-\d{2} /.test(name)) return { stop: `Meeting notes start with their date, as ${today()} Board.` };
  };
  cosm.on("file.created.before", dated, { kind: "meeting" });
  cosm.on("file.moved.before", dated, { kind: "meeting" });

  // Tell the other packages, and the package's own views, when one was made.
  cosm.on("file.created", async ({ paths }) => {
    for (const path of paths) await cosm.emit("written", { path });
  }, { kind: "meeting" });

  // Closing a session (Agent session's) asks whether to write today's standup note first: yes keeps it open while the
  // agent writes it.
  cosm.on("agent-session:closed.before", async ({ session }: { session?: string }) => {
    if (!session) return;
    const yes = await cosm.ui.ask("Write today's standup note?", { description: "The agent writes what this session moved forward into today's meeting note.", choices: ["Write It", "Close"] });
    if (yes !== "Write It") return;
    await cosm.call("agent-session:send", { session, message: { prompt: "standup" } });
    return { stop: "Writing the standup note first" };
  });
}
```

`agent/prompts/standup.md`, what the agent does on the closing question's yes (agents.md):

<!-- example: standups/agent/prompts/standup.md -->
```markdown
---
description: Write today's standup note from what this session moved forward
---
# Standup

Today's meeting notes: !`cosm file list "meetings/$(date +%F)*.md"`

Write three short lines into today's standup note, `meetings/<today> Standup.md` (make it if there is none, named
with the date first): what moved forward in this session, what is next, and anything blocked. Read the session's
changed pages first; never invent progress. Say in one line what you wrote.
```

```sh
cosm package on standups                     # after the user's y
cosm package check standups
cosm package try event standups file.created.before '{"path": "meetings/Board.md", "kind": "standups:meeting", "text": ""}'
# {"stop":"Meeting notes start with their date, as 2026-10-30 Board."}
```
