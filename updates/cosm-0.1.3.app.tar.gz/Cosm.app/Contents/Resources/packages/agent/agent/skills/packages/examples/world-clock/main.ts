import type { Cosm } from "cosm";
import { shape } from "cosm/shape";

/** The time now in a time zone, as "Friday 14:05". Throws on a zone that isn't one. */
export function timeIn(zone: string): string {
  return new Intl.DateTimeFormat("en-GB", { timeZone: zone, weekday: "long", hour: "2-digit", minute: "2-digit" }).format(new Date());
}

export default function (cosm: Cosm) {
  cosm.point.add("cosm:settings", { name: "zones", shape: shape.string(), default: "Europe/Stockholm America/New_York", label: "Time zones", description: "The zones World clock shows, separated by spaces." });

  // A tool: `cosm world-clock:clocks` in the agent's shell (and an MCP tool where the agent's package offers tools).
  cosm.point.add("cosm:commands", { name: "clocks",
    description: "The time now in each of the user's time zones, one a line.",
    run: async () => {
      const zones = ((await cosm.setting.get<string>("zones")) ?? "").split(/\s+/).filter(Boolean);
      return zones.map((z) => `${z}  ${timeIn(z)}`);
    },
  });

  // An MCP server of its own, always handed to the agent: bin/clock-server, speaking MCP on stdin and stdout.
  cosm.point.add("agent:mcp", { name: "clock", program: "bin/clock-server" });
  // Claude Code may use its MCP tool without asking.
  cosm.point.add("claude:config", { name: "clock", allow: ["mcp__clock__time_in"] });
}
