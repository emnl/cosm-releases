import type { Cosm } from "cosm";
import { shape } from "cosm/shape";

const DIR = "Reading list";

export default async function (cosm: Cosm) {
  cosm.package.uses("agent-session");
  const book = await cosm.package.file.read("icons/book.svg");
  const article = await cosm.package.file.read("templates/article.md");
  cosm.point.add("cosm:kinds", { name: "article", extends: "markdown:page", match: `${DIR}/*.md`, label: "Article", template: article });
  cosm.point.add("cosm:settings", { name: "most", shape: shape.number({ min: 1, max: 100 }), default: 10, label: "Remind me when more than this many wait" });

  cosm.point.add("cosm:views", { name: "reading", file: "views/reading.html", label: "Reading list", icon: book });
  cosm.point.add("cosm:items", { name: "open", label: "Reading list", content: { icon: book },
    action: { open: "reading-list:reading" }, location: { in: "file-tree:tree" } });

  cosm.point.add("cosm:items", { name: "save-link", label: "Save a Link…", content: { description: "A web page to read later" }, location: { in: "palette" },
    action: async () => {
      const address = await cosm.ui.ask("The page's address?", { answer: "text" });
      if (!address) return;
      const why = await cosm.ui.ask("Why read it?", { answer: "text" });
      // Named after the address's last part, never over another page.
      const name = address.replace(/[?#].*$/, "").replace(/\/+$/, "").split("/").pop()!.replace(/\.[a-z]+$/, "").replace(/[-_]+/g, " ") || "link";
      let path = `${DIR}/${name}.md`;
      for (let n = 2; await cosm.file.stat(path); n++) path = `${DIR}/${name} ${n}.md`;
      await cosm.file.write(path, `# ${name}\n\nWhy read it: ${why ?? ""}\n\nAddress: ${address}\n`);
      return "Saved to your reading list";   // a string is shown as a notice
    } });

  cosm.point.add("cosm:items", { name: "new-article", label: "New Article…", location: { in: "menu-bar", menu: "File" },
    action: { new: { kind: "article", folder: DIR, name: "{name}", question: "What is it called?" } } });

  cosm.point.add("cosm:items", { name: "done", label: "Done Reading", location: { in: "file-menu", kind: "article" },
    action: async ({ path }) => { if (path) await cosm.file.move(path, `${DIR}/Read/${path.slice(path.lastIndexOf("/") + 1)}`); } });

  // "What next?": the read-next command in the conversation it was chosen on (Agent session's thing,
  // `agent-session:session:<id>`), else the one on screen used last, else a new one (Agent session's). Its
  // button in the chat, and its view's button, do the same.
  const SESSION = "agent-session:session:";
  const conversation = (thing?: string) => (thing?.startsWith(SESSION) && !thing.endsWith(":") ? thing.slice(SESSION.length) : undefined);
  const readNext = async (thing?: string) => {
    const on = (await cosm.ui.shown()).filter((x) => conversation(x.arg)).sort((a, b) => b.used.localeCompare(a.used));
    const s = conversation(thing) || conversation(on[0]?.arg) || String(await cosm.call("agent-session:start"));
    await cosm.call("agent-session:send", { session: s, message: { prompt: "read-next" } });
  };
  cosm.point.add("cosm:items", { name: "read-next", label: "What next?", content: { icon: "star" },
    action: ({ thing }) => readNext(thing), location: { in: "agent-session:holder" } });

  cosm.point.add("cosm:items", { name: "waiting", label: "Pages wait in your reading list", action: { open: "reading-list:reading" }, location: { in: "agent-session:holder" },
    content: { changes: { files: `${DIR}/*.md`, events: "setting.changed" }, run: async () => {
      const n = (await cosm.file.list(`${DIR}/*.md`)).length;
      return n > (await cosm.setting.get<number>("most")) ? { label: `${n} pages wait in your reading list` } : null;
    } } });

  // Its view's functions (views/reading.ts calls them; nobody else does). `articles` is kept live: it reads again when
  // a page in the folder changes, whoever changed it (the agent, Done, Finder).
  return cosm.view.export({
    articles: {
      description: "The pages waiting to be read, newest first, each with why it was saved.",
      changes: { files: `${DIR}/*.md` },
      run: async () => {
        const paths = await cosm.file.list(`${DIR}/*.md`);
        const all = await Promise.all(paths.map(async (path) => {
          const [text, stat] = await Promise.all([cosm.file.read(path), cosm.file.stat(path)]);
          return { path, title: path.slice(DIR.length + 1, -3), why: /^Why read it: (.*)$/m.exec(text)?.[1] ?? "", modified: stat?.modified ?? 0 };
        }));
        return all.sort((a, b) => b.modified - a.modified);
      },
    },
    done: {
      description: "Moves a page to Read/: it leaves the list.",
      input: shape.object({ path: shape.string() }),
      run: ({ path }: { path: string }) => cosm.file.move(path, `${DIR}/Read/${path.slice(path.lastIndexOf("/") + 1)}`),
    },
    readNext: () => readNext(),
  });
}
