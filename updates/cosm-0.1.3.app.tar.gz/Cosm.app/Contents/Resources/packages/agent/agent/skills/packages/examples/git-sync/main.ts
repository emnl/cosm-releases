// Git sync: what others pushed comes in first, then what changed here goes out. It runs when the window opens and
// closes, and by hand from the palette (Sync Now, Push with Tokens). Quiet when nothing changed, unless run by hand.
// git runs with Bun.spawn in the cosm's folder; a failure is a notice that stays (`as: "problem"`).
import type { Cosm } from "cosm";
import { shape } from "cosm/shape";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:settings", { name: "remote", shape: shape.string(), default: "origin", label: "Remote", description: "The git remote to pull from and push to.", hidden: true });
  cosm.point.add("cosm:settings", { name: "branch", shape: shape.string(), default: "", label: "Branch", description: "The branch to sync; empty: the one checked out.", hidden: true });

  const folder = cosm.package.folders.cosm;
  /** Runs a program in the cosm's folder: its output, or a throw with `why` when it fails. */
  async function run(words: string[], why: string): Promise<string> {
    const p = Bun.spawn(words, { cwd: folder, stdin: "ignore", stdout: "pipe", stderr: "pipe", signal: cosm.signal });
    const [out, code] = await Promise.all([new Response(p.stdout).text(), p.exited]);
    if (code !== 0) throw new Error(why);
    return out.trim();
  }
  const git = (why: string, ...args: string[]) => run(["git", ...args], why);
  const ok = (...args: string[]) => git("", ...args).then(() => true, () => false);
  const files = (n: number) => `${n} ${n === 1 ? "file" : "files"}`;
  /** A line that looks like it holds a token: a known key's prefix, a bearer header, or a long value given to a name
   * like token, secret, password or api key (a value written as ${NAME} is a reference, not the token). */
  const TOKEN = /((sk|pk|rk)-[a-z0-9_-]{16,}|gh[pousr]_[a-z0-9]{20,}|xox[abpr]-[a-z0-9-]{10,}|AIza[0-9a-z_-]{20,}|bearer\s+[a-z0-9._~+/=-]{16,}|(token|secret|password|api[_-]?key|authorization)["']?\s*[:=]\s*["']?[a-z0-9._~+/=-]{16,})/i;
  /** The files about to be pushed (changed or new, not ignored) with a line that looks like it holds a token. */
  async function withTokenLines(): Promise<string[]> {
    const changed = (await git("couldn't read git's status.", "ls-files", "-m", "-o", "--exclude-standard")).split("\n").filter(Boolean);
    const found: string[] = [];
    for (const f of changed) {
      const file = Bun.file(`${folder}/${f}`);
      if (file.size > 1_000_000) continue;
      const text = await file.text().catch(() => "");
      if (text.split("\n").some((l) => TOKEN.test(l) && !l.includes("${"))) found.push(f);
    }
    return found;
  }

  /** One sync: what to tell the user, or null when there is nothing to say. */
  async function sync(byHand: boolean, withTokens = false): Promise<string | null> {
    if (!Bun.which("git")) throw new Error("git isn't installed on this computer.");
    const remote = (await cosm.setting.get<string>("remote")) || "origin";
    if (!(await ok("rev-parse", "--is-inside-work-tree"))) throw new Error("this cosm is not a git repository yet.");
    // A rebase left half done (a run stopped in the middle) is for a person to finish, not for the next run.
    if (await ok("rev-parse", "--verify", "-q", "REBASE_HEAD"))
      throw new Error("a rebase was left half done in this cosm; it needs finishing by hand (git status) before syncing again.");
    const branch = (await cosm.setting.get<string>("branch")) || await git("no branch is checked out.", "symbolic-ref", "--short", "HEAD");

    // Cosm's own passing files, and the cosm's secrets, stay out of git.
    const ignore = await cosm.file.read(".gitignore").catch(() => "");
    const missing = [".cosm/cookies/", ".cosm/secrets.env"].filter((l) => !ignore.split("\n").includes(l));
    if (missing.length) await cosm.file.append(".gitignore", (ignore && !ignore.endsWith("\n") ? "\n" : "") + missing.join("\n") + "\n");

    if (await git("couldn't read git's status.", "status", "--porcelain")) {
      // A file about to go out with a line that looks like a token (an agent's .mcp.json with a key in it) isn't pushed
      // without the user's say.
      const found = await withTokenLines();
      if (found.length && !withTokens)
        throw new Error(`${found.slice(0, 3).join(", ")} looks like it holds a token, so nothing was pushed. Move the token out, or use Push with Tokens.`);
      await git("couldn't commit the changes here.", "add", "-A");
      const now = new Date();
      const stamp = `${now.toISOString().slice(0, 10)} ${now.toTimeString().slice(0, 5)}`;
      await git("couldn't commit the changes here.", "commit", "-q", "-m", `Cosm: ${stamp}`);
    }

    const unreachable = `couldn't reach ${remote}. Offline, or this computer can't sign in to it.`;
    // A remote without this branch yet (a new, empty one): the first push makes it.
    if (!(await ok("ls-remote", "--exit-code", "--heads", remote, branch))) {
      await git(unreachable, "ls-remote", remote);
      await git(`couldn't push to ${remote}.`, "push", "-q", "-u", remote, `HEAD:${branch}`);
      return `Git sync: this cosm is now on ${remote}`;
    }
    await git(unreachable, "fetch", "-q", remote, branch);
    const theirs = `${remote}/${branch}`;
    const said: string[] = [];
    const before = await git("", "rev-parse", "HEAD");
    const incoming = Number(await git("", "rev-list", "--count", `HEAD..${theirs}`));
    if (incoming > 0) {
      if (!(await ok("rebase", "-q", theirs))) {
        await ok("rebase", "--abort");
        throw new Error(`the same lines changed here and on ${remote}, so nothing was pulled. Your changes here are safe.`);
      }
      const n = (await git("", "diff", "--name-only", before, "HEAD", "--", ".", ":!.gitignore")).split("\n").filter(Boolean).length;
      if (n) said.push(`pulled changes to ${files(n)}`);
    }
    const outgoing = Number(await git("", "rev-list", "--count", `${theirs}..HEAD`));
    if (outgoing > 0) {
      const n = (await git("", "diff", "--name-only", theirs, "HEAD")).split("\n").filter(Boolean).length;
      await git(`couldn't push to ${remote}.`, "push", "-q", remote, `HEAD:${branch}`);
      if (n || byHand) said.push(`pushed changes to ${files(n)}`);
    }
    if (said.length) return `Git sync: ${said.join(", ")}`;
    return byHand ? "Git sync: up to date" : null;
  }

  /** A sync that says how it went: a notice, or a problem that stays until dismissed. */
  async function told(byHand: boolean, withTokens = false) {
    try {
      const said = await sync(byHand, withTokens);
      if (said) await cosm.ui.notify(said);
    } catch (e) {
      await cosm.ui.notify(`Git sync: ${(e as Error).message}`, { as: "problem" });
    }
  }

  cosm.on("window.opened", () => told(false));
  cosm.on("window.closed", () => told(false));
  cosm.point.add("cosm:items", { name: "sync-now", label: "Sync Now", content: { icon: "sync", description: "Pull and push this cosm now" },
    action: () => told(true), location: { in: "palette" } });
  cosm.point.add("cosm:items", { name: "push-with-tokens", label: "Push with Tokens", content: { description: "Push even though a file looks like it holds a token" },
    action: () => told(true, true), location: { in: "palette" } });
}
