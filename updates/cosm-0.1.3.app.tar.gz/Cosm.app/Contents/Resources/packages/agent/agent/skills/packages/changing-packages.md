# Changing another package

The user wants something of a package they didn't write gone or done differently: "stop Star chart's weekly review
reminder", "my own catch-up instead of Star chart's", "don't give me the email skill", "no catch-up when a session
starts". A built-in package is never edited where it is, and a package from a repo is overwritten by its next update, so
the change is made from outside it. Find the wish's row:

| The wish | What does it | Below |
|---|---|---|
| Something about some files: their view, whether search has them, their facts | a kind extending the package's kind; Open With; an association | files-and-kinds.md |
| How the agent works, even against a package's rules ("stop asking before filing") | a preference or a profile line | Rules: last |
| Something the package lets the user choose | a setting of the package | A setting |
| A part not wanted at all (a command, a skill, a button, the reminder line, the question on closing) | switch it off | Switch a part off |
| A part wanted, but the user's own way | `cosm part replace <package>:<part> <a package named for the change>` | Override |
| Two packages giving one thing | the user's answer, `cosm setting prefer` | Ties |
| The package's code itself, which many parts share | a copy of the whole package | Copying a package |

Each is done on the user's word (their request is it), and said in one line with what goes with it and when it takes
effect. What the user can do themselves: Settings → a package's page lists its parts with a switch each (off and on),
and an overriding package's page says when a part it overrides changed; Settings → Packages shows each tie.

## Parts and their names

Everything a package brings that can be switched off or overridden is a **part**, named `<package>:<part>`, by where it
is defined in the package (not where it shows):

| Part | Named | Example |
|---|---|---|
| A file or folder found by name | its path without its ending | `star-chart:agent/instructions`, `star-chart:agent/prompts/recall`, `star-chart:agent/skills/email` (the whole folder) |
| A command | `commands/<name>` | `star-chart:commands/due` |
| A kind | `kinds/<name>` | `star-chart:kinds/log` |
| A view | `views/<name>` (overriding it: the whole view, its `file` one of the overriding package's) | `star-chart:views/inbox` |
| A theme | `themes/<name>` | `cosm-theme:themes/cosm-dark` |
| What it does on an event (all its handlers for that event) | `on/<event>` | `star-chart:on/agent-session:closed.before` |
| An item | `items/<name>` | `star-chart:items/review` |
| A setting, a secret, an event it fires, word forms, folders search leaves out | `settings/<name>`, `secrets/<name>`, `events/<name>`, `stems/<name>`, `skip/<name>` | `tasks:settings/when-due` |
| An MCP server | `agent/mcp/<name>` | `crm:agent/mcp/crm` |
| A contribution to another package's point (package.md, Points) | `<owner>/<point>/<name>`: a file in that folder by its path without its ending, one added in code by its name | `star-chart:agent/start/recall`, `star-chart:daily-note/sections/due` |

Every contribution to a point is a part, Cosm's own points too. Not parts: presets, exports, and Cosm's own
instructions (its setting `instructions`, agents.md). Leaving out what a package's own code reads (a setting, a view
it opens) breaks that read; `cosm package check` warns when something left out is used. `cosm part list <package>` lists every part with what it is and how it
stands (off, overridden by …), then the overrides it makes of other packages' parts; `--json` with each part's
content and path.

```
$ cosm part list star-chart
star-chart — Star chart (on)
  agent/instructions           what the agent should know
  agent/prompts/recall        a prompt: the agent's prompt recall
  agent/skills/email           a skill: Go through the user's mail inbox with them, one thread at a time — what it is, who it's fr…
  views/inbox                  a view: Inbox
  commands/due              a command: cosm star-chart:due
  kinds/log                    a kind: extends markdown:page, **/* Log – *.md …
  agent/start/recall           When a session starts: recall
  on/agent-session:closed.before  what it does on an event: on a session about to close
  items/review                 an item
  …
```

## A setting

`cosm setting list <package>` lists what the package lets the user choose. When one says it, set it: `cosm setting set
<package> <setting> <value>`, and say what it is now. A wish a setting doesn't cover, for a package with an author: the
better change is a new setting there, so tell the user that it could be one.

## Switch a part off

A part the user doesn't want is switched off in the cosm; the package stays on and keeps updating. Each part is named in
full, so one command can switch off parts of several packages:

```
$ cosm part off star-chart:items/review
OK: Star chart's items/review (now) switched off
$ cosm part on star-chart:items/review
OK: Star chart's items/review (now) switched on again
```

It is kept in `.cosm/packages.json`: `{"star-chart": {"on": true, "off": ["items/review"]}}`. While off, a part isn't
there: no command, no skill, no button, no handler run, no tool, no contribution to a point. Instructions, commands,
skills and MCP servers from the next session; the rest at once. `off` refuses a part the package doesn't have; an
overriding package's override is switched off as `<package>:<base package>:<part>`. `--json` gives the reply as data,
one per package: `[{package, label, verb, changed: [{part, takesEffect}], already, overridden, instead, warnings}]`.

The usual wishes:

| "Stop …" | Switch off |
|---|---|
| asking me to reflect when I close | `star-chart:on/agent-session:closed.before` (the question on closing) |
| giving me the email skill | `star-chart:agent/skills/email` |
| the Log button | `star-chart:items/log` |

**What breaks.** `off` and `check` say, with `!`, what a part that stays on uses of the one switched off: a tool a
command runs (`` !`cosm star-chart:due 3` ``), a command an item or a handler sends:

```
$ cosm part off star-chart:commands/due
OK: Star chart's commands/due (now) switched off
! commands/due is left out here, and the command recall (star-chart) runs !`cosm star-chart:due`: it fails
! commands/due is left out here, and the command review (star-chart) runs !`cosm star-chart:due`: it fails
```

Say these to the user before or with the change, in plain words, and offer what fixes them (switch off the part that
uses it too, or override it). A package whose code calls or reads the one switched off says so
(`cosm.package.uses`): `off` asks first, naming it; one that said `{ if: "on" }` does without it.

**What the window does is not all.** A package's instructions may have the agent do the same thing on its own: Star
chart's tell the agent to run the `recall` command on its first reply and to offer `reflect` when the user is done.
Read the package's `agent/instructions.md` before saying it is done, and when it says so, add a line to the user's profile too
(Star chart: under `## How I like to work` in `profile.md`): "- Don't offer Reflect when I'm done; I ask for it
(2026-10-27)". Do both on the user's word, and say both: either alone leaves half of it.

## Override

A package takes the place of another's part by name, in its main.ts:

```ts
cosm.part.override("star-chart:agent/prompts/recall", { file: "agent/prompts/recall.md" });
```

A file part's override names a file of the overriding package (`file`); any other part's carries what takes its place
(`value`), in the part's own shape: the handlers of an event (functions or actions, as `cosm.on` takes them), an item
(as `cosm:items` takes it), a tool (`{ description, inputs, run }`), a kind. Functions in a value are the overriding
package's own and run in its worker. Cosm keeps the fingerprint of the base's part as it was when taken in the
overriding package's `cosm.lock`, beside its `cosm.json`:

```json
{
  "overrides": {
    "star-chart:agent/prompts/recall": "c6c08fb62c024d1e"
  }
}
```

`cosm.lock` is Cosm's bookkeeping: written by `replace` and `accept`, never by hand. While both packages are on, the
base's part *is* the override: the base's name and place (the `recall` command, Star chart's item in the chat), with the
override's content, run as the overriding package. The rest of the base keeps updating.

**Start with `cosm part replace`.** It copies the base's part into the package named after the change (a file part
at the same path, `agent/prompts/recall.md`), writes the fingerprint in `cosm.lock`, and declares the override in main.ts:
it makes the package (off) the first time, with `--label` and `--description` (give them, as package.md says to write
them), and a main.ts holding the line; a package that has a main.ts already is told the line to add.

```
$ cosm part replace star-chart:agent/prompts/recall short-catch-up --label "Short catch-up" --description "A two-line catch-up of what's due this week."
OK: Short catch-up overrides star-chart:agent/prompts/recall with a copy of Star chart's to change: …/.cosm/packages/short-catch-up/agent/prompts/recall.md
  Short catch-up is new here: .cosm/packages/short-catch-up/
  its main.ts declares it: cosm.part.override("star-chart:agent/prompts/recall", { file: "agent/prompts/recall.md" });
  the fingerprint of Star chart's part, kept in cosm.lock to tell when it changes: c6c08fb62c024d1e
  Short catch-up is off: the override is used once the user switches it on (cosm package on short-catch-up, on their yes)
```

Then change the copy as the user asked, and only that. For any other part, `replace` prints the base's value in its
shape, with its bare names written in full (`"command": "star-chart:review"`), so the copy keeps naming the base's
things. A function of the base's can't be copied (it lives in the base's code): it shows as `"<a function of your own>"`,
and a new main.ts holds the line as a comment until the package's own function is written in its place. Read the
base's main.ts for what that function does.
`replace` refuses a path already taken in the package (move that file first), a part the base doesn't have, a part the
package overrides already, and a package that is built in or comes from a repo (its next update would undo the change).
`--json` gives the reply as data: `{ref, package, label, base, made, copy, main ("written", "comment" or "add"),
mainPath, line, fingerprint, on, baseOn, takesEffect}`.

**Names inside an override.**

- **A file part** (a command, a skill, a page) is read in the base's name, as the base's own file was: the copy works
  unchanged. Name one of the overriding package's own in full.
- **A value** is the overriding package's code: a bare name in it is the overriding package's own, so name the base's
  things in full (`cosm.call("agent-session:send", { session: s, message: { prompt: "star-chart:recall" } })`, `cosm.call("agent-session:start")`), as `replace` writes
  them. Its functions run as the overriding package: its folders, settings and storage.

| | While the override is in |
|---|---|
| Name and place | The base's: other packages naming the base's part reach the override. |
| Commands | The base's name: `recall`. `cosm point read agent:prompts` says which package it comes from (`cosm point read agent:prompts`: `recall  star-chart`, overridden by short-catch-up). |
| Tools | The base's name, `cosm star-chart:due`, runs the override, as the overriding package. |
| Takes effect | Instructions, commands, skills, MCP servers from the next session; the rest now. |

**When it isn't in.** The overriding package off: the base's part is back at once. The base off: the override does
nothing (`check` says so with `!`). One override switched off on its own: leave it out of the overriding package by the
base's part in full (`cosm part off short-catch-up:star-chart:agent/prompts/recall`; the base's own is in again, or
another package's override of it). Dropping one: take its `cosm.part.override` line out of main.ts, its file, and its entry
in `cosm.lock`; the base's part is back.

### When the base changes

The fingerprint is of the base's part as it was taken over (a function's by its code). When the base's part changes
(an app update, its author's new version), Cosm says so: `check` on the overriding package (`! Star chart changed
agent/prompts/recall since Short catch-up took its place: cosm part changed star-chart:agent/prompts/recall shows it
beside the override`), and a notice in the window once per change, with what packages place on problems (`notice`: Agent session's Ask the Agent). Then:

1. `cosm part changed <part>` shows the base's part now beside the override (`--json`: `state` `same`, `changed` or
   `gone`, `baseContent`, `basePath`, `override`, `overridePath`). A function shows as `{"fn": …}`: read the base's
   main.ts for its code.
2. Read both and say in plain words what differs, sorting what the user changed on purpose from what the base changed
   since: "Star chart's catch-up now looks 4 days ahead and lists the inbox; yours looks 7 days ahead and leaves the
   inbox out." Ask which differences are the user's to keep.
3. Offer, recommending one: "**1** bring yours up to date (Star chart's new lines carried into yours, your changes kept)
   · **2** keep yours as it is".
4. On **1**: change the override, `cosm package check <package>`, then `cosm part accept <part>`, which records the
   base's part now as the new fingerprint in `cosm.lock`. On **2**: `cosm part accept <part>` alone. Say when it
   takes effect.

```
$ cosm part accept star-chart:agent/prompts/recall
OK: Short catch-up's override of star-chart:agent/prompts/recall is up to date with Star chart's (ed3bf0b14e1f6c6b)
```

`changed` and `accept` take the overriding package as a second word when several override the part. **The base no
longer has the part** (`gone`: removed or renamed, which can't be told apart): the override does nothing. Look for its
successor in `cosm part list <base>`, and offer to move the override to it (the line under the new name, then
`accept`) or to drop it. An overriding package from a repo can't be changed here: offer only to keep it (`accept`) or to
tell its author.

### "No catch-up when a session starts"

The catch-up is Star chart's contribution `recall` to the agent's point `agent:start` (it sends Recall,
`cosm.call("agent-session:send", …)`), beside `profile`, which hands the agent the profile and the map. Leave out only it:

```sh
cosm part off star-chart:agent/start/recall
```

and add the profile line (Star chart's instructions run the `recall` command on the first reply too): "- No catch-up on my
first message: run Recall only when I ask (2026-10-27)". Say both: "Sessions no longer open with a catch-up, and
I've noted in your profile not to run one on my own; Recall in ⌘K still works when you ask."

## Ties

Where two packages give one thing, the user decides, kept in `.cosm/settings.json` (`prefer`); until then the earlier
package in Cosm's order gives it, and `check` and `cosm package ties` say so. A kind without `match` extending another's
ties with it on every key both set (files-and-kinds.md), so a package giving every page its own editor makes a tie on
`view`:

| Tie | Answer |
|---|---|
| Two kinds matching one file | `cosm setting prefer kind <package>` |
| A key two kinds of equal weight set (`view`, `merge`, `template`, `index.text`, `index.search`) | `cosm setting prefer <key> <package>` |
| Two packages overriding one part | `cosm setting prefer overrides:<package>:<part> <package>` |
| Two presets of one setting | `cosm setting prefer presets:<owner>:<setting> <package>` (until then the setting keeps its own default) |

```
$ cosm package ties
overrides:star-chart:agent/prompts/recall: other-recall (until the user ranks them: cosm setting prefer; also short-catch-up)
$ cosm package ties --json
{"overrides:star-chart:agent/prompts/recall": {"key": "overrides", "chosen": "other-recall", "declaredBy": ["other-recall", "short-catch-up"], "ranked": false, "part": "star-chart:agent/prompts/recall"}}
$ cosm setting prefer overrides:star-chart:agent/prompts/recall short-catch-up
```

Each tie: `key` (what `cosm setting prefer` takes: `view`, `kind`, `overrides`, `extends`, `presets`), `chosen` (the
package giving it now), `declaredBy` (the packages in it), `ranked` (whether the user answered), and as they apply
`things` and `example` (how many it decides, one of them), `part`, `view`, `setting`. Settings → Packages asks the user
and keeps the answer; the agent sets one only on the user's word, and says what it changed, from its output. `cosm
setting prefer <what> default` takes an answer back.

## Rules: last

A package's instructions (`agent/instructions`) can be switched off, and overridden only whole. Overriding them forks the package's
most-changed file: every later change to it comes back as a change to bring over. A wish about how the agent works
("stop asking before filing", "write to Anna in English") is a preference or a line in the user's profile, even when
it goes against a package's instructions (SKILL.md). Override instructions only when a line can't do it, and leave them
out only when the user wants none of what they say, saying what goes with them (Star chart's are how the agent keeps
the cosm's layout).

## One package per change

Each change the user asks for is its own package in the cosm, `.cosm/packages/<name>/`, named for what it does
(`short-catch-up`, `no-catch-up`): its label and description say the change, and the overrides that make one change go
together in its main.ts. A later wish that belongs to it goes in it; a new wish is a new package. Such a package is like
any other: switched on and off by itself, shown under its own name in Settings → Packages, and sent to someone else as
its folder (its `cosm.lock` with it). Made by `cosm part replace`, it is off: switch it on after the user's **y**; in
a cosm the user hasn't trusted on this computer it can't be switched on, so say where they trust it.

"I want my own catch-up instead of Star chart's", from the start:

```sh
cosm part replace star-chart:agent/prompts/recall short-catch-up --label "Short catch-up" --description "…"   # the copy, main.ts, cosm.lock; the package made (off)
# change .cosm/packages/short-catch-up/agent/prompts/recall.md as the user asked
cosm package check short-catch-up                   # ✓ overrides star-chart:agent/prompts/recall once it is on
cosm package on short-catch-up                      # after the user's y
cosm point read agent:prompts                 # recall: Star chart's, overridden by short-catch-up
```

Short catch-up is then three files beside its command: `cosm.json` (who it is), `main.ts` (the `cosm.part.override` line)
and `cosm.lock` (the fingerprint); `examples/short-catch-up/` is that package. The question: "Your catch-up is ready as Short catch-up. Turn it on? **y** yes ·
**n** no". Then say that the next session's catch-up is theirs, and that when Star chart changes its own, Cosm says so
and the agent offers to bring theirs up to date.

## Copying a package

Copying a whole package into `.cosm/packages/<the same name>/` makes the copy that package for this cosm: it stops
getting the app's or its author's updates to every part, not just the one changed. Only for a change in its code itself,
which many parts share (Star chart's `src/` gives its tools and handlers), and on **y** after saying that. Everything
else above leaves the package updating. `cosm package remove <package>` takes the copy away, and the built-in one is
used again.
