---
description: Where things stand — what's due this week and what to pick up
---
# Recall

Takes no argument. `profile.md` and the map are already loaded. If `## Me` in `profile.md` is empty, the cosm is new: suggest the `setup` command and stop.

## What the cosm shows


Today: !`date +%Y-%m-%d`

Open tasks due within 7 days, overdue included, from anywhere in the cosm:
!`cosm star-chart:due 7`

Most recently changed pages (newest first):
!`cosm star-chart:recent`

## Answer


Two lines at most, in the user's language:

1. **Due:** the tasks above, overdue first, each with its space. Leave the line out when nothing is due.
2. If the user's message asked something, answer it here instead. Otherwise one line that suggests where to pick up, from the recently changed pages: "Pick up where you left off: [[Acme supply deal]] — or just tell me what you want to do."
