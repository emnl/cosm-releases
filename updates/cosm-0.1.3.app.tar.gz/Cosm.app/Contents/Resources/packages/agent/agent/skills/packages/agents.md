# Agents: what the agent gets, and the agent itself

The user asks for something about the agent: "give the agent a tool that tells the time anywhere", "let the agent use
our CRM's MCP server", "let Claude run my package's commands without asking", "give the agent my API token", "start a
session and send it this", "use Gemini instead", "add another agent". The agent is a package like any other: Cosm names
no agent. What any package gives whatever agent runs, it adds to the points of the built-in `agent` package (package.md,
Points): files in its `agent/` folder (`agent/instructions.md`, `agent/prompts/`, `agent/skills/`), and in code `cosm.point.add`
to `agent:mcp`, `agent:secrets` and `agent:programs`; its tools go to Cosm's own
`cosm:commands`, which Cosm's shell runs. A package that *is* an agent, a connector, adds its agent to
`agent:agents`; conversations with it are Agent session's (Sessions, below).
What the agent gets takes effect from the next session; a tool, at once.

A package's root `AGENTS.md` means what it means in any project: how to work on the package's code. It doesn't reach
the agent in a cosm (`cosm package check` says so when there is no `agent/instructions.md`).

## What every agent gets

The `agent` package's points and Cosm's tools, each read as any point: after the parts the cosm switches off and those other packages override
(changing-packages.md), in Cosm's package order. The agent's package reads them (the `agent` package's `share`, below) and puts
them in its agent's shape each time it starts a session:

| Point | What adds to it |
|---|---|
| `agent:instructions` | Cosm's own three facts first (the `agent` package's `agent/instructions.md`: this folder is a cosm; `cosm help` lists what there is; move and trash through `cosm file`; switched off as any part, `cosm part off agent:agent/instructions`), then each package's `agent/instructions.md`, in package order |
| `agent:prompts` | each package's `agent/prompts/<name>.md`, typed as the agent's package says (Claude Code's `/cosm:<name>`) |
| `agent:skills` | each package's `agent/skills/<name>/` (a folder with its `SKILL.md`) |
| `cosm:commands` | Cosm's own commands (`cosm index search` …), then each package's: `cosm <package>:<name>` in its shell, the agent's tools (MCP tools while its package offers them) |
| `agent:mcp` | `cosm` (the engine's lookups and the packages' tools, the `agent` package's), then each package's servers: `{program, args}` or `{url, headers}`, in code |
| `agent:secrets` | the package's secrets the agent's sessions get, as `COSM_SECRET_<NAME>`: one by its name (`cosm:secrets` declares it), in code |
| `agent:programs` | programs the agent runs by name in its shell: `{name, program}`, one of the package's (`bin/uv`), run with the package's own variables (its cache folder, its settings); each connector puts them first on its agent's PATH as a session starts. Only the agent gets them: a package that needs another's program asks that package for it (its export), and libraries come through Bun (`dependencies`). In code |
| `<agent>:config` | what packages give one agent alone, a point that agent's package defines (Claude Code's `claude:config`) |

**The same name twice:** the first in Cosm's package order keeps it, the other is reached by its full name,
`<package>:<name>` (`/cosm:short-catch-up:recall`); nothing is dropped or numbered, and `cosm package check` says so.

`cosm point read agent:prompts` (and the others) lists what the agent gets, each with its package and file:

```
$ cosm point read agent:instructions
agent  agent  …/packages/agent/agent/instructions.md
claude  claude  …/packages/claude/agent/instructions.md
star-chart  star-chart  …/packages/star-chart/agent/instructions.md
$ cosm point read agent:prompts
recall  star-chart  …/packages/star-chart/agent/prompts/recall.md
reflect  star-chart  …/packages/star-chart/agent/prompts/reflect.md
```

`cosm setting set cosm instructions false` leaves Cosm's own three facts out (for a package whose instructions say
them its own way); `default` brings them back.

## agent/: instructions, commands and skills

Files in the package's `agent/` folder, found by name; no code needed. A package of only these is a whole package
(package.md).

| File | What it is |
|---|---|
| `agent/instructions.md` | What the agent should know while the package is on: its places, its rules, its tools by name. Short and plain: it is in every session's context. Part `agent/instructions`. |
| `agent/prompts/<name>.md` | A prompt the user runs by name (`reflect`, typed as the agent's package says: `/cosm:reflect` in Claude Code), or the package's code sends (`cosm.call("agent-session:send", { session, message: { prompt: "reflect" } })`: an item's function, given the session it was chosen on, views.md). Its text is the prompt. A line `` !`cosm star-chart:due 3` `` runs that tool as the agent loads the command, its answer in the line's place (an agent that runs such lines: Claude Code does; one that doesn't sees the line as written); `check` says when the cosm switches off a tool a command runs. Part `agent/prompts/<name>`. |
| `agent/skills/<name>/SKILL.md` | A skill the agent loads when it applies, with its `name` and `description` in front matter; files beside it are the skill's. Part `agent/skills/<name>`. |

Name another package's command in full (`star-chart:reflect`); a bare name is the package's own.

## Tools: cosm \<package\>:\<name\>

A command is a function of the package's on Cosm's command line, the agent's tool: a contribution to `cosm:commands`. While the package is
on, `cosm <package>:<name>` runs it from the agent's shell (`cosm star-chart:due --days 7`); and where the agent's package offers tools (Claude Code's and
Gemini CLI's setting "Offer Cosm's lookups as tools", off by default), it is an MCP tool too, `<package>_<name>`. Most
packages add none: a tool is for something the agent needs to ask or do that Cosm's own lookups (`cosm help`,
reference.md) don't give.

```ts
cosm.point.add("cosm:commands", {
  name: "search-logs",
  description: "Searches the session logs (kept out of ordinary search).",
  step: "Searched your logs for “{words}”",
  inputs: [{ name: "words", label: "Words to search for", type: "list" }],
  run: async ({ words }) => (await cosm.index.search(words.join(" "), { kind: "star-chart:log" })).map((h) => h.thing),
});
```

| Key | Meaning |
|---|---|
| `name` | Its name, kebab-case: `cosm <package>:<name>`, and its part `commands/<name>`. |
| `description` | One line on what it does or gives: the agent reads it in `cosm help`, and it is the MCP tool's description. |
| `step` | How a call of it reads in a chat, as a step the agent took: "Searched your logs for “{words}”", each `{<input>}` filled from the call. The agent's package shows it (Claude Code's chat does); without one, the step reads "Ran star-chart:search-logs". Say what was done in the user's words, naming no file kind the cosm may not hold. |
| `inputs` | What it takes, in order: each `{ name, label?, description?, type?, choices?, optional? }`. `type` is `text` (the default), `number`, `switch` (true or false), `list` (texts; it takes the remaining words, so it comes last) or `stdin` (a text: in the shell, what is piped in when it isn't given as a word or flag, `… | cosm <package>:<tool>`; one at most, and only a tool with one reads stdin). `choices` are the values it takes. The name is kebab-case: its flag (`--days`) and its key in `run`'s object. |
| `run` | The function: given one object with the inputs by name, typed from `inputs` (`days` is a `number`, or missing when optional). Cosm checks every call against the inputs before `run`. |

**What it returns** is shown by one rule: a string as it is, a list of strings one a line, anything else as indented
JSON; `--json` prints the value as it is. Nothing (`undefined`, `null`) prints
nothing. **A failure is a throw**: `throw new Error("no Knowledge folder called people")` prints `FAIL: …` and exits 1 in
the shell and is an MCP error; say what to do instead in the message.

**A tool the agent can use well** follows what Cosm's own commands do (advice: `cosm package check` doesn't hold you to
it):
- Every input has a `label` and, where it isn't obvious, a `description`: they are its help (`cosm <package>:<name> --help`).
- Asking twice is safe: a tool that adds or changes something, given what is already so, succeeds and says nothing
  changed (a value saying what happened, `{ change: "added" | "none" }`, never `already: true`), rather than failing.
- A failure says what to do instead, naming the call that would work (`no Knowledge folder called planets. There are:
  people companies`), so the agent's next try is right.
- One that changes several things at once (moves many files, removes) takes an input that says what it would do and
  does nothing, as `cosm file move --dry-run` does.
- What it returns has one shape every time, so `--json` reads the same whatever the case.

**From the shell**, inputs are flags or words: `cosm star-chart:due --days 7` or `cosm star-chart:due 7`. Words without a
flag fill the inputs not given, the required ones first, then the optional ones, in order; a `list` takes the rest; a
switch is only ever its flag (`--all` alone is true). Or the whole object piped in with `-` as the only word: `echo
'{"days": 7}' | cosm star-chart:due -`. `cosm help` lists every tool with its inputs; `cosm help star-chart:due` says one.

**While it runs**, its second argument says who called it (`{ by }`: a package's name, `window` or `shell`; the agent's own commands give its connector's name, `claude`, as
its program is the connector's; which
conversation it is about is an input it asks for, as `cosm agent-session:rename <session> <title>` does, the agent
filling in its conversation's id, which Cosm tells it as each session starts), and `cosm.signal` fires when no one waits
any more (the user pressed Skip, the agent interrupted the command, the package restarted): pass it on to `fetch` and
`Bun.spawn`, so a late write doesn't overwrite what the user did meanwhile.

A tool is the agent's. What a package's views and other packages call is its API: functions it exports
(`cosm.view.export` for its own views, `cosm.main.<name>()`; `cosm.package.export` for others, `cosm.call("<package>:<name>", …)`
from other packages; a tool that other packages want too calls the exported function in one line. A handler is
registered with `cosm.on`.

A package whose code calls or reads another (`cosm.call`, `cosm.point.read`, `cosm.point.default`) says so in its
`main.ts`: `cosm.package.uses("agent-session")`, or `cosm.package.uses("agent-session", { if: "on" })` when it does
without it. Then it switches on only while the other is on, and switching the other off asks first. A call or read it
didn't say is refused, naming the line to add. What its registrations name already counts (a kind it extends, a part
it overrides): `cosm package list` shows what each package uses.

## MCP servers and secrets

| Point | What a contribution is |
|---|---|
| `agent:mcp` | An MCP server, always handed to the agent while the package is on: `{ name, program: "bin/clock-server", args?: […] }` (a program of the package's, speaking MCP over stdio; it gets no JSON on stdin) or `{ name, url: "https://…", headers?: {…} }` (a remote one). `${NAME}` in the url and headers is filled in from the package's variables (below; `check` refuses a name that isn't one): `"Authorization": "Bearer ${COSM_SECRET_CRM_TOKEN}"`, so a token stays in its secrets. A name an earlier package has is reached as `<package>-<name>`. Part `agent/mcp/<name>`. |
| `agent:secrets` | `{ name }`: one of the package's secrets (`cosm:secrets`, package.md) given to the agent's sessions, as `COSM_SECRET_<NAME>` in the agent's environment. A secret the agent has can end up in a transcript; give it only when the agent itself must use it. |

A server the package runs is started by the agent, not by Cosm, wherever the agent runs it from: it gets the package's
variables (its folder, data, settings and secrets) in its environment and finds its files from `$COSM_PACKAGE_DIR`, not
the working folder. Prefer an MCP server for what a tool can't do (a long-lived connection, a stream, an outside
service's own server); for anything else a tool is simpler and works in every agent's shell.

**`cosm mcp`** serves the engine's lookups and every package's tools (as `<package>_<name>`: a tool's name can't hold
`:`). Every agent's MCP file holds it; the agent's package leaves it out unless its own setting `lookups-as-tools` is on.

### For one agent alone: its point

What only one agent's package reads, in that agent's own terms, is a point that agent's package defines:
`cosm.point.add("claude:config", { name: "recipes", allow: ["Bash(cosm recipes:*)"] })` is read by the Claude package
only, which says what it takes in the point's shape (`cosm package check` checks against it; while the Claude package
is off, the contribution does nothing). Prefer what works for every agent (a tool, an event, a command); use this only
for what one agent alone can do.

| Agent package | Its point, and what it reads |
|---|---|
| Claude Code (`claude`) | `claude:config`: `allow`, `ask`, `deny`: Claude Code permission rules added to its lists (`"Bash(cosm recipes:*)"`, `"mcp__recipes__plan"`); `hooks`: Claude Code hooks of the package's own, in Claude Code's `hooks.json` shape, the package's folder as `${CLAUDE_PLUGIN_ROOT}/package`. A theme's `agents.claude`: Claude Code's own screen colours (themes.md), checked against the same shape. |
| Gemini CLI (`gemini`) | none; a theme's `agents.gemini` (else made from the theme's colours). |

What a package lets an agent do without asking (`allow`, hooks) is said to the user before it is switched on.
`cosm point read claude:config` lists what the packages that are on give Claude Code.

## Sessions

A session is one conversation with an agent. Agent session (a package) keeps them: each has an id of its own, made
with it (`c-7k2p`), the agent it runs on, and the agent's own id for it, kept as the agent makes or changes one. Agent
session is the broker: any package starts, sends to and ends a session only through its exports, in main.ts and in
views alike (`cosm.call`), and it calls the session's agent (its connector, below):

| Call | What it does |
|---|---|
| `cosm.call("agent:list")` | The agents that are on: `{ name, label, package, chosen }`, the one used now (Settings → General → Defaults) first. |
| `cosm.call("agent-session:start", { agent?, session?, as?, first? })` | Starts a session with that agent (none named: the user's, asked once when several), or carries one on (`session`), as a chat or in its agent's terminal (`as: "terminal"`): its id. Started as a chat while it runs in its terminal, the terminal stops: a conversation runs in one program at a time. |
| `cosm.call("agent-session:running", { session })` | Which of its programs runs now, as its connector says: `{ as: "chat" \| "terminal", process }` (the process's full name), or `null`. |
| `cosm.call("agent-session:send", { session, message })` | To the session's agent: a text (`"…"` or `{ text, images?, context? }`) or one of the agent's prompts by name (`{ prompt: "star-chart:reflect" }`, in full), typed the agent's way. It waits while the agent answers; a package's message while the session starts goes before the user's. A session running in its terminal gets the text typed in there. A session not running is carried on first (its agent started again on it), so a sender never has to. |
| `cosm.call("agent-session:answer", { session, answer: { id, allow, always?, answers? } })` | Answers what the agent asked (a step, a plan, a form), by the id in its stream. The shell's is `cosm agent-session:answer <session> allow\|always\|deny\|<answer>`. |
| `cosm.call("agent-session:cancel", { session })` / `cosm.call("agent-session:stop", { session })` | Stops what it is doing now / ends its run (it stays open). |
| `cosm.call("agent-session:set", { session, model?, effort? })` | Its model or effort. |
| `cosm.call("agent-session:close", { session })` | Closes it (a package may keep it open first, below). |
| `cosm.call("agent-session:get", { session })` | It as the list keeps it: `{ id, agent, agentSession?, started, closed?, title?, package }`. |

What the agent says is a stream of Agent session's, `agent-session:<id>`: what it kept, then as it comes. A package's
main.ts follows it by name (`cosm.stream.subscribe("agent-session:c-7k2p", …)`, package.md); a view gets it only
from its package, as a handle (`cosm.stream.pass`, views.md): Agent chat hands its chat the conversation's.

Agent session keeps the list (when each started, closed or not, the user's title) in its data folder, shows them in the
right pane's holder, and fires its events, each with `{session}`: `agent-session:started`,
`agent-session:closed.before` (a handler may keep it open: `{ stop }`), `agent-session:closed`,
`agent-session:removed`. The shell has `cosm agent-session:list|new|send|answer|which|close|reopen|remove|rename`: `cosm
agent-session:send c-7k2p "Summarise the week"` sends a message (carrying the conversation on when nothing of it runs)
and prints the agent's reply once its turn ends, so a script can talk to the agent with no window open. When the agent
asks something first (a step to allow, a plan, questions), it prints the question and the short commands that answer
it, and returns: `cosm agent-session:answer c-7k2p allow` (or `always`, allowing that step from now on where offered,
or `deny`); a plan takes `allow` or `deny`; a question a choice's label or words of the user's own (several questions:
`{"<question>": "<answer>"}`), or `deny` to decline. It answers the oldest open question, or the one `--id` names. It is refused while a turn of the conversation runs (send
again once it has ended), so the agent sending to its own conversation never waits on itself. Running in its terminal,
the text is typed in there and nothing is waited for. New Session starts the
session at once; a message `agent:start`'s contributions give it (`{send}`: Star chart's Recall) goes before anything
else sent to it, the user's first message too.

Star chart asks before a session closes, and sends its command when the user says yes:

```ts
cosm.on("agent-session:closed.before", async ({ session }) => {
  if (!session || (await cosm.call("agent-session:storage-get", { session, key: "reflected" }))) return;
  const yes = await cosm.ui.ask("Reflect before you go?", { choices: ["Reflect", "Close"] });
  if (yes !== "Reflect") return;
  await cosm.call("agent-session:send", { session, message: { prompt: "star-chart:reflect" } });
  return { stop: "Reflecting first" };
});
```

An agent in its terminal is its connector's process `terminal-<session>`, drawn as a terminal: `agent-session:start`
with `as: "terminal"` starts it (or finds it running), `agent-session:running` names it, and Agent terminal draws it
(`<cosm-terminal process="<package>:terminal-<session>">`, views.md).

What a package keeps for one session goes in the session's storage: `agent-session:storage-get`, `storage-set` and
`storage-delete` (`{ session, key, value }`), each package's keys its own, gone when the session leaves the list; a
change fires `agent-session:storage.changed` (`{session, package, key}`). What happens in a session is the `agent` package's (below, What
happens in a session): packages answer it through its points and hear it as its events, the session in their data.
The shell reaches the calls as any package's exports, its input as one JSON object:
`cosm package call agent-session:send '{"session": "c-7k2p", "message": "hello"}'` hands the message over and returns
at once, where `cosm agent-session:send` waits for the reply.

The agent knows its own conversation: each time its session starts (new, carried on, after it was cleared or
compacted), Agent session's contribution to `agent:start` tells it, `This conversation is agent-session:session:c-7k2p
(its id: c-7k2p).`, with what the start's other contributions say: at once for an agent whose hooks tell its start,
else with the first message after it; never with ordinary messages. One that lost it looks itself up by its own session
id: `cosm agent-session:which <the agent's own id>` answers the conversation's thing, and `cosm agent-session:list`
shows each conversation's agent id beside its own (in Claude Code, a skill's text gets the session's own id as
`${CLAUDE_SESSION_ID}`). An item the agent runs for its conversation is given it as a click in the chat would be:
`cosm ui run star-chart:reflect --thing agent-session:session:c-7k2p`. Cosm sets no variable for the conversation, and
reads none from a caller.

## Programs

Almost everything a package does is a function in its main.ts. What stays a program, a process of its own with a
command line, is what speaks a protocol or runs in a terminal:

| Program | Named by |
|---|---|
| An agent, as a chat or in a terminal | its connector starts them as its processes (`cosm.process.start`); Agent session speaks ACP with a chat's, reading its output's stream |
| An MCP server of the package's | `cosm.point.add("agent:mcp", { name: "clock", program: "bin/clock-server", args: […] })` |
| A step shown running in a terminal (an install, a sign-in) | the package's view starts it as one of its processes (`cosm.process.start("setup", { program: "bin/claude-agent", args: ["install"], as: "terminal" })`) and draws it (`<cosm-terminal process="claude:setup">`) |

**How a command line is run.** Its words are split at spaces (no quoting). The first word is a file of the package
(`bin/clock-server`: run as it is when executable, with its own `#!` line, else with bash) or a program on the PATH;
`${NAME}` in any word is filled in from the variables below (a name that isn't one stops it from starting). It runs in the
cosm's folder, with no JSON on stdin, and these in its environment:

| Variable | What it holds |
|---|---|
| `COSM_ROOT_DIR` | The cosm's folder, also the working folder. |
| `COSM_PACKAGE` | The package's name. A part overriding another package's runs as the overriding package. |
| `COSM_PACKAGE_DIR` | The package's folder (absolute). |
| `COSM_DATA_DIR` | The package's own lasting folder in the cosm, `.cosm/data/<package>/` (`cosm.package.folders.data` in main.ts). |
| `COSM_CACHE_DIR` | What this computer rebuilds for the cosm (`~/.cosm/local/<id>/`), outside it; use `$COSM_CACHE_DIR/<package>/`. |
| `COSM_SETTING_<NAME>` | Each of its settings: text; a switch `true` or `false`, a number as written. |
| `COSM_SECRET_<NAME>` | Each of its secrets the user has entered. Only its own. |
| `PATH` | With the engine's folder first: `cosm`, and the Bun Cosm ships (`#!/usr/bin/env bun` works). |

Names become variables by upper-casing and `-` → `_` (`crm-token` → `COSM_SECRET_CRM_TOKEN`).

### Running a program from main.ts

A tool, a handler or an item's function that needs a program of the system runs it with Bun, where it is used, as any
Bun code does: `$` for a shell line, `Bun.spawn` for more control. Code runs in the cosm's folder. Pass `cosm.signal`,
so the program stops when no one waits on it; prefer a library to a program the user would have to install (package.md).

```ts
import { $ } from "bun";

cosm.point.add("cosm:commands", {
  name: "last-commit",
  description: "The cosm's last git commit: when, and what it said.",
  run: async () => (await $`git log -1 --format=%cr:%n%s`.cwd(cosm.package.folders.cosm).quiet().text()).trim(),
});
```

```ts
// Claude Code's package runs its adapter: its folder, input on stdin, the call's signal, its own variables.
const p = Bun.spawn([`${cosm.package.folders.package}/bin/claude-agent`, mode], {
  cwd: cosm.package.folders.cosm, stdin: new TextEncoder().encode(JSON.stringify(input)), stdout: "pipe", stderr: "pipe", signal: cosm.signal,
  env: { ...process.env, COSM_PACKAGE: cosm.package.name, COSM_PACKAGE_DIR: cosm.package.folders.package, COSM_DATA_DIR: cosm.package.folders.data },
});
const [out, err, code] = await Promise.all([new Response(p.stdout).text(), new Response(p.stderr).text(), p.exited]);
if (code !== 0) throw new Error(err.trim().split("\n").pop() || `claude-agent ${mode} stopped (${code})`);
```

A program spawned from main.ts gets only what is passed to it: the `COSM_*` variables above are for the programs Cosm
starts, so hand on what it needs, as Claude Code's does. From main.ts itself, ask Cosm through the API (`cosm.file`,
`cosm.index` …); a program it starts, in any language, can run `cosm`, which is on its PATH.

## agent:agents: a package that is an agent

A package that is an agent is a connector: it adds its agent to the `agent` package's point `agent:agents`, by a name
of its choosing (several, if it runs several). It only prepares its agent's program for a conversation (its setup from
what every agent gets, in its agent's shape), starts it as one of its own processes, says which of its programs runs
(`running`) and stops it. The program stays the connector's process: its variables, its log (what it says on stderr),
its life with the package (switched off, its programs end). Agent session, the broker, does the rest: it speaks ACP
with a chat's program itself (below, chat: ACP), and types into a terminal what is sent there. A connector keeps no
list of conversations, fires no events of its own about them and maps no ids: Agent session calls it by the
conversation's id (`session`), gives it the agent's own id to carry one on (`resume`), and learns the agent's id from
ACP (`session/new`); when the agent changes it where Agent session can't see it (a fresh start in its terminal,
told by its hooks), the connector says so: `cosm.call("agent-session:agent-id", { session, id })`. Every other
package reaches it through Agent session (above).

```ts
const me = cosm.package.name;
async function running({ session }: { session: string }) {
  const on = (await cosm.process.list({ package: me })).some((p) => p.name === `${me}:chat-${session}` && p.running);
  return on ? { as: "chat" as const, process: `${me}:chat-${session}` } : null;
}
cosm.point.add("agent:agents", {
  name: "my-agent",              // its name, the package's choice
  label: "My agent",
  prompt: "/cosm:{name}",        // how one of the agent's prompts is typed to it
  start: async ({ session }) => {
    if (!(await running({ session }))) await cosm.process.start(`chat-${session}`, { program: "bin/chat" });
    return { process: `${me}:chat-${session}` };   // its chat speaks ACP: Agent session takes it from here
  },
  running,                       // which of its programs runs: it knows its own processes
  stop: ({ session }) => cosm.process.stop(`chat-${session}`),
});
```

| Key | Meaning |
|---|---|
| `name` | Its name, the package's choice (usually the package's own). A package may add several. |
| `label` | The agent's name, in Settings → General → Defaults and the session's header. |
| `prompt` | How one of the agent's prompts is typed to it, `{name}` its name (`"/cosm:{name}"`; `"/{name}"` when not given). |
| `hooks` | `true` when the agent's own hooks tell its moments (below, What happens in a session). |
| `start` | `({ session, as, resume?, first? }) => { process, mcp?, rules?, agentSession? }`: prepares and starts the conversation's program, or finds it running, and answers its process's full name: as a chat (`as: "chat"`, a `lines` program speaking ACP) or in a terminal (`as: "terminal"`, a process `terminal-<session>` drawn as one, opening with `first`). One program a conversation: starting one stops the other. `resume`: the agent's own id, to carry the conversation on. For a chat: `mcp`, the MCP servers its ACP session gets (the `agent` package's `share` gives them: all, some, or none when not given); `rules`, Cosm's instructions to go with a new conversation's first message, for an agent that takes none as it starts (Gemini CLI's). `agentSession`: the agent's own id when the connector chose it (Claude Code in its terminal). |
| `running` | `({ session }) => { as, process } \| null`: which of the conversation's programs runs now (`as: "chat"` or `"terminal"`, `process` its full name `<package>:<name>`), from its own processes (`cosm.process.list`). Agent session asks it before every message and start: a conversation running in its terminal is typed into there (the words, then Enter), and Agent terminal draws the process it names. |
| `stop` | Ends its program, chat or terminal. |
| `sessions` | `({ sessions }) => […]`: what the agent knows of those sessions, by its own ids (below). |
| `servers` | `() => [Server…]`: the MCP servers the agent has from its own setup (added with its own commands, kept in its own files), in `share`'s `mcp` shape, so packages can reach them too. |

Every connector's chat program speaks ACP: an agent that doesn't gets a small adapter program of its connector's that
does (as Claude's, `package-src/claude`). Agent session reads the program's output from its stream (the engine keeps a
`lines` program's stdout as a stream of its package's, named as the process, from its first byte: package.md, Long-running
programs), one ACP connection a conversation, so two conversations on one connector never share request ids or state.
It doesn't pretend a connection across a break: when items of the program's output were lost before it read them, or
its own code started again while the program ran, the turn that ran ends as interrupted, with a note, and the program
stops; the next message carries the conversation on (`session/load`, where the agent offers it). A program that ends
mid-turn ends its turn with why (`The agent stopped (exit code 7).`), and the conversation's stream closes until it
is carried on.

Its terminal, when it has one, is the connector's own: `start({as: "terminal"})` runs it as a process drawn as a
terminal, `terminal-<session>` (Agent terminal draws it), with what the agent needs in its environment.

Getting the agent ready (installing it, signing in) is its package's own: a view of its on its page in Settings
(`location: { in: "settings" }`, as tall as its page) that says how the agent stands and runs the step that would help
now, in a terminal, as one of the package's processes; when the process ends (`<cosm-terminal>`'s `ended`), it looks
again. Claude's and Gemini's `views/setup.html` do this, asking their package's `status` export:

```ts
cosm.point.add("cosm:views", { name: "setup", file: "views/setup.html", label: "Claude Code", location: { in: "settings" } });
cosm.view.export({ status: { changes: { events: ["setting.changed"] }, run: async () => (await run("ready"))[0] } });   // the view: live(cosm.main.status)
```

An agent that loads setup of its own from the cosm (Claude Code's `.claude/` and `.mcp.json`, Gemini CLI's `.gemini/`
and `.env`: hooks, MCP servers, settings it acts on) decides whether to use it on this computer: Cosm's trust covers
only the cosm's own packages. Claude's and Gemini's ask once, the first time a session starts with it there
(`cosm.ui.ask`), keep the answer in their cache (this computer's, for the cosm) and show it on their setup view to
change.

A sign-in of the cosm's own goes in the package's data folder. `agent:agents` is a point used one at a time: the user's
default is the agent a new session starts with (Settings → General → Defaults, or `cosm setting default agent:agents <package>`); with
several and none set, Cosm asks the user once, the first time a session starts. The others stay usable: Session → New
Session With starts one with another agent.

### sessions

`sessions` is given `{ sessions: [ids] }`, the agent's own ids (Agent session keeps them), and returns a list, one
object per session it knows:
`{ id, begun, title, tokens, size, model, transcript }`. `begun`: whether the agent has anything for it yet. `title`:
what it was about (the session list). `tokens` of `size`, `model`: how full its context is, of how much, on which model
(the gauge, until a turn's end says it: Agent session keeps `used` and `size` from the agent's usage at each turn's end).
`transcript`: its file.

### What every agent gets, in its shape

`await cosm.call<Share>("agent:share")`, the `agent` package's export, reads its points and Cosm's tools into one object, `{ instructions,
prompts, skills, tools, mcp, secrets }`: the instructions in order with their text (Cosm's, then each package's
`agent/instructions.md`), each prompt (the name it is reached by, and its file) and skill (its folder), each tool with
its `step`, the MCP servers ready to start (`cosm` first), and the secrets packages give the agent
(`COSM_SECRET_<NAME>`, read with `cosm.secret.get(name, { package })`). Each is a point read as any other
(`cosm.point.read("agent:skills")`): `share` puts them together, starts nothing, and works out each server's program by
its full path with what its package's programs get (`cosm.package.program`). Its types come with it: `import type { Agent, Share } from "package:agent"` (package.md, Points) checks a connector
(`start`, `running` and `stop` it must have) and types `Share`. Claude Code's package writes them as a folder of its own for each session (a plugin of Cosm's commands and skills, the
instructions as an appended system prompt, its MCP file) and starts Claude Code with them; Gemini CLI's gives the
instructions with a new session's first message, since it takes none as it starts.

### What happens in a session

The `agent` package owns the moments, their points and their events, whichever agent runs; Agent session tells it each
one, in Cosm's terms: `cosm.call("agent:fire", { event, data })`, `data` with its `session` (Agent session's id). The
agent package then calls the contributions to that moment's point, in package order, each `run(data)` given what
happened, and what they returned comes back, `{said}` (before a step, `{said, input}`: the step's input as they
changed it, or null), for the agent. A contribution that takes over 15 seconds is gone on without (said in the agent
package's log). Then it fires the moment as its own event, with the same data, for packages that only hear of it.
Agent session tells the moments from what a chat's program says (over ACP), and what their contributions said
goes to the agent with the next message. An agent with hooks of its own (a connector with `hooks: true`) has its
connector take them: the Claude package writes each conversation's hooks file to run `cosm claude:hook --run c-7k2p`
(the conversation it was started for) with Claude's note on stdin (a tool with a `stdin` input), which passes the moment
up for that conversation (`cosm.call("agent-session:hook", { session, event, data })`; at each start it tells the agent's
own id too, `agent-session:agent-id`) and prints the answers in Claude Code's form; with a message,
what went with it apart from the user's words comes back too. A turn the user stops runs no hook: Agent session tells
that one for every agent.

| Moment (`event`) | Its data | Point: what a contribution's `run` returns | Event |
|---|---|---|---|
| `started` | `{session, reason: startup \| resume \| compact \| clear}` | `agent:start`: text for the agent; `{send: message}` is sent first | `agent:started` |
| `message.sent` | `{session, message, text, prompt?}` (`message`: its id; `prompt`: one of the agent's prompts, by name) | `agent:message`: text added to the message | `agent:message.sent` |
| `file.read` | `{session, path}` | — | `agent:file.read` |
| `step.before` | from hooks (Claude Code): `{session, step, input, uses: {commands, paths}}`; from a chat: `{session, step, file?}` (`step` the tool's name or kind; `file` the path it acts on) | `agent:step`: text for the agent, or `{input}` (the step's input changed, the next one gets it: hooks only) | `agent:step.before` |
| `step.failed` | from hooks: `{session, step, input: null, error, uses}`; from a chat: `{session, step, text}` (`text` what the step said) | `agent:failed`: text for the agent | `agent:step.failed` |
| `turn.ended` | from hooks: `{session, stopped: false, transcript}`; from a chat, and a turn the user stopped: `{session, text, stopped, used?, size?}` (how full, when the agent said) | — | `agent:turn.ended` |

```ts
// Text for the agent as each session starts (wrap it in a tag of its own), and a counter that only hears turns end.
cosm.point.add("agent:start", { name: "tally", run: async ({ session }) => `<tally>3 open tasks</tally>` });
cosm.on("agent:turn.ended", async ({ session, stopped }) => { /* … */ });
```

### chat: ACP

ACP v1 (agentclientprotocol.com): JSON-RPC, one message a line on stdin and stdout. Agent session is the client
(above), through the official ACP library; Agent chat's view follows the conversation's stream its package hands it.
What follows is what that client does, the one every agent's package is tried with; any ACP agent works as it is. It asks `initialize`
(offering form elicitation), then `session/new`, or `session/load` to carry a session on when the agent offers
`loadSession`; both carry `mcpServers`. It sends `session/prompt` with text and images, `session/cancel`, and
`session/set_config_option` for options of category `model` and `thought_level`. It shows `agent_message_chunk` (a new
`messageId` starts a new reply), `user_message_chunk`, `tool_call` and `tool_call_update` (title, kind, `locations`,
`content`), `available_commands_update` (the "/" menu), `config_option_update` and `usage_update` (the gauge). It
answers `session/request_permission` (Allow, Allow for this session, Deny) and `elicitation/create` in form mode. Two
additions under `_meta.cosm`, both optional: `refused` on a failed `tool_call_update` (a step refused for want of the
user's OK) and `covers` on an allow-always option (what it allows). The id `session/new` returns is the agent's own,
which Agent session keeps and gives back to load the session later.

An agent that runs commands in a sandbox must let them reach Cosm's engine: `cosm` talks to it over a Unix socket in
`~/.cosm/run/`. An agent's package that turns on such a sandbox allows that folder in it.

## Complete examples

The built-in connectors are full, real ones: `claude` (its own ACP adapter around the unmodified agent, its hooks; `sessions`,
its setup view with its install and sign-in steps, asking about the cosm's own `.claude/`), `gemini` (an agent that speaks ACP itself) and `stand-in` (a pretend
one with canned answers, which asks permission and questions too). Read them with `cosm package list` (their folders).

### The smallest agent: Echo

`examples/echo-agent/`: it answers with what it was told, over ACP. Its `cosm.json` says who it is; its `main.ts` starts
its program for a conversation and says which process it is; Agent session speaks ACP with it:

<!-- example: echo-agent/main.ts -->
```ts
// Echo: a package that is an agent, a connector. Its agent is a program of the package (bin/chat.pl) that speaks ACP:
// each conversation runs it as one of the package's processes, and Agent session speaks the protocol with it (it
// writes to the program and reads its output's stream). It has no terminal of its own, so the chat is how it shows.
import type { Cosm } from "cosm";
import type {} from "package:agent";   // the agent package's types: what a connector must have is checked

export default function (cosm: Cosm) {
  const me = cosm.package.name;
  /** Whether the conversation's chat runs: its process, which this package knows. */
  const running = async ({ session }: { session: string }) =>
    (await cosm.process.list({ package: me })).some((p) => p.name === `${me}:chat-${session}` && p.running) ? { as: "chat" as const, process: `${me}:chat-${session}` } : null;
  cosm.point.add("agent:agents", { name: "echo-agent", label: "Echo", prompt: "/{name}",
    start: async ({ session, as }) => {
      if (as === "terminal") throw new Error("Echo has no terminal of its own: its chat is how it shows");
      if (!(await running({ session }))) await cosm.process.start(`chat-${session}`, { program: "bin/chat.pl" });
      return { process: `${me}:chat-${session}` };
    },
    running,
    stop: ({ session }) => cosm.process.stop(`chat-${session}`),
  });
}
```

and `bin/chat.pl` (executable) handles `initialize`, `session/new` and `session/prompt`, and sends a step and a reply
as `session/update`s. The chat can be any language; in TypeScript, a file starting `#!/usr/bin/env bun` reads its lines
with `for await (const line of console)` and writes each message as `JSON.stringify(…) + "\n"`.

### A tool and an MCP server: World clock

World clock gives the agent the time anywhere: a tool giving the user's zones, an MCP server of its own, and Claude
Code allowed to use the server's tool without asking. `cosm.json` as Echo's, with its own name, label and description;
`main.ts`:

<!-- example: world-clock/main.ts -->
```ts
import type { Cosm } from "cosm";
import { shape } from "cosm/shape";

/** The time now in a time zone, as "Friday 14:05". Throws on a zone that isn't one. */
export function timeIn(zone: string): string {
  return new Intl.DateTimeFormat("en-GB", { timeZone: zone, weekday: "long", hour: "2-digit", minute: "2-digit" }).format(new Date());
}

export default function (cosm: Cosm) {
  cosm.point.add("cosm:settings", { name: "zones", shape: shape.string(), default: "Europe/Stockholm America/New_York", label: "Time zones", description: "The zones World clock shows, separated by spaces." });

  // A tool: `cosm world-clock:clocks` in the agent's shell (and an MCP tool where the agent's package offers tools).
  cosm.point.add("cosm:commands", { name: "clocks",
    description: "The time now in each of the user's time zones, one a line.",
    run: async () => {
      const zones = ((await cosm.setting.get<string>("zones")) ?? "").split(/\s+/).filter(Boolean);
      return zones.map((z) => `${z}  ${timeIn(z)}`);
    },
  });

  // An MCP server of its own, always handed to the agent: bin/clock-server, speaking MCP on stdin and stdout.
  cosm.point.add("agent:mcp", { name: "clock", program: "bin/clock-server" });
  // Claude Code may use its MCP tool without asking.
  cosm.point.add("claude:config", { name: "clock", allow: ["mcp__clock__time_in"] });
}
```

`bin/clock-server` (executable):

<!-- example: world-clock/bin/clock-server -->
```ts
#!/usr/bin/env bun
// World clock's MCP server: JSON-RPC 2.0 on stdin and stdout, one message a line, with one tool, the time in a zone.
import { timeIn } from "../main.ts";

const tool = { name: "time_in", description: "The time now in a time zone, as Europe/Stockholm or America/New_York.",
  inputSchema: { type: "object", properties: { zone: { type: "string", description: "An IANA time zone" } }, required: ["zone"] } };
const send = (m: object) => process.stdout.write(JSON.stringify({ jsonrpc: "2.0", ...m }) + "\n");

for await (const line of console) {
  let m: any;
  try { m = JSON.parse(line); } catch { continue; }
  if (m.id === undefined) continue; // a notification: nothing to answer
  if (m.method === "initialize") send({ id: m.id, result: { protocolVersion: m.params?.protocolVersion ?? "2025-06-18", capabilities: { tools: {} }, serverInfo: { name: "world-clock", version: "1.0.0" } } });
  else if (m.method === "tools/list") send({ id: m.id, result: { tools: [tool] } });
  else if (m.method === "tools/call") {
    const zone = String(m.params?.arguments?.zone ?? "");
    let text: string, isError = false;
    try { text = timeIn(zone); } catch { text = `No time zone called ${zone}`; isError = true; }
    send({ id: m.id, result: { content: [{ type: "text", text }], isError } });
  } else send({ id: m.id, error: { code: -32601, message: `no method ${m.method}` } });
}
```

Trying it:

```sh
printf '%s\n' '{"jsonrpc":"2.0","id":1,"method":"tools/list"}' | .cosm/packages/world-clock/bin/clock-server
cosm package check world-clock
cosm package on world-clock          # after the user's y; the server reaches the agent from the next session
cosm world-clock:clocks              # Europe/Stockholm  Friday 23:12 …
```

### A remote MCP server with a token: CRM

"Let the agent use our CRM": the CRM's own MCP server, reached over the web with the user's token, kept as a secret the
user pastes into Cosm's window, never into the chat. `main.ts`:

<!-- example: crm/main.ts -->
```ts
import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:secrets", { name: "crm-token", label: "CRM token", description: "From the CRM's settings, under API." });
  cosm.point.add("agent:mcp", { name: "crm", url: "https://mcp.example-crm.com/mcp", headers: { Authorization: "Bearer ${COSM_SECRET_CRM_TOKEN}" } });
}
```

The `${…}` is Cosm's, filled in when the agent starts, so it is written in a plain string, not a template literal.

The user gives a secret in the package's Settings. When the agent has built such a package and needs the token now,
it asks for it in the window instead of the chat: `cosm ui ask "Paste your CRM token (CRM settings → API)" --secret
crm:crm-token`. The user types it in a hidden field, the window keeps it as the package's secret, and the command
prints only `given` (or exits 1 when the user cancels): the value never reaches the agent or its transcript.

## Outside MCP servers, for packages

The agent reaches MCP servers in its chat; a package's view or button reaches the same ones through the built-in MCP
client package (off until switched on: `cosm package on mcp-client`): every server Cosm gives the agent (`agent:mcp`), every one the
agent has from its own setup (its connector's `servers`: Claude Code's `claude mcp add`, its `.mcp.json`; Gemini CLI's
settings), and any a package adds to `mcp-client:servers`, a program on this Mac speaking MCP on stdin and stdout, or an
address:

```ts
cosm.point.add("mcp-client:servers", { name: "deepwiki", label: "DeepWiki", url: "https://mcp.deepwiki.com/mcp" });
cosm.point.add("mcp-client:servers", { name: "notes", program: "/usr/local/bin/notes-mcp", args: ["--stdio"] });
// In its code (or a view's function): the tool's answer as the server gives it.
const r = await cosm.call("mcp-client:call", { server: "deepwiki", tool: "read_wiki_structure", args: { repoName: "oven-sh/bun" } });
```

`cosm mcp-client:servers`, `cosm mcp-client:tools <server>` and `cosm mcp-client:call <server> <tool> '<json>'` do the same from the shell.
An answer is `{content, structuredContent?, isError?}`: many servers answer text written for a model (DeepWiki's is
markdown), so a view showing it draws text, or asks the agent; data comes only as a server's `structuredContent`. A
server over an address that wants the user's sign-in (the MCP spec's OAuth: Notion's, Linear's) is signed in to on its
first use through the user's default sign-in (`cosm-points:sign-in`, OAuth's): the user is asked once, their browser
opens the server's own page, and the token is kept and renewed; nothing is set up first. `cosm oauth:signed-in` lists
it and `cosm oauth:sign-out <label>` forgets it. A server that lets no app register itself (GitHub's) isn't reached.
