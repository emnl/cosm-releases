# Files, kinds and the index

The user asks about what the cosm holds and how Cosm treats it: "open my images in Cosm and let search find them",
"keep the session logs out of search", "show meeting notes as a board", "make the attendees of a meeting askable",
"search should find *budgets* when I type *budget*". Each is a **kind**, a kind extending another, or how the
**index** is built. A package reads and writes the cosm's files through **`cosm.file`**, and keeps small state of its
own in **`cosm.storage`**.

All of it is registered in `main.ts` (package.md). The calls are in `cosm.d.ts`; reference.md lists every one.

## The cosm's files: `cosm.file`

A package reads and changes the user's files through `cosm.file`, in `main.ts` (a view asks its main.ts, views.md; it
has a handle only on the file it shows). Paths are relative
to the cosm's folder (`spaces/Home.md`). Going through Cosm is what asks the before-events (a package can refuse
or change a save, a move, a trash: events.md), tells the others what changed, and keeps an open file's typing safe.
`node:fs` is for the package's own folders (`cosm.package.folders.data` and `.cache`, package.md), never the cosm's
files.

| Call | What it does |
|---|---|
| `read(path)`, `read(path, {bytes: true})` | The file's text, or its bytes. Throws when it isn't there. |
| `write(path, content)` | Writes a file whole (text or `Uint8Array`): a new file, or a deliberate replace. |
| `append(path, text)` | Adds text to the end (makes the file when it isn't there), without losing anything written meanwhile. |
| `change(path, fn)` | Changes a file: `fn` gets its text now and gives the new text. Written only while the file is still that text; when it changed meanwhile (the user typed in it), `fn` runs again on the newest. |
| `name(path)` | The file's name as Cosm shows it: without its ending when a kind claims it (`Plan` for `Plan.md`), else whole. |
| `list(glob)` | The paths a glob matches, read as a kind's `match` is (hidden files left out). |
| `tree({skip?})` | The cosm's folders and files: each `{name, path, folder, modified, children, kind?, view?}`; `skip`, globs of what to leave out. |
| `stat(path)` | `{kind, name, modified, size, folder}`, or `null` when it isn't there. `modified` is seconds since 1970. |
| `move(from, to)` | Moves or renames a file or folder: `to` a new name (it stays in its folder), a path (`notes/x.md`), `./<name>` for the cosm's top, or a folder ending in `/` (its name kept); a page in a folder of its own name takes the folder along. Packages that handle `file.moved` fix what pointed at it (Markdown fixes `[[links]]`), just after it returns. |
| `trash(path)` | Moves it to the cosm's trash, where it can be put back. |
| `which(name, {kind?, from?})` | The file a name means (as Cosm shows names), the nearest to `from`; `null` when none. |

To change a file that may be open in the window, use `change`, never `read` then `write`: `write` replaces what the
user typed meanwhile. Markdown keeps links right after a move this way:

```ts
cosm.on("file.moved", async ({ moves }) => {
  const pairs = moves.map((m) => [name(m.from), name(m.to)] as const).filter(([o, n]) => o !== n);
  if (!pairs.length) return;
  const rename = (text: string) => pairs.reduce((t, [o, n]) => renamed(t, o, n), text);
  for (const p of await cosm.file.list("**/*.md")) {
    const text = await cosm.file.read(p);
    if (rename(text) !== text) await cosm.file.change(p, rename);
  }
});
```

A view also has `cosm.file.open(path)`: a handle for an editor, saved on top of the version read and merged by the
file's kind (views.md).

A glob for `list`, and for `tree`'s `skip` (`cosm.file.tree({ skip: ["*.tmp", "drafts"] })`: what it matches is left
out, a folder with all it holds), reads as a kind's `match` does, in main.ts, a view and the shell (`cosm file list`) alike: a name
alone matches in any folder (`"*.pdf"`), `/` first keeps to the cosm's top (`"/profile.md"`), `**` crosses folders
(`"meetings/**/*.md"`), `{a,b}` is either.

From the shell: `cosm file tree [--skip <glob>]… [--hidden]`, `cosm file stat <path>`, `cosm file which <name> [--kind <kind>] [--from <path>]`,
`cosm file move <path> <to>`, `cosm file trash <path>`.

## Connected folders: `cosm.root`

A cosm can reach folders outside it (a shared Drive folder, ~/Documents/Company): the user's connected folders, the
engine's roots. Each has an id made from its name that never changes, and a file in one is `@<id>/<path>`
(`@company/Board/plan.md`), taken wherever a path is: `cosm.file.read`, `write`, `change`, `stat`, `list`,
`cosm.ui.open`, a view's `cosm.file.open`. They are reached on demand and never absorbed: not in the index or search,
not in `cosm.file.tree`. `cosm.file.move` works there and between the cosm and a connected folder (renamed where it
can be, else copied and the original removed once the copy is whole); `cosm.file.trash` there uses the Mac's trash (a
cloud drive's own trash), not the cosm's.

- `cosm.root.list()`: `[{id, name, path, reachable}]`, `path` where it is on this computer (null: not located here).
- `cosm.root.add(path, { name })`, `remove(id)` (never its files), `locate(id, path)`: refused when a folder overlaps
  the cosm or another (one file, one name). The engine tells `root.changed` after each.
- `cosm.root.path("@company/x.md")`: its place on this computer, for code that isn't Cosm's (`node:fs`, a program).
- `cosm.root.watch("@company/Board")`: one level watched while a view shows it (answers how to stop); a change there
  reaches views whose `changes: { files: "@company/Board/*" }` matches.

**Hearing a connected folder:** a package hears one only by asking, with `files` on a file event's handler:
`cosm.on("file.created", file, { files: "@scans/*.pdf" })` (one level; `**` for all under the folder). The engine
then watches there while the package is on, asleep or not, and wakes it for `file.created`, `file.saved`,
`file.removed` and `file.moved` (a rename within what it watches; a deep watch tells a rename as removed and created).
A handler without `files` never hears a connected folder, so nothing written for the cosm reacts to a shared drive.
Events tell only what happens while Cosm runs: a package that must not miss anything looks at what is there when it
starts. A deep watch on a large or busy shared folder wakes the package often.

Kinds match the written form: `**/*.md` reaches every connected folder, `meetings/*.md` stays in the cosm,
`@company/Board/*.md` names one folder (`@*/Board/*.md`, any).

## The trash: `cosm.trash`

`cosm.file.trash(path)` moves a file or folder to the cosm's trash (`.cosm/trash/`, in Cosm's own folder), noting where it came from.
`cosm.trash` reads it and puts things back, as File tree's Trash view does:

| Call | What it does |
|---|---|
| `list()` | Newest first: `{name, from, folder, modified}` each: its name in the trash, where it came from (`null`: unknown), whether it is a folder, when it went. |
| `restore(name)` | Puts it back where it came from; answers its path now. |

```ts
const items = await cosm.trash.list();
const to = await cosm.trash.restore(items[0].name);
```

A trash is told to packages as `file.trashed` (`{paths}`), and can be refused first with `file.trashed.before`
(events.md).

## Storage: `cosm.storage`

Small things a package keeps between runs (a filter, a counter, which tab was open), by key, as JSON values. They are
kept in the cosm (`.cosm/data/<package>/storage/`, a file a key, so two computers changing different keys don't clash),
so they last and sync with it. `cosm.storage.update(key, fn)` works out the new value from the one kept and writes it
only if nothing changed it meanwhile (else `fn` runs again): two writers never lose each other's change. The same key
changed on two computers while apart still clashes in a sync service. Larger things go in files of the
package's own data folder (`cosm.package.folders.data`, package.md).

| Call | What it does |
|---|---|
| `get(key)` | Its value, or `null`. |
| `set(key, value)` | Keeps a value. |
| `update(key, fn)` | The value `fn` works out from the one kept (`fn` synchronous, only computing), written only while nothing changed it meanwhile: else read again and `fn` run again, a few times, then a conflict error. Answers what it wrote. The shell's `cosm storage get <key> --token` and `cosm storage set <key> <value> --if <token>` do the same. |
| `delete(key)` | Takes a key away. |
| `list()` | The keys. |

What belongs to one conversation with the agent goes in that conversation's storage, Agent session's:
`agent-session:storage-get`, `storage-set` and `storage-delete`, each with the conversation's id (`c-7k2p`) and a key.
Each package has its own keys there, and they go when the conversation leaves the list, so nothing needs clearing.
A change fires `agent-session:storage.changed` (`{session, package, key}`), for a view that shows what is kept.
Search hints remembers what it already hinted at in each conversation; Star chart, whether Reflect ran in it:

```ts
const seen = async (session: string) => new Set(((await cosm.call("agent-session:storage-get", { session, key: "seen" })) as string[] | null) ?? []);
await cosm.call("agent-session:storage-set", { session, key: "seen", value: [...shown] });
```

A view keeps its own state the same way: Agent session's holder keeps which view it shows with
`cosm.storage.set("shown", …)`.

From the shell: `cosm storage get|set|delete|list <key> [--package <package>]`.

## Kinds

A kind is a sort of thing the cosm holds: Markdown's pages, Tables' tables, images. It says which things are of it
(files it matches, or items a function lists) and how Cosm treats them: the view they open in, how two versions merge,
what search reads of them, their facts. Search, and what goes to the agent with a message, cover only what kinds have:
the **index** holds every thing a kind has, its text and its facts, rebuilt from the cosm (deleting it loses
nothing). A file no kind has still shows in the left pane and opens as a card, with Open in the system's app for it.

`cosm.point.add("cosm:kinds", {name, …})` adds one. Markdown's page:

```ts
cosm.point.add("cosm:kinds", { name: "page", match: "**/*.md", label: "Note", view: "page", merge: ({ base, mine, theirs }) => merge3(base, mine, theirs) });
```

Another package names it `<package>:<name>` (`markdown:page`); in the package's own calls the bare name is enough
(`view: "page"`, `{ kind: "page" }`).

| Field | Meaning |
|---|---|
| `match` | The files it has: a glob, or a list of globs (Globs, below). Nothing in a hidden folder is matched. |
| `items` | Or its things aren't files: a function listing them (Items, below). A kind has `match` or `items`, not both. |
| `watch` | With `items`: a file (usually under `.cosm/`) whose change lists the items again. |
| `extends` | Another package's kind it narrows: `markdown:page` (Extending, below). Without `match`, it covers all of that kind's things. |
| `view` | The view its things open in: one of the package's views taking a file or a thing (views.md), or another's as `package:view`. |
| `template` | A new file's starting text, when this kind is made (⌘N, a `{new: {kind}}` action, views.md), read from a file of the package (`await cosm.package.file.read("templates/article.md")`). `{name}`, `{date}` and `{time}` are filled in. To change another package's, a kind that extends it with a `template` of its own. |
| `label` | The kind's name as the user reads it ("Note": File → New reads "New Note"). On a kind whose `match` names one file (no wildcard), that file's name as shown ("Profile" for `/profile.md`). |
| `merge` | How a file of it merges when it changed on disk while open: a function given `{base, mine, theirs}` that answers the merged text, or `null` when it can't; or `"lines"`, Cosm's merge by lines. Without one, or on `null`, nothing is written and the user chooses (Keep mine, Keep theirs, Compare). |
| `search` | `false` keeps its things out of ordinary search (⌘K's passages, what Search hints brings with a message). They are still indexed, found with `--kind` and `--in`, and their facts are in the graph. |

What search reads of a kind's things and their facts are part of it: its `text` and `facts` (The index, below), on
the package's own kinds.

Kinds take effect at once for the window and from the next message for search, while their package is on.
`cosm package check` says how many files each kind has here.

### Items: things that are no files

A kind with `items` lists things that aren't files: Tables' tables, rows a program keeps elsewhere. The function
answers one object per item: `key` (stable), `name`, `lead` (its first line) and `text` (what search reads). Each item
is known everywhere as `<package>:<kind>:<key>` (`tables:table:expenses`): in search hits, facts, `cosm.ui.open`, a
view's argument (a view with `input: "thing"`, views.md).

```ts
cosm.point.add("cosm:views", { name: "table", file: "views/table.html", label: "Table", icon: "table", input: "thing" });
cosm.point.add("cosm:kinds", { name: "table", label: "Table", view: "table", watch: ".cosm/data/tables/tables.db", items: () => {
  const db = reading();
  if (!db) return [];
  return names(db).map((t) => ({ key: t, name: t, lead: describe(db, t), text: docsOf(db, t) }));
} });
```

Items are listed once the package is on, again when the `watch` file changes, and when `cosm index refresh <kind>` is
run (for items that change outside the cosm). A view showing them redraws on its own. Items are changed by their
package's own tools, not through `cosm.file`.

### A thing's kinds, and which wins

A thing is first of the kind that claims it (one kind of its own per thing; two packages' kinds claiming one file are
a tie the user settles, below). Then it is also of every kind **extending** that one which takes it: one whose `match`
takes it, and every one without `match`. The thing's `kind` (what `cosm file stat` and the tree give) is the narrowest
of them that has a `match`.

Each key with one value (`view`, `merge`, `template`, `index.text`, `index.search`) comes from one kind. Cosm picks it
in this order:

1. **The user's association** wins over every kind: "Open With … Always" in the window, or `cosm setting associate`
   on the user's word (below).
2. **The most specific kind.** A kind extending another with a `match` is narrower than the one it extends. Between
   two packages' kinds that both take the thing, the narrower `match` wins, by its glob: compared folder by folder
   from the left, a folder written out beats a pattern (`*.md`), which beats `*`, which beats `**`
   (`spaces/acme/*.md` beats `spaces/**/*.md`); a glob naming one file beats every pattern. A kind without `match` is
   never narrower than the kind it extends: it ties with it on every key both set.
3. **Within one package, the later kind.**
4. **Between packages, the user's ranking.** Two packages' kinds of equal weight giving different values are a tie:
   the user's answer (`cosm setting prefer <key> <package>`) settles it, kept for this cosm; until then the earlier
   package in Cosm's order gives it. Two giving the same value are no tie.

`index.facts` doesn't pick one: every kind of the thing that has facts adds them.

`cosm kind explain <path>` (or `<package>:<kind>:<key>` for an item) shows, for one thing, its kinds and every key
with the kind it came from, why it won, and what lost. The first thing to run when a file opens in the wrong view,
isn't found, or goes to the agent when it shouldn't:

```
$ cosm kind explain "meetings/2026-10-27 Board.md"
meetings/2026-10-27 Board.md
  kind: boards:meeting (is also markdown:page, meetings:meeting)
  view: boards:board  from boards:meeting (the narrowest kind)
      lost: markdown:page from markdown:page (to a narrower kind)
  merge: a function  from markdown:page
  index.text: a function  from markdown:page
  index.search: true  (the default)
  index.facts: a function  from markdown:page
  index.facts: a function  from meetings:meeting
```

`cosm kind list` lists every kind that is on, with what it extends, its match or items, and its view. `cosm package
ties` lists each tie and who gives it now.

### Changing how another package's things are treated: extends

To give some of another package's things a different view, keep them out of search or add facts, don't register a
kind that matches them (a second kind claiming the same files is a tie): **extend** that package's kind, narrowed by
`match`, and set only what changes. Everything else stays the other package's.

```ts
cosm.point.add("cosm:kinds", { name: "log", extends: "markdown:page", match: "**/* Log – *.md", label: "Session log", search: false });
```

A log stays a Markdown page (its editor, its merge, its links) and is kept out of ordinary search. Star chart's
profile, logs, preferences and fixes are all kinds extending `markdown:page` this way. Cosm sees from the `extends`
that the package uses Markdown, and won't switch it on while Markdown is off.

Without `match`, an extending kind covers every one of the other's things and ties with it on each key both set: a
package giving every page an editor of its own (`cosm.point.add("cosm:kinds", { name: "page", extends: "markdown:page", view: "editor" })`)
ties with Markdown on `view`, and Cosm asks the user which gives pages their view (`check` shows the `!`). Say so
before switching it on; when the user's request already said ("all my pages in my editor"), run `cosm setting prefer
view <package>` once it is on. One that only adds facts ties with nothing.

To act only on one kind's files in an event, narrow the handler: `cosm.on("file.saved", fn, { kind: "page" })`. It
hears the kind's files and those of every kind extending it (events.md).

### The user's choices: Open With, associations and ties

A file's other views (those of kinds that lost) are offered in its right-click menu as "Open With …". Choosing one
shows the file in it until another file opens; "Always" keeps the choice for files like it as an **association** in
`.cosm/settings.json`. When the user asks the agent for one ("always open my meeting notes in Markdown's editor"), set
it, and say what it changed:

```
$ cosm setting associate view "meetings/*.md" markdown
OK: meetings/*.md takes its view from markdown
$ cosm setting associate view "meetings/*.md" default
OK: meetings/*.md takes its view as the kinds say again
```

An association names a key (`view`, `merge`, `template`, `index.text`, `index.search`), a glob and a package, and goes
before every kind. It refuses one that would do nothing, saying why. **A tie's answer** is `cosm setting prefer <key>
<package>` (or `kind <package>` for two kinds claiming one file): the package goes first for that key, in every tie it
is in. Only on the user's word: never settle a tie a package the agent just built makes, unless the user asked for
that; say before switching it on that Cosm will ask.

## Globs

One set of rules wherever Cosm reads a glob: a kind's `match`, `cosm:skip`, associations, `cosm.index.search`'s
`in`, `cosm index search --in`.

- A glob is matched against the path from the cosm's root (`knowledge/people/Anna Berg.md`).
- `*` stays within one folder; `**` crosses folders, and matches no folder too (`**/*.md` takes `Plan.md` at the top);
  `{a,b}` is either.
- A glob without `/` matches the file's name in any folder: `"*.pdf"` is every PDF, `"profile.md"` every file of that
  name.
- A glob starting with `/` is anchored to the root: `"/profile.md"` is only the one at the top. With a `/` elsewhere it
  is already matched from the root: `"/archive/**"` and `"archive/**"` are the same.
- Case counts: `"**/*.{png,PNG}"`.
- A folder and everything in it: `"meetings/**"`; only the files directly in it: `"meetings/*"`. A folder's name alone
  (`"meetings"`) matches only files called that.
- Letters compare in their composed Unicode form, on the glob and the path alike: `"Möten/*.md"` matches the folder
  however the system stored its name.
- A `match` that names one file (no `*`, `?`, `{` or `[`) is that file: brackets in a name are taken as written.

## The index

The index holds every thing a kind has: its name, its first line (the lead), its text, and its facts. The engine keeps
it current: it watches the cosm, and every `cosm index` command first takes in every change up to that moment
(`cosm index sync` does only that).

### Building it: a kind's `text` and `facts`, `cosm:stems`, `cosm:skip`

**A kind's `text`**: what search reads of its things. `"file"` is the file's own text
(the default for a file of text), `"name"` only its name (for a file that isn't text), or a function given `{things}`
(paths, or item ids) that answers `{thing, name?, lead?, text}` for each, `thing` exactly as given. Star chart reads a
log's Summary as its lead through Markdown's tool:

```ts
cosm.point.add("cosm:kinds", { name: "log", extends: "markdown:page", match: "**/* Log – *.md", text: ({ things }) =>
  cosm.call<{ thing: string; name: string; lead: string; text: string }[]>("markdown:mdText", { things, "lead-section": "Summary" }) });
```

The function runs for every thing at first, then for new and changed ones. Keep what is slow to extract in the
package's cache (`cosm.package.folders.cache`), by path and modified time.

**A kind's `facts`**: what is known of each thing, as a graph. The function is given `{things}`, the new
or changed ones, and answers `{<thing>: {<relation>: <value or list of values>}}`. A value is a text, a number, `true`
or `false`, a link to another thing (`{to: "Anna Berg"}`, by its path or its name as written; it is found by name), or
a date (`{date: "2026-11-01"}`). Every package's facts for the same thing are combined. Markdown gives each page's
`[[links]]`:

```ts
cosm.point.add("cosm:kinds", { name: "page", match: "**/*.md", view: "page", facts: async ({ things }) => Object.fromEntries(await Promise.all(
  things.map(async (t) => [t, { links: links(await read(t)).map((to) => ({ to })) }] as const))) });
```

**`cosm:stems`** (`{ name, stems, compounds? }`): a word's forms, so *budgets* finds *budget*. `stems` is given `{words}` (many
at once, while indexing) and answers one form per word, in order: its stem, or `""` for a glue word ("and", "the").
`compounds: true` finds words inside longer ones (*tillskott* in *aktieägartillskott*). Advanced search (built in) gives
both, in the cosm's languages; a package rarely needs its own. One is used at a time: with two, the user picks in
Settings → General.

**`cosm:skip`** (`{ name, globs }`): globs never indexed: no text, no facts, never found, not even with `in`, never sent to
the agent. Star chart skips `knowledge/skills/**`. To keep things out of ordinary search but findable, a kind's
`search: false`.

### Asking it

The calls, in `main.ts`:

| Call | What it gives |
|---|---|
| `search(words, {kind?, in?, passages?})` | What matches, best first: `{thing, lead?, passage?}` each. `kind` one kind's things, `in` those in files a glob matches (any of them): both find what ordinary search leaves out. `passages: true` adds the passage that matched. |
| `find(conditions)` | The things meeting every condition on their facts: `["status=open", "due<2026-11-01", "kind=markdown:page"]`. Each `{thing, name, kind, lead?, modified}`. |
| `query(sql)` | One read-only SQL statement over the tables `things` (thing, kind, name, modified, lead) and `facts` (thing, rel, type, node, target, value, source): its rows, each an object by column. |
| `retrieve(words, {kind?, in?})` | The candidates and their numbers, for a package that ranks them itself: `{total, words: [{word, form, count}], things: [{thing, name, lead, kind, words, inName, bm25, named}]}`. `search` is the same, ranked by Cosm. |
| `analyze(text)` | The text's words as the index makes them out, each `{word, form}` (`form` `""` for a glue word), in the order they first come. |

A condition is `rel` (has the fact), `rel=x`, `rel!=x`, `rel<x`, `rel<=x`, `rel>x`, `rel>=x`, or `kind=<kind>`,
`folder=<folder>`. A link compares by the name or path it found (`links=Plan` and `links=Plan.md` both).

Star chart searches its logs, which it keeps out of ordinary search:

```ts
cosm.point.add("cosm:commands", { name: "search-logs", description: "Searches the session logs (kept out of ordinary search).",
  inputs: [{ name: "words", label: "Words to search for", type: "list" }],
  run: async ({ words }) => (await cosm.index.search(words.join(" "), { kind: "star-chart:log" })).map((h) => `${h.thing}${h.lead ? ` — ${h.lead}` : ""}`) });
```

### From the shell

| Command | What it does |
|---|---|
| `cosm index search [--kind <kind>] [--in <glob>]… [--passages] <words>` | What matches, best first, one `thing — lead` a line. |
| `cosm index facts <thing>` | A thing's facts (`out:`) and the facts pointing at it (`in:`). |
| `cosm index find <condition>…` | The things meeting every condition, one a line. Quote a condition with `<` or `>`. |
| `cosm index query "<SQL>"` | The rows, tab-separated under a header. |
| `cosm index retrieve …`, `cosm index analyze <text>` | As the calls, as JSON. |
| `cosm index refresh <kind>` | Lists a kind's items again. |

```
$ cosm index facts "meetings/2026-10-27 Board.md"
meetings/2026-10-27 Board.md
out:
  links: knowledge/people/Anna Berg.md
  attendee: knowledge/people/Anna Berg.md
  held: 2026-10-27
$ cosm index find attendee="Anna Berg"
meetings/2026-10-27 Board.md
$ cosm index find "held>=2026-10-26"
meetings/2026-10-27 Board.md
```

`--json` gives any of them as JSON.

### How search works, and what goes with a message

Basic search is the engine's: words as written, matched as prefixes, ranked by BM25, over each thing's text. With
stems, everything is indexed a second time in its words' forms, and a message's words are matched there too. Ordinary search is every thing whose kind doesn't set `search: false`.

What goes to the agent with a message is what packages answer as contributions to the agent's point `agent:message` (agents.md).
Open file, a built-in package, tells what is open in the window. Search hints, another, brings what in ordinary search
bears on the message (it ranks `cosm.index.retrieve`'s candidates itself). `search: false` divides the work: what
ordinary search holds is Search hints'; what a kind keeps out of it is its package's own, to bring when it bears on
something (Star chart's logs, by its own tool). `cosm search-hints:explain "<message>"` shows what a message would bring,
and why.

## Examples

Each is a whole package: its `cosm.json` holds only who it is (package.md), and `main.ts` the rest. Try one with:

```sh
cosm package check <name>
cosm package on <name>                 # after the user's y
cosm kind explain <a path it should take>
```

### A kind of files that aren't text: images

`examples/images/`: images open in a view of the package's own (`views/image.html`, views.md) and are found by their
names.

```ts
import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:views", { name: "image", file: "views/image.html", label: "Image", input: "file" });
  cosm.point.add("cosm:kinds", { name: "image", match: "**/*.{png,PNG,jpg,JPG,jpeg,JPEG,gif,GIF,webp,WEBP}", label: "Image", view: "image" });
  cosm.index.text("image", "name");
}
```

### A view for some of another package's files: meeting notes as a board

`boards`: Markdown's pages in `meetings/` open as a board of the package's own; every other page stays in Markdown's
editor. A kind extending `markdown:page`, narrowed to that folder, sets only `view`; Open With still offers Markdown's
page. The board itself, `views/board.html`, is an editor (views.md: `cosm.file.open(cosm.view.arg)`, each heading a
column, each line a card, the whole text written back on every move).

<!-- example: boards/main.ts -->
```ts
import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:views", { name: "board", file: "views/board.html", label: "Board", input: "file" });
  cosm.point.add("cosm:kinds", { name: "meeting", extends: "markdown:page", match: "meetings/**/*.md", label: "Meeting note", view: "board" });
}
```

### Out of search: a quiet archive

"Keep the old archive out of search and out of what the agent is sent." Extending Markdown's kind with `search: false`
keeps the pages findable on purpose (`cosm index search --in "archive/**" …`); `skip` drops the old exports from
the index entirely.

<!-- example: archive/main.ts -->
```ts
import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:kinds", { name: "archived", extends: "markdown:page", match: "archive/**/*.md", search: false });
  cosm.point.add("cosm:skip", { name: "exports", globs: ["archive/exports/**"] });
}
```

### Facts on another package's pages: meeting attendees

`meetings`: meeting notes say who came on a line `Attendees: [[Anna Berg]], [[Erik]]`, and their date in the file's
name (`2026-10-27 Board.md`). Its facts make them askable: every meeting Anna attended (`cosm index find
attendee="Anna Berg"`), the meetings since Monday (`cosm index find "held>=2026-10-26"`). Markdown's links stay: facts
combine.

<!-- example: meetings/main.ts -->
```ts
import type { Cosm, Facts } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:kinds", { name: "meeting", extends: "markdown:page", match: "meetings/**/*.md", label: "Meeting note",
    // Each [[Name]] on the Attendees line as an attendee; the date in the file's name as the day it was held.
    facts: meetingFacts });
  async function meetingFacts({ things }: { things: string[] }) {
    const out: Record<string, Facts> = {};
    for (const path of things) {
      const text = await cosm.file.read(path).catch(() => "");
      const line = text.split("\n").find((l) => l.startsWith("Attendees:")) ?? "";
      const facts: Facts = { attendee: [...line.matchAll(/\[\[([^\]|#]+)/g)].map((m) => ({ to: m[1] })) };
      const day = /^\d{4}-\d{2}-\d{2}/.exec(path.split("/").pop() ?? "")?.[0];
      if (day) facts.held = { date: day };
      out[path] = facts;
    }
    return out;
  }
}
```

```sh
cosm package check meetings
cosm package on meetings                              # after the user's y
cosm index facts "meetings/2026-10-27 Board.md"
cosm index find attendee="Anna Berg"
```
