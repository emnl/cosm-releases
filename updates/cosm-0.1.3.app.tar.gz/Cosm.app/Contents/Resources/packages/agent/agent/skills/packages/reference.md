# Reference

Every call a package has, every event it can hear, every element of the kit, and the engine's lookups. One line each;
the page named after a line explains it. The calls are `cosm.d.ts` (`../../sdk/cosm.d.ts` beside this guide), the one
authority on names and shapes: open it when a line here is not enough. `import type { Cosm } from "cosm"` gives
`main.ts` its types; Cosm maps the name when it checks a package, nothing is installed.

**Where** says who has the call: `main` is `main.ts` (the `cosm` its default function is given), `view` is a view's
`window.cosm`, `both` is either. Calls marked *registers* are made while `main.ts`'s default function runs; made later,
they throw.

Every function a package registers runs in its own worker and may be async. It is given one object with named fields,
and answers the thing asked for, bare; nothing (`undefined`, `null`) says nothing; a string is text for whoever reads
it; `{stop}` is the one decision, only in a before-event; a throw is the one failure.

## The package

| Call | What it does | Where |
|---|---|---|
| `cosm.package.name` | The package's name. | both |
| `cosm.package.folders` | `{package, cosm, data, cache}`: its own folder (never written to), the cosm's, its data in this cosm (`.cosm/data/<package>/`, synced), its cache on this computer (rebuilt at will). Data and cache are made when first asked for. | main |
| `cosm.package.signal` | The package's `AbortSignal`: aborted as it stops, before `package.stopping`'s handlers. Pass it to what runs on its own. | main |
| `cosm.package.keep(why)` | Holds the package's worker running while work Cosm can't see goes on (a socket, a timer); answers `{release()}`. Shown with its reason in Settings → Packages and `cosm package running`; goes with the worker (events.md, A package's life). | main |
| `cosm.signal` | The current call's `AbortSignal`: fires when no one waits on the call any more (Skip, the agent interrupted, the package restarted). Pass it to `fetch` or `Bun.spawn`. | main |
| `cosm.log(...what)` | A line in the package's log (`cosm package log`); `console.log` goes there too (from a view, only `cosm.log`, named by the view, with what its scripts throw that nothing catches). | both |
| `cosm.part.override(part, {file} \| {value})` | *Registers.* Takes the place of another package's part (`star-chart:agent/prompts/recall`): a file of its own at the same path, or a value in the part's shape (changing-packages.md). | main |

## Events (events.md)

| Call | What it does | Where |
|---|---|---|
| `cosm.on(event, handler, {kind}?)` | *Registers.* A handler `(data, context)` for an event; what it returns is the answer where the event takes one. `{kind}` narrows a file event to a kind's files (and the kinds extending it). | main |
| `cosm.on(event, handler)` | In a view: its view events (`view.opened` …, answering the window's `view.find`, `view.rename`), `theme.changed`, `ui.changed`; no other. Returns the function that stops hearing it. | view |
| `cosm.emit(name, data?)` | Fires one of the package's own events, heard as `<package>:<name>` by other packages and the window (its views follow it through a live value); one named `<name>.before` waits for its handlers and answers `{stop?}` (events.md). | main |
| `cosm.point.add("cosm:events", { name: name, description})` | *Registers.* Says what one of its own events means (for `cosm help` and other packages' authors). | main |

## What it adds (package.md, views.md, files-and-kinds.md, agents.md)

| Call | What it does | Where |
|---|---|---|
| `cosm.point.define(name, {description, holds, shape?, functions?, uses?, label?})` | *Registers.* A point others add to: `holds` files, values or functions; `shape` its data (`cosm/shape`, a schema library's or JSON Schema); `functions` the functions each contribution has; `uses` all or one (package.md, Points). | main |
| `cosm.point.add(point, {name, …})` | *Registers.* A contribution to a point, its own or another package's (`daily-note:sections`), checked against the point's shape. | main |
| `cosm.point.read(point)` | Every contribution, in Cosm's order: `[{package, name, as, path?, by?, …}]` (`by`: the package overriding it), functions callable. | main |
| `cosm.point.default(point)` | For a `uses: "one"` point: the contribution used now (the user's default), or null. | main |
| `cosm.package.file.read(path, {bytes?})` | One of the package's own files, by its path in it, as text (or bytes); read while `main.ts` registers, it counts as its code (changed, the package loads again). | main |
| `cosm.point.add("cosm:kinds", {name, …kind})` | *Registers.* A kind of files (`match`) or of things that are no files (`items`, `watch`), or a narrower one of another package's (`extends`): `view`, `template`, `label`, `merge`, `search`, and what the index reads of its things, `text` (`"name"`, `"file"` or `fn({things})` answering `{thing, name?, lead?, text?}` each) and `facts` (`fn({things})` answering `{[thing]: Facts}`, combined with every other package's) (files-and-kinds.md). | main |
| `cosm.point.add("cosm:stems", {name, stems, compounds?})` | *Registers.* A word's forms: `stems({words})` answers the forms; `compounds` finds words inside longer ones. Used one at a time (Settings → General → Defaults when two packages give one). | main |
| `cosm.point.add("cosm:skip", {name, globs})` | *Registers.* Globs never indexed, by a name of the package's. | main |
| `cosm.point.add("cosm:schedules", {name, when, description?, run})` | *Registers.* `run({name, when, due})` at set times while Cosm runs, the package woken for it: `every 10m`, `daily 08:00`, `weekly mon 08:00`, once (`2026-11-07 13:00`, `today 13:00`). One due while Cosm was closed runs once at its next start. | main |
| `cosm.point.add("cosm:views", {name, …view})` | *Registers.* A view: `file` (its page, a path in the package), `label`, `icon`, `input` (`file`, `folder`, `thing`), `location`. | main |
| `cosm.point.add("cosm:items", item)` | *Registers.* An item in a place: `name`, `label`, `location`, `action` (or `find`), `keys`, and `content` (what views read: an object, or a function per session; Cosm's places read `icon`, `description`). | main |
| `cosm.package.export(functions)` | *Registers.* The package's API for other packages, `cosm.call("<package>:<name>", {…})`. Each a function or `{run, input?, description?}`: `run` takes one object (its input, checked against `input`: `cosm/shape`, a schema library's or JSON Schema) and the call's context. | main |
| `cosm.view.export(functions)` | *Registers.* The functions its own views call, `cosm.main.<name>({…})`, `live(cosm.main.<name>)`: as `cosm.package.export`'s, and `changes` (`{files?, storage?, data?, events?}`: what its answer depends on; `{}` never by itself). Answers its list: return it from main.ts's default function, for `ApiOf<typeof main>`. | main |
| `cosm.point.add("cosm:commands", {name, description, step?, inputs?, run})` | *Registers.* A command on Cosm's command line: `cosm <package>:<name>` in a terminal or the agent's shell (the agent's tool), an MCP tool where tools are offered; `step` how a call reads in a chat; `run(args, {by, session?})` (agents.md). | main |
| `cosm.point.add("agent:mcp", {name, program, args?} \| {name, url, headers?})` | *Registers.* An MCP server for the agent (the `agent` package's point); `${COSM_SECRET_<NAME>}` is filled in with the package's secret. | main |
| `cosm.point.add("agent:secrets", {name})` | *Registers.* Gives the agent's sessions one of the package's secrets as `COSM_SECRET_<NAME>`. | main |
| `cosm.point.add("agent:programs", {name, program})` | *Registers.* Gives the agent a program of the package's (`bin/uv`) to run by `name` in its shell, with the package's own variables; only the agent gets it. | main |
| `cosm.point.add("agent:agents", {name, label, start, running, stop, …})` | *Registers.* A connector: an agent the package runs, by a name of its choosing: `label`, `prompt`, `hooks`, `start` (answers its program's process; Agent session speaks ACP with a chat's), `running`, `stop`, `sessions` (agents.md). | main |
| `cosm.call("agent:share")` | What every agent gets, from the `agent` package's points and Cosm's tools, MCP servers ready to start and secrets with their values, for a package that is an agent to shape its way: `{instructions, prompts, skills, tools, mcp, secrets}` (agents.md). | main |
| `import type { … } from "package:<name>"` | Another package's types, from its main.ts (types only: `cosm package check` refuses importing its code), as `Agent` and `Share` from `package:agent` (package.md, Points). | main |
| `cosm.point.add("cosm:settings", {name, …setting})` | *Registers.* A setting: `shape` (`cosm/shape`, a schema library's or JSON Schema: the values it takes and the control Settings draws), `default`, `label`, `description`, `question`, `current`, `hidden`. | main |
| `import { shape } from "cosm/shape"` | Shapes without a schema library, as plain JSON Schema that carries its TypeScript type: `shape.string({format?})`, `number({min, max, whole})`, `boolean()`, `enum([…])`, `array(s)`, `object({…})` with `optional(s)`, `record(s)`, `unknown()`, each with `description`; `Infer<typeof s>` its type (package.md, Points). | main |
| `cosm.setting.preset(owner, values)` | *Registers.* Values it suggests for another package's settings (`cosm` for Cosm's own), below the user's. | main |
| `cosm.point.add("cosm:secrets", { name: name, label?, description?})` | *Registers.* A secret the user gives. | main |

## Settings and secrets (package.md)

| Call | What it does | Where |
|---|---|---|
| `cosm.setting.get(name)` | A setting's value: its own by name, another package's as `<package>:<name>`, Cosm's own as `cosm:<name>`. | main |
| `cosm.secret.get(name)` | Its own secret's value, or null when the user hasn't given it. | main |

## Files (files-and-kinds.md)

| Call | What it does | Where |
|---|---|---|
| `cosm.file.read(path, {bytes}?)` | The file's text, or its bytes. | main |
| `cosm.file.write(path, content)` | Writes a file whole through Cosm (before-events ask first, the save is told): a new file, or a deliberate replace. | main |
| `cosm.file.append(path, text)` | Adds text to a file's end (made when missing), losing nothing written meanwhile. | main |
| `cosm.file.change(path, fn)` | Changes a file that may be open: `fn(text)` gives the new text; run again on the newest when the file changed meanwhile. | main |
| `cosm.file.name(path)` | The name Cosm shows ("Plan" for `Plan.md` when a kind claims it). | main |
| `cosm.file.list(glob)` | The paths a glob matches, read as a kind's `match` is (hidden files left out). Read while `main.ts` registers (as `cosm.file.read`), what it read counts towards what it registered: a file read changed, or one the glob matches added, changed or gone, the package registers again. | main |
| `cosm.file.tree({skip?, hidden?})` | The cosm's folders and files as `TreeNode`s: `name`, `path`, `folder`, `modified`, `children`, `kind?`, `view?`; `skip` leaves out what its globs match (Cosm's glob rule; a folder with all it holds); `hidden: "include"` lists hidden files and folders too, a part of their path starting with `.` (never `.cosm`, `.trash`, `.git`, `.DS_Store`). | main |
| `cosm.file.stat(path)` | `{kind, name, modified, size, folder}`, or null when it isn't there. | main |
| `cosm.file.move(from, to)` | Moves or renames a file or folder; packages fix what pointed at it. | main |
| `cosm.file.trash(path)` | To the cosm's trash, where it can be put back. | main |
| `cosm.file.which(name, {kind?, from?}?)` | The file a name means, the nearest to `from`; null when none. | main |
| `cosm.file.open(path)` | Opens a file for editing: a `FileHandle`. | view |
| `handle.path`, `handle.modified` | Its path (follows a move); when it was written, as opened or last read. | view |
| `handle.read({bytes}?)` | Its content now. | view |
| `handle.write(content)` | The whole content as it stands on screen; Cosm saves it when it sees fit. | view |
| `handle.sync()` | Saves what is unsaved now. | view |
| `handle.on("changed" \| "moved" \| "trashed", fn)` | It changed underneath (`{why}`: `changed`, `merged`, `theirs`, `edited`), moved (`{path}`), or went to the trash. Returns the stop function. | view |
| `handle.close()` | Lets it go, saved first. | view |
| `cosm.trash.list()` | What is in the trash, newest first: `{name, from, folder, modified}`. | main |
| `cosm.trash.restore(name)` | Puts it back; its path now. | main |
| `cosm.process.start(name, {program, args?, as?, cols?, rows?})` | Starts one of the package's long-running programs, run by Cosm apart from its code (package.md): `as: "lines"` (its output a stream named as it is, `<package>:<name>`, a line an item) or `"terminal"`. | main |
| `cosm.process.write(name, text)` | Types into it. | both |
| `cosm.process.resize(name, cols, rows)` | A terminal's size. | both |
| `cosm.process.stop(name)` | Asks it to end, then makes it. | main |
| `cosm.process.list({package?})` | The programs packages run: `{name, package, program, as, pid, started, attached, running, code?}`. | main |
| `cosm.process.attach(name, fn(text), {ended?})` | What a process writes, as text, from what it wrote lately on; returns the function that lets it go. | view |
| `cosm.stream.open(name, {keep?})` | One of the package's streams (package.md): `{name, write(...items), close()}`; found again, with what it kept, after its code loads again. | main |
| `cosm.stream.subscribe(name \| handle, fn)` | What a stream kept, then what comes, in order: `fn(items, {closed, code?, missed?})` (`code`: how a program ended; `missed`: items lost before these); returns the stop function. main.ts by any stream's name; a view only by a handle its package gave it. | both |
| `cosm.stream.pass(name)` | A handle on a stream (not a program's output) for the package's view: a view function returns it, the view subscribes to it; the window is sent its items, the package may sleep. | main |
| `cosm.stream.list({package?})` | The streams: `{name, package, open, kept, subscribers, program}`. | main |
| `cosm.call("agent:list")` | The agents that are on: `{name, label, package, chosen}`, the one used now first (the `agent` package's). | main |
| `cosm.call("agent-session:start", {agent?, session?, as?, first?})` | Starts a session with an agent (none named: the user's), or carries one on (`session`), as a chat or in its agent's terminal (`as: "terminal"`; Agent session's exports, all below): its id, `c-7k2p` (its stream is `agent-session:<id>`). | main |
| `cosm.call("agent-session:running", {session})` | Which of its programs runs now, as its connector says: `{as: "chat" \| "terminal", process}`, or `null`. | main |
| `cosm.call("agent-session:send", {session, message})` | To the session's agent: a text (`"…"` or `{text, images?, context?}`) or one of the agent's prompts by name (`{prompt: "<package>:<name>"}`); while the agent answers, it waits its turn. It returns once handed over; the shell's `cosm agent-session:send <session> <text>` waits for the reply and prints it (or what the agent asks, and how to answer; refused while a turn runs). | main |
| `cosm.call("agent-session:answer", {session, answer: {id, allow, always?, answers?}})` | Answers what the agent asked (a step, a plan, a form) by the id in its stream. | main |
| `cosm.call("agent-session:cancel", {session})` / `cosm.call("agent-session:stop", {session})` | Stops its turn / ends its run. | main |
| `cosm.call("agent-session:set", {session, model?, effort?})` | Its model or effort. | main |
| `cosm.call("agent-session:close", {session})` / `cosm.call("agent-session:get", {session})` | Closes it (a package may keep it open) / it as the list keeps it. | main |

## The index (files-and-kinds.md)

| Call | What it does | Where |
|---|---|---|
| `cosm.index.find(conditions)` | Things meeting every condition (`["status=open", "kind=markdown:page"]`): `{thing, name, kind, lead?, modified}`. | main |
| `cosm.index.search(words, {kind?, in?, passages?}?)` | What matches, best first: `{thing, lead?, passage?}`. | main |
| `cosm.index.analyze(text)` | The text's words as the index makes them out, each `{word, form}` (`form` `""` for a glue word). | main |
| `cosm.index.retrieve(words, {kind?, in?}?)` | The candidates and their numbers, for a package that ranks them itself: `{total, words, things}`. | main |
| `cosm.index.query(sql)` | One read-only SQL statement over `things` and `facts`: rows as objects. | main |

## Storage (package.md)

| Call | What it does | Where |
|---|---|---|
| `cosm.storage.get(key)` | A value the package keeps in the cosm, or null. | main |
| `cosm.storage.set(key, value)` | Keeps a JSON value. | main |
| `cosm.storage.update(key, fn)` | The value `fn` works out from the one kept, written only while nothing changed it meanwhile (else `fn` again, a few times, then a conflict). | main |
| `cosm.storage.delete(key)` | Lets one go. | main |
| `cosm.storage.list()` | Its keys. | main |
| `cosm.instructions()` | Cosm's own instructions for the agent (`cosm instructions`): what every agent is told first, before each package's `agent/instructions.md`. | main |

## Sessions (agents.md)

A session is Agent session's, by its id (`c-7k2p`); its list is Agent session's (`cosm agent-session:list`, its events
`agent-session:started`, `:closed.before`, `:closed`, `:removed`, each `{session}`); Agent session's exports reach its
agent (`cosm.call("agent-session:send", …)`, agents.md, Sessions). What its agent says is the stream
`agent-session:<id>` (`cosm.stream.subscribe`; a view gets it handed by its package). Cosm itself keeps no sessions: a
package learns which conversation something is about from an event's data (`{session, …}`, the agent's events and
Agent session's), or from the thing it was chosen on (`agent-session:session:<id>`, an item's `thing`; the agent gives
it with `cosm ui run <item> --thing <thing>`). The agent is told its own conversation as each session starts, and finds
it again with `cosm agent-session:which <its own session id>`. A command's second argument and a handler's context name
no session, and no variable of Cosm's names it.

## The window (views.md)

| Call | What it does | Where |
|---|---|---|
| `cosm.ui.shown(pane?)` | Every view on screen (one pane's, or all): `{pane, view, label, kind?, arg?, name?, path?, used, facts?}` (`facts`: what the view published about itself). | both |
| `cosm.view.publish(facts)` | Facts about this view, what only it knows (`{ selection }`): merged into what it published, `null` takes one away; read as its `facts` in `cosm.ui.shown()`, gone when it closes (views.md, What is on screen). | view |
| `cosm.ui.active(view?)` | The view used last (of one view, or any), or null. | both |
| `cosm.ui.open(target, arg?)` | Opens a file (in the most recently used view of its kind), or a view with its argument; rejects when no window is open. | both |
| `cosm.ui.close(target?)` | Closes what is opened (the file or view given, else what is open now); its pane shows its placed views again. | both |
| `cosm.ui.back()`, `cosm.ui.forward()` | Through the window's history. | main |
| `cosm.ui.items(place)` | What is placed in a place: `{id, name, package, label, content, open?, arg?}` (`open` and `arg`: what an item that opens something opens, as its action says it). | both |
| `cosm.ui.run(item, on?)` | Does what choosing an item does, by its id (`stamp:stamp`), run as the package that made it; `on`: the `{path}` or `{folder}` it is used on, and the `{thing}` it acts on (else the thing its view shows). How a view runs items another package placed in it. Rejects when no window is open. | both |
| `cosm.ui.progress(title, fn)` | Long work shown where notices show, with Cancel: `fn(progress, signal)`, `progress({message?, done?})` (`done` 0 to 1), `signal` aborted on Cancel; goes when `fn` returns or throws (thrown on, said by what started the work) (views.md). | both |
| `cosm.ui.notify(text, {as: "problem"}?)` | A notice; a problem stays until dismissed, with what packages place on problems (`notice`: Agent session's Ask the Agent). | both |
| `cosm.ui.ask(question, asking?)` | Asks the user: one of `choices`, typed text (`answer: "text"`), else Yes / No; `in: "background"` as a card in the corner. The answer, or null. | both |
| `cosm.ui.icon.list()` | Every icon the window handed the view (`cosm:icons`), by the name it is reached as and in full, each with its SVG: `{name, svg}`. In main.ts, `cosm.point.read("cosm:icons")`. | view |
| `data-cosm-file="<path>"`, `data-cosm-folder="<path>"` | On an element of the page: a right-click there shows the window's menu for that file or folder. | view |
| `cosm.ui.menu(rows, {at?, current?, find?})` | A menu of the view's own rows (`{id, label, hint?, items?}`, `{heading}`, `"separator"`), drawn by the window under `at`: what was chosen as the path of ids, or null. | view |
| `cosm.view` | `{name, arg}`: which view this is and what it was opened for, null for nothing. | view |
| `cosm.main.<name>(…)` | One of its package's view functions (`cosm.view.export`). | view |
| `cosm.file.open(path)` | A handle on the file the view shows (its `arg`; any other refused): `read`, `write`, `sync`, `close`, `on("changed" \| "moved" \| "trashed")`; read only for a file that isn't text. | view |
| `cosm.process.attach(name, out, {ended?})` | Shows a process by its full name, any package's: what it wrote lately, then as it comes; answers how to let go (the process runs on). | view |
| `cosm.call(ref, input?)` | Another package's export, named in full (`agent-session:start`), given its one input (an object): what it returns, or an Error. Never a command: those are the command line's (`cosm package check` warns on a call it can read that reaches no export). | main |

### Shapes the calls take

| Shape | Keys |
|---|---|
| `Action` | a function `({path?, folder?, thing?, text?, package?})` run in the worker (a string it returns is a notice; it sends the agent something with `cosm.call("agent-session:send", …)`); `{ask: {question, description?, yes}}`; `{open, arg?}`; `{new: {kind, folder?, name?, template?, question?}}` |
| `Location` | `{in, kind?, folder?, menu?}` (an item may have several); `in` is `left-pane`, `centre-pane`, `right-pane`, `palette`, `file-menu`, `folder-menu`, `menu-bar` (with `menu`), `settings`, or a view that takes items or holds views (`file-tree:tree`, `agent-session:holder`) |
| `Content` | an object (any keys a view reads; `icon`, `description` for Cosm's places; `label` in place of the item's), or `({thing?})` (the thing its view shows) answering one or null (hidden), alone or as `{ run, changes }`: worked out again when what `changes` names changes (as a view function's) |
| `Tool` | `{description, inputs?, run(args)}`; each input `{name, label?, description?, type?: text \| number \| switch \| list \| stdin, choices?, optional?}` |
| `Connector` | `label`, `prompt?`, `hooks?`, `start({session, as, resume?, first?, env})`, `send({session, message: {text, images?, context?}})`, `stop`, `answer`, `cancel`, `set`, `sessions({sessions})` (agents.md) |
| `Kind` | `extends`, `match` (glob or globs) or `items({})` with `watch`, `view`, `template`, `label`, `merge` (`"lines"` or `fn({base, mine, theirs})` → text or null), `search` (false: out of ordinary search) |

## Events (events.md)

A handler gets `(data, context)`. `context` is `{name, package, by}`: the event's name, the package that fired it
(`cosm` for Cosm's own) and who caused it (`window`, a package's name, `shell`, `outside`). Below, the data; the
conversation an event is about is there, as `session`.

| Event | Data | Answer |
|---|---|---|
| `file.saved`, `file.created`, `file.opened`, `file.trashed`, `file.removed` | `{paths}` (removed: deleted outside Cosm; a rename outside Cosm is `file.moved`) | — |
| `file.moved` | `{moves: [{from, to}]}` (a folder's files move with it) | — |
| `file.saved.before`, `file.created.before` | `{path, kind, text}` | nothing, `{stop}`, or `{text}` to write instead |
| `file.moved.before` | `{path, kind, to}` | nothing, `{stop}`, or `{to}` (a path in the cosm) |
| `file.trashed.before` | `{path, kind}` | nothing or `{stop}` |
| `window.opened`, `window.closed` | `{}`: the first window opened on the cosm, the last closed | — |
| `package.started` | `{reason}`: a worker of the package's code starts (`startup`, `on`, `reload`, `update`, `wake`); its own handlers only | — |
| `package.stopping` | `{reason}`: before its code stops (`idle`, `off`, `reload`, `update`, `removed`, `quit`); `cosm.package.signal` aborted first; 3 s | — |
| `<package>:<event>` | what it was emitted with | — |

The engine's change events, heard in main.ts and in a view alike, each with the new value:

| Event | Data |
|---|---|
| `ui.changed` | `{shown}` (every view on screen, as `cosm.ui.shown()` gives them) or `{items}` (the names of items whose labels changed) |
| `setting.changed` | `{package, name, value, scope}` for one setting; `{scope}` alone for the user's choices (a tie, an association, the layout) |
| `view.opened` | `{arg}`: another argument opened in the view |
| `view.closed`, `view.focus`, `view.find` | none: it left the screen; take the cursor; ⌘F (answer `{count, current}`, or use `<cosm-find>`) |
| `view.rename` | `{path}`: rename it in place; answer the new name, or null |
| `package.changed` | `{package?}`: which packages there are or are on, or one's files |
| `kind.changed` | `{kind}`: a kind's items changed |

A view also hears the session's events, as main.ts does:
the `agent` package's (`agent:message.sent` `{session, text}`, `agent:turn.ended` `{session, stopped, used?, size?}` …:
agents.md) and Agent session's.

## The kit (views.md)

Every view page gets these elements, drawn in the page (no shadow root), styled by the kit's stylesheet.

| Element | Attributes and properties | What it is |
|---|---|---|
| `<cosm-list>` | `.from` (a live value), `.items` (rows), `call` (a view function, kept live, given the view's argument), `empty` | Rows: label, line, the date in words, `right` or `count`; grouped by `group`; a click opens `open`; a file's row marked for its menu; the shown one lit. Shows a live value's first load, reload, empty and failure the same way. |
| `<cosm-table>` | as `<cosm-list>`, and `columns` (JSON `[{key, label?, align?}]`; else the row's own) | The same rows as a table: numbers grouped, dates as words. |
| `<cosm-item>` | `label`, `line`, `date`, `right`, `count`, `icon`, `open`, `arg`, `group`; children `slot="actions"` | One row of a list or table, or on its own a row opening `open`, its `slot="actions"` children (buttons) at its right. |
| `<cosm-button>` | `open` (with `arg`); `primary`; `disabled` | A button in Cosm's look: a click is the page's own, or opens `open` (`cosm.ui.open`). |
| `<cosm-tree>` | `.from` (a live value of the tree), `.layout = {sections, foot, hidden}`, `.others`, `.folds` (and its `folds` event), `.move = (from, to) => …`; `folder` | The cosm's folder as the left pane shows it, with the items placed in its view. A click opens a file, or a folder (`cosm.ui.open`: `folder.opened`); rename in place and drag to move through `.move`. |
| `<cosm-toolbar>` | `label` (when the view shows no file or folder), `readonly` (no rename) | Where the view's header goes: the window draws it (back, forward, the argument's folders, a click opening one; its name, a click renaming it, a right-click its file menu), and it drags the window. |
| `<cosm-find>` | `el.finder = (words, step) => ({count, current})`, step `next`, `previous`, `close` | The view's find bar on ⌘F; without `finder` it finds in the page's text. |
| `<cosm-place>` | `point` (which of its package's places; the view's own name without it), `show` (the view shown); `el.views` (`{view, label, icon?, point}[]`); `change` event | Where a view shows the views placed in its package's place (`location.in: "<package>:<place>"`, a point the package defines), one at a time; without `show`, the first. |
| `<cosm-icon>` | `name` | An icon: one of Cosm's by name, or an SVG as text, in the text's colour. |
| `cosm/view` | `state`, `live`, `show`, `html`, `view` | A view's runtime, given by the window (views.md, Live data): `import { live, show, html } from "cosm/view"`. |
| `<cosm-terminal>` | `process` (`<package>:<name>`), `size` (text size in px) | A process's terminal drawn in the view (xterm.js), attached to it: what is typed goes to it, its size follows the element; `ended` when it ends. |

A view's own header (a row of its own at its top) drags the window when it carries `data-drag-region`, and a
double-click there zooms it, as a title bar (what is pressed for itself there, a button, a link or a field, doesn't); the window's toolbar (`<cosm-toolbar>`) does this itself. Where the window's own controls
sit over the view (the window's top left), `--window-controls-left` is the room they take: a header pads its left by
it (`padding-left: max(14px, var(--window-controls-left, 0px))`).

## The engine's lookups

`cosm help --guide` prints this table: every command of `cosm` itself, in the agent's shell and in a package's
programs. `cosm help` lists them with the tools each package offers; `--json` gives any lookup's answer as JSON.

| Lookup | What it gives |
|---|---|
| `cosm file tree [--skip <glob>]… [--hidden]` | The cosm's folder as JSON: `{name, path, folder, children, modified}` each, and for a file, when they apply: `kind` (its most specific kind, `package:kind`; the file is then named without its ending), `label` (the name its kind gives that one file: show it by this) and `view` (`package:view`, only when one shows it: none is the card). `--skip <glob>` leaves out what it matches, by Cosm's glob rule (a folder with all it holds). `--hidden` lists hidden files and folders too (a name starting with `.`, and all they hold: the path says it); never `.cosm`, `.trash`, `.git` or `.DS_Store`. |
| `cosm kind explain <path \| package:kind:key>` | A thing's kinds (the one claiming it, then those extending it that take it) and every key it gets (view, merge, template, index.text, index.search, index.facts, label) with the kind and package each came from, by which step, and what lost and why (files-and-kinds.md). |
| `cosm instructions` | Cosm's own instructions for the agent, as text: what a cosm is, moving and trashing through Cosm, finding things, settings, packages, asking the user. The agent package gives them to every agent first, before each package's. |
| `cosm kind list` | The kinds that are on: each with its package, the kind it extends, its match or items, its label, view and template, whether it is searched. |
| `cosm index search [--kind <kind>] [--in <glob>]… [--passages] <words>` | What matches, best first, `path — first line` a line; `--kind <name>` (or `<package>:<name>`) one kind's things (a kind that isn't there: FAIL, naming those that are); `--in <glob>` the files a glob matches (given more than once: any of them; a bad glob: FAIL); with `--kind` or `--in`, what ordinary search leaves out (a kind's `index.search: false`) is found too, and with both, both must hold; `--passages` the matching passage of each, `path<TAB>passage`. |
| `cosm index analyze <text>` | The text's words as the index makes them out, each with its form (the root search matches it by; `""` for a glue word), in the order they first come, as JSON `[{word, form}]`: for a package matching text its own way. |
| `cosm index retrieve [--kind <kind>] [--in <glob>]… [--passages] <words>` | The candidates for the words and their numbers, as JSON, for a package that ranks them itself (a reranker, as Search hints): `{total, words: [{word, form, count}], things: [{thing, name, lead, kind, words, inName, bm25, named}]}`; `--kind` and `--in` as for `index search`. |
| `cosm index facts <thing>` | A thing's facts (files-and-kinds.md, Facts): out, `rel: object` (a node as its path, or `<name> (not found)`), then in, `rel from <thing>`, each once; a thing is a path, `package:kind:key`, or a name as `cosm file which` takes it. `--json`: `{thing, out: [{rel, type, node, target \| value, sources}], in: [{thing, rel, sources}]}`. |
| `cosm index find <condition>…` | The things in the index whose facts meet every condition, one a line (`--json`: `[{thing, name, kind}]`): `rel` (has one), `rel=x`, `rel!=x` (has none equal to x), `rel<x`, `rel<=x`, `rel>x`, `rel>=x`. A node compares by its path or the name it was written as (`owner=Anna Berg`); a number as a number; text and dates as text (dates are ISO). Two conditions are the things' own, not facts: `kind=<kind>` (`page` or `markdown:page`: that kind's things and those of every kind extending it) and `folder=<folder>` (the files inside it, at any depth). |
| `cosm index query "<SQL>"` | One read-only SQL statement over the tables `things` (thing, kind, name, modified, lead: its first line) and `facts` (thing, rel, type, node, target, value, source): tab-separated rows under a header line; `--json`: `{columns, rows}`, each row a list in the columns' order. |
| `cosm index sync` | Brings the index up to date. |
| `cosm index refresh <kind>` | Lists a kind's items again: from its package's code its own kind by name, from the agent `<package>:<kind>` (files-and-kinds.md). |
| `cosm file move <path> <to> [--dry-run]` | Moves a file or a folder. `<to>` is a new name (it stays in its folder), a path (`notes/x.md`), `./<name>` for the cosm's top, or a folder ending in `/` (its name kept). A page in a folder of its own name takes the folder along; a folder renamed takes its own page. Runs `file.moved`, prints the new path. `--dry-run`: what would move, the pages that link to it (their links are fixed as it moves), or why a package would refuse it; nothing moves. |
| `cosm file trash <path> [--dry-run]` | Moves a file or folder to the cosm's trash, where the window can put it back; runs `file.trashed`. `--dry-run`: what would go (a folder's files), or why a package would refuse it; nothing moves. |
| `cosm trash list` | What is in the cosm's trash, newest first: each one's name in the trash and where it came from (a line each, tab-separated; `--json` adds whether it is a folder and when it went). |
| `cosm trash restore <name>` | Puts something from the trash back where it came from (at a free name there; the cosm's top folder when that isn't known) and prints its path now. |
| `cosm process list [package]` | The long-running programs packages started (`cosm.process.start`), a line each: its name (`<package>:<name>`), how it runs (lines or terminal), running or how it ended, and how many are attached. |
| `cosm process stop <package>:<name>` | Stops a program a package runs (asked to end, then made to after a moment); its package hears `process.exited`. |
| `cosm process attach <package>:<name>` | Prints what a program a package runs wrote lately, then what it writes as it comes, until it ends (or the command is stopped). |
| `cosm process write <package>:<name> <text>` | Types into a program a package runs: the text as given. |
| `cosm ui outline [package:view]` | What the views on screen show, as the agent reads a page: under a line naming each view (its pane, the view and what it shows), an element a line, nested by indent: its role, its name in quotes, what it holds ([checked], [level=2], a field's value) and, on what can be clicked or typed into, a ref (`[ref=b4]`) for `cosm ui click` and `cosm ui type`. A ref holds until the next outline. A question or other sheet of the window's open over them comes first (`# window: sheet`), with refs of its own: answered by `cosm ui click` and `cosm ui type` as the user would. The window must be open. |
| `cosm ui click <ref>` | Clicks an element of a view on screen, by its ref in the last outline, once it can be clicked: drawn, enabled, in the view and not covered (5 seconds at most). When it can't, it fails saying why (hidden, disabled, outside the view, covered by a sheet or another element): outline again to see what is there. |
| `cosm ui type <ref> <text>` | Types into a field or editable text of a view on screen, by its ref in the last outline: added where the cursor is, as typing does. |
| `cosm ui press <ref> <key>` | Presses a key on an element of a view on screen, by its ref in the last outline: Enter submits a field's form, Escape closes, Tab moves on. |
| `cosm ui snapshot [package:view] [--out <out>]` | Takes a picture of the window as drawn (or of one view on screen) and prints the PNG's path: by default in the cosm's cache (the ten newest kept), or `--out <path>`. The window must be open, and the view on screen. |
| `cosm ui wait [--text <text>] [--ref <ref>] [--view <package:view>] [--gone] [--timeout <seconds>]` | Waits until something is on screen, instead of sleeping: `--text <text>` until it shows in a view on screen (`--view` narrows it to one), `--ref <ref>` until that element of the last outline can be used (drawn, enabled, not covered), `--view <package:view>` alone until that view is on screen and has drawn something; `--gone` until it no longer is. Prints how long it took; fails after `--timeout` seconds (10 unless given, 60 at most), saying what it last saw. The window must be open. |
| `cosm ui diff [package:view]` | What the views on screen show now, as only what changed since the last outline (or diff): lines added (`+`), lines gone (`-`), each under its view's line; refs are the new ones, as `cosm ui outline` gives them. With no outline before it, the whole outline. The window must be open. |
| `cosm schedule list` | The schedules packages added (`cosm:schedules`), a line each: its name (`<package>:<name>`), its `when`, when it ran last and when it runs next (this computer's clock), or why its `when` isn't read. |
| `cosm stream list [package]` | The streams packages write (`cosm.stream`) and programs' output, a line each: its name (`<package>:<name>`), open or closed, how many items it keeps, and the packages that subscribed. |
| `cosm stream subscribe <package>:<name>` | Prints what a stream kept, then each item written to it as it comes, one line of JSON each, until it closes (or the command is stopped). A stream not open yet is waited for. |
| `cosm ui close [path \| package:view]` | Closes what is opened in the window (the file or view given, else what is open now); its pane shows its placed views again. |
| `cosm ui open <path \| folder \| package:view \| web address> [arg]` | Shows a file, or a package's view with its argument, in the window; a file no view shows gets the card, with Open in the system's app for it, as a click in the sidebar does. A folder is told to packages as `folder.opened`: what it shows is theirs (Star chart opens a space's page). A web address (http, https, mailto, tel) opens in the user's browser. What an action's `open` does, the same way. With no window open it fails, saying so. |
| `cosm ui active [--view <package:view>]` | The view used last in the window, of one view (`--view markdown:page`) or of any: `{pane, view, label, kind, arg, name, path, used}` (a package's `cosm.ui.active`), or null when none is on screen. |
| `cosm ui shown [left \| centre \| right]` | Every view on screen, or one pane's (`left`, `centre`, `right`), each as `cosm ui active` gives it (a package's `cosm.ui.shown`). |
| `cosm ui back` | A step back in the history of the window used last, in the pane used last (as ⌘[). |
| `cosm ui forward` | A step forward in the history of the window used last, in the pane used last (as ⌘]). |
| `cosm file stat <path>` | What is known of a file or folder of the cosm: `{kind, name, modified, size, folder}` (a package's `cosm.file.stat`), or null when it isn't there. |
| `cosm file list <glob>` | The cosm's files a glob matches, a path a line, by Cosm's glob rule (as a kind's `match` reads it): `*.pdf` in any folder, `/` first for the cosm's top (`/profile.md`), `**` across folders, `{a,b}` either; hidden files left out (a package's `cosm.file.list`). In a connected folder too: `@company/Reports/*.md` (a folder as `name/`), `@company/**/*.pdf` all under it. |
| `cosm file which <name> [--kind <kind>] [--from <from>]` | The file a name means, as its path from the cosm's root: the name as the tree shows it (a kind's file without its ending, any other file with it), matched exactly (case counts; letters compare in their composed Unicode form, so `Åsa` finds a file whose name was stored decomposed); a name with a `/` is the end of a path (`People/Anna Berg`). `--kind` (`page` or `markdown:page`) keeps to that kind's files. Several files of that name: the one the name means read from the folder of `--from` (the file or folder where the name was written) wins (`Plan` from `a/x.md` is `a/Plan`; `People/Bo` from it is `a/People/Bo`), else the shortest path (fewest folders, then fewest characters, then A to Z). Nothing found: `FAIL` and exit 1. Every link in the window is opened through it; a page calls it as `cosm.file.which(name, {kind: "markdown:page", from: path})`. |
| `cosm ui notify "text" [--as problem]` | A notice in the window; `--as problem` stays, with what packages place on problems. |
| `cosm emit <event> ['{json}']` | Fires an event: from a package's code its own, by its short name; from the agent `<package>:<event>`. Every package with a handler for it (cosm.on) runs it with the event's data, and the window hears it; nothing waits (events.md). |
| `cosm ui ask "question" [--description "…"] [--choice "A"]… [--answer text\|folder] [--in background] [--secret <package>:<name>]` | Asks the user in the window and waits; prints the answer, or exits 1 when there is none (views.md). Each `--choice` is a button (Yes and No when none is given); `--answer text` has the user type it; `--answer folder` has them choose a folder (the Mac's folder picker) and prints its full path; `--in background` asks without taking the window. `--secret <package>:<name>`: the user types a secret the package declares, in a hidden field, and the window keeps it as the package's (as its Settings would): it prints only `given`, never the value. |
| `cosm setting list [<package>]` | The packages' settings, and Cosm's own under `cosm` (package.md): each looked up in the cosm, then in the user's `~/.cosm/settings.json`, then its default. |
| `cosm setting set <package> <setting> <value>` | Sets one in the cosm's `.cosm/settings.json`, or several at once: `cosm setting set <package> a=1 'b=two words'`, written together, so a package reading them loads again once (`default` takes a value away). |
| `cosm setting unasked [<package>]` | The settings whose question the user hasn't answered yet. |
| `cosm setting associate <key> <glob> <package\|default>` | The user's choice of which package gives those files a key: view, merge, template, index.text, index.search (refused when it would do nothing; files-and-kinds.md). |
| `cosm setting layout` | The panes as they are now: per pane (left, centre, right) `stacked` or `tabs` and its views in order, the views placed in other views, and `opens` (the pane what is opened shows in); each with its key (`package:name`, a package's placement; `you:…`, one you added). |
| `cosm setting layout set '<json>' \| default` | Keeps the cosm's own layout: per pane `show`, `views` in order (`{"place": "<key>"}`, or `{"view": "<package>:<view>", "arg": "…"}`) and `hidden` keys; `default` takes it away (views.md, The user's layout). |
| `cosm setting prefer <key\|kind\|overrides:<part>\|presets:<owner>:<setting>> <package\|default>` | The user's answer where two packages tie: a key two kinds of equal weight set (view, merge, template, index.text, index.search), two kinds claiming a file (`kind`), two overrides of one part (`overrides:<package>:<part>`), two presets of one setting (`presets:<owner>:<setting>`). |
| `cosm setting default <package:point> <package\|default>` | The user's default where a point is used one at a time (`uses: "one"`): the package whose contribution it uses (`default` takes it away; then the user is asked again when it is needed). Kept in .cosm/settings.json → `default`. |
| `cosm package list [--notify]` | Every package: on or off, built in or the cosm's own, its label, what it does and its folder (the built-in ones are read there as examples). `--notify`: and tells the window of replaced parts whose base changed. |
| `cosm package check [<package>]` | Checks the packages (or one) against the contract and says what is wrong; non-zero when something is. |
| `cosm package test [<package>]` | Runs a package's own tests (its `tests/*.test.ts`, with `bun test`), each on throwaway cosms of this engine made with `cosm/test`; without a package, every package that is on and has tests. Tests are optional. Non-zero when one fails. |
| `cosm package on <package>` | Switches a package on (while a window is open it starts: its `window.opened`). |
| `cosm package off <package> [--yes] [--dry-run]` | Switches a package off. When packages that are on use it, it says which and stays on: --yes switches it off anyway. `--dry-run`: which packages that are on use it; nothing changes. |
| `cosm package call <package>:<name> ['{…}']` | Calls a function a package exports (`cosm.package.export`), as `cosm.call` does, with its input as one JSON object. Prints what it returned. |
| `cosm package log <package> [--all]` | A package's runs: when, what, how each ended and how long it took. The last 40 lines, with a run of the same call that went well folded into one line (how many, how long); what went wrong is shown whole. --all: the whole log as kept, about 200 KB, to grep. |
| `cosm package history <package>` | A cosm's own package's checkpoints, newest first, a line each: its number, when, why it was kept (it loaded; its files changed, or changed and didn't load; before a restore), and the files that changed since the one before. Cosm keeps a copy of the package's files (not what it stores) each time they change and each time its code loads, the last 20, on this computer only. |
| `cosm package restore <package> <n>` | Puts a cosm's own package's code back as checkpoint <n> holds it (its libraries and what it stores stay); its code as it is now is kept first, so the restore can be undone. It loads again. |
| `cosm package ties` | Each tie between packages that are on, keyed as `cosm setting prefer` takes it, with who gives it now, whether the user ranked them all, and how many things it decides. |
| `cosm part list [<package>]` | Every part of a package (or of every package that is on) by name, with what it is and how it stands (`--json`: with its content). |
| `cosm part off <package:part>…` | Switches parts of packages off in this cosm, each in full, `<package>:<part>` (changing-packages.md). |
| `cosm part on <package:part>…` | Switches parts that this cosm switched off back on. |
| `cosm part replace <package:part> <package> [--label …] [--description …]` | A copy of another package's part to change, taking its place, in a package of the cosm's own named for the change (made, off, if it isn't there): a file part copied to the same path there, a part its main.ts registers as `cosm.part.override`'s value; cosm.lock keeps the base part's fingerprint (changing-packages.md). |
| `cosm part changed <package:part> [<package>]` | How an override stands against its base (`same`, `changed`, `gone`), with the base's part now and the override, to bring it up to date. |
| `cosm part accept <package:part> [<package>]` | Records the fingerprint of the base's part as it is now in cosm.lock. |
| `cosm point list` | Every point there is (Cosm's own, then each package's that is on): what it is for, what it holds (files, values, functions), its shape, what adds to it in order, and for one used one at a time the default (packages.md, Points). |
| `cosm point read <package:point>` | What adds to a point, in Cosm's package order, after the cosm's leave-outs and the overrides: each with its package, its name and the name it is reached by, and its file or values. |
| `cosm point default <package:point>` | The contribution a point used one at a time (`uses: "one"`) uses now: the user's default; with several and none set, the user is asked once. |
| `cosm package try event <package> <event> ['{fields}']` | Tries one package's handlers for an event (cosm.on), by hand, with the event's data given as JSON: for building and testing a package (events.md). |
| `cosm package event <event> [-- <file>…]` | Fires one of Cosm's events for every package that is on, as the window does: a file event with its files. |
| `cosm package try item <package> <item> [--path <path>] [--folder <path>]` | Tries an item's function by hand, named by the item's name, without the window: what it returns is printed, a question it asks first is answered yes; `--path` or `--folder` for what it is used on. For building and testing a package; another package asks for work through tools, the user chooses items (`cosm ui run`). |
| `cosm package running` | What the packages are working on now (a handler, a tool, a label, a page's call), each with how long it has run, longest first, and what holds a package running (`cosm.package.keep`, with its reason): what to look at when something seems stuck. |
| `cosm package restart <package>` | Restarts a package: its worker ends (and what it was working on with it), and its main.ts is loaded fresh. For a package stuck on something (cosm package running shows it). |
| `cosm package data <package>` | A package's own lasting folder in the cosm, `.cosm/data/<name>/` (its programs get it as COSM_DATA_DIR). |
| `cosm package add <source> [--as <name>] [--yes]` | Adds a package from where it is published (package.md); without `--yes`, what would come. |
| `cosm package update [<package>] [--yes]` | What's newer for each package from a source; with `--yes`, updates it. |
| `cosm package remove <package>` | Removes a package added from a source, or one of the cosm's own (to the cosm's trash; one used from a folder elsewhere is only no longer used), or the cosm's copy of a built-in package (the built-in one is used again). |
| `cosm storage get <key> [--package <package>] [--token]` | A value the calling package keeps in its storage (`.cosm/data/<package>/storage/`, a file a key): its own key; text as it is, any other value as JSON; a key it hasn't: nothing, exit 1. `--token` prints `{"value", "token"}` instead: the token for `storage set --if` (`none` for a key without a value). `--package` names the package: another package's, or one's for a caller that isn't a package (the agent, a person). |
| `cosm storage set <key> <value> [--package <package>] <token>` | Keeps a value under a key: one that reads as JSON (`3`, `["c1"]`, `{"a": 1}`) as JSON, any other as text. With `--if <token>` (from `storage get --token`) it is kept only while the key is as it was read; else nothing is written and it fails with a conflict, so a change made meanwhile isn't lost: read it again and retry. |
| `cosm storage delete <key> [--package <package>]` | Takes a key away. |
| `cosm storage list [--package <package>]` | Every key the package keeps, with its value, as one JSON object. |
| `cosm ui run <package>:<item> [--path <path>] [--folder <path>] [--thing <thing>]` | Does what choosing a package's item does, wherever it is placed, run as its package: `cosm ui run stamp:stamp`; `--path`/`--folder`, what it is used on; `--thing`, the thing that is no file it acts on, as a click in a view showing that thing gives it (`--thing agent-session:session:c-7k2p`: an agent's own conversation). Needs the window open. |
| `cosm trust get` | Whether what came with this cosm may run on this computer: the user's answer, kept in `~/.cosm/trust.json`, as JSON: `{state, packages: [{name, label, description, copy, does}]}`, `does` what each would do. |
| `cosm trust set yes\|no\|forget` | Sets the user's answer (Settings → General asks it): the user's own, in the window or their terminal; refused to a package and to the agent. |
| `cosm root add <folder> [--name <name>]` | Connects a folder outside the cosm (a shared Drive folder, ~/Documents/Company) as a root: its files are then named `@<id>/<path>` (`@company/Reports/q3.md`), the id made from its name and never changed. Nothing in it is read until asked for; it isn't searched or in the tree. Refused when it overlaps the cosm or another connected folder (one file, one name). `{id, name, path, change}`: `change` is `added`, or `none` for the same folder again. Only on the user's ask. |
| `cosm root list` | The connected folders: `[{id, name, path, reachable}]`, `path` where it is on this computer (null: not located here: `cosm root locate`). |
| `cosm root remove <id>` | Forgets a connected folder: its files stay where they are. Its id is never given to another folder; adding the same folder again gets it back. Only on the user's ask. |
| `cosm root path @<id>/<path>` | Where a file of a connected folder (`@company/Reports/q3.md`) is on this computer: its full path, for tools that aren't Cosm's (`cat`, an Office tool), which don't know `@<id>/`. |
| `cosm root locate <id> <folder>` | Where a connected folder is on this computer: when the cosm came from another computer, or the folder moved. `{id, name, path}`. |
| `cosm package folders` | The cosm's folder and the one this machine rebuilds for it: `{cosm, cache}`. |
| `cosm merge <path>` | Merges two versions of a file through its kind's `merge` (`{"base", "mine", "theirs"}` on stdin). |
| `cosm schema` | The contract's JSON Schema. |
| `cosm version` | The engine's version and the contract it reads. |
| `cosm mcp` | An MCP server serving the lookups as tools (agents.md). |
| `cosm serve [status \| stop]` | The cosm's engine as a service: started by the first call that needs it, stopping after 15 minutes with no client (a window, subscribed to its events, counts); `status` says how it is, `stop` stops it. |
