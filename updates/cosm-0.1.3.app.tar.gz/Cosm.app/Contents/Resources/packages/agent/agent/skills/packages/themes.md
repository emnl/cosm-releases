# Themes

The user asks for a different look: "a darker theme in purple", "warmer colours", "make the agent's screen match".
A theme is added in code to Cosm's point `cosm:themes`, by its name; a package may add several (Cosm theme adds
`cosm-light` and `cosm-dark`). Keep it in place, or in a JSON file the package imports:

```ts
import type { Cosm, Theme } from "cosm";
import dusk from "./themes/dusk.json";
export default function (cosm: Cosm) {
  cosm.point.add("cosm:themes", { name: "dusk", ...(dusk as Theme) });
}
```

The user picks one in Settings → Appearance (Cosm's setting `theme`,
`<package>:<theme>`: `cosm setting set cosm theme dusk:dusk`); none chosen, the window shows the theme matching the
system's light or dark. A theme shows at once, while its package is on.

## A theme

| Key | Meaning |
|---|---|
| `label` | Its name in Settings → Appearance. |
| `look` | Required: `light` or `dark`: whether it is a light or a dark theme (pages and the agent's screen follow it). |
| `colours` | Required, all 28 (below), each a CSS colour (`#1b1726`, `rgba(…)`, `rgb(… / 0.2)`, or `var(--accent)` for another of its own). |
| `terminal` | The agent's own screen, in xterm's names, all of them when given: `background`, `foreground`, `cursor`, `cursorAccent`, `selectionBackground`, `black`, `red`, `green`, `yellow`, `blue`, `magenta`, `cyan`, `white`, and each `bright…` of the eight. Without it, the screen is made from the colours. |
| `agents.<package>` | One agent's own theme for its screen, as that agent's package reads it (agents.md): Claude Code's `{"name", "base": "light" \| "dark", "overrides": {…}}`; Gemini CLI's own shape. |

**The colours:**

| Colour | What it paints |
|---|---|
| `page` | The page in the centre. |
| `side` | The left pane's background. |
| `chat` | The agent's pane. |
| `card` | Cards and menus. |
| `bubble` | The user's messages in the chat. |
| `text`, `muted`, `faint` | Text, from strongest to faintest. |
| `title` | Page titles. |
| `bullet` | A list's bullets. |
| `line`, `line-strong` | Lines between things, light and strong. |
| `sel` | A row under the pointer. |
| `fill`, `fill-strong` | Buttons and fields, at rest and pressed. |
| `accent`, `onaccent` | The accent (what is chosen, what to press), and text on it. |
| `ok`, `warn`, `danger` | What a message means: done, take care, failed or can't be undone. |
| `red`, `orange`, `yellow`, `green`, `teal`, `blue`, `purple`, `pink` | The palette: hues for telling unrelated things apart (tags, chart series, categories), each readable as text on the theme's own page. |

A colour may name another of the theme's (`"danger": "var(--red)"`, `"accent": "var(--blue)"`). The user may pick one
of the eight hues as the accent instead of the theme's (Settings → Appearance, Cosm's setting `accent`); text on it then
takes the theme's `text` or `page`, whichever reads better. Worked out from these, never a theme's own: `flash` (what
just changed, a find's current match) and `selrow` (a selection, the other matches) from the accent, `accent-soft`,
`ring` (keyboard focus), `group` (grouped rows' background: `card` in a dark theme), `ok-soft`, `warn-soft`, `danger-soft`, and a soft tint of each hue (`red-soft` … `pink-soft`: a tag's background, under
the hue's own text).

Only colours: a theme can't change the frame, the fonts or the text size (Cosm's own settings `text-font`,
`code-font` and `text-size`: `cosm setting list cosm`). `cosm package check` refuses a theme missing any colour or part
of `terminal`, naming each one missing, and checks `agents.<package>` against the shape of that agent's own point (`claude:config`).
`cosm point read cosm:themes` lists every theme of the packages that are on, each with its package and all it gives,
as the window and the agents' packages read them (the cosm keeps the chosen one as `<package>:<theme>`); in code,
`cosm.point.read("cosm:themes")`.

Every view gets the colours as CSS variables (`var(--accent)`, `var(--page)`, views.md), and the text settings as
`var(--text-font)`, `var(--code-font)` and `var(--text-size)`. When the user picks another theme, the variables change
in every view on screen: a view that paints with them needs no code to follow. One that copies colours into a canvas
or a library draws again on `theme.changed` (views.md, Theme).

Each theme is a part of its package (`themes/<name>`), which the user can switch off or another package override (`cosm part off cosm-theme:
themes/cosm-dark`, changing-packages.md).

## A complete example

`examples/dusk/`: a dark theme in plum and violet, with Claude Code's screen to match. Its `cosm.json` holds nothing but
who it is, and its `main.ts` adds the theme, kept in `themes/dusk.json` (its `terminal` cut short here: the file has
all 21):

```json
{
  "label": "Dusk",
  "look": "dark",
  "colours": {
    "page": "#1b1726", "side": "#16121f", "chat": "#1e1a2a", "card": "#231e31", "bubble": "#2b2540",
    "text": "#e5e1f1", "muted": "#a59fbb", "faint": "#7a7491",
    "line": "rgba(255, 255, 255, 0.07)", "line-strong": "rgba(255, 255, 255, 0.12)", "sel": "rgba(255, 255, 255, 0.06)",
    "fill": "rgba(255, 255, 255, 0.05)", "fill-strong": "rgba(255, 255, 255, 0.09)",
    "accent": "#b9a4f0", "onaccent": "#1b1726", "title": "#c8b8f5", "bullet": "var(--accent)",
    "flash": "rgb(185 164 240 / 0.25)", "selrow": "rgb(185 164 240 / 0.16)"
  },
  "terminal": { "background": "#1E1A2A", "foreground": "#E5E1F1", "cursor": "#B9A4F0" },
  "agents": {
    "claude": { "name": "Dusk", "base": "dark", "overrides": { "claude": "#B9A4F0", "text": "#E5E1F1", "inactive": "#7A7491" } }
  }
}
```

```sh
cosm package check dusk
cosm package on dusk                 # after the user's y
cosm setting set cosm theme dusk:dusk
```

The built-in `cosm-theme` holds Cosm Light and Cosm Dark, each with its own Claude Code and Gemini CLI screens.
