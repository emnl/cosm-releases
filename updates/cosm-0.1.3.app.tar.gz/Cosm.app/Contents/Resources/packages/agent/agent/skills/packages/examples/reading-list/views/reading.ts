// The reading list: what waits in the folder, a search over it (the list keeps what matches), Done on each, and "What
// next?" for the agent's pick.
// Everything comes from this package's main.ts (its view functions); `articles` is kept live, so a page the agent
// saves, Done, or a move elsewhere shows by itself.
import { html, live, show, state, view } from "cosm/view";
import type { ApiOf } from "cosm";
import type main from "../main.ts";

const cosm = view<ApiOf<typeof main>>();
const articles = live(cosm.main.articles);
const search = state("");

show("#root", () => {
  const all = articles.value ?? [];
  const words = search.value.trim().toLowerCase();
  return html`
    <header class="cosm-page-head">
      <div><h1 class="cosm-page-title">Reading list ${articles.value ? html`<span class="cosm-count">${all.length}</span>` : ""}</h1></div>
      <div class="cosm-page-head-actions"><button class="cosm-button primary" @click=${() => cosm.main.readNext()}>What next?</button></div>
    </header>
    <main class="cosm-page-body cosm-stack">
      ${all.length ? html`<div class="cosm-input-group"><input type="search" placeholder="Find in the list" aria-label="Find in the list" .value=${search.value}
        @input=${(e: Event) => { search.value = (e.target as HTMLInputElement).value; }}></div>` : ""}
      ${articles.status === "loading" ? html`<div aria-hidden="true"><div class="cosm-skeleton line"></div><div class="cosm-skeleton line"></div><div class="cosm-skeleton line"></div></div>`
      : articles.status === "failed" && !articles.value ? html`<div class="cosm-empty" role="status"><p class="cosm-empty-title">Couldn't load the list</p><p class="cosm-empty-line">${articles.error?.message}</p></div>`
      : !all.length ? html`<div class="cosm-empty"><p class="cosm-empty-line">Nothing waiting to be read. Save a link from ⌘K.</p></div>`
      : html`<cosm-list class="grouped" key="open" .filter=${words ? (r: { label: string; line?: string }) => `${r.label} ${r.line ?? ""}`.toLowerCase().includes(words) : null}
          @clear=${() => { search.value = ""; }}>${all.map((a) => html`
          <cosm-item label=${a.title} line=${a.why} open=${a.path}>
            <button slot="actions" class="cosm-button small" @click=${() => cosm.main.done({ path: a.path })}>Done</button>
          </cosm-item>`)}</cosm-list>`}
      ${articles.status === "failed" && articles.value ? html`<p class="cosm-caption" role="status">${articles.error?.message}</p>` : ""}
    </main>`;
});
