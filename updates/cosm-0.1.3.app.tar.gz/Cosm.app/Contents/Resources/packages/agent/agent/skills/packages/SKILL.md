---
name: packages
description: Building, changing or fixing a Cosm package (a folder with cosm.json and main.ts). Load it when the user wants Cosm to do something it doesn't (a page that sums something up, a button, a reminder, a tool for the agent, syncing with an outside service, a different look, another agent), wants to change how Cosm or a package they didn't write behaves (its layout, its rules, its commands, what its panes show, stop a reminder, their own version of one part), asks what packages they have or to switch one on or off, and when a package reports a problem or Cosm says a part the user replaced has changed. A procedure the agent follows when the work comes up is a skill in the user's skills folder, not a package.
---
# Packages

Cosm is a shared workspace for the user and the agent, on a small engine. Everything else it does comes from packages,
its own opinions included, down to what a page is (Markdown) and how the folder is drawn (File tree). The agent extends
Cosm by building packages from what the user asks for, and changes it by changing them.

Packages now (name, on or off, built in or this cosm's, label — what it does): !`cosm package list`

## Package, skill or preference

Choose the smallest that does it:

- **A preference** (Star chart: `knowledge/preferences/`): how the user wants something done. "Write to Anna in English."
- **A skill** (Star chart: `knowledge/skills/<name>/SKILL.md`): a procedure the agent follows when the work comes up.
  With no package that lays the cosm out (Star chart), ask the user where preferences and skills go.
- **A package**: anything that must happen without the agent being asked, anything in the window (a page, a row in
  the sidebar, a button, a menu entry, a reminder, colours), a secret, a tool for the agent, a different agent.

A change to how the agent works is a preference or profile line, even when it goes against a package's rules ("stop
asking before filing").

## What a package is

A folder, a small project of its own, run as it is (nothing is built):

| File or folder | What it is |
|---|---|
| `cosm.json` | Who the package is: `name`, `label`, `description`, `version`, and `"cosm": ">=1.0"`. Nothing else. |
| `main.ts` | Everything it adds: a default-exported function given `cosm`, which registers views, items, tools, kinds, event handlers, settings, secrets. Run by Bun, in a worker of its own. |
| `views/<name>.html` | Its pages, written with Cosm's kit (`<cosm-list>`, `<cosm-toolbar>` …), each added to `cosm:views` in `main.ts` with its `file`. Plain HTML (buttons, fields, tables) looks like Cosm without a class. A view reaches the cosm through its package's `main.ts` (`cosm.main`), and draws what it answers, kept up to date, with `cosm/view` (`live`, `show`): nothing to bundle; a `.ts` module Cosm builds (views.md § Live data). |
| `agent/instructions.md`, `agent/prompts/<name>.md`, `agent/skills/<name>/SKILL.md` | What the agent knows, the commands it runs by name, its skills. |
| (any) | Themes are added in code (themes.md); an icon or a template is given where it is used, read from the package's file (`cosm.package.file.read`). A package that lays out a cosm does it the first time it starts there (`package.started`, with a flag in its storage), as Star chart does. |
| `package.json`, `bun.lock` | Only when it uses libraries from npm. |

A package that only teaches the agent (an `agent/instructions.md`, a command) needs no `main.ts`. `package.md` has every key and
call a package's own wiring uses.

## A first package in five minutes

To do: every unticked `- [ ]` line in the user's pages, in one list the user opens from ⌘K, and the same list as a tool
for the agent. Three files in `.cosm/packages/todo/`.

`cosm.json`:

<!-- example: todo/cosm.json -->
```json
{
  "name": "todo",
  "label": "To do",
  "description": "Every unticked task in your pages, in one list.",
  "version": "1.0.0",
  "cosm": ">=1.0"
}
```

`main.ts`:

<!-- example: todo/main.ts -->
```ts
import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  /** Every unticked "- [ ]" line in the cosm's pages: the task, its page's name under it, opening the page. */
  async function tasks() {
    const rows = [];
    for (const path of await cosm.file.list("**/*.md")) {
      for (const m of (await cosm.file.read(path)).matchAll(/^\s*- \[ \] (.+)$/gm)) {
        rows.push({ label: m[1], line: await cosm.file.name(path), open: path });
      }
    }
    return rows;
  }

  cosm.point.add("cosm:views", { name: "list", file: "views/list.html", label: "To do", icon: "check" });
  cosm.view.export({ tasks: { run: tasks, changes: { files: "**/*.md" } } });
  cosm.point.add("cosm:items", { name: "show", label: "Show To Do", location: { in: "palette" }, action: { open: "todo:list" } });
  cosm.point.add("cosm:commands", { name: "list",
    description: "Every unticked task in the cosm's pages, with its page.",
    run: async () => (await tasks()).map((t) => `${t.label} (${t.open})`),
  });
}
```

`views/list.html`: the kit is loaded into every view and `window.cosm` is there; `<cosm-list call="tasks">` draws the
rows of `main.ts`'s `tasks`, and loads them again when a page changes (its `changes`).

<!-- example: todo/views/list.html -->
```html
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>To do</title>
<style>
  body { margin: 0; background: var(--page); color: var(--text); font-family: var(--ui-font, -apple-system, sans-serif); }
  main { width: min(640px, calc(100% - 64px)); margin: 0 auto; padding: 36px 0; }
</style>
</head>
<body>
<cosm-toolbar label="To do"></cosm-toolbar>
<main>
  <cosm-list call="tasks" empty="Nothing to do: no unticked tasks in your pages."></cosm-list>
</main>
</body>
</html>
```

Check it, then try it:

```
$ cosm package check todo
todo — To do (off)
  ✓ its code: main.ts
  ✓ tools: cosm todo:list
  ✓ views: list
  ✓ 1 item in the window
  ✓ nothing wrong found
  Takes effect: now (once it is on)
$ cosm package on todo          # once it works (Building one, step 4)
$ cosm todo:list
Call Anna (notes/Plan.md)
Send the deck (notes/Plan.md)
```

## Building one

The user asks for something Cosm doesn't do ("a to-do list with reminders"); hand back something that works and looks
like Cosm, with one plan and no string of questions. In order:

1. **Understand.** Read what is there (`cosm package list`, `cosm help`, the user's pages) and pick the smallest thing
   that does it (above). Know what it needs from outside: a key, a sign-in, an MCP server.
2. **Plan once.** In a few lines: what it will make, where it shows, what it needs from the user (a key), how it will
   look. The user says yes once; after that, decide the small things yourself.
3. **Get what it needs.** A key through `cosm ui ask "<where to find it>" --secret <package>:<name>`: the user types it
   in the window, which keeps it as the package's secret; you get only `given`. Never ask for a secret in the chat,
   never read `.cosm/secrets.env`, never print a secret or write one into a file; if the user pastes one in the chat,
   don't repeat it, ask them to enter it in the window.
4. **Start from what is tested.** A starter when one fits (below: copy it in, then adapt), else the closest example in
   `examples/` beside this guide, or a built-in package (`cosm package list` gives each one's folder). Write it in
   `.cosm/packages/<name>/` (name: lowercase letters, digits and `-`, the same as `name` in its `cosm.json`), and read
   the page for each thing it adds (below). Give every item a `name`, so the user can leave it out.
5. **Check.** `cosm package check <name>` after every change: it loads `main.ts` without running a handler, runs
   TypeScript's checker, and says what is wrong (`✗`), what does nothing (`!`), what it brings (`✓`) and when that
   takes effect. Fix every `✗`. It starts off, so it never runs half-built; once a first whole version checks clean,
   switch it on (`cosm package on <name>`) and try what has no view: a tool by its name, `cosm package try item`,
   `cosm package try event`. Read `cosm package log <name>`: its runs, what it logged, its views' script errors.
6. **Look.** `cosm ui open <package>:<view>`, then `cosm ui outline <package>:<view>`: what is on screen, an element a
   line, with refs. `cosm ui snapshot <package>:<view>` writes a PNG of it: read the picture to see its look.
7. **Use it.** As the user would: `cosm ui click <ref>`, `cosm ui type <ref> "text"` and `cosm ui press <ref> Enter` on the outline's refs (add a
   task, tick it, open a page), then `cosm ui diff` at once, before waiting: only what changed, with the new refs, and
   what it shows then is what the user sees on the click (a tick that isn't there yet lags; use `.mutate`). For what
   takes a while (a save, a load), `cosm ui wait --text "Saved"` (or `--ref <ref>`, `--gone`) instead of sleeping. A
   click that can't land says why (covered by a sheet, disabled, hidden): outline again rather than retrying. An empty
   state and a failure are states too: try them (no files yet, a wrong key).
8. **Judge and fix.** Against the design checklist (below); fix, then look and use again. Stuck: read the log, change
   one thing, try again; after three rounds that don't move, say what is in the way instead of going round.
9. **Hand over.** After the last change, look at a fresh render (outline and snapshot again) before saying it's done.
   Then say what it made, where it shows, how to use it, and what it couldn't do. Each version that loaded is kept
   (`cosm package history <name>`), so "go back" is `cosm package restore <name> <n>`.

Then `cosm setting unasked <name>`: ask each question it prints, one at a time, proposing a value, and set it on **y**
with `cosm setting set <name> <setting> <value>`. A tie `check` showed (`!`, another package gives the same thing) is
the user's to answer: say it, never answer it for them (changing-packages.md). Say when it takes effect: views, items,
tools and handlers at once; kinds in the window at once and in search from the next message; the agent's
instructions, commands, skills, MCP servers and what it gives the agent from the next session.

### The design checklist

- **Cosm's kit, not your own styles**: its page head (`cosm-page-head`, `cosm-page-title`), lists, tasks, buttons,
  fields and empty states (views.md); colours only from the theme's variables (`var(--text)`, `var(--accent)`), so
  it looks right light and dark.
- **Every state drawn**: loading (a skeleton), empty (a line saying what to do, with the action when there is one),
  failed (what went wrong, in words), and the full one.
- **Nothing overflows**: long names truncate or wrap, a narrow pane still reads, nothing scrolls sideways.
- **Spacing and alignment** follow the kit's: no stray margins, rows line up, one primary button at most.
- **Words**: plain and short, the user's ("Add a task", "Due today"), no system words (no ids, no "null", no JSON).
- **It reacts**: a change made elsewhere (the agent edits the page) shows by itself (`live`, `changes`); a click
  answers at once (`.mutate` with `optimisticData`); rows with a checkbox or a field are drawn with `repeat`, keyed.

In an untrusted cosm, `cosm package on` refuses a package of the cosm's own: say the user trusts the cosm in Settings →
General, and never set it yourself.

## Trying a change

Edit the files; Cosm loads `main.ts` again as soon as it is saved, and a view again when a file of its package changes.

- `cosm package check <name>`: after every change. When the saved `main.ts` doesn't load, it says so (`✗ its main.ts
  as saved is NOT running`), and the last version that loaded runs on until a save loads: the user loses nothing
  meanwhile, but what you are trying isn't your latest code.
- A tool: `cosm <package>:<tool> [inputs]` (once on). A tool run while the saved code doesn't load prints `note: your
  latest … main.ts is NOT running` above its answer.
- An event: `cosm package try event <package> <event> '<data as JSON>'` (events.md).
- A view: `cosm ui open <package>:<view> [arg]`, then `cosm ui outline`, `cosm ui click <ref>`, `cosm ui type <ref>
  "text"`, `cosm ui diff`, `cosm ui wait --text <text>` and `cosm ui snapshot` (a window must be open).
- Its own tests, when it has any: `cosm package test <name>` runs `tests/*.test.ts` with `bun test`. Tests are
  optional: write one when the user asks, or offer one where a rule is easy to get wrong. A test makes a throwaway
  cosm on the real engine with `cosm/test` and checks it the way the user and the agent use it:

  ```ts
  import { expect, test } from "bun:test";
  import { testCosm } from "cosm/test";

  test("the inbox counts its files", async () => {
    await using c = await testCosm({ files: { "inbox/a.md": "A\n" } });   // the package under test is on
    expect(await c.run("star-chart:inbox-count")).toBe("1");                 // any cosm command, as the agent runs it
    c.write("inbox/b.md", "B\n");                                          // a change from outside
    await c.until(async () => (await c.run("star-chart:inbox-count")) === "2"); // wait for what you expect, never sleep
  });
  ```

  `testCosm({ files, fixture, packages, settings })`: `fixture` copies a folder of `tests/fixtures/` in first. On it:
  `run(...words)` (throws with the command's words when it fails), `fails(...words)` (those words, or `""`),
  `read(path)`, `write(path, text)`, `storage(package, key)`, `until(check, { seconds, what })`. A view: `await
  c.window()` opens the window headless on the test cosm (WebKit, the window's own engine), then `c.run("ui", "open",
  …)`, `"wait"`, `"outline"`, `"click"` as when you look at it yourself; `w.answer(text)` answers a question the
  package asks. (From Cosm's own repository only, for now.)
- A version that went wrong: `cosm package history <name>` and `cosm package restore <name> <n>`.
- `cosm package log <name>`: its last runs (when, what, how each ended, how long), what it wrote with `cosm.log` or
  `console.log`, and each failure's stack; a run of the same call that went well is one line (`page calls lists  ok ×118`).
  `--all` gives the whole log as kept, to grep (`cosm package log <name> --all | grep -A12 threw`).
- `cosm package restart <name>`: its worker ended and its code loaded fresh, when something it keeps in memory went
  wrong.

`cosm package off <name>` switches one off; `cosm package remove <name>` removes one of the cosm's own (to its trash).
Switching off a built-in package is allowed (the user may want Cosm without Star chart): say what goes with it, and
switch it off on **y**.

## Where to look next

| Page | Read it when |
|---|---|
| `package.md` | writing `cosm.json`, settings, secrets, presets, libraries, versions; reading what `check` says |
| `events.md` | something should happen when a file is saved, a session starts, a message is sent; a change refused |
| `views.md` | a page, a button, a menu entry, a reminder in the chat, a row in the sidebar, a terminal |
| `files-and-kinds.md` | reading and writing the cosm's files; a kind of file Cosm shows, searches or merges; the index |
| `agents.md` | a command (the agent's tool), an MCP server or a secret for the agent; its instructions, prompts, skills; another agent |
| `changing-packages.md` | the user wants a package they didn't write changed: a part left out, overridden or replaced |
| `themes.md` | different colours |
| `reference.md` | every call of `cosm`, and the engine's lookups, in one place |
| `glossary.md` | a word the guide uses |

The examples, each a whole package in `examples/` (the pages quote them):

| Example | What it shows | Page |
|---|---|---|
| `todo` | a list from the pages, a view, a ⌘K item, a tool | this page |
| `standups` | a new session hearing today's meetings; a question before a session closes; a command | events.md |
| `reading-list` | a folder of its own, a kind with a template, a TypeScript view on `cosm/view` (live rows, a search, Done on each), an icon, a command | views.md |
| `glance` | a view drawn from functions its `main.ts` exports | views.md |
| `images` | a kind of files that aren't text, with a view of its own | files-and-kinds.md |
| `boards` | a view for some of another package's files (meeting notes as a board) | files-and-kinds.md |
| `archive` | pages kept out of search | files-and-kinds.md |
| `meetings` | facts on another package's pages (attendees, the day held) | files-and-kinds.md |
| `world-clock` | a tool and an MCP server of its own | agents.md |
| `crm` | a remote MCP server with the user's token | agents.md |
| `echo-agent` | another agent, over ACP | agents.md |
| `git-sync` | work as the window opens and closes, and from ⌘K (git), with settings | package.md |
| `short-catch-up` | a change to another package's part (an override) | changing-packages.md |
| `dusk` | a theme | themes.md |

## Packages from elsewhere

Someone else's package is added from where it is published: `cosm package add <source>`, where the source is a GitHub
repo (`github.com/owner/repo`; a folder in it as `github.com/owner/repo/folder`; `@v1.2` to stay on that version),
another git repo (`https://…`, needs git on this computer), or a folder on this computer (used where it is, for
working on a package). Without `--yes` it only fetches and says what would come. Tell the user that in plain words and
ask: "Add PDF viewer from github.com/anna/cosm-pdf? **y** yes · **n** no". On **y**: the same command with `--yes`
(and `--as <name>` if the name is taken). `cosm package update` says what is newer; ask before `cosm package update
<name> --yes`. Never add or update without the user's yes: a package runs with their full access, so it is trusted as
a whole; say so, and that they can read it first.

## When something is wrong

When a package reports a problem and the user asks about it: run `cosm package check <name>` and read `cosm package
log <name>`, read its `main.ts`, run the failing tool or event by hand to see the error, fix the cause, and say what it
was. A notice that a package changed a part another overrides ("Star chart changed the command recall since Short
catch-up took its place.") is no fault: changing-packages.md, When the base changes.
