// Echo: a package that is an agent, a connector. Its agent is a program of the package (bin/chat.pl) that speaks ACP:
// each conversation runs it as one of the package's processes, and Agent session speaks the protocol with it (it
// writes to the program and reads its output's stream). It has no terminal of its own, so the chat is how it shows.
import type { Cosm } from "cosm";
import type {} from "package:agent";   // the agent package's types: what a connector must have is checked

export default function (cosm: Cosm) {
  const me = cosm.package.name;
  /** Whether the conversation's chat runs: its process, which this package knows. */
  const running = async ({ session }: { session: string }) =>
    (await cosm.process.list({ package: me })).some((p) => p.name === `${me}:chat-${session}` && p.running) ? { as: "chat" as const, process: `${me}:chat-${session}` } : null;
  cosm.point.add("agent:agents", { name: "echo-agent", label: "Echo", prompt: "/{name}",
    start: async ({ session, as }) => {
      if (as === "terminal") throw new Error("Echo has no terminal of its own: its chat is how it shows");
      if (!(await running({ session }))) await cosm.process.start(`chat-${session}`, { program: "bin/chat.pl" });
      return { process: `${me}:chat-${session}` };
    },
    running,
    stop: ({ session }) => cosm.process.stop(`chat-${session}`),
  });
}
