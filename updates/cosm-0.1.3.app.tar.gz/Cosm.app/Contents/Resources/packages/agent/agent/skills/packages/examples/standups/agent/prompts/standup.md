---
description: Write today's standup note from what this session moved forward
---
# Standup

Today's meeting notes: !`cosm file list "meetings/$(date +%F)*.md"`

Write three short lines into today's standup note, `meetings/<today> Standup.md` (make it if there is none, named
with the date first): what moved forward in this session, what is next, and anything blocked. Read the session's
changed pages first; never invent progress. Say in one line what you wrote.
