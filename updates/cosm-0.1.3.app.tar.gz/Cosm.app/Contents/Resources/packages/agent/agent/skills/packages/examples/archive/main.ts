import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:kinds", { name: "archived", extends: "markdown:page", match: "archive/**/*.md", search: false });
  cosm.point.add("cosm:skip", { name: "exports", globs: ["archive/exports/**"] });
}
