// Standups: meeting notes named by their date, today's told to the agent, a standup note before closing.
import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.package.uses("agent-session");
  cosm.point.add("cosm:kinds", { name: "meeting", extends: "markdown:page", match: "meetings/*.md", label: "Meeting note" });
  cosm.point.add("cosm:events", { name: "written", description: "A meeting note was made: {path}." });
  const today = () => new Date().toISOString().slice(0, 10);

  // A new session hears today's meeting notes.
  cosm.point.add("agent:start", { name: "today", run: async () => {
    const notes = await cosm.file.list(`meetings/${today()}*.md`);
    if (notes.length) return `<standups>Meeting notes today:\n${notes.join("\n")}\n</standups>`;
  } });

  // A meeting note's name starts with its date.
  const dated = ({ path, to }: { path: string; to?: string }) => {
    const name = (to ?? path).split("/").pop() ?? "";
    if (!/^\d{4}-\d{2}-\d{2} /.test(name)) return { stop: `Meeting notes start with their date, as ${today()} Board.` };
  };
  cosm.on("file.created.before", dated, { kind: "meeting" });
  cosm.on("file.moved.before", dated, { kind: "meeting" });

  // Tell the other packages, and the package's own views, when one was made.
  cosm.on("file.created", async ({ paths }) => {
    for (const path of paths) await cosm.emit("written", { path });
  }, { kind: "meeting" });

  // Closing a session (Agent session's) asks whether to write today's standup note first: yes keeps it open while the
  // agent writes it.
  cosm.on("agent-session:closed.before", async ({ session }: { session?: string }) => {
    if (!session) return;
    const yes = await cosm.ui.ask("Write today's standup note?", { description: "The agent writes what this session moved forward into today's meeting note.", choices: ["Write It", "Close"] });
    if (yes !== "Write It") return;
    await cosm.call("agent-session:send", { session, message: { prompt: "standup" } });
    return { stop: "Writing the standup note first" };
  });
}
