// At a glance: a page of the package's own (views/glance.html), a button for it in File tree's sidebar, and the two
// functions the page draws from. They run here, in the package's worker; the page keeps them live (cosm/view), so
// both follow the cosm's pages as they change, and through <cosm-list call="recent">.
import type { Cosm, TreeNode } from "cosm";

export default async function (cosm: Cosm) {
  const glance = await cosm.package.file.read("icons/glance.svg");
  cosm.point.add("cosm:views", { name: "glance", file: "views/glance.html", label: "At a glance", icon: glance });
  cosm.point.add("cosm:items", { name: "glance", label: "At a glance", content: { icon: glance }, action: { open: "glance:glance" }, location: { in: "file-tree:tree" } });

  /** Every Markdown page in the cosm, from its tree (hidden folders are left out). */
  async function pages(): Promise<TreeNode[]> {
    const out: TreeNode[] = [];
    const walk = (nodes: TreeNode[]) => {
      for (const n of nodes) if (n.folder) walk(n.children); else if (n.path.endsWith(".md")) out.push(n);
    };
    walk(await cosm.file.tree());
    return out;
  }

  // Both read the cosm's pages again when one changes.
  const changes = { files: "**/*.md" };
  return cosm.view.export({
    /** How many pages each folder at the top holds: [{name, pages}], by name. */
    folders: { changes, run: async () => {
      const count = new Map<string, number>();
      for (const p of await pages()) {
        const top = p.path.includes("/") ? p.path.slice(0, p.path.indexOf("/")) : "(top)";
        count.set(top, (count.get(top) ?? 0) + 1);
      }
      return [...count].sort(([a], [b]) => a.localeCompare(b)).map(([name, n]) => ({ name, pages: n }));
    } },
    /** The ten pages changed most recently, newest first, as rows for <cosm-list>: {label, date, open}. */
    recent: { changes, run: async () => (await pages()).sort((a, b) => b.modified - a.modified).slice(0, 10)
      .map((p) => ({ label: p.name, date: new Date(p.modified * 1000).toISOString().slice(0, 10), open: p.path })) },
  });
}
