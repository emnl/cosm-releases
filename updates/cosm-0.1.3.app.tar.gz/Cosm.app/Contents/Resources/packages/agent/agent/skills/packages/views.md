# What the window shows: views and items

The user asks for something to see or click: "a page that sums up my week", "a row in the sidebar that opens it", "a
button in the chat to plan the week", "Plan the Week in ⌘K", "Double It on a recipe's right-click menu", "a reminder
line while the review is due", "New Recipe in File → New", "a terminal running my build beside the page". Two things
answer them:

- a **view**: a page of the package's own (`views/<name>.html` by habit), which `main.ts` adds to `cosm:views`, naming its `file`;
- an **item**: anything clickable (a ⌘K entry, a menu row, a button or a line in the chat, a row in the sidebar, a step
  on the package's Settings page), added to `cosm:items`: its label, its action, where it sits.

What the window shows changes at once while the package is on: the window loads a view again as soon as a file of its
package changes.

**The Cosm look, in short.** Check every view against this before calling it done:

1. Build from the kit and plain HTML (The kit, below): its elements and classes first, CSS of your own last.
2. Colours, fonts and sizes only through the theme's variables (`var(--accent)`, `var(--text)`, `var(--ui-font)`,
   `var(--ui-size)`, Theme, below), never a colour's value: the user's theme and dark mode follow by themselves. A
   meaning colour for what something means (`--danger` on a failure), a palette hue for telling unrelated things apart
   (`--teal` on a tag, under `--teal-soft`); and colour is never the only sign: a red dot also says "Overdue", a
   chart's series also have a legend or labels.
3. One primary action per view (`<button class="cosm-button primary">`); every other button plain or quiet.
4. Every list shows its first load, an empty list (a sentence saying what goes there, not "No data"), a search that
   finds nothing ("No matches", apart from empty) and a failure: the kit's lists do it for a live value.
5. Menus, questions, notices and long work through the window (`cosm.ui.menu`, `ask`, `notify`, `progress`), never a
   menu, dialog or toast of the page's own.
6. A side pane is narrow: write the narrow rules as media queries on the view's own width
   (`@media (max-width: 520px)`), and look at it at about 300 px.
7. The words are plain and in sentence case: no file path, command or JSON in what the user reads.
8. Look at it in light and dark.

## A view

A view is a page, a file of the package its contribution names (`file`): `views/<name>.html` by habit, or the `index.html` of a built page with its own scripts beside it (`views/<name>/index.html`). The
window shows it in a sealed frame and puts into its head, before the page's own scripts: an import map giving
`cosm/view` (Live data, below), the theme's variables (Theme, below), a base style (no margins, `--page` behind `--text`,
15 px in `--ui-font`), the kit's stylesheet, the view's `cosm` (`window.cosm`) and the kit's elements (`<cosm-list>`,
`<cosm-toolbar>` …, The kit, below). A page includes nothing and needs no framework.

- Its relative URLs reach its own package's folder, next to the HTML file (`<script type="module" src="week.ts">`,
  images, styles, fonts). It can reach the web, as any page can; a library shipped in the package keeps it working
  offline.
- **TypeScript:** a module the page loads that ends in `.ts` (or `.tsx`) is built by Cosm into one browser module, its
  imports bundled, `cosm/view` left to the window, kept until a file it was built from changes. `cosm package check`
  checks its types with main.ts's. A build that fails shows its first line in the view; the whole of it is in the
  package's log. A page can also be plain HTML with an inline `<script type="module">`, or a bundle the package builds
  itself (Agent chat's React chat): all three get the same `cosm`.
- A web link (http, https, mailto) clicked in it opens in the user's browser; the page stays.
- Light and dark follow the window.

`main.ts` wires it by its file's name:

```ts
cosm.point.add("cosm:views", { name: "week", file: "views/week.html", label: "This week", icon: "star", input: "folder", location: { in: "right-pane" } });
```

| Field | Meaning |
|---|---|
| `file` | Required: its page, a path in the package (`views/week.html`; a built one's `index.html`), served from the package's folder so what it links to beside it is found. |
| `label` | Its name: on a tab, in Settings → Layout, as `<cosm-place>` lists it. Without one, its name. |
| `icon` | Its icon (Icons, below). |
| `input` | What it is given: `file` (a path; the view a kind names with `view`, files-and-kinds.md), `folder` (a folder's path), `thing` (one of a kind's items that is no file, as `<package>:<kind>:<key>`: Tables' `table` is given `tables:table:expenses`, Agent session's holder and the views placed in it a conversation, `agent-session:session:c-7k2p`). Without it, whatever it is opened with, if anything. The view reads it as `cosm.view.arg`. |
| `location` | Where it sits by default: `{in: "left-pane"}`, `"centre-pane"`, `"right-pane"`, `"settings"` (on the package's own page in Settings, as tall as its page: an agent's install and sign-in, agents.md), or another package's view that holds views (`"agent-session:holder"`, Views in views, below). Without it, the view shows only when something opens it. |

A page is a view only once added to `cosm:views`; a view with no `location` shows only when something opens it (`cosm.ui.open("recipes:week")`).
A view is always named in full, `<package>:<view>`, its own package's too.

The smallest view, Images' (`examples/images/`): `cosm.point.add("cosm:views", { name: "image", file: "views/image.html", label: "Image", input: "file" })` with a kind
naming it (`view: "image"`), and a page that reads the file it shows through a handle on it (Editing a file, below;
an image opens read only):

```html
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Image</title></head>
<body>
<cosm-toolbar></cosm-toolbar>
<main></main>
<script>
  let file = null, url = null;
  async function show(path) {
    if (file) { void file.close(); file = null; }
    if (url) { URL.revokeObjectURL(url); url = null; }
    if (!path) { document.querySelector("main").replaceChildren(); return; }
    file = await cosm.file.open(path);
    url = URL.createObjectURL(new Blob([await file.read({ bytes: true })]));
    const img = Object.assign(document.createElement("img"), { src: url, alt: path });
    document.querySelector("main").replaceChildren(img);
  }
  cosm.on("view.opened", ({ arg }) => show(arg));   // another image opened in this view: the page is kept
  cosm.on("view.closed", () => show(null));         // off the screen
  show(cosm.view.arg);
</script>
</body>
</html>
```

## A view's cosm

A view reaches the cosm through its own package's `main.ts`, and the window through `cosm.ui`. Everything else (the
cosm's files, storage, the index, settings, other packages, events) is `main.ts`'s, which a view asks through the
functions its package lists for it: one route, so what a view shows is kept up to date the same way however it
changed, and every view of the package agrees.

| What | It is |
|---|---|
| `cosm.main.<fn>(input)` | One of its package's view functions (`cosm.view.export`, below), run in the package's worker: a promise of its answer, rejected with what it threw. |
| `cosm.view` | `{name, arg}`: which view this is (`"recipes:week"`) and what it was opened for (a path, a folder, a thing), `null` for nothing. `arg` follows: read it again after `view.opened`. |
| `cosm.package.name`, `cosm.log(…)` | Its package's name; a line in the page's console. |
| `cosm.on(event, fn)` | Its view events (View events, below), `theme.changed` and `ui.changed`, nothing else: what `main.ts` hears reaches a view as a live value. |
| `cosm.ui.*` | What the window does at its asking, as its own controls would: `open`, `close`, `menu` (its own rows), `ask`, `notify`, `progress`; and what it shows: `shown`, `active`, `items`, `icon.list` (the icons the window handed it); `run` (an item, as a click). |
| `cosm.file.open(path)` | A handle on the file it shows (its `arg`): any other is refused (Editing a file, below). |
| `cosm.stream.subscribe(handle, fn)` | A stream its package handed it: a view function returns `cosm.stream.pass("<package>:<name>")` (any package's stream, not a program's output), and the view subscribes to that handle: what it kept, then what comes. A view never follows a stream by name; its window is sent only the streams its views were handed. |
| `cosm.process.attach`, `write`, `resize` | A process by its full name, any package's, to show it and type into it (Terminals, below). Starting and stopping are `main.ts`'s. |

**Its package's functions.** `main.ts` keeps two lists: `cosm.view.export` for its own views, `cosm.package.export`
for other packages (`cosm.call("<package>:<name>", …)`, package.md); a function both need is in both, pointing at the
same code. An entry is a function, or `{ run, input?, description?, changes? }`: `input` its shape (`cosm/shape`, a
schema library's or JSON Schema), checked before `run` for every caller, a schema library's own parse giving `run` its
defaults and transforms; `description` what it does (`cosm package check` lists it); `changes` what its answer depends on (Live data,
below). A function kept live only reads. `cosm.view.export` answers its list: return it from main.ts's default
function, and a TypeScript view types its `cosm.main` from it.

```ts
// main.ts
export default function (cosm: Cosm) {
  cosm.point.add("cosm:views", { name: "week", file: "views/week.html", label: "This week" });
  return cosm.view.export({
    week: {
      description: "The week's pages, as rows.",
      changes: { files: "Weeks/*.md" },
      run: async () => (await cosm.file.list("Weeks/*.md")).map((p) => ({ label: p.slice(6, -3), open: p })),
    },
    plan: { input: shape.object({ session: shape.string(), day: shape.string() }), run: ({ session, day }) => cosm.call("agent-session:send", { session, message: `Plan ${day}.` }) },
  });
}
```

**Keys.** A key with ⌘ that the window handles itself (⌘K, ⌘[, ⌘], ⌘,, ⌘F, ⌘G, ⌘N) goes to the window, as if pressed
there, unless the page took it: one of its own `keydown` handlers called `preventDefault()`. Every other key stays the
page's.

**Focus.** In the Mac's web view a sealed frame takes keyboard focus only after the user has clicked in it once.
Until then `view.focus`, an element's `focus()` and the window moving the cursor to the view do nothing visible: a view
that wants typing at once (a file just made, to be renamed in a tree never clicked) can't count on it before that first
click. Once clicked, it keeps working. Tab goes through fields and the kit's rows; buttons take Option-Tab, as
everywhere on the Mac unless the user changed it.

**Clipboard.** A click in the page may use `navigator.clipboard`.

## Live data: state, live, show

A view's module imports its runtime, `cosm/view`, and draws from what it holds:

```ts
import { html, live, show, state, view } from "cosm/view";
import type { ApiOf } from "cosm";
import type main from "../main.ts";                  // its types only: main.ts runs in the package's worker

const cosm = view<ApiOf<typeof main>>();            // cosm.main typed from main.ts's view functions
const week = live(cosm.main.week);                  // what `week` answers, kept up to date
const search = state("");                           // the view's own: what is typed

show("#root", () => html`
  <input type="search" .value=${search.value} @input=${(e) => { search.value = e.target.value; }}>
  ${(week.value ?? []).filter((r) => r.label.includes(search.value)).map((r) => html`<cosm-item label=${r.label} open=${r.open}></cosm-item>`)}`);
```

| | What it is |
|---|---|
| `state(initial)` | A value the view keeps for itself (what is typed, a tab chosen), read and set as `.value`, replaced whole. Not kept: it starts again with the view. What lasts goes through `main.ts`. |
| `live(fn, input?)` | What one of its view functions answers: loaded once, then again only when what the function's `changes` names changed, when its input changed, or on `.refresh()`. `.value` is the last good answer (`undefined` before the first: `null`, `0` and `false` are answers); `.status` `"loading"`, `"refreshing"`, `"ready"` or `"failed"`; `.error` why it failed, the last value kept. `input` is a value, or a function reading `state()`: a new input loads again. |
| `show(target, draw)` | Draws what `draw` gives (Lit's `html`) into the target (an element or a selector), replacing what was there, and again whenever a state or live value it read changes; changes in one turn are one redraw. |
| `.mutate(action, {optimisticData})` | On a live value: a change the user makes, shown at once (SWR's `mutate`). `action` is the call that changes it (`() => cosm.main.tick({ id })`); `optimisticData` what to show meanwhile (a value, or one made from the value now); then it loads again. If the action fails, what was shown is put back and the failure is thrown. Every click that changes what a live value shows goes through it, or the user waits for the write. |
| `repeat(items, key, row)` | Lit's keyed list: each row keeps its own elements as rows come, go and move. Use it for rows holding state the template doesn't set (a checkbox the user ticked, a field typed in, focus); with `.map`, a row that goes hands its elements, ticked box and all, to the row after it. |
| `.subscribe(fn)` | On a state or a live value: `fn` told when it changed, for a view that draws itself (React's `useSyncExternalStore(l.subscribe, () => l.value)`). |
| `view<Api>()` | The view's `cosm`, `main` typed. |

Make states and live values once, at the top of the module, never inside `draw`.

**What makes a live value load again** is what its function says in `changes`, matched by Cosm to every change,
whoever made it (the agent, a package, the user, another app):

| In `changes` | What changed |
|---|---|
| `files` | The user's files, by Cosm's glob rule (`"Weeks/*.md"`, `"**/*.md"`; a move counts for its old and new path). |
| `storage` | The package's own storage keys (`"sort"`; `"*"` any). |
| `data` | Files in the package's own data folder (`cosm.package.folders.data`), by glob: a database and its journal, `"reading.db*"`. Its storage is not among them. |
| `events` | An event by its name: one Cosm can't see coming otherwise (a web service fetched, another app), `"<package>:<event>"` or `"*:<event>"` from any package, or one of Cosm's (`"setting.changed"`). The event says only that something may be stale; the function reads it again. |

`changes: {}` says it never changes by itself; a function kept live with no `changes` never loads again by itself, and
`cosm package check` warns. Changes coming in a burst load it once, a moment after they settle (about a tenth of a
second, at most a second after the first); one request at a time; an answer made stale while it ran is dropped.

**A failure** of a call the user's action made (a click's `cosm.main.done(…)`) that nothing catches is a notice in the
window, its message as thrown: throw a sentence the user can read. A live value's failure never is: it is in its
`status` and `error`, and the kit's lists show it quietly. Every failure is in the package's log.

**A view that draws itself** with another library (React, Vue) uses the same: `live` and `subscribe`. Agent chat's chat
(`package-src/agent-chat/src/live.ts`) is one: `useSyncExternalStore(l.subscribe, () => l.value)`.

## Where views sit

### The three panes

The window is three equal panes, left, centre and right, each a place for views (`left-pane`, `centre-pane`,
`right-pane`). A pane shows the views placed in it stacked (each an even share of the height) or as tabs, as the user
chooses in Settings → Layout; with none, it is blank.

What is opened (a file, a view by `cosm.ui.open`, a row, an item's `open`) shows in one pane, the layout's **`opens`**:
the centre unless the user chose another. There it takes the place of that pane's placed views while something is
open; they come back when nothing is. A file goes first to a view on screen that shows its kind, in any pane (the one
used last), and only with none to the `opens` pane.

Each pane keeps its own history: the `opens` pane what was opened in it, any other what was given to a view there. A
view's toolbar arrows step back and forward in its own pane; ⌘[ and ⌘] (and `cosm.ui.back()`, `cosm.ui.forward()`)
in the pane used last.

**Which pane.** The left pane is the way in: File tree's tree (`file-tree:tree`) sits there. A page of the package's
that is a way in (a list, a dashboard) is usually an item in the tree opening the view (`{in: "file-tree:tree"}`,
Items, below), not a second view under the tree; give a view `left-pane` only when it must stay in sight. The right
pane is for what goes beside the page being read; Agent session's holder sits there. A view with no `location` opens
where `opens` says. When the user names a pane ("a list in the left pane"), say which you built.

**The user's layout** wins over every package: what they arranged in Settings → Layout is kept in the cosm. `cosm
setting layout` shows the panes as they are now; on the user's word, `cosm setting layout set '<json>'` keeps theirs,
the whole of it (`default` takes it away):

```json
{
  "right": { "show": "tabs", "views": [{ "place": "agent-session:holder" }, { "view": "markdown:page", "arg": "profile.md" }], "hidden": ["today:today"] },
  "opens": "centre"
}
```

Per pane (`left`, `centre`, `right`): `show` (`stacked` or `tabs`), `views` in order (`{"place": "<package>:<view>"}`, a
view a package placed there, or `{"view": "<package>:<view>", "arg": "…"}`, any view the user added, with its
argument) and `hidden` (placed views not shown). A placed view the layout doesn't name keeps its place after those it
does. `opens`: `left`, `centre` or `right`.

### Views in views

A view can hold other packages' views. It does so through a **place**: a point its package defines (package.md,
Points), which other packages' views and items name in `location.in`, in full. A place is usually named as the view
that draws it:

```ts
// Agent session's main.ts: the place, drawn by its holder view.
cosm.point.define("holder", { description: "Views that show a session, one at a time.", holds: "values" });
// Agent chat's main.ts: its chat sits there, given the conversation the holder shows.
cosm.point.add("cosm:views", { name: "chat", file: "views/chat/index.html", label: "Chat", input: "thing", location: { in: "agent-session:holder" } });
```

What is placed in a place reads as the point's contributions too (`cosm point read agent-session:holder`): each item
and view with its package, a part where it is defined (`agent-chat:views/chat`), which the user can switch off.

The holder shows the views placed in it one at a time, in its `<cosm-place>` (The kit, below): the window lays the
placed view's own frame over that element's box and moves it with the box, so each view stays a frame of its own. The
placed view is given what the holder shows (its argument). Opening a view placed in a view (`cosm.ui.open("agent-chat:chat",
id)`) opens its holder with that argument and shows the view there.

`packages/agent-session/` is the real one. Its `main.ts` registers the view,
`cosm.point.add("cosm:views", { name: "holder", file: "views/holder.html", label: "Agent session", input: "thing", location: { in: "right-pane" } })`, its kind `session` (the conversations on
its list, `agent-session:session:<id>`, opened in the holder), and the place `holder`; Agent chat's chat and Agent terminal's terminal place themselves in it. Its page puts the session's header in the window's bar
(`<cosm-toolbar nav="off" menu over>`: the title's menu lists the sessions, the views placed there to show it as, a new
session with another agent; its note the agent and how full; ✦ the session's menu, + new, × close) over a
`<cosm-place>` taking the whole page, so the chat scrolls under the bar; the view switched to is kept:

```html
<body>
  <div class="bar"><button class="switch" type="button" hidden></button></div>
  <cosm-place></cosm-place>
<script>
  const place = document.querySelector("cosm-place"), button = document.querySelector(".switch");
  const next = () => { const v = place.views, i = v.findIndex((x) => x.view === place.show); return v.length > 1 ? v[(i + 1) % v.length] : null; };
  const label = () => { const n = next(); button.hidden = !n; if (n) button.textContent = n.label; };
  place.addEventListener("change", label);
  button.addEventListener("click", () => {
    const n = next(); if (!n) return;
    place.show = n.view;
    void cosm.main.keepShownView({ view: n.view });   // kept by its main.ts, in its storage
  });
  void cosm.main.shownView().then((v) => { if (v) place.setAttribute("show", v); });
</script>
</body>
```

Placing a view in another needs the holder's package on (`cosm package check` warns otherwise), the place defined as a
point of its package (`check` refuses one that isn't), and the holder to have a `<cosm-place>`. A view of a package
that defines several places shows each with its own: `<cosm-place point="buttons">` (a name of its package's, or in
full); without `point`, the place named as the view. A holder shows one placed view at a time; stacked or tabs is the
pane's choice, not the holder's.

## Opening

`cosm.ui.open(target, arg?)` asks the window to show a file (a path in the cosm) or a view (`"<package>:<view>"`, with
its argument). Where it shows is the window's: a file goes to the view used last that shows its kind, else that view
opens in the `opens` pane; a file no view shows gets a card (with Open in the system's app). It resolves once
asked. The same as an action: `{open: target, arg?}`, which also opens a web address in the browser.

```ts
await cosm.ui.open("spaces/Home.md");
await cosm.ui.open("star-chart:archive", "archive");
await cosm.ui.open("agent-chat:chat", `agent-session:session:${id}`);   // placed in agent-session:holder: the holder opens, showing the chat
```

What is on screen: `cosm.ui.shown(pane?)` gives every view on screen (one pane's, or all) as `{pane, view, label, kind,
arg, name, path?, used, facts?}`; `cosm.ui.active(view?)` the one used last (opened, clicked or typed in), of
one view or of any, or `null`. Either changing is heard as `ui.changed` with `{shown}`, all of them as `shown()` gives
them.

A view publishes facts about itself, what only it knows: `cosm.view.publish({ selection })`, merged
into what it published before, a fact set to `null` taken away. The window files them under the view that sent them
(no view can write another's), others read them as that view's `facts` in `cosm.ui.shown()`, they change with
`ui.changed`, and they go when the view closes. They never pass through `main.ts`, so publishing wakes no worker.
Markdown's and Plain text's editors publish `selection`, `{text, from, to}` (its lines, 1-based), or `null`:

```ts
// an editor's view
editor.onSelect((s) => cosm.view.publish({ selection: s ? { text: s.text, from: s.from, to: s.to } : null }));

// a reader: the view with a file worked in last, and what it has selected
const [v] = (await cosm.ui.shown()).filter((s) => s.path).sort((a, b) => b.used.localeCompare(a.used));
const selected = v?.facts?.selection;
```

## View events

The window asks a view things through events it hears with `cosm.on`. A view only gets those it listens to, and hears
no others: what `main.ts` hears (a package's event, a setting changed) reaches it through a live value whose function's
`changes` names it.

| Event | When | The view |
|---|---|---|
| `view.opened` | The view is given another argument (`{arg}`): another file of its kind opened, the holder shows another session. | Shows the new one. A view that hears it is **kept**: loaded once and told each argument; one that doesn't is loaded again for each, and let go while off the screen. Not sent for the argument it was loaded with: read `cosm.view.arg` at start. |
| `view.closed` | A kept view left the screen. | Lets go of what it shows (closes its file: the window lets go of open files itself a second later). |
| `view.find` | ⌘F, sent to the view used last that hears it. | Shows its find bar: the kit's `<cosm-find>` listens for it itself. |
| `view.focus` | The window wants the cursor in the view (a file just made with ⌘N, once named). | Focuses its text (Focus, above). |
| `view.rename` | The window asks the view to rename a file or folder in place (`{path}`: the file menu's Rename, a file just made). | Shows the name as a field, renames through its package's `main.ts`, and answers the new name, or `null` when the name stays. `<cosm-tree>` answers it itself, through the view's `move`. |
| `theme.changed` | The look changed (Theme, below). | Draws again what copies colours. |
| `ui.changed` | What is on screen changed (`{shown}`), or what `cosm.ui.items` gives (`{items}`: their names, `["*"]` when packages changed). | Reads again what it shows of them. |

A view attached to a process (`<cosm-terminal>`) is kept too, hidden or not, so its screen stays drawn.

```js
cosm.on("view.opened", ({ arg }) => show(arg));
cosm.on("view.closed", () => show(null));
cosm.on("view.focus", () => editor.focus());
show(cosm.view.arg);
```

## Items

```ts
cosm.point.add("cosm:items", { name: "plan-week", label: "Plan the Week", location: { in: "palette" },
  content: { icon: "star", description: "The agent plans the week from the inbox" },
  // The conversation it was chosen on (the one on screen used last, from ⌘K), else a new one: this package's choice.
  action: async ({ thing }) => {
    const on = thing?.startsWith("agent-session:session:") && !thing.endsWith(":") ? thing.slice("agent-session:session:".length) : "";
    return cosm.call("agent-session:send", { session: on || String(await cosm.call("agent-session:start")), message: { prompt: "plan-week" } });
  } });
```

| Field | Meaning |
|---|---|
| `name` | Its name, kebab-case: `items/<name>`, which the user can leave out and another package override (changing-packages.md). Required. |
| `label` | Its words, wherever it shows (⌘K, a menu, a view) and for a screen reader: what choosing it does (`Sign Out…`, `Plan the Week`), never a state; what is goes in `content.description` (`Signed in to Notion.`), which Settings shows beside the button carrying the label. Required. |
| `location` | Where it sits: `{in: <place>}`, with `kind` (a `file-menu`'s) or `folder` (a `folder-menu`'s). Required. |
| `action` | What choosing it does (below); or `find`, rows for what is typed in ⌘K. Required. An item whose action can't run here (a command left out) isn't shown. |
| `keys` | Its shortcut in the menu bar. |
| `content` | What it carries for the views that draw it: an object, or a function working it out (below). Each view reads what it wants; Cosm's own places (⌘K, menus, notices, Settings) read `icon` (below) and `description` (the line under it, or its tooltip). |

### Places

`location.in` is one of a closed list (`check` refuses any other, naming the closest), or another package's place (a
point it defines and one of its views draws: `file-tree:tree`, `agent-session:holder`):

| Place | Where | With |
|---|---|---|
| `palette` | ⌘K | |
| `file-menu` | a file's right-click menu | `kind`: only that kind's files (and the kinds extending it); without it, every file |
| `folder-menu` | a folder's right-click menu | `folder`: a glob of the folders it is on (`spaces/*`); without it, every folder |
| `menu-bar` | a menu of the menu bar | `menu`: which (File, Edit, View, Window, where it sits in a section of its own; any other is a menu of its own, between View and Window, there while a package puts something in it) |
| `settings` | the package's page in Settings: a step (an install, a sign-in) or a page to open | |
| `notice` | on a problem Cosm shows (a problem notice, a part changed since it was overridden): its function gets the problem's words (`text`) and the package it is about (`package`). Cosm puts nothing there itself: Agent session's Ask the Agent is one | |
| `<package>:<view>` | inside that view, which reads its items and draws them | `file-tree:tree` (rows in the sidebar), `agent-session:holder` (the session's menu, ✦ in its header, over its chat and its terminal alike: an item with an icon is something to do, ticked once `done` in the session; one without is a reminder, listed first, a dot on ✦ while it is there) |

Panes hold views, not items: an item in `left-pane` is refused ("put it into a view, as file-tree:tree").

An item can sit in several places at once (`location: [{ in: "palette" }, { in: "menu-bar", menu: "Session" }]`), and
in the menu bar have a shortcut (`keys: "CmdOrCtrl+Alt+N"`; the first package in order to claim one has it). Agent
session's Session menu is its own: New Session and Close Session, with Star chart's commands under them.

Each view draws its items its own way, from what their content carries. **File tree's tree** puts an item where its
layout names it (`sections[].items` and `foot`, as `"<package>:<item>"`, a setting Star chart presets) and any other at
the end of the tree, a row with its icon and label. **Agent session's holder** lists them in the session's menu (✦ in
its header): one with an `icon` as something to do (ticked while `done` is set: when it was done in the session), one
without as a reminder, first (a dot on ✦ while one is there). A package places only its own views and actions this way.

### Actions

An item's action is one of these.

| Action | Does |
|---|---|
| a function `({path, folder, thing, text, package}) => …` | Runs in the package's worker, given what it is used on (`Target`): the file (`path`) on a file's menu, the folder on a folder's; the thing that is no file it was chosen on (`thing`: the one its view shows, a table or a conversation; from ⌘K or the menu bar, the one on screen used last; none when none is on screen); on a problem (`notice`), its words and the package it is about. A string it gives is shown as a notice. Sending the agent something is a function's: `cosm.call("agent-session:send", { session, message: { prompt: "reflect" } })`, and which conversation (the one it was chosen on, a new one from `agent-session:start`, none) is the package's choice. |
| `{open: "<target>", arg?}` | Opens a file (a path from the cosm's root; a bare name is always a path), a view (`"<package>:<view>"`, in full, the package's own too), or a web address (`https:`, `mailto:`, in the browser). |
| `{new: {kind, folder?, name?, template?, question?}}` | Makes a new file of a kind (`package:kind` for another's) in `folder`, named `name`, from `template` (else the kind's); `question` asks the user first and `{name}` is the answer; on a folder's menu `{folder}` is the folder right-clicked. Without `question` and `name`, the file is Untitled and opened for renaming. |
| `{ask: {question, description?, yes}}` | Asks first; `yes` is the action run on Yes. |

### Running an item

`cosm.ui.run("<package>:<item>", on?)` does what choosing an item does, by its id, wherever it is placed and whoever asks
(a view drawing it, another package's code, the shell's `cosm ui run stamp:stamp`): it runs as the package that
made the item, its function given what it is used on (`on`: `{path}` or `{folder}`) and the thing its view shows. A view that
draws items another package placed in it runs them this way. Something a package's code does itself has its own call
(`cosm.ui.open`, `cosm.call("agent-session:send", …)`, `cosm.ui.ask`); an item is how the user chooses it. What should work without the
window is a function the package exports (`cosm.package.export`; other packages `cosm.call("<package>:<name>")`) or
a command (`cosm:commands`, the agent's tool), and an item for the same thing calls the same code.

Building a package, try an item's function by hand, without the window: `cosm package try item <package> <item>
[--path <file>] [--folder <folder>]` prints what it returns and answers yes to a question it asks first
(`cosm package try event` does the same for event handlers, events.md).

### Content from a function

Content may be a function, given `{thing}` (the thing the view it shows in shows, when it shows one), answering an
object (with `label`, it takes the place of the item's own words) or `null` to hide the item. It is worked out once
for each thing shown, and again when what it depends on changes: give it as `{ run, changes }`, `changes` as a view
function's (Live data, above: files, storage keys, data, events). A bare function is worked out again only when the
packages change. Time passing is no change: a look that depends on the day names an event of the package's that a
schedule of its fires (`daily 00:00`, Keeping time in events.md), and is worked out again with it. It only reads: one that writes or emits what it depends
on runs again and again. Star chart's session button and reminder line:

```ts
// The holder shows a conversation as Agent session's thing: `agent-session:session:<id>`.
const conversation = (thing?: string) => thing?.startsWith("agent-session:session:") ? thing.slice("agent-session:session:".length) : undefined;
cosm.point.add("cosm:items", { name: "reflect", label: "Reflect", location: { in: "agent-session:holder" },
  action: ({ thing }) => { const session = conversation(thing); return session ? cosm.call("agent-session:send", { session, message: { prompt: "reflect" } }) : "No session is open."; },
  // done: when Reflect ran in this conversation (the session's menu ticks it while it is set).
  content: { changes: { events: "agent-session:storage.changed" },
    run: async ({ thing }) => ({ icon: "bulb", done: conversation(thing) ? await cosm.call("agent-session:storage-get", { session: conversation(thing), key: "reflected" }) : null }) } });
cosm.point.add("cosm:items", { name: "review-due", label: "Weekly review due", location: { in: "agent-session:holder" },
  action: ({ thing }) => cosm.call("agent-session:send", { session: conversation(thing)!, message: { prompt: "review" } }),
  content: { changes: { storage: "last-review" }, run: async () => ((await reviewIsDue()) ? { label: `Weekly review due: the last one was ${await daysSince()} days ago.` } : null) } });
```

Keep it quick: read a count, not the whole cosm. Say a value for what it is (`done`: when), not `true`.

### A view reading its items

A view that takes items defines a place for them (`cosm.point.define("tree", { holds: "values", description })` in
its package's main.ts) and reads them with `cosm.ui.items(place)`, the place's name (usually its own): each `{id, name, package,
label, content, open?, arg?}`, labels and content already worked out for the thing the view shows (`open` and `arg`: what one that opens something opens, as its action says it); a click is `cosm.ui.run(it.id)`.
When they change it hears `ui.changed` with `{items}` (the items' names, `["*"]` when packages changed); read again then:

```js
const draw = async () => {
  const items = await cosm.ui.items(cosm.view.name);
  bar.replaceChildren(...items.map((it) => {
    const b = Object.assign(document.createElement("button"), { textContent: it.label, title: it.content.description ?? "" });
    b.onclick = () => cosm.ui.run(it.id).catch((e) => cosm.ui.notify(e.message));
    return b;
  }));
};
cosm.on("ui.changed", (d) => { if (d.items) draw(); });
draw();
```

`cosm.ui.items` reads any place the same way (`"palette"`, `"file-menu"`).

### Icons

An icon is optional, and is one of two things. A name is one of the icons the packages that are on add to Cosm's point
`cosm:icons` (`cosm point read cosm:icons`): Cosm's own come from the built-in Cosm icons package (`archive`, `bulb`,
`chat`, `check`, `dot`, `folder`, `inbox`, `page`, `star`, `sync`, `table`, `terminal`, `trash` …). A name is reached
bare while no earlier package has it, and always in full (`cosm-icons:inbox`). A package adds icons the same way,
for itself and for others to name:

```ts
cosm.point.add("cosm:icons", { name: "basket", svg: await cosm.package.file.read("icons/basket.svg") });
```

An icon may also be an SVG itself, as text, read from its file where it is used (`cosm.package.file.read`, package.md):

```ts
const book = await cosm.package.file.read("icons/book.svg");
cosm.point.add("cosm:views", { name: "reading", file: "views/reading.html", label: "Reading list", icon: book });
```

An SVG given as text is drawn as a mask in the theme's colour; one added to `cosm:icons` is drawn in `currentColor`.
Either way draw it in one colour on a transparent ground (13 by 13 works). `check` refuses a name no package that is
on has. The kit's `<cosm-icon name="…">` draws either (an item's `content.icon` or a view's `icon`, as it is given);
in a view, `cosm.ui.icon.list()` gives every icon the window handed it, with its SVG text.

## Hover boxes

An element's `title` shows as the window's hover box, in the theme's colours, as the pointer or the keyboard reaches
it: a button that is only an icon gets one (`title="Archive"`). A last part in brackets is its key, shown faint:
`title="New page [⌘N]"`. Nothing else to write; the system's own tooltip never shows.

## Menus

A file's or folder's right-click menu is the window's, the same everywhere: Open, Open With, what packages add for
it, Rename, Move to Trash (a folder's: New … Here first). A view gives it to anything it draws that stands for a file or
folder by marking it, as a web link opens in the browser: a right-click on an element with `data-cosm-file="<path>"`
(or `data-cosm-folder="<path>"`) shows that menu at the pointer. The kit's rows and tree mark themselves; the toolbar is
the window's own.

```html
<div class="card" data-cosm-file="Weeks/2026-W45.md">This week</div>
```

The menu's Rename asks the view the row is in to rename it in place (`view.rename`).

A view's own menu (a button that gives choices) is the window's too: `cosm.ui.menu(rows, {at, current, find})` shows
the rows under `at` (an element of the page; else at the pointer), drawn by the window over every view, so it floats
over the views around it however deep the view is placed. A row is `{id, label, hint?, items?}` (`items`: its own
options, behind ⋯ on the row), `{heading}`, or `"separator"`; `current` is the id (or ids) ticked; `find` adds a find
field over the rows (its placeholder). It answers what was chosen as the path of ids (`["c-7k2p"]`, or
`["c-7k2p", "rename"]` for a row's option), or null when closed with nothing chosen. A press on `at` while it is
open closes it.

```js
button.addEventListener("click", async () => {
  const picked = await cosm.ui.menu([
    { id: "chat", label: "Chat" },
    { id: "terminal", label: "Agent terminal" },
  ], { at: button, current: shown });
  if (picked) show(picked[0]);
});
```

## Asking and telling

- `cosm.ui.notify(text)`: a notice in the window. `{as: "problem"}` stays until dismissed, with what packages place on problems (`notice`: Agent session's Ask the Agent).
- `cosm.ui.progress(title, async (progress, signal) => …)`: long work the user sees where notices show and can cancel (a first mail fetch, an import, a conversion). `progress({message, done})` says how far it is (`done` from 0 to 1; without it, a running line); Cancel aborts `signal`, so pass it on (`fetch`, `Bun.spawn`) or check it between steps. It goes when the function returns (its answer is progress's) or throws (thrown on: a button's action that fails is a problem notice, background work's throw is in the package's log; to tell the user more, `cosm.ui.notify` it yourself). In main.ts and views alike:

```ts
await cosm.ui.progress("Importing expenses.csv", async (progress, signal) => {
  for (let i = 0; i < rows.length; i += 100) {
    if (signal.aborted) return;
    await insert(rows.slice(i, i + 100));
    progress({ message: `${i + 100} of ${rows.length} rows`, done: (i + 100) / rows.length });
  }
});
```
- `cosm.ui.ask(question, options?)`: asks the user; their answer, or `null` when they dismissed it. `choices: [...]`
  are its buttons (the answer is the one chosen); `answer: "text"` takes a line of text; neither is Yes / No. The
  window always gives a way out (Cancel beside the choices, except beside Yes / No; Escape; a click outside), which
  answers `null`: don't add a Cancel or Not now of your own (`choices: ["Sign in"]`, not `["Sign in", "Not now"]`).
  `description` is the line under it; `in: "background"` asks as a card in the corner instead of a sheet that takes
  the keyboard. Any window answers it, one opened later too.

```js
const name = await cosm.ui.ask("What is the recipe called?", { answer: "text" });
if (name === null) return;   // dismissed
const how = await cosm.ui.ask("Double it?", { choices: ["Double", "Keep"], description: "Every amount times two." });
```

Both work in `main.ts` too.

## The kit

Standard elements, drawn in the page itself (no shadow root), so the page's own CSS can restyle them. Every one takes
`hidden` (hidden until the page takes it away). They draw what the view gives them and never fetch: no package calls,
files, storage or events of their own.

```html
<cosm-toolbar label="This week"></cosm-toolbar>
<cosm-find></cosm-find>
<main>
  <h1>This week</h1>
  <cosm-list call="week" empty="Nothing planned yet."></cosm-list>
</main>
```

| Element | Attributes and properties | What it is |
|---|---|---|
| `<cosm-list>` | `.from` (a live value), `.items` (rows), `call`, `empty` | A list of rows: label, the line under it, at the right the date in words (Today, Yesterday, a weekday, "21 Oct"), else `right`, else `count`; rows with a `group` after the others under its heading. A click opens a row's `open`; a row opening a file is marked for its menu (`data-cosm-file`); the row of what is on screen is lit. |
| `<cosm-table>` | as `<cosm-list>`, and `columns` | The same rows as a table. `columns='[{"key": "amount", "label": "Amount", "align": "right"}]'` (JSON) names its columns; without it, the row's own (label, line, date, right, count) that any row has. Numbers grouped and at the right, ISO dates as "21 Oct", empty as a dash. |
| `<cosm-item>` | `label`, `icon`, `count`, `open`, `arg`, `line`, `date`, `right`, `group`; children `slot="actions"` | One row. Inside a list or table, one of its rows; on its own, a row (icon, label, the line, count) opening `open`, lit while that is on screen, its children marked `slot="actions"` (buttons) at its right, apart from its own click. `slot` here is a kit convention the element reads, not the browser's slots. |
| `<cosm-button>` | `open` (with `arg`), `primary`, `disabled` | A button in Cosm's look: what a click does is the page's own (`addEventListener("click", …)`, often `cosm.main.<fn>()`), or `open` opens something (`cosm.ui.open`). Enter and Space click it. |
| `<cosm-tree>` | `.from` (a live value of the tree), `.layout`, `.others`, `.folds` and its `folds` event, `.move`; `folder` | The cosm's files and folders with File tree's behaviour: a click opens a file, or opens a folder (`cosm.ui.open`, which a package answers: `folder.opened`) and unfolds it; rename in place (`view.rename`) and drag to move, both through `.move = (from, to) => …` (the view's package's main.ts); a right-click is the window's menu; arrow keys and Enter; what is on screen lit and unfolded to. `layout`: `{sections: [{folder, label, sort: "name" \| "recent", show: "link", icon, items}], foot: [items], hidden: [globs]}`, items as `"<package>:<item>"`. `others` false hides files no view shows. File tree's own view is one. |
| `<cosm-toolbar>` | `label`, `readonly`, `nav`, `note`, `menu`, `over`; children `<cosm-toolbar-button>` | Where the view's header goes: the window draws it there, the same bar in every pane, and the view says what is in it. By default, as for a page: back and forward in its pane, where it is (its folders: a click opens one), its name (a click renames the file it shows in place, not with `readonly`; a right-click gives the file menu, where Open With is); with no argument, `label` is the name. `nav="off"`: no history and no folders, the view's own title (`label`) with `note`, a quiet word, beside it. `menu`: the title opens a menu of the view's own: the toolbar hears `title`, its `detail` the title's rect for `cosm.ui.menu(rows, { at: e.detail })`. `<cosm-toolbar-button icon="plus" label="New">`: icon buttons at its right, in order, each a `click` of its own (`detail`: its rect); `dot` marks one where something waits, `hidden` leaves it out. `over`: what the view holds passes under it (a view placed in it, Agent session's holder), so it is always the see-through material. A view placed in another starts below that one's bar (`--inset-top`) and scrolls under it. It drags the window. |
| `<cosm-find>` | property `finder` | The view's find bar: hidden until ⌘F (`view.find`); Enter finds the next, ⇧Enter the one before, Escape closes. Without a `finder` it finds in the page's text; a view with its own text (an editor) sets `finder = (words, step) => ({count, current})`, `step` `"next"`, `"previous"` or `"close"`. |
| `<cosm-icon>` | `name` | An icon by name (Icons, above), in the text's colour. |
| `<cosm-place>` | `point`, `show`; properties `views`, `show`; event `change` | Where a view shows the views placed in one of its package's places (`point`; the view's own name without it) (Views in views): one at a time, `views` the ones placed here (`[{view, label, icon?}]`), `show` the one shown (set it to switch; the attribute picks the one to start with, else the first). `change` fires when either changes. |
| `<cosm-terminal>` | `process`, `size` | A process's terminal, drawn here (Terminals, below). `size`: its text size in pixels. |

`<cosm-place>` and `<cosm-terminal>` take the rest of a column (`flex: 1`): give their page `html, body { height: 100%;
margin: 0 } body { display: flex; flex-direction: column }`.

**A list's rows** come from a live value (`.from=${articles}`: its rows, and its status shown the same way in every
list: a skeleton while it first loads, what is there while it reloads, the empty line, a failure as a line, or under
the rows that stay), plain rows the view has (`.items`), child `<cosm-item>`s, or `call="<fn>"`, a shortcut for a list
and nothing else: a live value of that view function inside, given `{ arg }`, the view's argument. A view that also
shows a count makes the live value itself and hands it to the list, so it is fetched once. A function may give a list
of rows, one row, or `null` (none). `empty="…"` shows once loaded with none: the page owns its empty state.

**A row**: `{label, line?, date? ("2026-10-21", or "2026-10-21T09:14" to show the time), right?, count?, icon?, open?
(a file of the cosm, a view "package:view", a web address), arg? (the view's argument), group?}`; any other key is a
column for a table.

**Plain HTML looks like Cosm.** The kit's stylesheet gives a page's own `<button>` (`type="submit"`: in the accent
colour), `<input>`, `<select>`, `<textarea>`, checkboxes, headings, links, `<code>`, `<pre>`, `<table>`, `<hr>` Cosm's
look without a class. All of it counts for nothing in the cascade (`:where()`): any rule of the page's own wins. A part
of the page that draws itself turns it off with `data-cosm-plain="off"` (on a `<div>`: that part; on `<body>` or
`<html>`: the whole page).

**The kit's patterns** are classes for what a view draws itself, each on the theme's colours and the kit's sizes
(`--space-1` … `--space-7`, `--radius-sm` … `--radius-xl`, `--ui-size`, `--small-size` …). The Style guide package shows
every one with the markup that draws it (Settings → Packages, then ⌘K, Open Style Guide); by job:

| Job | Classes |
|---|---|
| A page | `cosm-page`, `cosm-page-head`, `cosm-page-title`, `cosm-page-subtitle`, `cosm-page-head-actions`, `cosm-page-body`; `cosm-section`, `cosm-section-head`, `cosm-section-title` |
| Buttons | `cosm-button` with `primary`, `quiet`, `danger`, `link`, `small`, `large`, `icon`; `cosm-button-group` |
| Fields | `cosm-form`, `cosm-field`, `cosm-field-label`, `cosm-field-hint`, `cosm-field-error` (with `aria-invalid="true"`; the kit ties a field's label, hint and error to its control), `cosm-field-row`, `cosm-input-group`, `cosm-input-addon`, `cosm-number`, `cosm-switch`, `cosm-check`, `cosm-disclosure`; `<cosm-tabs>` and `<cosm-segmented>` (the value the view's: `.value`, `value="…"`, and a `change` event `{detail: {value}}`; one tab stop, arrow keys) |
| Settings and details | `cosm-group`, `cosm-group-row`, `cosm-group-label`, `cosm-group-value`, `cosm-group-foot`, `cosm-label-head`; `cosm-pairs` |
| Collections | `cosm-list`, `cosm-list-row`, `cosm-list-main`, `cosm-list-title`, `cosm-list-line`, `cosm-list-meta` (what `<cosm-list>` draws); `cosm-table-wrap`, `cosm-table` (what `<cosm-table>` draws); `.filter` on a `<cosm-list>` keeps what a search matches, and says No matches with a `clear` event; `class="grouped"` on a list for a queue the user works through (an inbox), with `cosm-list-tail`, `cosm-list-actions` (shown on hover, in place of the date), `cosm-list-foot`; `cosm-tasks`, `cosm-task` |
| Things to say | `cosm-notice` (`accent`, `ok`, `warn`, `danger`), `cosm-badge`, `cosm-dot`, `cosm-stats`, `cosm-stat`; `cosm-tags`, `cosm-tag` (`selected`, or a palette hue: `teal` …), `cosm-tag-remove` |
| States | `cosm-empty` (`cosm-empty-title`, `cosm-empty-line`, `cosm-empty-actions`), `cosm-skeleton line` (a first load), `cosm-spinner` (an action), `cosm-progress` |
| Layout and text | `cosm-card`, `cosm-stack`, `cosm-hstack`, `cosm-grid`, `cosm-split`; `cosm-title`, `cosm-subtitle`, `cosm-caption`, `cosm-muted`, `cosm-faint`, `cosm-count` (in a `cosm-page-title`: a pill beside the title), `cosm-truncate`, `cosm-sr`; `cosm-prose` for anything to read |
| Reactions (the kit's, no code) | `aria-busy="true"` on a button while working, `data-done="Saved"` for its ✓ after; `data-copy="#id"` copies that element's text; a `cosm-stat-value` (or `data-roll`) rolls to a new number; a `cosm-badge` or `cosm-count` bumps when it changes; a `progress.cosm-progress` at its end says ✓ |
| A side pane | `cosm-row` (a side-pane row), `cosm-heading` (its section heading), `cosm-side` on `<body>` (the pane's colour) |

## Terminals

A terminal is a program the package runs as one of its processes, in a terminal (`cosm.process.start(name, {program,
as: "terminal"})`, package.md); a view draws it with the kit's `<cosm-terminal process="<package>:<name>">`. The process
is the package's: it runs on through the view closing or loading again, the package's code loading again and the
window closing, until it ends or the package stops it. The element attaches to it (what it wrote lately, then as it
comes), sends what is typed and follows the element's size; its `ended` event (`{detail: {code}}`) says the program
ended. `size`: its text size in pixels. Its colours are the theme's terminal colours, else Cosm's; a `cosm://<path>`
link in it opens that page. The element is a bundle of its own (xterm.js), given only to a view whose page has one.

A view can draw a process its own way instead: `cosm.process.attach(name, (text) => …, {ended})` gives what it writes,
as text, and `cosm.process.write` and `resize` reach it.

`packages/agent-terminal/` is the real one: a view placed in Agent session's holder, drawing the conversation's agent
in a terminal, which its connector runs as its process `terminal-<session>` (named by
`cosm.call("agent-session:running", {session})` and started through Agent terminal's own `main.ts` with
`cosm.call("agent-session:start", {session, as: "terminal"})`, agents.md), its text size the package's setting:

```html
<style>html, body { height: 100%; margin: 0; } body { display: flex; flex-direction: column; }</style>
<cosm-terminal></cosm-terminal>
<script type="module">
  import { live } from "cosm/view";
  const term = document.querySelector("cosm-terminal");
  const size = live(cosm.main.textSize);                        // the setting, kept up to date
  size.subscribe(() => term.setAttribute("size", String(size.value ?? 13.5)));
  async function show(session) {
    const { name } = await cosm.main.terminal({ session, start: true }); // its main.ts starts it when it isn't running
    term.setAttribute("process", name);
  }
  void show(cosm.view.arg);
</script>
```

## Editing a file: cosm.file.open

A view that edits its file goes through a handle, never `cosm.file.write`. The window keeps the file's record, as for
every file open on screen: it saves only on top of the version it read; when someone else changed the file meanwhile
(the agent, a package, a sync), the file's kind merges the two (its `merge`, files-and-kinds.md), and when it can't,
nothing is written and the user chooses (Keep mine, Keep theirs, Compare). A save goes through the before-events too
(`file.saved.before`, events.md).

`const f = await cosm.file.open(path)` opens the file the view shows (its `arg`) and gives a handle; each call gives one
of its own. Any other file is refused: what else a view shows of the cosm comes from its package's `main.ts`. A file
that isn't text (an image, a PDF) opens read only: `f.read({ bytes: true })`, `changed`, `moved` and `trashed`; `write`
is refused.

| On the handle | What it is |
|---|---|
| `f.path`, `f.modified` | Its path (it follows a move), and when it was written (seconds since 1970). |
| `f.read()`, `f.read({bytes: true})` | Its content now: as opened, or as last changed underneath. |
| `f.write(content)` | After every change on screen, at once, the whole content as it now stands; Cosm saves it when it sees fit. |
| `f.sync()` | Saves what is unsaved now: when typing leaves the page. |
| `f.on("changed", ({why}) => …)` | It changed underneath: read it again and show it, keeping the cursor, not as a step of the user's undo. `why`: `changed` (someone else), `merged` (a save merged with such a change), `theirs` (the user chose Keep theirs), `edited` (another view of the same file). |
| `f.on("moved", ({path}) => …)`, `f.on("trashed", () => …)` | It moved, or went to the trash. |
| `f.close()` | When the view shows it no more: saved first, then let go. |

```js
let file = null, asked = 0;
async function show(path) {
  const mine = ++asked;
  if (file) { void file.close(); file = null; }   // the one before: saved, then let go
  box.value = ""; box.disabled = true;           // nothing typed until the next is open
  if (!path) return;
  const f = await cosm.file.open(path);
  if (mine !== asked) { void f.close(); return; }   // another file was asked for meanwhile
  file = f;
  box.value = await f.read(); box.disabled = false;
  f.on("changed", async () => { const at = box.selectionStart; box.value = await f.read(); box.setSelectionRange(at, at); });
}
box.addEventListener("input", () => file?.write(box.value));
box.addEventListener("blur", () => file?.sync());
cosm.on("view.opened", ({ arg }) => show(arg));
cosm.on("view.closed", () => show(null));
cosm.on("view.focus", () => box.focus());
show(cosm.view.arg);
```

Plain text's editor (its built view in Plain text's folder, `views/editor/`: `cosm package list` gives the folder) is
the whole thing: its own undo per file, every find match marked through `<cosm-find>`'s `finder`, and the selection
published as its own `selection` fact (`cosm.view.publish`), read by others in `cosm.ui.shown()`.

## Theme

Set on the page's `:root`, and changed in place when the user changes the theme or a text setting (the page isn't
loaded again):

| Variable | What it holds |
|---|---|
| `--page`, `--side`, `--chat`, `--card`, `--bubble`, `--text`, `--muted`, `--faint`, `--title`, `--bullet`, `--line`, `--line-strong`, `--sel`, `--fill`, `--fill-strong`, `--accent`, `--onaccent`, `--ok`, `--warn`, `--danger`; the palette `--red`, `--orange`, `--yellow`, `--green`, `--teal`, `--blue`, `--purple`, `--pink`; worked out from them `--flash`, `--selrow`, `--accent-soft`, `--ring`, `--group`, `--ok-soft`, `--warn-soft`, `--danger-soft`, `--red-soft` … `--pink-soft` | The theme's colours (themes.md). `--flash`: what just changed, a find's current match; `--selrow`: a selection, the other matches. A meaning colour for what a thing means (`--danger` on a failure), a palette hue for telling unrelated things apart (a tag, a chart series). |
| `--text-font` | The text font (Settings → Appearance), as a whole `font-family` list. For a page's text. |
| `--code-font` | The code font, the same way. For code, and text whose spaces must line up. |
| `--text-size` | The text size, with its unit (`16px`). Size the rest of the text in `em` from it. |
| `--ui-font` | The interface's font, which no setting changes: for buttons, labels and small print. |
| `--ui-size`, `--small-size` | Interface text (rows, menus, buttons, labels) and small print (hints, counts): Cosm's own sizes. Use them rather than a number of the page's own. |
| `--text-line` | Page text's line height, with `--text-size`. |
| `--code-size` | Code within text (`0.9em`). |

Give each a fallback (`var(--text-size, 16px)`) so the page also looks right opened on its own.

Each colour has this one name. Other kits' names (shadcn's `--background`, `--foreground`, `--primary`, `--border` …)
aren't set: `cosm package check` says Cosm's name for each a view uses, and warns on a colour a view fixes itself
(`#fff`, `rgb(…)`) outside a `var(--x, …)` fallback, a shadow or a mask.

Colour with `var(--…)`, in CSS, an inline style or an SVG's `style`, and the view follows a new look by itself. Only
drawing that copies a colour's value (a canvas, a library handed colours, `getComputedStyle` read once) has to draw
again: it hears `theme.changed` (`{dark}`), told once the variables are the new ones:

```js
cosm.on("theme.changed", () => drawChart());
```

## A complete example

`reading-list`: pages to read later, in a folder of its own, `Reading list/`. A row in the sidebar opens a page listing
them, with a search and Done on each (a TypeScript view on `cosm/view`, its rows a live value that follows the folder);
⌘K offers Save a Link…; File → New makes one; a page's right-click menu files it as read; the chat has a button
asking the agent what to read next, and a reminder line while too many wait. The folder is the package's own, named
for what it holds: a package knows no other's layout.

`cosm.json`:

<!-- example: reading-list/cosm.json -->
```json
{
  "name": "reading-list",
  "label": "Reading list",
  "description": "Pages to read later, kept in one folder: a list of them, a reminder when too many wait, and the agent's pick of what to read next.",
  "version": "1.0.0",
  "cosm": ">=1.0"
}
```

`main.ts`:

<!-- example: reading-list/main.ts -->
```ts
import type { Cosm } from "cosm";
import { shape } from "cosm/shape";

const DIR = "Reading list";

export default async function (cosm: Cosm) {
  cosm.package.uses("agent-session");
  const book = await cosm.package.file.read("icons/book.svg");
  const article = await cosm.package.file.read("templates/article.md");
  cosm.point.add("cosm:kinds", { name: "article", extends: "markdown:page", match: `${DIR}/*.md`, label: "Article", template: article });
  cosm.point.add("cosm:settings", { name: "most", shape: shape.number({ min: 1, max: 100 }), default: 10, label: "Remind me when more than this many wait" });

  cosm.point.add("cosm:views", { name: "reading", file: "views/reading.html", label: "Reading list", icon: book });
  cosm.point.add("cosm:items", { name: "open", label: "Reading list", content: { icon: book },
    action: { open: "reading-list:reading" }, location: { in: "file-tree:tree" } });

  cosm.point.add("cosm:items", { name: "save-link", label: "Save a Link…", content: { description: "A web page to read later" }, location: { in: "palette" },
    action: async () => {
      const address = await cosm.ui.ask("The page's address?", { answer: "text" });
      if (!address) return;
      const why = await cosm.ui.ask("Why read it?", { answer: "text" });
      // Named after the address's last part, never over another page.
      const name = address.replace(/[?#].*$/, "").replace(/\/+$/, "").split("/").pop()!.replace(/\.[a-z]+$/, "").replace(/[-_]+/g, " ") || "link";
      let path = `${DIR}/${name}.md`;
      for (let n = 2; await cosm.file.stat(path); n++) path = `${DIR}/${name} ${n}.md`;
      await cosm.file.write(path, `# ${name}\n\nWhy read it: ${why ?? ""}\n\nAddress: ${address}\n`);
      return "Saved to your reading list";   // a string is shown as a notice
    } });

  cosm.point.add("cosm:items", { name: "new-article", label: "New Article…", location: { in: "menu-bar", menu: "File" },
    action: { new: { kind: "article", folder: DIR, name: "{name}", question: "What is it called?" } } });

  cosm.point.add("cosm:items", { name: "done", label: "Done Reading", location: { in: "file-menu", kind: "article" },
    action: async ({ path }) => { if (path) await cosm.file.move(path, `${DIR}/Read/${path.slice(path.lastIndexOf("/") + 1)}`); } });

  // "What next?": the read-next command in the conversation it was chosen on (Agent session's thing,
  // `agent-session:session:<id>`), else the one on screen used last, else a new one (Agent session's). Its
  // button in the chat, and its view's button, do the same.
  const SESSION = "agent-session:session:";
  const conversation = (thing?: string) => (thing?.startsWith(SESSION) && !thing.endsWith(":") ? thing.slice(SESSION.length) : undefined);
  const readNext = async (thing?: string) => {
    const on = (await cosm.ui.shown()).filter((x) => conversation(x.arg)).sort((a, b) => b.used.localeCompare(a.used));
    const s = conversation(thing) || conversation(on[0]?.arg) || String(await cosm.call("agent-session:start"));
    await cosm.call("agent-session:send", { session: s, message: { prompt: "read-next" } });
  };
  cosm.point.add("cosm:items", { name: "read-next", label: "What next?", content: { icon: "star" },
    action: ({ thing }) => readNext(thing), location: { in: "agent-session:holder" } });

  cosm.point.add("cosm:items", { name: "waiting", label: "Pages wait in your reading list", action: { open: "reading-list:reading" }, location: { in: "agent-session:holder" },
    content: { changes: { files: `${DIR}/*.md`, events: "setting.changed" }, run: async () => {
      const n = (await cosm.file.list(`${DIR}/*.md`)).length;
      return n > (await cosm.setting.get<number>("most")) ? { label: `${n} pages wait in your reading list` } : null;
    } } });

  // Its view's functions (views/reading.ts calls them; nobody else does). `articles` is kept live: it reads again when
  // a page in the folder changes, whoever changed it (the agent, Done, Finder).
  return cosm.view.export({
    articles: {
      description: "The pages waiting to be read, newest first, each with why it was saved.",
      changes: { files: `${DIR}/*.md` },
      run: async () => {
        const paths = await cosm.file.list(`${DIR}/*.md`);
        const all = await Promise.all(paths.map(async (path) => {
          const [text, stat] = await Promise.all([cosm.file.read(path), cosm.file.stat(path)]);
          return { path, title: path.slice(DIR.length + 1, -3), why: /^Why read it: (.*)$/m.exec(text)?.[1] ?? "", modified: stat?.modified ?? 0 };
        }));
        return all.sort((a, b) => b.modified - a.modified);
      },
    },
    done: {
      description: "Moves a page to Read/: it leaves the list.",
      input: shape.object({ path: shape.string() }),
      run: ({ path }: { path: string }) => cosm.file.move(path, `${DIR}/Read/${path.slice(path.lastIndexOf("/") + 1)}`),
    },
    readNext: () => readNext(),
  });
}
```

`views/reading.html`:

<!-- example: reading-list/views/reading.html -->
```html
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Reading list</title>
</head>
<body>
<cosm-toolbar label="Reading list"></cosm-toolbar>
<div class="cosm-page" id="root"></div>
<script type="module" src="reading.ts"></script>
</body>
</html>
```

`agent/prompts/read-next.md`, what the button has the agent do (agents.md):

`views/reading.ts`, the view's module (built by Cosm, `cosm/view` from the window):

<!-- example: reading-list/views/reading.ts -->
```ts
// The reading list: what waits in the folder, a search over it (the list keeps what matches), Done on each, and "What
// next?" for the agent's pick.
// Everything comes from this package's main.ts (its view functions); `articles` is kept live, so a page the agent
// saves, Done, or a move elsewhere shows by itself.
import { html, live, show, state, view } from "cosm/view";
import type { ApiOf } from "cosm";
import type main from "../main.ts";

const cosm = view<ApiOf<typeof main>>();
const articles = live(cosm.main.articles);
const search = state("");

show("#root", () => {
  const all = articles.value ?? [];
  const words = search.value.trim().toLowerCase();
  return html`
    <header class="cosm-page-head">
      <div><h1 class="cosm-page-title">Reading list ${articles.value ? html`<span class="cosm-count">${all.length}</span>` : ""}</h1></div>
      <div class="cosm-page-head-actions"><button class="cosm-button primary" @click=${() => cosm.main.readNext()}>What next?</button></div>
    </header>
    <main class="cosm-page-body cosm-stack">
      ${all.length ? html`<div class="cosm-input-group"><input type="search" placeholder="Find in the list" aria-label="Find in the list" .value=${search.value}
        @input=${(e: Event) => { search.value = (e.target as HTMLInputElement).value; }}></div>` : ""}
      ${articles.status === "loading" ? html`<div aria-hidden="true"><div class="cosm-skeleton line"></div><div class="cosm-skeleton line"></div><div class="cosm-skeleton line"></div></div>`
      : articles.status === "failed" && !articles.value ? html`<div class="cosm-empty" role="status"><p class="cosm-empty-title">Couldn't load the list</p><p class="cosm-empty-line">${articles.error?.message}</p></div>`
      : !all.length ? html`<div class="cosm-empty"><p class="cosm-empty-line">Nothing waiting to be read. Save a link from ⌘K.</p></div>`
      : html`<cosm-list class="grouped" key="open" .filter=${words ? (r: { label: string; line?: string }) => `${r.label} ${r.line ?? ""}`.toLowerCase().includes(words) : null}
          @clear=${() => { search.value = ""; }}>${all.map((a) => html`
          <cosm-item label=${a.title} line=${a.why} open=${a.path}>
            <button slot="actions" class="cosm-button small" @click=${() => cosm.main.done({ path: a.path })}>Done</button>
          </cosm-item>`)}</cosm-list>`}
      ${articles.status === "failed" && articles.value ? html`<p class="cosm-caption" role="status">${articles.error?.message}</p>` : ""}
    </main>`;
});
```

<!-- example: reading-list/agent/prompts/read-next.md -->
```markdown
---
description: Pick the one page to read next from the reading list
---
# Read next

The pages waiting: !`cosm index find kind=reading-list:article`

Read the first lines of each, weigh them against what the user is working on now (the spaces changed most recently),
and recommend one, in two lines: which, and why now. Link it by its name. Don't list the others.
```

`templates/article.md`, a new article's starting text (`{name}` filled in):

<!-- example: reading-list/templates/article.md -->
```markdown
# {name}

Why read it:

Address:
```

`icons/book.svg`, one colour on a transparent ground:

<!-- example: reading-list/icons/book.svg -->
```
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 13 13"><path d="M2 2.5C2 1.7 2.7 1 3.5 1H11v9H3.5c-.8 0-1.5.7-1.5 1.5V2.5zM2 11.5c0 .8.7 1.5 1.5 1.5H11v-1.5" fill="none" stroke="black" stroke-width="1.2"/></svg>
```

```sh
cosm package check reading-list
cosm package on reading-list        # after the user's y
cosm ui open reading-list:reading
```

`examples/glance/` draws a page from functions its `main.ts` exports (`cosm.main.folders()`, `<cosm-list
call="recent">`); `examples/images/` is a file's view, kept, reading the file's bytes.
