import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:views", { name: "board", file: "views/board.html", label: "Board", input: "file" });
  cosm.point.add("cosm:kinds", { name: "meeting", extends: "markdown:page", match: "meetings/**/*.md", label: "Meeting note", view: "board" });
}
