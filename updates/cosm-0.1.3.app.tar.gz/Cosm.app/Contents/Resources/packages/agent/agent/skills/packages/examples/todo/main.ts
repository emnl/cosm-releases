import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  /** Every unticked "- [ ]" line in the cosm's pages: the task, its page's name under it, opening the page. */
  async function tasks() {
    const rows = [];
    for (const path of await cosm.file.list("**/*.md")) {
      for (const m of (await cosm.file.read(path)).matchAll(/^\s*- \[ \] (.+)$/gm)) {
        rows.push({ label: m[1], line: await cosm.file.name(path), open: path });
      }
    }
    return rows;
  }

  cosm.point.add("cosm:views", { name: "list", file: "views/list.html", label: "To do", icon: "check" });
  cosm.view.export({ tasks: { run: tasks, changes: { files: "**/*.md" } } });
  cosm.point.add("cosm:items", { name: "show", label: "Show To Do", location: { in: "palette" }, action: { open: "todo:list" } });
  cosm.point.add("cosm:commands", { name: "list",
    description: "Every unticked task in the cosm's pages, with its page.",
    run: async () => (await tasks()).map((t) => `${t.label} (${t.open})`),
  });
}
