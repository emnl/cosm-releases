---
description: Pick the one page to read next from the reading list
---
# Read next

The pages waiting: !`cosm index find kind=reading-list:article`

Read the first lines of each, weigh them against what the user is working on now (the spaces changed most recently),
and recommend one, in two lines: which, and why now. Link it by its name. Don't list the others.
