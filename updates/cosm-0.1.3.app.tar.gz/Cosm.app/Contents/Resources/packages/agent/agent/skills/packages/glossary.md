# Glossary

One meaning per word, across `cosm.json`, `main.ts`, views and the `cosm` command. When a word here is used in the
guide, it means this and nothing else. The names in code are those of the SDK (`share/sdk/cosm.d.ts`).

Shortcuts are written as on a Mac (⌘K, ⇧⌘G). On other systems ⌘ is Ctrl (Ctrl+K, Ctrl+Shift+G), and the window shows
them that way. Tell the user a shortcut the way their system writes it.

## The cosm and its packages

| Word | Meaning |
|---|---|
| **cosm** | One folder of the user's notes and files, opened in Cosm. Lowercase. Cosm (capitalised) is the app. |
| **engine** | The `cosm` command's service, one per cosm, started by the first call that needs it: it watches the cosm, keeps the index, fires the events and runs the packages, with or without a window. The window, the agent and every package are its clients. |
| **package** | A folder with a `cosm.json`: everything Cosm does beyond its small engine. Built in, the cosm's own (`.cosm/packages/<name>/`), or used from a folder on this computer. |
| **`cosm.json`** | Who a package is: `name`, `label`, `description`, `version`, `cosm`. Nothing else. |
| **`main.ts`** | A package's code: a default-exported function given `cosm`, which registers what the package adds. |
| **register** | Add something to Cosm from `main.ts`'s default function (`cosm.point.add`, `cosm.on` …). Only while that function runs; a later call throws. |
| **worker** | Where a package's code runs: one Bun process for all packages, a worker each, so a stuck package holds up only itself. |
| **API version** | `"cosm": ">=1.0"` in `cosm.json`: the version of Cosm's API the package is written for. A later minor only adds; another major is another API. |
| **uses** | The packages a package can't do without, worked out from what it registers (a kind it extends, a command it sends, an event of theirs it handles …). It isn't switched on while one it uses is off. |
| **library** | An npm package a package uses, named in its `package.json` and pinned in `bun.lock`; Cosm installs it. |
| **stale** | A package whose saved `main.ts` doesn't load: the last version that loaded runs on, and everything the agent reads says so. |
| **name** | The identifier of anything a package registers or ships: kebab-case (`git-sync`, `sign-in`), stable. A package's name is its folder's name. |
| **reference** (`Ref`) | A name pointing at another package's thing, `<package>:<name>` (`markdown:page`, `star-chart:recall`); a bare name is the package's own. `cosm.call` always takes it in full. |
| **path** | A file or folder of the cosm, named from the cosm's folder (`notes/Plan.md`), wherever it is called from. |
| **glob** | A pattern on paths from the cosm's root: `*` within one folder, `**` across folders, `{a,b}` either; one without `/` matches a file's name in any folder; one starting with `/` is anchored to the root. |
| **point** | A place one package defines (`cosm.point.define`) and others add to (`cosm.point.add`, or files in its folder): `<owner>:<point>`, Cosm's own as `cosm:<point>`. Its owner reads it (`cosm.point.read`). |
| **contribution** | One thing added to a point, by its name; a part of the package that adds it (`<owner>/<point>/<name>`). |
| **shape** | What a contribution's data (or a setting's value) must be: JSON Schema, written with `cosm/shape` or a schema library (zod, ArkType). Cosm checks it. A point's functions are named beside it (`functions`). |
| **default** | For a point used one at a time (`uses: "one"`): the contribution the user picked, what `cosm.point.default` gives (`cosm setting default`). The others stay usable. |
| **label** | The text shown for a thing: a package's, a view's, an item's, a kind's. |
| **description** | The line under a label. |

## What the cosm holds

| Word | Meaning |
|---|---|
| **kind** | A sort of thing the cosm holds (pages, tables, images): the files it matches, or the items a function lists, and how Cosm treats them (view, merge, template, label, whether search has them). Added to `cosm:kinds`. |
| **extends** | A kind narrowing another package's kind: its things are the other's that its `match` takes, and it sets only what it changes. |
| **thing** | One thing the index holds: a file by its path, or a kind's item by `<package>:<kind>:<key>` (`tables:table:expenses`). |
| **item** (of a kind) | A thing a kind lists with a function rather than a file (a table in a database). The guide says "a kind's items" for these. |
| **index** | Cosm's derived layer: every thing a kind has, its text and its facts, kept in the cache and rebuilt from the cosm. Asked with `cosm.index.find`, `.search`, `.query`, `.retrieve`, `.analyze`. |
| **fact** | What is known of a thing, read by a kind's facts function: a relation and a value (a text, a number, yes or no, a date, or a link to another thing, `{to}`). `links` is the relation for a link. |
| **merge** | How a file of a kind is put together when it changed on disk while open: a function, or `"lines"` (Cosm's own). |

## The window

| Word | Meaning |
|---|---|
| **pane** | The window's left, centre and right: three equal panes, each showing its views stacked or as tabs. What is opened shows in the pane the layout `opens` (the centre unless the user chose another). |
| **view** | A page of a package (its `file`, `views/<name>.html` by habit), added to `cosm:views`: shown in a pane, or held in another package's view. It has `window.cosm`, the same calls as `main.ts` less registering. |
| **kit** | Cosm's elements and stylesheet, loaded into every view: `<cosm-list>`, `<cosm-table>`, `<cosm-item>`, `<cosm-button>`, `<cosm-tree>`, `<cosm-toolbar>`, `<cosm-find>`, `<cosm-place>`, `<cosm-terminal>`. |
| **place** | Where an item or a view sits: `location.in`, one of `left-pane`, `centre-pane`, `right-pane`, `palette`, `file-menu`, `folder-menu`, `menu-bar`, `settings`, or another package's place: a point it defines and one of its views draws (`file-tree:tree`, `agent-session:holder`). |
| **holder** | A view that holds other packages' views and shows one at a time in its `<cosm-place>`: they name it as their place (`location: { in: "agent-session:holder" }`). |
| **item** (in the window) | Anything clickable, added to `cosm:items`: a label, an action and a location. Never the same as a kind's item. |
| **action** | What choosing an item does: a function of the package's (which sends the agent something, when it does), `{ask}` (a question first), `{open}`, `{new}` (a file). |
| **export** | A function `main.ts` lists for others to call: `cosm.view.export` for its own views (`cosm.main.<name>()`, kept live with `live`), `cosm.package.export` for other packages (`cosm.call("<package>:<name>")`). Not the agent's tools (`cosm:commands`). |
| **terminal** | A program a package runs as its process in a terminal (`cosm.process.start`, `as: "terminal"`), drawn in a view by `<cosm-terminal process>`. |
| **card** | What the centre shows for a file no view shows: its name, icon, size, and Open in the system's app for it. |
| **notice**, **problem** | A line in the window, `cosm.ui.notify(text)`; with `{as: "problem"}` it stays until dismissed, with what packages place on problems (`notice`: Agent session's Ask the Agent). |

## The agent

| Word | Meaning |
|---|---|
| **session** | One conversation with an agent, by Agent session's id (`c-7k2p`), active or closed; Agent session (a package) keeps the list and is the broker: every package starts and sends to one through it (`cosm.call("agent-session:send", …)`), and it calls the agent's connector; the agent keeps what was said. |
| **agent** (a package), **connector** | A package that adds itself to `agent:agents` (Claude Code, Gemini CLI): it prepares, starts and stops its agent's program for a conversation and says which runs (Agent session speaks ACP with a chat's); the user's default starts new sessions. |
| **command** | A function a package adds to Cosm's command line, a contribution to `cosm:commands`: `cosm <package>:<name>` in a terminal, a script or the agent's shell, an MCP tool where tools are offered (the agent's tools). Other packages reach a package's exports, never its tools. |
| **lookup** | One of the engine's own calls, not a package's: `cosm file …`, `cosm index …`, `cosm ui …` in the shell, `cosm.file.*`, `cosm.index.*`, `cosm.ui.*` in code (`cosm help` lists them). |
| **prompt** | One of the agent's prompts, a package's `agent/prompts/<name>.md`, sent by name (`{ prompt: "star-chart:recall" }`); how it is typed is its agent package's (`/cosm:recall` in Claude Code). |
| **skill** | A package's `agent/skills/<name>/SKILL.md`, given to the agent, loaded the agent's own way. |
| **step** | One of the agent's actions while it works (reading a file, running a command): the agent's points `agent:step` and `agent:failed` answer it, its events `agent:step.before` and `agent:step.failed` tell it. |

## Events

| Word | Meaning |
|---|---|
| **event** | Something that happens: Cosm's (`file.saved`, `window.opened` …), named `<scope>.<what happened>`, or a package's own (`<package>:<name>`, fired with `cosm.emit`). Heard with `cosm.on`. |
| **data** | What a handler is given first: the event's fields, exactly as emitted (`{paths}`, `{moves}`, `{text}` …). |
| **context** | What a handler is given second: `{name, package, by}`: the event's name, who fired it (`cosm` for Cosm's own), and who caused it (`window`, a package's name, the agent's connector's for the agent's own commands, `shell`, `outside`). The conversation an event is about is in its data (`session`), never here: Cosm keeps no conversations. |
| **before-event** | An event before a change (`file.saved.before`, `file.moved.before` …), whose handler can stop it (`{stop: "why"}`) or change what is about to happen. |
| **signal** | `cosm.signal`: fires when no one waits on the current call any more (Skip, an interrupted tool, a restart). Pass it on to `fetch` and `Bun.spawn`. |

## What the user sets

| Word | Meaning |
|---|---|
| **setting** | A value the user can choose for a package in this cosm, added to `cosm:settings` and read with `cosm.setting.get`; Cosm's own under the name `cosm`. Layered: its default, a preset, the user's for every cosm, this cosm's. |
| **preset** | A value a package suggests for a setting it doesn't own (`cosm.setting.preset`), below the user's own. |
| **secret** | A token the user pastes into Cosm's window, added to `cosm:secrets`, kept in `.cosm/secrets.env`, read by the package's own code with `cosm.secret.get`, and given to the agent only when the package adds it to `agent:secrets`. |
| **storage** | What a package keeps between runs, by key (`cosm.storage`); what is one conversation's under keys of its own (`<session>/<key>`); for more, files in its data folder (`cosm.package.folders.data`). |
| **trust** | The user's answer whether the packages that came with a cosm may run on this computer (Settings → General; `cosm trust get` says it). |

## Changing packages

| Word | Meaning |
|---|---|
| **part** | One thing a package brings that the cosm can leave out or another package can override, named `<package>:<part>`: a file by its path without its ending (`star-chart:agent/prompts/recall`), a registered thing by its name (`star-chart:items/review`). `cosm part list` lists them. |
| **off** (a part) | A part of a package that is on, switched off in this cosm (`cosm part off <package>:<part>`); the rest stays on and updates. |
| **override** | A package taking the place of another's part (`cosm.part.override`), made with `cosm part replace`. |
| **fingerprint** | What stands for the base's part as it was when overridden, kept in the overriding package's `cosm.lock`; the base's part no longer matching it is a change Cosm reports, and `cosm part accept` records it anew. |
| **tie** | Two packages giving one thing (a kind's key, a file's kind, an override, a preset): the user's answer decides (`cosm setting prefer`), until then the earlier package in Cosm's order. |
| **association** | The user's choice that one package gives the files a glob matches a key (Open With … Always; `cosm setting associate`): it goes before every kind. |
