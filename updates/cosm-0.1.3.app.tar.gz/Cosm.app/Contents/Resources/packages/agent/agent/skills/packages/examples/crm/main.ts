import type { Cosm } from "cosm";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:secrets", { name: "crm-token", label: "CRM token", description: "From the CRM's settings, under API." });
  cosm.point.add("agent:mcp", { name: "crm", url: "https://mcp.example-crm.com/mcp", headers: { Authorization: "Bearer ${COSM_SECRET_CRM_TOKEN}" } });
}
