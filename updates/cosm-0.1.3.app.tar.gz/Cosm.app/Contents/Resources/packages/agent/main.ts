// The agent: what every agent gets, as points other packages add to, and the connectors (core defines
// only the points it reads itself, so these are a package's). A package adds by folder (`agent/instructions.md`,
// `agent/prompts/<name>.md`, `agent/skills/<name>/`, `agent/mcp/<name>.json`, `agent/secrets/<name>.json`) or in code
// (`cosm.point.add("agent:mcp", …)`). A connector (Claude Code's package, Gemini CLI's, the stand-in's) adds its agent
// to `agent:agents` and gives it what every agent gets its own way (this package's `share`). Conversations are Agent
// session's, the broker: packages start one and send to it through its exports
// (`agent-session:start`, `agent-session:send`); it starts the program through the connector, speaks with it and tells this package each moment
// (`fire`), so the points where packages have a say before the agent goes on, and the `agent:` events, stay this
// package's.
//
// Its types are for the packages that add to its points (`import type { Agent } from "package:agent"`): with them,
// `cosm.point.add("agent:agents", …)` is checked against what a connector must have.
import type { Cosm } from "cosm";

type Awaitable<T> = T | Promise<T>;

/** Which of a conversation's programs runs, as its connector says: a chat or a terminal, by its process's full name. */
export type Running = { as: "chat" | "terminal"; process: string };
/** An answer to what an agent asked: allowed or not, for the rest of the session (`always`), a form's `answers` by question. */
export interface AgentAnswer { id: string; allow: boolean; always?: boolean; answers?: Record<string, string> }
/** What a connector's start says of the program it runs: its process's full name (`<package>:<name>`), and, for a
 * chat, what the agent's ACP session gets: MCP servers (`mcp`, ACP's `mcpServers`) and Cosm's instructions to go with
 * a new conversation's first message (`rules`, for an agent that takes none as it starts). `agentSession`: the agent's
 * own id for the conversation, when the connector chose it (Claude Code in a terminal). */
export type Started = { process: string; mcp?: Server[]; rules?: string; agentSession?: string };
/**
 * A connector: a contribution to `agent:agents`, by a name of its package's choosing (a package may add several). It
 * only prepares its agent's program for a conversation (its setup, from what every agent gets: this package's
 * `share`), starts it as one of its package's processes (as a chat: a `lines` program that speaks ACP; or in a
 * terminal, as the agent looks run by hand), says which of them runs, and stops it. The program stays the connector's
 * process (its log, its variables, its life with the package). Agent session, the broker, does the rest: it speaks
 * ACP with the chat's program (writing to it, reading its output's stream) and types into the terminal. A connector
 * keeps no list of conversations and fires no events of its own about them: Agent session calls it by the
 * conversation's id (`session`), and keeps the agent's own id for each, given back as `resume`; when the agent changes
 * that id where Agent session can't see it (a fresh start in its terminal), the connector says so
 * (`agent-session:agent-id`).
 */
export interface Agent {
  /** The agent's name as the user sees it (the session header, the agent menu, Settings). Two packages may give the
   * same one: what lists agents tells them apart (by the package's name it gets beside each). */
  label: string;
  /** How one of the agent's prompts is typed to it, `{name}` its name: `/cosm:{name}` (`/{name}` when not given). */
  prompt?: string;
  /** The agent's own hooks tell its moments (Claude Code's, through its connector and `agent-session:hook`): Agent
   * session then tells only a chat's start and a turn the user stopped, and what goes with a message apart from the
   * user's words is given to the hook, never put in the message. */
  hooks?: boolean;
  /** Prepares and starts the conversation's program, or finds it running, and says which process it is: as a chat
   * (`as: "chat"`, a `lines` program speaking ACP) or in a terminal (`as: "terminal"`, a process drawn as a terminal,
   * opening with `first`). One program a conversation: starting one stops the other. `resume`: the agent's own id for
   * the conversation, to carry it on. */
  start: (input: { session: string; as: "chat" | "terminal"; resume?: string; first?: string }) => Awaitable<Started>;
  /** Which of the conversation's programs runs now, as the connector knows its own processes: as a chat or in a
   * terminal, with its process's full name (what Agent session writes to, and Agent terminal draws); null when none
   * runs. Agent session asks it before every message and start, so a conversation running in its terminal is typed
   * into there, never restarted as a chat. */
  running: (input: { session: string }) => Awaitable<Running | null>;
  /** Ends the conversation's program, chat or terminal. */
  stop: (input: { session: string }) => Awaitable<void>;
  /** What the agent keeps of its sessions, by its own ids: title, how full, transcript. */
  sessions?: (input: { sessions: string[] }) => Awaitable<({ id: string } & Record<string, unknown>)[]>;
  /** The MCP servers the agent has from its own setup (added with its own commands, kept in its own files), not the ones
   * Cosm gives it (`agent:mcp`): for packages to reach them too. */
  servers?: () => Awaitable<Server[]>;
}
/** An MCP server for the agent: a program of the package's (stdio), or a remote one. `${COSM_SECRET_<NAME>}` is filled
 * in with the package's secret <name> (as a variable name: `api-key` is `COSM_SECRET_API_KEY`). */
export type Mcp = { program: string; args?: string[] } | { url: string; headers?: Record<string, string> };
/** An MCP server for the agent's session, ready to start, as `share` gives them: a program by its full path with its
 * arguments and variables, or a remote one with its headers. */
export type Server = { name: string; program: string; args: string[]; env: Record<string, string> } | { name: string; url: string; headers: Record<string, string> };
/** What every agent gets, as data (`cosm.call("agent:share")`). Names are those each is reached by (its own, or
 * `<package>:<name>` when an earlier package has one the same). */
export interface Share {
  /** What the agent should know: each package's `agent/instructions.md`, in order, with its text. */
  instructions: { package: string; path: string; text: string }[];
  /** Each prompt (a file) and skill (a folder), by name. */
  prompts: { name: string; package: string; path: string }[];
  skills: { name: string; package: string; path: string }[];
  /** The tools, Cosm's own commands among them (`command`: its words after `cosm`), each with how a call reads in a chat
   * (`step`, `{input}` filled from the call). A package's is `cosm <package>:<name>` in the shell. */
  tools: { name: string; package: string; description: string; step?: string; command: string; inputs: { name: string; type?: string; flag?: boolean }[] }[];
  /** The MCP servers: Cosm's own lookups as "cosm" first (this package's), then each package's, ready to start. */
  mcp: Server[];
  /** The secrets packages give the agent's sessions, as COSM_SECRET_<NAME>. */
  secrets: Record<string, string>;
  /** Programs packages give the agent, for its connector to put on the agent's PATH: each by the name it is run by,
   * the program in full, and the variables of its package it runs with (COSM_*). */
  programs: { name: string; package: string; program: string; env: Record<string, string> }[];
}
declare module "cosm" {
  interface PointTypes {
    "agent:agents": { name: string } & Agent;
    "agent:mcp": { name: string } & Mcp;
    "agent:secrets": { name: string };
    "agent:programs": { name: string; program: string };
  }
}

export default function (cosm: Cosm) {
  cosm.point.define("instructions", { label: "What the agent should know", holds: "files",
    description: "What the agent should know of a package: its agent/instructions.md, read by every agent before the user's first message, in package order. A change reaches the agent from its next session." });
  cosm.point.define("prompts", { label: "Prompts", holds: "files",
    description: "Prompts the user or a package sends the agent by name: agent/prompts/<name>.md, each agent's package writing them its agent's way (Claude Code: /<name>). A change reaches the agent from its next session." });
  cosm.point.define("skills", { label: "Skills", holds: "files",
    description: "The agent's skills: agent/skills/<name>/SKILL.md, with what else the skill uses beside it. A change reaches the agent from its next session." });
  cosm.point.define("mcp", { label: "MCP servers", holds: "values",
    description: "MCP servers for the agent: a program of the package's ({program, args}) or a remote one ({url, headers}), ${NAME} filled from what its programs get (COSM_SECRET_<NAME> for a secret). Started with each session: a change reaches the agent from its next one.",
    shape: { type: "object", minProperties: 1, properties: { program: { type: "string", minLength: 1 }, args: { type: "array", items: { type: "string" } },
      url: { type: "string", minLength: 1 }, headers: { type: "object", additionalProperties: { type: "string" } } } } });
  cosm.point.define("secrets", { label: "Secrets for the agent", holds: "values",
    description: "Which of the package's secrets (cosm:secrets) the agent's sessions get, as COSM_SECRET_<NAME>: one by its name. Given as a session starts: a change reaches the agent from its next one." });
  cosm.point.define("programs", { label: "Programs for the agent", holds: "values",
    description: "Programs the agent may run by name in its shell: one of the package's (program: \"bin/uv\"), run with the package's own variables. Each agent's connector puts them on its agent's PATH as a session starts: a change reaches the agent from its next session. Only the agent gets them.",
    shape: { type: "object", required: ["program"], properties: { program: { type: "string", minLength: 1 } } } });
  cosm.point.define("agents", { holds: "functions", uses: "one", label: "Agent",
    description: "A connector: an agent's label, how its prompts are typed (prompt: \"/cosm:{name}\"), whether its own hooks tell its moments (hooks), and the functions that run its program for a conversation of Agent session's (start, running, stop; sessions when it has them; servers, the MCP servers the agent has from its own setup). Agent session speaks ACP with a chat's program and types into a terminal.",
    shape: { type: "object", required: ["label"], properties: { label: { type: "string", minLength: 1 }, prompt: { type: "string", minLength: 1 }, hooks: { type: "boolean" } } },
    functions: ["start", "running", "stop"] });

  // What happens in a conversation, as Agent session tells it (`agent:fire`, the session its id). Where packages have a
  // say before the agent goes on, a point holding functions: each contribution's `run` is called in package order,
  // given what happened (with its session), and what it returns goes to the agent (text; before a step, `{input}`
  // changes the step for the next one and the agent). Every moment is also this package's event, for those who only
  // hear of it (`agent:<event>`, the session in its data).
  cosm.point.define("start", { holds: "functions", functions: ["run"], label: "When a session starts",
    description: "Runs as a session starts, new or carried on ({session, reason}: startup, resume, compact): text it returns goes to the agent; `{send: message}` (a text or `{prompt}`) is sent to the session before anything else sent to it." });
  // As a session starts: the folders connected to this cosm (the engine's roots), so "the company drive" means one
  // without a lookup. How to work in them is in agent/instructions.md.
  cosm.point.add("agent:start", { name: "connected-folders", run: async () => {
    const roots = await cosm.root.list().catch(() => []);
    if (!roots.length) return "";
    const one = (r: (typeof roots)[number]) => `${r.name} (@${r.id}/${r.reachable ? "" : ", can't be reached now"})`;
    return `Connected folders: ${roots.map(one).join(", ")}.`;
  } });
  cosm.point.define("message", { holds: "functions", functions: ["run"], label: "With each message",
    description: "Runs as each message is sent ({session, text, prompt?}): text it returns goes to the agent with the message." });
  cosm.point.define("step", { holds: "functions", functions: ["run"], label: "Before each step",
    description: "Runs before each step of the agent ({session, step, input, uses: {commands, paths}}): text it returns goes to the agent; {input} changes the step's input, for the next one and the agent." });
  cosm.point.define("failed", { holds: "functions", functions: ["run"], label: "When a step fails",
    description: "Runs after a step of the agent failed ({session, step, input, uses, error}): text it returns goes to the agent." });
  const EVENTS: Record<string, string> = {
    "started": "A session started, new or carried on: {session, reason}.",
    "message.sent": "A message was sent to the agent: {session, message (its id, when the conversation gives one), text, prompt?}.",
    "file.read": "The agent read a file: {session, path}.",
    "step.before": "The agent is about to take a step: {session, step, input, uses}.",
    "step.failed": "A step of the agent failed: {session, step, input, uses, error}.",
    "turn.ended": "The agent's turn ended: {session, text?, stopped, used?, size?, transcript?}.",
  };
  for (const [name, description] of Object.entries(EVENTS)) cosm.point.add("cosm:events", { name, description });
  /** The moments that have a point, by event. */
  const HOOKS: Record<string, string> = { "started": "start", "message.sent": "message", "step.before": "step", "step.failed": "failed" };
  /** How long one contribution may take before the agent goes on without it (it is told in this package's log). */
  const LIMIT = 15_000;

  // Cosm's own lookups as an MCP server, for agents that offer MCP tools (`cosm` is on the PATH of what Cosm starts).
  cosm.point.add("mcp", { name: "cosm", program: "cosm", args: ["mcp"] });

  type Hook = { run: (data: Record<string, unknown>) => Promise<unknown> };
  /** The MCP servers every agent gets (`agent:mcp`), ready to start: a program of its package by its full path with
   * what that package's programs get (run as the package overriding it, when one does), a remote one with `${NAME}`
   * filled in. One that can't start is left out and said in this package's log. */
  async function servers(): Promise<Server[]> {
    const out: Server[] = [];
    for (const c of await cosm.point.read<any>("mcp")) {
      const runs = c.by ?? c.package;
      // A server's name as an agent takes it: letters, digits, - and _ (a clash's full name with -).
      const name = c.as.replace(":", "-");
      try {
        if (typeof c.url === "string") {
          const headers: Record<string, string> = {};
          for (const [k, v] of Object.entries(c.headers ?? {})) headers[k] = await cosm.package.fill(String(v), { package: runs });
          out.push({ name, url: await cosm.package.fill(c.url, { package: runs }), headers });
        } else {
          const p = await cosm.package.program(c.program, { args: c.args ?? [], package: runs });
          // What the server gets of Cosm's: its package's context, settings and secrets.
          out.push({ name, program: p.program, args: p.args, env: Object.fromEntries(Object.entries(p.env).filter(([k]) => k.startsWith("COSM_"))) });
        }
      } catch (e) { cosm.log(`${runs}'s MCP server ${c.name} was left out: ${(e as Error).message ?? e}`); }
    }
    return out;
  }

  cosm.package.export({
    /** What every agent gets (this package's points and Cosm's tools), as data, for an agent's package to give its
     * agent its own way. Each point is read as any other, after the cosm's leave-outs and the overrides, in Cosm's
     * package order; what can't be used is left out and said in this package's log. */
    async share(): Promise<Share> {
      const read = (p: string) => cosm.point.read<any>(p);
      const [ins, prompts, skills, tools, secrets, programs] = await Promise.all(["instructions", "prompts", "skills", "cosm:commands", "secrets", "programs"].map(read));
      const left = (c: any, what: string, why: string) => { cosm.log(`${c.package}'s ${what} ${c.name} is left out: ${why}`); return false; };
      const isSkill = async (c: any) => (c.path && (await Bun.file(`${c.path}/SKILL.md`).exists())) || left(c, "skill", "no SKILL.md in its folder");
      const isPrompt = (c: any) => (c.path?.endsWith(".md") ?? false) || left(c, "prompt", "a prompt is a .md file");
      // A secret a package names for the agent's sessions, with its value (one not given is left out).
      const given: Record<string, string> = {};
      for (const c of secrets) {
        const v = await cosm.secret.get(c.name, { package: c.by ?? c.package }).catch((e) => { cosm.log(`${c.package}'s secret ${c.name} for the agent: ${e.message ?? e}`); return null; });
        if (typeof v === "string") given[`COSM_SECRET_${c.name.toUpperCase().replace(/[^A-Z0-9]/g, "_")}`] = v;
      }
      return {
        // Cosm's own first, then each package's.
        instructions: [{ package: "cosm", path: "", text: await cosm.instructions().catch((e) => { cosm.log(`Cosm's instructions: ${e instanceof Error ? e.message : e}`); return ""; }) },
          ...await Promise.all(ins.map(async (c) => ({ package: c.package, path: c.path!, text: await Bun.file(c.path!).text().catch(() => "") })))],
        prompts: prompts.filter(isPrompt).map((c) => ({ name: c.as, package: c.package, path: c.path! })),
        skills: (await Promise.all(skills.map(async (c) => ((await isSkill(c)) ? [{ name: c.as, package: c.package, path: c.path as string }] : [])))).flat(),
        tools: tools.map((c) => ({ name: c.as, package: c.package, description: c.description ?? "", ...(c.step ? { step: c.step } : {}),
          command: c.package === "cosm" ? c.command : `${c.package}:${c.name}`, inputs: c.inputs ?? [] })),
        mcp: await servers(),
        secrets: given,
        programs: (await Promise.all(programs.map(async (c) => {
          try {
            const p = await cosm.package.program(c.program, { package: c.by ?? c.package });
            return [{ name: c.as, package: c.package, program: p.program, env: Object.fromEntries(Object.entries(p.env).filter(([k]) => k.startsWith("COSM_"))) }];
          } catch (e) { cosm.log(`${c.package}'s program ${c.name} for the agent is left out: ${e instanceof Error ? e.message : e}`); return []; }
        }))).flat(),
      };
    },
    /** What happened in a conversation, told by Agent session (from what its connector passed up: the chat's events,
     * or the agent's own hooks): `event` one of started, message.sent, file.read, step.before, step.failed, turn.ended;
     * `data` with its `session` (Agent session's id). The point's contributions run in package order and what they said
     * comes back, for the agent: `{said}`, and before a step `{said, input}` (the step's input as they changed it, or
     * null). Then this package's event `agent:<event>` is fired, with the same data. */
    async fire({ event, data = {} }: { event: string; data?: Record<string, unknown> }) {
      if (!(event in EVENTS)) throw new Error(`${event} isn't one of the agent's moments (${Object.keys(EVENTS).join(", ")})`);
      const d: Record<string, unknown> = { ...data };
      if (event.startsWith("step.") && !d.uses) d.uses = { commands: [], paths: typeof d.file === "string" ? [d.file] : [] };
      const said: string[] = [];
      const send: unknown[] = [];
      let input: unknown = d.input, changed = false;
      const point = HOOKS[event];
      for (const h of point ? await cosm.point.read<Hook>(point) : []) {
        let timer: ReturnType<typeof setTimeout> | undefined;
        const late = new Promise<"late">((ok) => { timer = setTimeout(() => ok("late"), LIMIT); });
        try {
          const r = await Promise.race([h.run({ ...d, ...(changed ? { input } : {}) }), late]);
          if (r === "late") { cosm.log(`${h.package}'s ${h.name} (${point}) took over ${LIMIT / 1000} s: the agent went on without it`); continue; }
          if (typeof r === "string" && r.trim()) said.push(r.trimEnd());
          // As a session starts: a message to send it first (`{send: {prompt: "<package>:<name>"}}`), before anything else sent.
          else if (event === "started" && r && typeof r === "object" && "send" in r) send.push((r as { send: unknown }).send);
          else if (event === "step.before" && r && typeof r === "object" && "input" in r) { input = (r as { input: unknown }).input; changed = true; }
        } catch (e) { cosm.log(`${h.package}'s ${h.name} (${point}) failed: ${e instanceof Error ? e.message : e}`); }
        finally { clearTimeout(timer); }
      }
      await cosm.emit(event, d);
      return event === "step.before" ? { said: said.join("\n"), input: changed ? input : null } : event === "started" ? { said: said.join("\n"), send } : { said: said.join("\n") };
    },
    /** The agents that are on, the one used now first (without asking). */
    async list() {
      const all = (await cosm.point.read<Agent>("agents")).map((a) => ({ name: a.as, label: a.label, package: a.package, chosen: a.default === true }));
      return all.sort((a, b) => Number(b.chosen) - Number(a.chosen));
    },
  });
}
