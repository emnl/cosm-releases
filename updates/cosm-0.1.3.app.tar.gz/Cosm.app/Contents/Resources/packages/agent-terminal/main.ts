import type { Cosm } from "cosm";
import type { Running } from "package:agent";
import { shape } from "cosm/shape";

export default function (cosm: Cosm) {
  cosm.package.uses("agent-session");
  // The agent in a terminal, in Agent session's holder: the conversation's connector runs it as one of its processes
  // (it names the process, through `agent-session:running`), so it goes on when this view or this code loads again; the
  // view draws it.
  cosm.point.add("cosm:views", { name: "terminal", file: "views/terminal.html", label: "Agent terminal", icon: "terminal", input: "thing", location: { in: "agent-session:holder" } });
  cosm.point.add("cosm:settings", { name: "text-size",
    shape: shape.number({ min: 9, max: 24 }),
    default: 13.5,
    label: "Text size",
    description: "How large the agent's terminal draws its text, in pixels.",
  });
  /** The conversation's terminal, as its connector says (through Agent session): its process's name, or none. */
  const terminalOf = async (session: string) => {
    const on = await cosm.call<Running | null>("agent-session:running", { session });
    return on?.as === "terminal" ? on.process : "";
  };
  // Its view's functions: the text size, and the conversation's terminal, started when asked (through Agent session).
  return cosm.view.export({
    textSize: { changes: { events: ["setting.changed"] }, run: () => cosm.setting.get("text-size") },
    terminal: { description: "A conversation's terminal: its process's name and whether it runs; started first with start: true.",
      input: shape.object({ session: shape.string(), start: shape.optional(shape.boolean()) }),
      run: async ({ session, start }: { session: string; start?: boolean }) => {
        const name = await terminalOf(session);
        if (name || !start) return { name, running: !!name };
        await cosm.call("agent-session:start", { session, as: "terminal" });
        const now = await terminalOf(session);
        if (!now) throw new Error("The agent's terminal didn't start: its package's log may say why.");
        return { name: now, running: true };
      } },
  });
}
