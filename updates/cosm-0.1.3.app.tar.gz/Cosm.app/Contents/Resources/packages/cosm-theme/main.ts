// Cosm theme: Cosm Light and Cosm Dark, each kept in a JSON file of its own and added to Cosm's themes here.
import type { Cosm, Theme } from "cosm";
import light from "./themes/cosm-light.json";
import dark from "./themes/cosm-dark.json";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:themes", { name: "cosm-light", ...(light as Theme) });
  cosm.point.add("cosm:themes", { name: "cosm-dark", ...(dark as Theme) });
}
