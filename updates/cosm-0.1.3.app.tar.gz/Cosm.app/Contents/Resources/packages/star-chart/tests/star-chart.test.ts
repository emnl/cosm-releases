// Star chart's promises, each tried on a throwaway cosm on the real engine (`cosm package test star-chart`).
import { describe, expect, test } from "bun:test";
import { testCosm } from "cosm/test";

const day = (offset: number) => { const d = new Date(); d.setDate(d.getDate() + offset); return d.toISOString().slice(0, 10); };

describe("Star chart", () => {
  test("lays out a new cosm: inbox, spaces, knowledge, archive and a profile", async () => {
    await using c = await testCosm();
    for (const f of ["inbox", "spaces", "knowledge", "archive"]) expect((await c.run("file", "stat", f)).length).toBeGreaterThan(0);
    expect(c.read("profile.md")).not.toBeNull();
  });

  test("its map names each space by its first line, counts knowledge and the inbox", async () => {
    await using c = await testCosm({ files: {
      "spaces/Garden/Garden.md": "# Garden\n\nThe vegetable beds and what to sow when.\n",
      "knowledge/people/Anna Berg.md": "# Anna Berg\n\nCFO at Acme.\n",
      "inbox/note.md": "A thought.\n",
      // A space inside a space, under a folder that is no space of its own; a notes folder is never one.
      "spaces/Garden/beds/Herbs/Herbs.md": "# Herbs\n\nBasil and thyme by the door.\n",
      "spaces/Garden/notes/notes.md": "# notes\n\nNot a space.\n",
    } });
    const map = await c.run("star-chart:map");
    expect(map).toContain("- Garden — The vegetable beds and what to sow when.");
    expect(map).toContain("\n  - beds/Herbs — Basil and thyme by the door.");
    expect(map).not.toContain("Not a space.");
    expect(map).toContain("- people: 1");
    expect(map).toContain("Inbox: 1 waiting.");
  });

  test("the review reads a space inside a space as a space", async () => {
    await using c = await testCosm({ files: {
      "spaces/Sting/Sting.md": "# Sting\n\n*As of 2026-11-01*\n",
      "spaces/Sting/Propel/Propel.md": "# Propel\n\n*As of 2026-11-05*\n" + "line\n".repeat(70),
      "spaces/Sting/Propel/notes/2026-11-06 Board.md": "# Board\n",
    } });
    const asOf = await c.run("star-chart:as-of");
    expect(asOf).toContain("Sting: as of 2026-11-01");
    expect(asOf).toContain("Propel: as of 2026-11-05, newest note 2026-11-06");
    expect(await c.run("star-chart:long-pages")).toContain("spaces/Sting/Propel/Propel.md");
  });

  test("due lists open tasks dated up to three days ahead, not done or later ones", async () => {
    await using c = await testCosm({ files: { "spaces/Home/tasks.md": [
      `- [ ] Pay the invoice 📅 ${day(-1)}`,
      `- [x] Already paid 📅 ${day(-1)}`,
      `- [ ] Call the plumber 📅 ${day(2)}`,
      `- [ ] Book the summer house 📅 ${day(30)}`,
    ].join("\n") + "\n" } });
    const due = await c.run("star-chart:due");
    expect(due).toContain("Pay the invoice");
    expect(due).toContain("Call the plumber");
    expect(due).not.toContain("Already paid");
    expect(due).not.toContain("summer house");
    expect(await c.run("star-chart:due", "--days", "40")).toContain("summer house");
  });

  test("the inbox: how many wait, oldest first", async () => {
    await using c = await testCosm({ files: { "inbox/b.md": "B\n" } });
    c.write("inbox/a.md", "A\n");
    await c.until(async () => (await c.run("star-chart:inbox-count")) === "2", { what: "the inbox to count two" });
    expect((await c.run("star-chart:inbox-list")).split("\n")).toEqual(["inbox/b.md", "inbox/a.md"]);
  });

  test("index lists a Knowledge folder's pages, and names the folders when one isn't there", async () => {
    await using c = await testCosm({ files: { "knowledge/companies/Acme.md": "# Acme\n\nLogistics, 240 seats.\n" } });
    expect(await c.run("star-chart:index", "companies")).toContain("Acme — Logistics, 240 seats.");
    const said = await c.fails("star-chart:index", "planets");
    expect(said).toContain("no Knowledge folder called planets");
    expect(said).toContain("companies");
  });

  test("the profile stays where it is: a move or trash is refused with Star chart's reason", async () => {
    await using c = await testCosm();
    expect(await c.fails("file", "move", "profile.md", "me.md")).toContain("The profile stays at the top of the cosm");
    expect(await c.fails("file", "trash", "profile.md")).toContain("The profile stays at the top of the cosm");
    expect(c.read("profile.md")).not.toBeNull();
  });

  test("reviewed keeps when the weekly review was done", async () => {
    await using c = await testCosm();
    expect(await c.run("star-chart:reviewed")).toContain("last review: never");
    await c.run("star-chart:reviewed", "review");
    expect(await c.storage("star-chart", "last-review")).toBe(new Date().toISOString().slice(0, 10));
    expect(await c.fails("star-chart:reviewed", "lunch")).toContain(`"lunch" isn't one`);
  });
});
