---
date: 2026-10-22
---
# Acme deal
Annual platform licence for Acme Logistics, **240 seats**. Target signature before 31 October. Contact: [[Anna Berg]].

## Open items
- [x] Send revised order form
- [ ] Agree the liability cap: legal wants 24 months of fees 📅 2026-10-28
- [ ] Settle payment terms: they asked for net-60
- [ ] Book the signing call with [[Anna Berg]] and [[Tom Reyes]]

## Terms
| Term | Ours | Acme | Status |
| --- | --- | --- | --- |
| Seats | 240 | 240 | Agreed |
| Liability cap | 12 months | 24 months | Open |
| Payment | Net-30 | Net-60 | Open |

## Notes
- 22 Oct. Redlines back from legal; everything else accepted.
- 15 Oct. Anna confirmed budget sign-off with their CFO.
