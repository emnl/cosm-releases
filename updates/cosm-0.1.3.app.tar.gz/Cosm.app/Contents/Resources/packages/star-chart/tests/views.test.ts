// Star chart's views and window items, each tried on a throwaway cosm with the window open headless (`cosm/test`'s
// window: WebKit, the window's engine), used through the agent's own commands (`cosm ui open`, `wait`, `outline`).
import { describe, expect, test } from "bun:test";
import { testCosm } from "cosm/test";

const view = async (c: Awaited<ReturnType<typeof testCosm>>, target: string, arg: string[], text: string, name: string) => {
  await c.run("ui", "open", target, ...arg);
  await c.run("ui", "wait", "--text", text, "--view", name);
  return c.run("ui", "outline", name);
};

describe("Star chart's views", () => {
  test("the archive: an archived space and a session log, each under its group", async () => {
    await using c = await testCosm({ fixture: "sample" });
    await c.window();
    const out = await view(c, "star-chart:archive", ["archive"], "Q2 board pack", "star-chart:archive");
    for (const t of ["Q2 board pack", "Hiring kickoff", "Spaces", "Logs"]) expect(out).toContain(t);
    expect(out).not.toContain("old export");
  }, 60000);

  test("the inbox: opening its folder shows what waits, the session logs apart, and the button for the agent", async () => {
    await using c = await testCosm({ fixture: "sample" });
    await c.window();
    const out = await view(c, "inbox", [], "Session logs", "star-chart:inbox");
    for (const t of ["Q3 numbers", "Call notes", "Redlines from legal", "scan of the contract", "Acme redlines", "File with the agent"]) expect(out).toContain(t);
  }, 60000);
});

describe("Star chart's items", () => {
  test("its commands are in ⌘K", async () => {
    await using c = await testCosm();
    const items = JSON.parse(await c.run("point", "read", "cosm:items", "--json")) as { package: string; label?: string; location?: unknown }[];
    const mine = items.filter((i) => i.package === "star-chart").map((i) => i.label);
    for (const l of ["Recall", "Go Through Inbox", "Review", "Reflect", "Write Log"]) expect(mine).toContain(l);
  });
});
