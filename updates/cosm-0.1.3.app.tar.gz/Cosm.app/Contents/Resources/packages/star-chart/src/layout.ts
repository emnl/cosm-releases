// Star chart's layout read from the cosm's folder: inbox, spaces, knowledge, archive and profile.md. Each
// function takes the cosm's folder and gives what a tool or a page shows; file reads are plain (it only reads here).
import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";

export type Root = string;
const isDir = (p: string) => statSync(p, { throwIfNoEntry: false })?.isDirectory() ?? false;
const isFile = (p: string) => statSync(p, { throwIfNoEntry: false })?.isFile() ?? false;
const mtime = (p: string) => (statSync(p, { throwIfNoEntry: false })?.mtimeMs ?? 0) / 1000;
/** A folder's entries, sorted, without hidden ones. */
export const kids = (d: string) => (isDir(d) ? readdirSync(d).filter((n) => !n.startsWith(".")).sort() : []);
export const base = (p: string) => p.split("/").pop() ?? p;
/** Every file under a folder (paths from the root), hidden ones left out. */
export function files(root: Root, dir: string, keep: (p: string) => boolean = () => true): string[] {
  const out: string[] = [];
  for (const n of kids(`${root}/${dir}`)) {
    const p = `${dir}/${n}`;
    if (isDir(`${root}/${p}`)) out.push(...files(root, p, keep)); else if (keep(p)) out.push(p);
  }
  return out;
}
/** Every folder under a folder (paths from the root), hidden ones left out. */
function folders(root: Root, dir: string): string[] {
  return kids(`${root}/${dir}`).flatMap((n) => { const p = `${dir}/${n}`; return isDir(`${root}/${p}`) ? [p, ...folders(root, p)] : []; });
}
const read = (root: Root, p: string) => { try { return readFileSync(`${root}/${p}`, "utf8"); } catch { return ""; } };
/** A day and a time as local time: YYYY-MM-DD, and YYYY-MM-DDTHH:MM. */
const pad = (n: number) => String(n).padStart(2, "0");
export const day = (s: number) => { const d = new Date(s * 1000); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
const when = (s: number) => { const d = new Date(s * 1000); return `${day(s)}T${pad(d.getHours())}:${pad(d.getMinutes())}`; };
/** The spaces: every folder under spaces/, at any depth, with a page of its own name (spaces/Sting/Propel/Propel.md),
 * as paths from the root, each before the spaces inside it. A notes folder is never one. */
export function spaces(root: Root): string[] {
  const walk = (d: string): string[] => kids(`${root}/${d}`).flatMap((n) => {
    const p = `${d}/${n}`;
    if (n === "notes" || !isDir(`${root}/${p}`)) return [];
    return [...(isFile(`${root}/${p}/${n}.md`) ? [p] : []), ...walk(p)];
  });
  return walk("spaces");
}
/** The pages directly in each space and three down Knowledge, as the review reads them (knowledge/*\/*\/*.md), without
 * todo, tasks and skills' SKILL.md. */
function reviewPages(root: Root): string[] {
  const spaced = spaces(root).flatMap((s) => kids(`${root}/${s}`).filter((f) => f.endsWith(".md")).map((f) => `${s}/${f}`));
  const know = kids(`${root}/knowledge`).flatMap((k) => kids(`${root}/knowledge/${k}`).flatMap((e) => kids(`${root}/knowledge/${k}/${e}`).filter((f) => f.endsWith(".md")).map((f) => `knowledge/${k}/${e}/${f}`)));
  return [...spaced, ...know].filter((p) => !/\/(todo|tasks|SKILL)\.md$/.test(p) && isFile(`${root}/${p}`));
}

// --- the lookups -------------------------------------------------------------------------------------------------------

/** Open tasks with a date, due within `days` days or overdue: file:line:task. The date is the one after 📅, else the
 * first date outside [[links]]. */
export function due(root: Root, days = 3): string[] {
  const lim = new Date(); lim.setDate(lim.getDate() + days);
  const limit = day(lim.getTime() / 1000);
  const out: string[] = [];
  for (const f of ["inbox", "spaces", "knowledge"].flatMap((d) => files(root, d, (p) => p.endsWith(".md")))) {
    read(root, f).split("\n").forEach((line, i) => {
      if (!/^\s*- \[ \].*\d{4}-\d{2}-\d{2}/.test(line)) return;
      const cal = /📅 *(\d{4}-\d{2}-\d{2})/.exec(line);
      const d = cal ? cal[1] : /\d{4}-\d{2}-\d{2}/.exec(line.replace(/\[\[[^\]]*\]\]/g, ""))?.[0];
      if (d && d <= limit) out.push(`${f}:${i + 1}:${line}`);
    });
  }
  return out;
}
/** The five pages in spaces changed most recently. */
export const recent = (root: Root) => files(root, "spaces", (p) => p.endsWith(".md") && !/\/(todo|tasks)\.md$/.test(p)).sort((a, b) => mtime(`${root}/${b}`) - mtime(`${root}/${a}`)).slice(0, 5);
/** What waits in the inbox, oldest first, and how many. */
export const inboxList = (root: Root) => files(root, "inbox").sort((a, b) => mtime(`${root}/${a}`) - mtime(`${root}/${b}`));
export const inboxCount = (root: Root) => files(root, "inbox").length;
const isLog = (n: string) => / Log – .*\.md$/.test(n);
/** The newest session log (by its name, which starts with its date), for its summary. */
const newestLog = (root: Root) => [...files(root, "inbox"), ...files(root, "archive/logs")].filter((p) => isLog(base(p))).sort((a, b) => base(a).localeCompare(base(b))).pop() ?? "";
/** A page's section: the lines under `## <name>` up to the next `## `. */
const section = (t: string, name: string) => { const out: string[] = []; let on = false; for (const l of t.split("\n")) { if (l.startsWith(`## ${name}`)) { on = true; continue; } if (l.startsWith("## ")) on = false; else if (on) out.push(l); } return out; };
export const logSummary = (root: Root) => { const f = newestLog(root); return f ? [f, ...section(read(root, f), "Summary")].join("\n") : ""; };
export const pages = (root: Root) => ["spaces", "knowledge"].flatMap((d) => files(root, d, (p) => p.endsWith(".md")));

/** A Knowledge folder's entries: each page, or each folder with a page of its own (a person with notes, a skill): its
 * name, its page (when it has one) and its path, alphabetical. */
export function knowledge(root: Root, folder: string): { name: string; page: string | null; path: string }[] {
  const dir = folder.includes("/") ? folder.replace(/\/+$/, "") : `knowledge/${folder}`;
  return kids(`${root}/${dir}`).flatMap((n) => {
    const e = `${dir}/${n}`;
    if (isDir(`${root}/${e}`)) return [{ name: n, page: isFile(`${root}/${e}/${n}.md`) ? `${e}/${n}.md` : isFile(`${root}/${e}/SKILL.md`) ? `${e}/SKILL.md` : null, path: e }];
    return n.endsWith(".md") ? [{ name: n.slice(0, -3), page: e, path: e }] : [];
  }).sort((a, b) => a.name.toLowerCase().localeCompare(b.name.toLowerCase()));
}
export const knowledgeFolders = (root: Root) => kids(`${root}/knowledge`).filter((n) => isDir(`${root}/knowledge/${n}`));
export const count = (root: Root, dir: string) => kids(`${root}/${dir}`).length;

// --- the weekly review's lookups ---------------------------------------------------------------------------------------

export const longPages = (root: Root) => reviewPages(root).flatMap((f) => { const n = (read(root, f).match(/\n/g) ?? []).length; return n > 60 ? [`${f} (${n} lines)`] : []; });
export const logHeadings = (root: Root) => reviewPages(root).flatMap((f) => read(root, f).split("\n").flatMap((l, i) =>
  /^##+ (.*[^\p{L}\p{N}])?(\d{4}-\d{2}-\d{2}|Log|History|Changelog|Updates)([^\p{L}\p{N}].*)?$/u.test(l) ? [`${f}:${i + 1}:${l}`] : []));
export function asOf(root: Root): string[] {
  const dirs = [...spaces(root), ...kids(`${root}/knowledge`).filter((k) => k !== "skills").flatMap((k) => kids(`${root}/knowledge/${k}`).map((e) => `knowledge/${k}/${e}`))]
    .filter((d) => isDir(`${root}/${d}`));
  return dirs.map((d) => {
    const s = base(d);
    const a = /\*As of (\d{4}-\d{2}-\d{2})/.exec(read(root, `${d}/${s}.md`))?.[1];
    const n = kids(`${root}/${d}/notes`).map((f) => /^\d{4}-\d{2}-\d{2}/.exec(f)?.[0]).filter(Boolean).sort().pop();
    return `${s}: as of ${a ?? "none"}, newest note ${n ?? "none"}`;
  });
}
export const notesFolders = (root: Root) => ["spaces", "knowledge"].flatMap((d) => folders(root, d)).filter((p) => /\/notes\//.test(p));
export function dupNames(root: Root): string[] {
  const seen = new Map<string, number>();
  for (const f of ["inbox", "spaces", "knowledge", "archive"].flatMap((d) => files(root, d, (p) => p.endsWith(".md") && !/\/(todo|tasks)\.md$/.test(p) && !p.startsWith("knowledge/skills/")))) {
    const n = base(f).toLowerCase(); seen.set(n, (seen.get(n) ?? 0) + 1);
  }
  return [...seen].filter(([, c]) => c > 1).map(([n]) => n).sort();
}
/** [[Links]] in spaces and Knowledge (skills left out) to pages that don't exist anywhere in the cosm. */
export function brokenLinks(root: Root): string[] {
  const names = new Map<string, string>();
  for (const f of ["spaces", "knowledge"].flatMap((d) => files(root, d, (p) => p.endsWith(".md") && !p.split("/").includes("skills")))) {
    for (const m of read(root, f).matchAll(/\[\[([^\]|#]+)/g)) {
      const n = m[1].replace(/\\$/, "").split("/").pop()!.replace(/\.md$/, "");
      if (!/\.[A-Za-z0-9]{2,4}$/.test(n) && !names.has(n.toLowerCase())) names.set(n.toLowerCase(), n);
    }
  }
  const all = new Set(files(root, ".", (p) => p.endsWith(".md")).map((p) => base(p).slice(0, -3).toLowerCase()));
  return [...names].filter(([k]) => !all.has(k)).sort(([a], [b]) => a.localeCompare(b)).map(([, n]) => `[[${n}]]`);
}
export function strayFiles(root: Root): string[] {
  const inside = ["spaces", "knowledge", "archive"].flatMap((d) => files(root, d, (p) => !p.endsWith(".md") && !p.startsWith("knowledge/skills/")));
  const top = kids(root).filter((n) => isFile(`${root}/${n}`) && n !== "profile.md");
  return [...inside, ...top];
}
export function oversize(root: Root): string[] {
  const size = (p: string) => statSync(`${root}/${p}`, { throwIfNoEntry: false })?.size ?? 0;
  const out = ["knowledge/preferences", "knowledge/fixes"].flatMap((d) => kids(`${root}/${d}`).filter((f) => f.endsWith(".md")).map((f) => `${d}/${f}`)).filter((p) => size(p) > 2000);
  if (isFile(`${root}/profile.md`) && size("profile.md") > 1500) out.push("profile.md");
  return out;
}
/** The session logs since the week before the last weekly review (`last`: its day, kept in Star chart's storage). */
export function logsSinceReview(root: Root, last: string): string[] {
  const l = last || "2000-01-01";
  const d = new Date(`${l}T00:00:00`); d.setDate(d.getDate() - 7);
  const since = day(d.getTime() / 1000);
  return files(root, "archive/logs").filter((p) => isLog(base(p)) && base(p) >= since).sort();
}

// --- its pages' rows -------------------------------------------------------------------------------------------------

export interface Row { label: string; open?: string | null; line?: string; date?: string; group?: string }
/** A file's name as Cosm shows it (cosm.file.name), given by the caller for every file the rows hold. */
export type Names = (p: string) => string;

/** The inbox: newest first, each with its first line (a page's); the session logs set apart at the end, with their
 * time; a date and time at the front of a name left out of what is shown. */
export function inboxRows(root: Root, firstLine: (p: string) => string | undefined, shown: Names): Row[] {
  const all = files(root, "inbox").sort((a, b) => mtime(`${root}/${b}`) - mtime(`${root}/${a}`));
  const log = / Log – /;
  const strip = /^\d{4}-\d{2}-\d{2}[ -]\d{2}[.:]?\d{2}[ -]+(Log – )?/;
  return [...all.filter((p) => !log.test(base(p))), ...all.filter((p) => log.test(base(p)))].map((p) => {
    const n = shown(p), s = n.replace(strip, "") || n;
    return log.test(base(p)) ? { label: s, open: p, group: "Session logs", date: when(mtime(`${root}/${p}`)) } : { label: s, open: p, line: firstLine(p), date: day(mtime(`${root}/${p}`)) };
  });
}
/** The archive: each part (spaces that are done, older session logs) under its own heading, newest first; a folder with
 * a page of its own name is one row (an archived space), any other folder is opened up. */
export function archiveRows(root: Root, shown: Names): Row[] {
  const items = (d: string): [string, string, number][] => kids(`${root}/${d}`).flatMap((n) => {
    const p = `${d}/${n}`;
    if (isDir(`${root}/${p}`)) return isFile(`${root}/${p}/${n}.md`) ? [[n, `${p}/${n}.md`, mtime(`${root}/${p}`)] as [string, string, number]] : items(p);
    return [[shown(p), p, mtime(`${root}/${p}`)] as [string, string, number]];
  });
  return kids(`${root}/archive`).filter((n) => isDir(`${root}/archive/${n}`)).flatMap((part) => {
    const g = part.charAt(0).toUpperCase() + part.slice(1);
    return items(`archive/${part}`).sort((a, b) => b[2] - a[2]).map(([label, open, t]) => ({ label, open, group: g, date: day(t) }));
  });
}
/** Every file the inbox and the archive hold, for their names. */
export const listed = (root: Root) => [...files(root, "inbox"), ...files(root, "archive")];
/** A row's empty fields left out, as the pages expect. */
export const tidy = (r: Row) => Object.fromEntries(Object.entries(r).filter(([, v]) => v !== undefined && v !== null && v !== "")) as Row;

export { existsSync, read };
