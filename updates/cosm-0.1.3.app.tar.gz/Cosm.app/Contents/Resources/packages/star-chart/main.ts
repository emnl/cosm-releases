// Star chart: Cosm's own way of keeping notes. Its layout (inbox, spaces, knowledge, archive, profile.md),
// what the agent is told about it at each session's start, its pages' rows, the fixes it keeps for the agent's tools,
// and the weekly review's lookups. What it gives the agent (agent/instructions.md, agent/prompts/, agent/skills/) are its folders; its templates are read here, and it lays a cosm out the first time it starts there.
import type { Cosm, Target } from "cosm";
import { mkdir } from "node:fs/promises";
import * as L from "./src/layout.ts";

export default async function (cosm: Cosm) {
  const root = cosm.package.folders.cosm;

  // The first time it starts in a cosm: the layout's folders and an empty profile, never over what is there. Kept as
  // done in its storage (which travels with the cosm), so a folder the user removes later stays removed.
  const LAYOUT = ["inbox", "spaces", "knowledge/people", "knowledge/companies", "knowledge/preferences", "knowledge/fixes",
    "knowledge/skills", "archive/spaces"];
  cosm.on("package.started", async () => {
    if (await cosm.storage.get("laid-out")) return;
    for (const f of LAYOUT) await mkdir(`${root}/${f}`, { recursive: true });
    if (!(await cosm.file.stat("profile.md"))) await cosm.file.write("profile.md", await cosm.package.file.read("templates/profile.md"));
    await cosm.storage.set("laid-out", new Date().toISOString());
  });
  /** First lines of pages, as Markdown gives them (a skill's description, else the first plain line under its title). */
  const firstLines = async (pages: string[]) => {
    if (!pages.length) return new Map<string, string>();
    const got = await cosm.call<{ path: string; line: string }[]>("markdown:firstLines", { pages });
    return new Map(got.map((x) => [x.path, x.line]));
  };

  // --- its kinds ---------------------------------------------------------------------------------------------------

  cosm.point.add("cosm:kinds", { name: "profile", extends: "markdown:page", match: "/profile.md", label: "Profile", search: false,
    text: (a) => sectionText("Me", "Not written yet: setup writes it")(a) });
  // The profile stays where Star chart and the agent look for it: whoever asks (the window, a view, the agent), a move
  // or the trash is refused, saying why.
  const stays = () => ({ stop: "The profile stays at the top of the cosm as profile.md: Star chart and the agent read it there." });
  cosm.on("file.moved.before", stays, { kind: "profile" });
  cosm.on("file.trashed.before", stays, { kind: "profile" });
  cosm.point.add("cosm:kinds", { name: "log", extends: "markdown:page", match: "**/* Log – *.md", label: "Session log", search: false,
    text: (a) => sectionText("Summary")(a) });
  cosm.point.add("cosm:kinds", { name: "preference", extends: "markdown:page", match: "knowledge/preferences/*.md", label: "Preference" });
  cosm.point.add("cosm:kinds", { name: "fix", extends: "markdown:page", match: "knowledge/fixes/*.md", label: "Fix", search: false });
  cosm.point.add("cosm:skip", { name: "skills", globs: ["knowledge/skills/**"] });
  // A session log's text is Markdown's, its Summary's first paragraph the lead; the profile's lead is the first
  // paragraph under Me (the Settings row's line), or that it isn't written yet.
  const sectionText = (section: string, empty?: string) => async ({ things }: { things: string[] }) => {
    const got = await cosm.call<{ thing: string; name: string; lead: string; text: string }[]>("markdown:mdText", { things, "lead-section": section });
    return got.map((t) => ({ ...t, lead: t.lead || empty || "" }));
  };

  // --- the window -----------------------------------------------------------------------------------------------------

  cosm.point.add("cosm:views", { name: "inbox", file: "views/inbox.html", label: "Inbox", icon: "inbox", input: "folder" });
  cosm.point.add("cosm:views", { name: "archive", file: "views/archive.html", label: "Archive", icon: "archive", input: "folder" });
  /** The conversation a thing is (Agent session's `agent-session:session:<id>`; none for another, or one not started
   * yet). */
  const SESSION = "agent-session:session:";
  const conversation = (thing?: string) => (thing?.startsWith(SESSION) && !thing.endsWith(":") ? thing.slice(SESSION.length) : undefined);
  /** The conversation on screen the user used last (cosm.ui.shown), if any. */
  const onScreen = async () => (await cosm.ui.shown()).map((x) => ({ id: conversation(x.arg), used: x.used })).filter((x) => x.id).sort((a, b) => b.used.localeCompare(a.used))[0]?.id;
  /** Sends the agent one of Star chart's prompts in `session` (the one it was chosen in), else the conversation on
   * screen used last, else (`start`) a new one from Agent session; one whose agent isn't running (Cosm started again
   * since) is carried on first. Without `start` and with no session, it says so. */
  const toAgent = async (prompt: string, session?: string, start = true): Promise<string | undefined> => {
    let s = session || (await onScreen());
    // A new one is shown, as the user asked for it.
    if (!s) { if (!start) return "No session is open."; s = String(await cosm.call("agent-session:start")); await cosm.ui.open("agent-session:holder", SESSION + s); }
    const message = { prompt: prompt.includes(":") ? prompt : `star-chart:${prompt}` };
    // One whose agent isn't running (Cosm started again since) is carried on by Agent session as it sends.
    await cosm.call("agent-session:send", { session: s, message });
    return undefined;
  };
  // Commands that start a session when none is open; Reflect and Log only ever go to one that is (they are about it).
  // The one it was chosen on.
  const sends = (c: string) => ({ thing }: Target) => toAgent(c, conversation(thing));
  const aboutSession = (c: string) => ({ thing }: Target) => toAgent(c, conversation(thing), false);
  cosm.point.add("cosm:items", { name: "recall", label: "Recall", content: { description: "Where things stand and what to pick up" }, action: sends("recall"), location: [{ in: "palette" }, { in: "menu-bar", menu: "Session" }] });
  cosm.point.add("cosm:items", { name: "inbox", label: "Go Through Inbox", content: { description: "File what is waiting in the inbox" }, action: sends("inbox"), location: [{ in: "palette" }, { in: "menu-bar", menu: "Session" }] });
  cosm.point.add("cosm:items", { name: "review", label: "Review", content: { description: "The weekly review" }, action: sends("review"), location: [{ in: "palette" }, { in: "menu-bar", menu: "Session" }] });
  cosm.point.add("cosm:items", { name: "setup", label: "Setup", content: { description: "Learn who you are and what you work on" }, action: sends("setup"), location: [{ in: "palette" }, { in: "menu-bar", menu: "Session" }] });
  /** A session's own keys, in its storage (Agent session's): gone with the session. */
  const kept = (session: string) => ({
    get: async <T>(key: string) => (await cosm.call("agent-session:storage-get", { session, key })) as T | null,
    set: (key: string, value: unknown) => cosm.call("agent-session:storage-set", { session, key, value }),
    delete: (key: string) => cosm.call("agent-session:storage-delete", { session, key }),
  });
  // The session's buttons, in Agent session's holder (over the chat and the screen alike), and in ⌘K and the Session
  // menu: `done` (when) once Reflect, or the log, ran in the session (sent by the button or typed).
  const ranChanges = { events: ["agent-session:storage.changed"] };
  const ran = async (session: string | undefined, what: string) => (session ? (await kept(session).get<string>(what)) ?? null : null);
  cosm.point.add("cosm:items", { name: "reflect", label: "Reflect", action: aboutSession("reflect"), location: [{ in: "agent-session:holder" }, { in: "palette" }, { in: "menu-bar", menu: "Session" }],
    content: { changes: ranChanges, run: async ({ thing }) => ({ icon: "bulb", description: "What this session taught, and what could become a skill", done: await ran(conversation(thing), "reflected") }) } });
  cosm.point.add("cosm:items", { name: "log", label: "Write Log", action: aboutSession("log"), location: [{ in: "agent-session:holder" }, { in: "palette" }, { in: "menu-bar", menu: "Session" }],
    content: { changes: ranChanges, run: async ({ thing }) => ({ icon: "page", description: "Write a record of this session", done: await ran(conversation(thing), "logged") }) } });
  cosm.point.add("cosm:items", { name: "profile", label: "Profile", content: { description: "What Cosm knows about you and how you like to work. The agent reads it at the start of every session and keeps it up to date; change any line." },
    action: { open: "profile.md" }, location: { in: "settings" } });
  cosm.setting.preset("cosm", { start: "profile.md", new: { kind: "markdown:page", folder: "inbox" } });

  // The sidebar: File tree laid out as Star chart keeps a cosm (its `sections` setting), the archive in its foot.
  cosm.point.add("cosm:items", { name: "archive", label: "Archive", content: { icon: "archive" }, action: { open: "star-chart:archive", arg: "archive" }, location: { in: "file-tree:tree" } });
  cosm.setting.preset("file-tree", { sections: {
    sections: [
      { folder: "inbox", label: "Inbox", icon: "inbox", show: "link" },
      { folder: "spaces", label: "Spaces", sort: "recent" },
      { folder: "knowledge", label: "Knowledge", sort: "name", items: ["tables:tables"] },
    ],
    foot: ["star-chart:archive", "file-tree:trash"],
  } });
  // Opening the inbox folder (a click in the sidebar, the agent's `cosm ui open inbox`) shows the inbox view.
  cosm.on("folder.opened", async (e) => { if ((e as { folder?: unknown }).folder === "inbox") await cosm.ui.open("star-chart:inbox", "inbox"); });

  // Its pages' rows: the inbox, a Knowledge folder, the archive. Star chart works out what they show, so the window needs
  // to know nothing of its layout.
  const withLines = async (rows: (lines: (p: string) => string | undefined) => L.Row[]) => {
    const want = new Set<string>();
    rows((p) => { if (p.endsWith(".md")) want.add(p); return undefined; });
    const lines = await firstLines([...want]);
    return rows((p) => lines.get(p)).map(L.tidy);
  };
  /** Each file's name as Cosm shows it (a file a kind claims without its ending). */
  const names = async () => {
    const ps = L.listed(root);
    const got = await Promise.all(ps.map((p) => cosm.file.name(p)));
    const map = new Map(ps.map((p, i) => [p, got[i]]));
    return (p: string) => map.get(p) ?? L.base(p);
  };
  cosm.package.export({
    /** What exists in the cosm and where (its tool `map` gives the same to the agent). */
    map,
  });
  cosm.view.export({
    /** The inbox view's "File with the agent". */
    fileInbox: { run: () => toAgent("inbox"), changes: {} },
    inboxRows: { run: async () => { const n = await names(); return withLines((f) => L.inboxRows(root, f, n)); }, changes: { files: "/inbox/**" } },
    archiveRows: { run: async () => L.archiveRows(root, await names()).map(L.tidy), changes: { files: "/archive/**" } },
  });

  // --- the agent's tools ---------------------------------------------------------------------------------------------

  /** The map: what exists and where, made fresh from the cosm itself each time. */
  async function map(): Promise<string> {
    // A space inside another is shown under it, by the folders between them (Sting, then  Propel).
    const spaces = L.spaces(root);
    const inside = (p: string) => spaces.filter((q) => p.startsWith(`${q}/`));
    const spaceLine = (p: string) => { const up = inside(p); return `${"  ".repeat(up.length)}- ${p.slice((up.pop() ?? "spaces").length + 1)} — ${lines.get(`${p}/${L.base(p)}.md`) ?? ""}`; };
    const knowledge = L.knowledgeFolders(root);
    const entries = Object.fromEntries(["skills", "preferences", "fixes"].map((k) => [k, L.knowledge(root, k)]));
    const lines = await firstLines([...spaces.map((s) => `${s}/${L.base(s)}.md`), ...Object.values(entries).flat().flatMap((e) => (e.page ? [e.page] : []))]);
    const list = (k: string, ending = "") => (entries[k].length ? entries[k].map((e) => `- ${e.name}${ending}${e.page && lines.get(e.page) ? ` — ${lines.get(e.page)}` : ""}`) : ["- none yet"]);
    return [
      "Spaces (spaces/), each with what it is:",
      ...spaces.map(spaceLine),
      "", "Knowledge (knowledge/), each folder with how many pages it holds; `cosm star-chart:index <folder>` lists them:",
      ...knowledge.filter((k) => !["skills", "preferences", "fixes"].includes(k)).map((k) => `- ${k}: ${L.count(root, `knowledge/${k}`)}`),
      "", "Skills (knowledge/skills/<name>/SKILL.md), each with when it applies:", ...list("skills"),
      "", "Preferences (knowledge/preferences/), read the one for a kind of work before doing it:", ...list("preferences", ".md"),
      "", "Fixes (knowledge/fixes/):", ...list("fixes", ".md"),
      "", `Inbox: ${L.inboxCount(root)} waiting. Archive (archive/): search it when a page isn't found elsewhere.`,
    ].join("\n");
  }

  cosm.point.add("cosm:commands", { name: "map", step: "Looked at what your cosm holds", description: "What exists in the cosm and where: each space with what it is, each Knowledge folder with how many pages it holds, every skill, preference and fix, and what waits in the inbox.", run: map });
  cosm.point.add("cosm:commands", { name: "index", step: "Looked up your Knowledge pages", description: "A Knowledge folder's pages, each with its first line, alphabetical; without a folder, the folders with how many pages each holds.",
    inputs: [{ name: "folder", label: "Knowledge folder", description: "people, companies, skills …", optional: true }], run: async ({ folder }) => {
      if (!folder) return L.knowledgeFolders(root).map((k) => `${k}: ${L.count(root, `knowledge/${k}`)} pages`);
      const f = folder.toLowerCase();
      if (!L.knowledgeFolders(root).includes(f)) throw new Error(`no Knowledge folder called ${folder}. There are: ${L.knowledgeFolders(root).join(" ")}`);
      const es = L.knowledge(root, f);
      const lines = await firstLines(es.flatMap((e) => (e.page ? [e.page] : [])));
      return es.map((e) => `${e.name}${e.page && lines.get(e.page) ? ` — ${lines.get(e.page)}` : ""}`);
    } });
  cosm.point.add("cosm:commands", { name: "due", step: "Looked up what is due", description: "Open tasks with a date that are overdue or due within the next days (default 3), as file:line: task.",
    inputs: [{ name: "days", label: "Days ahead", type: "number", optional: true }], run: ({ days }) => L.due(root, days ?? 3) });
  cosm.point.add("cosm:commands", { name: "recent", description: "The five pages in spaces changed most recently.", run: () => L.recent(root) });
  cosm.point.add("cosm:commands", { name: "inbox-list", description: "What waits in the inbox, oldest first.", run: () => L.inboxList(root) });
  cosm.point.add("cosm:commands", { name: "inbox-count", description: "How many files wait in the inbox.", run: () => L.inboxCount(root) });
  cosm.point.add("cosm:commands", { name: "log-summary", description: "The newest session log's path and its Summary section.", run: () => L.logSummary(root) });
  cosm.point.add("cosm:commands", { name: "search-logs", step: "Searched your logs for “{words}”", description: "Searches the session logs (kept out of ordinary search).", inputs: [{ name: "words", label: "Words to search for", type: "list" }],
    run: async ({ words }) => (await cosm.index.search(words.join(" "), { kind: "star-chart:log" })).map((h) => `${h.thing}${h.lead ? ` — ${h.lead}` : ""}`) });
  cosm.point.add("cosm:commands", { name: "fixes", description: "The known fixes for tools, by the tool's name (knowledge/fixes/<tool>.md).", inputs: [{ name: "tools", label: "Tool names", description: "one or more", type: "list" }],
    run: ({ tools }) => tools.flatMap((t) => t.split(/\s+/)).filter(Boolean).flatMap((t) => L.read(root, `knowledge/fixes/${t}.md`).split("\n").filter((l) => l.startsWith("- "))) });
  cosm.point.add("cosm:commands", { name: "pages", description: "Every page in spaces and Knowledge.", run: () => L.pages(root) });
  // The weekly review's lookups.
  const review = (name: string, description: string, run: () => unknown) => cosm.point.add("cosm:commands", { name: name, description: `${description} (the weekly review).`, run });
  review("long-pages", "Pages over 60 lines", () => L.longPages(root));
  review("log-headings", "Dated or log-like headings inside pages", () => L.logHeadings(root));
  review("as-of", "Each space's and Knowledge page's As of date and newest note", () => L.asOf(root));
  review("notes-folders", "Every notes folder", () => L.notesFolders(root));
  review("dup-names", "Page names used twice", () => L.dupNames(root));
  review("broken-links", "[[Links]] to pages that don't exist", () => L.brokenLinks(root));
  review("stray-files", "Files outside the layout's places", () => L.strayFiles(root));
  review("oversize", "Preferences, fixes and the profile grown past their size", () => L.oversize(root));
  cosm.point.add("cosm:commands", { name: "logs-since-review", description: "Session logs since the last weekly review.", run: async () => L.logsSinceReview(root, (await cosm.storage.get<string>("last-review")) ?? "") });
  // When the weekly review and the mail pass were last done: kept by Star chart, never a file the agent writes.
  cosm.point.add("cosm:commands", { name: "reviewed", description: "Notes that the weekly review (review, also at setup) or the mail pass (mail) was done today; with neither, says when each was last done.",
    inputs: [{ name: "what", label: "review or mail", optional: true }], run: async ({ what }) => {
      const today = new Date().toISOString().slice(0, 10);
      if (what === "review" || what === "mail") await cosm.storage.set(`last-${what}`, today);
      else if (what) throw new Error(`"${what}" isn't one: review or mail`);
      return `last review: ${(await cosm.storage.get<string>("last-review")) ?? "never"}\nlast mail pass: ${(await cosm.storage.get<string>("last-mail")) ?? "never"}`;
    } });

  // --- the session ---------------------------------------------------------------------------------------------------

  // At a session's start: the profile and the map, for the agent; then /recall goes in (or, in a cosm with no profile
  // yet, /setup); before a session closes (Agent session's), the user is asked whether to reflect first, unless Reflect
  // ran in it.
  cosm.point.add("agent:start", { name: "profile", run: async () => {
    const profile = L.read(root, "profile.md");
    return `${profile ? `<profile.md>\n${profile.replace(/\n$/, "")}\n</profile.md>\n` : ""}<map>\n${await map()}\n</map>`;
  } });
  // Then Recall goes first (before anything else is sent), or Setup in a cosm with no profile yet.
  cosm.point.add("agent:start", { name: "recall", run: async ({ session, reason }: { session?: string; reason?: string }) => {
    if (!session || reason !== "startup") return;
    // Sent first, before whatever the user sends as the session starts.
    return { send: { prompt: L.read(root, "profile.md") ? "star-chart:recall" : "star-chart:setup" } };
  } });
  // What ran in a session, sent by a button or typed: the buttons' ticks and the closing question read it.
  cosm.on("agent:message.sent", async (d) => {
    const { text = "", prompt, session } = d as { text?: string; prompt?: string; session?: string };
    if (!session) return;
    const t = text.trim();
    if (prompt === "reflect" || /^\/(cosm:)?reflect\b/.test(t)) await kept(session).set("reflected", new Date().toISOString());
    if (prompt === "log" || /^\/(cosm:)?log\b/.test(t)) await kept(session).set("logged", new Date().toISOString());
  });
  cosm.on("agent-session:closed.before", async ({ session }: { session?: string }) => {
    if (!session || (await ran(session, "reflected"))) return;
    const yes = await cosm.ui.ask("Reflect before you go?", { description: "The agent checks this session for anything worth keeping that isn't written down yet. The session stays open; close it again when you're done.", choices: ["Reflect", "Close"] });
    // Dismissed (Cancel, Escape, a click outside): nothing closes.
    if (yes === null) return { stop: "Kept open" };
    if (yes !== "Reflect") return;
    await cosm.call("agent-session:send", { session, message: { prompt: "star-chart:reflect" } });
    return { stop: "Reflecting first" };
  });

  // Before a step of the agent: the fixes for what it is about to use (a fix named for the tool, a program its commands
  // run, or the ending of a file it names: fixes/pdftotext.md before `pdftotext …`), up to 2, each once per session.
  cosm.point.add("agent:step", { name: "fixes", run: async (e: { session?: string; step: string; uses: { commands: string[]; paths: string[] } }) => {
    const session = e.session;
    if (!session || !L.existsSync(`${root}/knowledge/fixes`)) return;
    const names = new Set([e.step.toLowerCase()]);
    const ending = (t: string) => { const b = t.replace(/^["'(),;]+|["'(),;]+$/g, "").split("/").pop() ?? ""; const m = /^(.+)\.([A-Za-z0-9]{2,5})$/.exec(b); if (m && /[A-Za-z]/.test(m[2])) names.add(m[2].toLowerCase()); };
    const skip = new Set(["sudo", "env", "time", "nohup", "xargs", "exec", "command", "then", "do", "if", "while", "!"]);
    for (const cmd of e.uses.commands) {
      for (const seg of cmd.split(/[|;&\n`(]/)) {
        const first = seg.split(/\s+/).filter((w) => w && (!w.includes("=") || w.startsWith("-"))).find((w) => !skip.has(w));
        if (first) { const p = first.replace(/^["'${}]+|["'${}]+$/g, "").split("/").pop() ?? ""; if (/^[\w.-]+$/.test(p)) names.add(p.toLowerCase()); }
      }
      cmd.split(/\s+/).forEach(ending);
    }
    e.uses.paths.forEach(ending);
    const store = kept(session);
    const shown = new Set((await store.get<string[]>("fixes-shown")) ?? []);
    const found = L.kids(`${root}/knowledge/fixes`).filter((f) => f.endsWith(".md")).map((f) => `knowledge/fixes/${f}`)
      .filter((p) => names.has(L.base(p).slice(0, -3).toLowerCase()) && !shown.has(p)).slice(0, 2);
    if (!found.length) return;
    await store.set("fixes-shown", [...shown, ...found].sort());
    return `<fixes hint="known fixes for what is about to run (Star chart's rules, Learning): use them">\n${found.map((p) => `From ${p}:\n${L.read(root, p).trimEnd()}`).join("\n")}\n</fixes>`;
  } });
}
