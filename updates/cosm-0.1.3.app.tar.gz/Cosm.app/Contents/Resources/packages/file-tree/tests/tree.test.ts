// File tree in the window (headless): the cosm's folders and files, laid out by its sections setting, hidden files
// only when asked, a click opening what it is.
import { describe, expect, test } from "bun:test";
import { testCosm } from "cosm/test";

const FILES = { "Inbox/a note.md": "A\n", "Projects/Garden/Garden.md": "# Garden\n", ".mcp.json": "{}\n" };
const SECTIONS = JSON.stringify({ sections: [{ folder: "Inbox", label: "Inbox", show: "link" }, { folder: "Projects", label: "Projects", sort: "name" }], foot: ["file-tree:trash"] });

describe("File tree", () => {
  test("lists the cosm's folders and files, the hidden ones only with Show hidden files", async () => {
    await using c = await testCosm({ files: FILES });
    await c.window();
    await c.run("ui", "wait", "--text", "Projects", "--view", "file-tree:tree", "--timeout", "30");
    let out = await c.run("ui", "outline", "file-tree:tree");
    for (const t of ["Inbox", "Projects"]) expect(out).toContain(t);
    expect(out).not.toContain(".mcp.json");
    await c.run("setting", "set", "file-tree", "hidden", "true");
    await c.run("ui", "wait", "--text", ".mcp.json", "--view", "file-tree:tree");
  }, 60000);

  test("laid out by its sections setting, with the trash in the foot", async () => {
    await using c = await testCosm({ files: FILES, settings: [["file-tree", "sections", SECTIONS]] });
    await c.window();
    await c.run("ui", "wait", "--text", "Projects", "--view", "file-tree:tree", "--timeout", "30");
    const out = await c.run("ui", "outline", "file-tree:tree");
    expect(out).toContain('treeitem "Inbox');
    expect(out).toContain('button "Trash"');
  }, 60000);

  test("a file clicked opens in its view", async () => {
    await using c = await testCosm({ files: FILES, packages: ["markdown"] });
    await c.window();
    await c.run("ui", "wait", "--text", "Projects", "--view", "file-tree:tree", "--timeout", "30");
    let out = await c.run("ui", "outline", "file-tree:tree");
    await c.run("ui", "click", /treeitem "Inbox"[^\n]*\[ref=([a-z]+\d+)\]/.exec(out)![1]);
    await c.run("ui", "wait", "--text", "a note", "--view", "file-tree:tree");
    out = await c.run("ui", "outline", "file-tree:tree");
    await c.run("ui", "click", /treeitem "a note"[^\n]*\[ref=([a-z]+\d+)\]/.exec(out)![1]);
    await c.until(async () => (await c.run("ui", "shown", "centre")).includes("a note"), { what: "the note open in the centre" });
  }, 60000);
});
