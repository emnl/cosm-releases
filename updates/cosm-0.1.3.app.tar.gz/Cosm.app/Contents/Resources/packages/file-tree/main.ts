// File tree: the cosm's folders and files as a tree in the left pane, and the trash. How the tree is laid out
// (sections, the items in them, a foot) is its `sections` setting, which a package that keeps a cosm a certain way
// presets (Star chart). A click on a folder opens it (`cosm.ui.open`), which a package answers (`folder.opened`). Its
// views reach the cosm through the functions below, never directly.
import type { Cosm } from "cosm";
import { shape } from "cosm/shape";

export default function (cosm: Cosm) {
  cosm.point.add("cosm:views", { name: "tree", file: "views/tree.html", label: "Files", location: { in: "left-pane" } });
  // Its place: items in the tree (`location: { in: "file-tree:tree" }`), shown where its `sections` setting names them
  // (`{folder, items: ["tables:tables"]}`), or under the tree.
  cosm.point.define("tree", { description: "Items in the file tree: rows under a section its sections setting names, or the foot.", holds: "values" });
  cosm.point.add("cosm:views", { name: "trash", file: "views/trash.html", label: "Trash", icon: "trash" });
  cosm.point.add("cosm:items", { name: "trash", label: "Trash", content: { icon: "trash" }, action: { open: "file-tree:trash" }, location: { in: "file-tree:tree" } });
  cosm.point.add("cosm:settings", { name: "others",
    shape: shape.boolean(),
    default: true,
    label: "Show other files",
    description: "Files no view shows (a PDF when no package has a view for PDFs) show in the tree, and open as a card, with Open in the system's app for it.",
  });
  cosm.point.add("cosm:settings", { name: "hidden",
    shape: shape.boolean(),
    default: false,
    label: "Show hidden files",
    description: "Files and folders whose names start with a dot (.claude, .mcp.json) show in the tree, faded, and open as any file does. Cosm's own folders never show.",
  });
  cosm.point.add("cosm:settings", { name: "sections",
    shape: shape.record(shape.unknown()),
    default: {},
    label: "Layout",
    description: "How the tree is laid out: {sections: [{folder, label, sort: name | recent, show: link, icon, items: [<package>:<item>]}], foot: [<package>:<item>], hidden: [globs]}. Without sections, the whole folder.",
    hidden: true,
  });

  // Its views' functions. The layout and the tree follow the settings and packages switched (a preset comes and goes
  // with its package); the tree, every file of the cosm; the trash, what goes to it and comes back.
  type Layout = { sections?: unknown[]; foot?: string[]; hidden?: string[] };
  const layout = async () => ((await cosm.setting.get("sections").catch(() => null)) ?? {}) as Layout;
  const settingsChange = { events: ["setting.changed", "package.changed"] };
  return cosm.view.export({
    layout: { description: "How the tree is laid out, and whether files no view shows are listed.", changes: settingsChange,
      run: async () => ({ sections: await layout(), others: (await cosm.setting.get("others").catch(() => true)) !== false }) },
    tree: { description: "The cosm's folders and files, what the layout hides left out.", changes: { files: "**", ...settingsChange },
      run: async () => cosm.file.tree({ skip: (await layout()).hidden ?? [], ...((await cosm.setting.get("hidden").catch(() => false)) === true ? { hidden: "include" as const } : {}) }) },
    folds: { description: "Which folds are open, as kept.", changes: {}, run: async () => (await cosm.storage.get("folds")) ?? {} },
    keepFolds: ({ folds }: { folds: Record<string, boolean> }) => cosm.storage.set("folds", folds),
    move: { description: "Moves or renames a file or folder (a package may refuse: its reason is thrown).",
      input: shape.object({ from: shape.string(), to: shape.string() }), run: ({ from, to }: { from: string; to: string }) => cosm.file.move(from, to) },
    trash: { description: "What is in the trash, newest first.", changes: { events: ["file.trashed", "file.created", "file.moved"] }, run: () => cosm.trash.list() },
    restore: { input: shape.object({ name: shape.string() }), run: ({ name }: { name: string }) => cosm.trash.restore(name) },
  });
}
