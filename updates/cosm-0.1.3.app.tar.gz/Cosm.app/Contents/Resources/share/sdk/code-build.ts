// Builds a package's main.ts and what it imports into one file for its worker: run by the package host with the Bun
// Cosm ships (`bun code-build.ts <dir> <out> <folder>`), a process of its own each time, since Bun's bundler remembers a
// library it didn't find for as long as its process runs (a library installed since would stay missing in the host).
// `cosm`, `cosm/*` and `package:*` stay outside (the worker gives them). The code goes to <out>, its source map inside
// it naming the saved files in full; a file the build makes beside the code (one imported as a file) goes into
// <folder> under its own name. Says, as one JSON line, `{added}` (the files it put in <folder> that weren't there), or
// `{error, added}`.
import { existsSync, mkdirSync, writeFileSync } from "node:fs";
import { basename, relative, resolve } from "node:path";

const [dir, out, folder] = process.argv.slice(2);
const added: string[] = [];
/** A build message as one line: where (from the package's folder), then what. */
const said = (m: any) => `${m?.position ? `${relative(dir, resolve(m.position.file))}:${m.position.line}:${m.position.column}: ` : ""}${m?.message ?? String(m)}`;

try {
  const r = await Bun.build({ entrypoints: [`${dir}/main.ts`], target: "bun", format: "esm", external: ["cosm", "cosm/*", "package:*"], sourcemap: "external", throw: false });
  const entry = r.outputs.find((o) => o.kind === "entry-point");
  if (!r.success || !entry) {
    console.log(JSON.stringify({ error: r.logs.filter((l: any) => l.level === "error").map(said).join("\n") || "its main.ts didn't build", added }));
  } else {
    mkdirSync(folder, { recursive: true });
    for (const o of r.outputs) if (o.kind === "asset") {
      const to = `${folder}/${basename(o.path)}`;
      if (!existsSync(to)) added.push(to);
      writeFileSync(to, new Uint8Array(await o.arrayBuffer()));
    }
    // The map's sources are named from where the build ran: named in full, they hold wherever the file is.
    let code = await entry.text();
    if (entry.sourcemap) {
      const map = JSON.parse(await entry.sourcemap.text());
      map.sources = (map.sources ?? []).map((s: string) => resolve(process.cwd(), s));
      code += `\n//# sourceMappingURL=data:application/json;base64,${Buffer.from(JSON.stringify(map)).toString("base64")}\n`;
    }
    writeFileSync(out, code);
    console.log(JSON.stringify({ added }));
  }
} catch (e) {
  // A failed build throws with each error in `errors`: said one a line.
  const list = (e as { errors?: unknown[] })?.errors;
  console.log(JSON.stringify({ error: Array.isArray(list) && list.length ? list.map(said).join("\n") : String((e as { message?: string })?.message ?? e), added }));
}
