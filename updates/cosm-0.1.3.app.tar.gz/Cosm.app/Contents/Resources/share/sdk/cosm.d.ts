// The Cosm API. A package's script, main.ts, is given `Cosm`:
//
//   import type { Cosm } from "cosm";
//   export default function (cosm: Cosm) { cosm.on("file.saved", (e) => { … }); }
// While the default function runs it only registers: asking Cosm then throws (the answer could wait on this load).
//
// and each of its views (the page its `cosm:views` contribution names, `file`, run in the window) has `ViewCosm` as
// `window.cosm`. Both share one set of calls (`Services`): main.ts adds what registers things, a view adds `cosm.view`,
// `cosm.main` and what only the window can do. Every name is the same in the shell, in code and in the engine:
// `cosm file move` is `cosm.file.move()` is the engine's `file.move`.
//
// Cosm maps the name "cosm" to this file when it checks a package; nothing is installed. Version 1.0 (cosm.json's
// "cosm": ">=1.0").
//
// Every function a package registers runs in the package's own worker, in Bun, and may be async. One rule for all of
// them:
//   in        one object with named fields (`{ things }`, the event, the clicked file, a tool's args), so Cosm can add
//             a field later without breaking a package;
//   out       the thing asked for, bare: a label, the texts, a tool's answer;
//   nothing   (undefined or null) says nothing: no label, carry on, no text for the agent, can't merge;
//   a string  is text for whoever reads it: the agent after a session or message event, the user for a tool;
//   { stop }  the one decision, only where something can be stopped (the before-events);
//   a throw   the one failure; Cosm says it to each caller in its own form and never takes it as a decision.

/** A reference to something of a package: `star-chart:inbox`, or a bare name for the package's own. */
export type Ref = string;
/** A path inside the cosm, relative to its folder: `02-spaces/Home.md`. */
export type Path = string;
/** One thing the index holds: a file by its path, or an item that is no file by `<package>:<kind>:<key>`. */
export type Thing = string;
type Awaitable<T> = T | Promise<T>;

// --- events -------------------------------------------------------------------------------------------------------------

/** Who called a function Cosm calls (an export, a point's function). Which conversation a call is about, when it is
 * about one, is in its input: Cosm keeps no conversations. */
export interface CallContext {
  /** A package's name (its code called, or a program it runs: the agent's own commands give its connector's, `claude`),
   * `window` (the user, there or in a view) or `shell` (a person's terminal). */
  by: string;
}
/**
 * What every handler is given second, after the event's data: the event's name, the package that fired it
 * (the name's prefix, `cosm` for Cosm's own) and who caused it. Everything else is in the data: the agent's events
 * name their conversation there (`data.session`, Agent session's id).
 */
export interface Context {
  /** `file.saved`, or a package's own as `<package>:<event>`. */
  name: string;
  /** The package that fired it, `cosm` for Cosm's own. */
  package: string;
  /** Who caused it: `window` (the user, in the window or in a package's view), a package's name (its main.ts, or a
   * program it runs: the agent's own commands give its connector's), `shell` (a person's terminal), or `outside`
   * (another app, git). */
  by: string;
}
/** An event's data: exactly what it was emitted with. */
export type Data = Record<string, unknown>;
/** A file event's data: the files, by path. */
export interface FilesData { paths: Path[] }
/** A move's data: each file that moved (a folder's contents move with it). */
export interface MovesData { moves: { from: Path; to: Path }[] }
/** A before-event's data: the file, its kind, and what is about to happen (`text` for a save, `to` for a move). */
export interface BeforeData { path: Path; kind: Ref | null; text?: string; to?: Path }
/** A before-event's answer: nothing lets the change through; `{stop}` stops it, saying why. */
export type Answer = void | undefined | null | { stop: string };
/** A save's or a new file's answer: as Answer, or the text to write instead (the next handler gets it). */
export type TextAnswer = Answer | { text: string };
/** A move's answer: as Answer, or where the file goes instead, a path in the cosm (only when it moves alone). */
export type MoveAnswer = Answer | { to: Path };

export type FileEvents = "file.saved" | "file.created" | "file.opened" | "file.trashed" | "file.removed";
export type BeforeEvents = "file.saved.before" | "file.created.before" | "file.moved.before" | "file.trashed.before";
/** `folder.opened` (`{folder}`): a folder was opened (`cosm.ui.open(folder)`: a click in the tree, a toolbar's path,
 * the agent); what it shows is a package's to answer (Star chart opens a space's page). */
export type CosmEvents = FileEvents | BeforeEvents | "file.moved" | "window.opened" | "window.closed" | "folder.opened"
  | "setting.changed" | "ui.changed" | "package.changed" | "kind.changed" | "package.started" | "package.stopping"
  | "process.started" | "process.exited" | "process.attached" | "process.detached" | "ui.progress"
  | "stream.opened" | "stream.items" | "stream.closed";
/**
 * What the window asks of a view, heard in the view with `cosm.on`: another argument opened in it, or it left the
 * screen; ⌘F (it shows its own find bar); take the cursor; rename a file or folder in place (`{path}`: answer the new
 * name, or null when the name stays).
 */
export type ViewEvents = "view.opened" | "view.closed" | "view.find" | "view.focus" | "view.rename";

/** Narrows a file handler to the files of a kind (and the kinds extending it). */
/** Narrows a file event's handler: to a kind's files, or to the files globs match (Cosm's glob rule). A connected
 * folder's files reach a handler only through globs that name them, and naming them asks the engine to watch there
 * while the package is on, asleep or not: `{ files: "@scans/*.pdf" }` one level, with `**` all under the folder. Only
 * changes while Cosm runs are told: a package that must not miss anything looks at what is there when it starts. */
export interface On { kind?: Ref; files?: string | string[] }

// --- what clicking does ---------------------------------------------------------------------------------------------------

export interface Ask { question: string; description?: string; yes: Action }
/** A new file of a kind, made in the window; `{name}` and `{folder}` fill in from the answer and the place. `template`:
 * its starting text (`{name}`, `{date}`, `{time}` filled in), else the kind's: kept in code, or imported from a file of
 * the package (`await cosm.package.file.read("templates/space.md")`). */
export interface New { kind: Ref; folder?: string; name?: string; template?: string; question?: string }
/** What an item's function is given when the item is chosen (a click, Enter, a shortcut, `cosm.ui.run`): the file or
 * folder it is used on; the thing that is no file it was chosen on (`agent-session:session:c-7k2p`: the one its view
 * shows; from ⌘K or the menu bar, the one on screen used last; none when no such thing is on screen); on a problem
 * (`in: "notice"`), the problem's words and the package it is about. What to do with them is the package's choice. */
export interface Target { path?: Path; folder?: Path; thing?: string; text?: string; package?: string }
/**
 * What choosing an item does: a function of the package's (run in its worker; a string it returns is a notice), a
 * question first, a file opened, or a new file made. Sending
 * the agent something is a function's (`cosm.call("agent-session:send", …)`): which conversation is the package's choice.
 */
export type Action =
  | ((target: Target) => Awaitable<unknown>)
  | { ask: Ask }
  | { open: Path | Ref; arg?: string }
  | { new: New };

// --- the window -----------------------------------------------------------------------------------------------------------

/** The places an item can be, or another package's place: a point it defines that one of its views draws (`file-tree:tree`). */
export type Place = "left-pane" | "centre-pane" | "right-pane" | "palette" | "file-menu" | "folder-menu" | "menu-bar" | "settings" | "notice" | (string & {});
/** Where an item is: a place, narrowed to files of a kind or in a folder (a right-click menu's); in the menu bar, its
 * `menu` (one of Cosm's, File, Edit, View, Window, or one of its own, shown between View and Window). */
export interface Location { in: Place; kind?: Ref; folder?: string; menu?: string }

/** A view: its page and its wiring. */
export interface View {
  /** Its page, a file of the package (`views/board.html`; a view built with its own scripts: its `index.html`), served
   * from the package's folder, so what it links to beside it is found. */
  file: string;
  label?: string;
  /** Optional: one of Cosm's icons by name (`cosm ui icon list`), or an SVG of its own as text (`await
   * cosm.package.file.read("icons/star.svg")`), drawn in the text's colour. */
  icon?: string;
  /** What it is given: a file, a folder, a thing of a kind that is no file (`<package>:<kind>:<key>`: a table, a
   * conversation), or nothing. */
  input?: "file" | "folder" | "thing";
  /** Where it sits: left-pane, centre-pane, right-pane, `settings` (on its own package's page in Settings, as tall as
   * its page: an agent's install and sign-in), or another package's place that holds views (`agent-session:holder`: a
   * point it defines, shown in its view's <cosm-place>). */
  location?: Location;
}
/**
 * What an item carries for the views that draw it: anything a view reads. Cosm's own places (⌘K, menus, notices,
 * Settings) and its kit read `icon` (one of Cosm's by name, or an SVG as text, as a view's `icon`) and `description` (a line under it); the
 * Agent session holder reads `done` too (a dot: done in the conversation). `label`, when given, takes the place of the
 * item's own.
 */
export type Content = { label?: string; icon?: string; description?: string; [key: string]: unknown };
/** An item's content worked out where it is shown. */
export type ContentFn = (input: { thing?: string }) => Awaitable<Content | null>;
export interface Item {
  /** Its name, so a cosm can leave it out or another package take its place (`items/<name>`). */
  name: string;
  /** Its words, wherever it shows (⌘K, a menu, a view), and for a screen reader. */
  label: string;
  /**
   * What it carries for the views that draw it: an object, or a function giving one for the thing that is no file the
   * view it is shown in shows (`{thing: "tables:table:expenses"}`; none outside one); null hides the item. A function
   * is worked out once (for each thing shown), and again only when what its `changes` name changes, as a view
   * function's (`{ run, changes: { storage: "last-review" } }`); a bare function never again by itself. It only reads:
   * a content function that writes or emits makes its own changes.
   */
  content?: Content | ContentFn | { run: ContentFn; changes?: Changes };
  action?: Action;
  /**
   * Answers what the user types where the item shows (⌘K): rows, each with its label, a line under it, and what
   * choosing it does. Markdown's "Find a Page" gives pages by name this way. Asked as the user types; a slow answer
   * is left out.
   */
  find?: (input: { query: string }) => Awaitable<{ label: string; description?: string; action: Exclude<Action, Function> }[]>;
  /** Where it sits: one place, or several (⌘K and a menu of the menu bar). */
  location: Location | Location[];
  /** Its shortcut in the menu bar (`CmdOrCtrl+Alt+N`); the first package in order to claim one has it. */
  keys?: string;
}

/**
 * A view on screen: where, which, its label, what it shows (its argument: a path, a thing that is no file as
 * `tables:table:expenses`), that argument's kind and name as Cosm shows it (a thing's name is its key), the file's path
 * when it shows one, and when it was last opened, clicked or typed in (ISO time).
 */
export interface Shown {
  pane: "left" | "centre" | "right";
  view: Ref;
  label: string;
  kind?: Ref | null;
  arg?: string;
  name?: string;
  path?: Path;
  /** When it was last shown, given a file or a thing, clicked or typed in (ISO time). */
  used: string;
  /** What the view published about itself (`cosm.view.publish`): Markdown's and Plain text's `selection`. */
  facts?: Record<string, unknown>;
}
/** An item as a place holds it: its label and content worked out for the thing its view shows; what it opens when it opens
 * something (`open` and `arg`, as its action and `cosm.ui.open` say it, so a view can light it while that is shown). It
 * runs with `cosm.ui.run(id)`. */
export interface Placed { id: string; name: string; package: string; label: string; content: Content; open?: string; arg?: string }
/** The window: the calls a script and a view share. */
export interface UiCalls {
  /** Every view on screen (one pane's, or all), in the window used last. When it changes, `ui.changed` is heard with
   * `{shown}`: all of them, as this gives them. */
  shown(pane?: "left" | "centre" | "right"): Promise<Shown[]>;
  /** The view used last: of that view (`markdown:page`), or of any. Null when there is none. */
  active(view?: Ref): Promise<Shown | null>;
  /**
   * Opens a file, or a view with its argument. A file goes to the most recently used view that shows its kind; with
   * none on screen, it shows in the pane what is opened shows in (the layout's `opens`). Rejects when there is nothing
   * to open, or no window is open to show it ("No window is open on this cosm").
   */
  open(target: Path | Ref, arg?: string): Promise<void>;
  /** Closes what is opened: the file or view given, else what is open now; its pane shows its placed views again. */
  close(target?: Path | Ref): Promise<void>;
  back(): Promise<void>;
  forward(): Promise<void>;
  /** What is placed in a place: a menu, the palette, a package's place (`file-tree:tree`). When their labels change,
   * `ui.changed` is heard with `{items}` (the items' names). */
  items(place: Place): Promise<Placed[]>;
  /** Does what choosing an item does, by its id (`"stamp:stamp"`, as `items` gives it; a bare name is the package's
   * own), wherever it is placed and
   * whoever asks: run as the package that made it, its function given what it is used on (`on`) and the thing it acts on
   * (`on.thing`, else the thing its view shows: as a click in a view of that thing gives it).
   * A view drawing items another package placed in it runs them this way. Rejects when no window is open. */
  run(item: Ref, on?: { path?: Path; folder?: Path; thing?: string }): Promise<void>;
  /**
   * Long work the user sees where notices show, and can cancel (a first mail fetch, an import): `fn(progress, signal)`,
   * where `progress({ message, done })` says how far it is (`done` from 0 to 1; without it, a running line) and
   * `signal` aborts when the user presses Cancel. It goes when `fn` returns (its answer is progress's) or throws (thrown
   * on: what started the work says the failure, a button's action as a problem notice, background work in the log).
   */
  progress<T>(title: string, fn: (progress: (p: { message?: string; done?: number }) => void, signal: AbortSignal) => Awaitable<T>): Promise<T>;
  /** A notice in the window; `as: "problem"` stays until dismissed, with Ask the agent. */
  notify(text: string, options?: { as?: "problem" }): Promise<void>;
  /**
   * Asks the user a question in the window: one of `choices`, or with `answer: "text"` what they type (Yes / No without
   * either); `answer: "folder"`: a folder they choose (the Mac's folder picker), its full path. It takes the keyboard as a sheet; `in: "background"` asks without interrupting, as a card in the corner.
   * Their answer, or null when they dismissed it.
   */
  ask(question: string, options?: Asking): Promise<string | null>;
}
/**
 * A row of a menu a view shows (`cosm.ui.menu(rows, …)`): one to choose (its `id`; without one, only its options can
 * be), with a `hint` at its end and its own options (`items`, behind ⋯ on the row); a heading; a separator.
 */
export type MenuRow = { id?: string; label: string; hint?: string; items?: MenuRow[] } | { heading: string } | "separator";
/** The window, in a view: also menus, which the window draws over every view. */
/** The window, as a view asks it: what mirrors the window's own controls, and what it shows.
 * Back and forward are the window's toolbar's (`<cosm-toolbar>`); a file's menu is a right-click on an element marked
 * `data-cosm-file="<path>"` (or `data-cosm-folder`). */
export interface ViewUi extends Omit<UiCalls, "back" | "forward"> {
  /**
   * A menu of the view's own rows, under `at` (an element of the page; else at the pointer): `current`, the id (or ids)
   * ticked; `find`, a find field over the rows (its placeholder). Answers what was chosen, as the path of ids (a row's
   * option: `[row, option]`), or null when closed with nothing chosen.
   */
  menu(rows: MenuRow[], options?: { at?: Element; current?: string | string[]; find?: string }): Promise<string[] | null>;
  /** Every icon the view may draw (`cosm:icons`, as the window handed them to it): each by the name it is reached as
   * (bare) and in full (`<package>:<name>`), with its SVG text (drawn in one colour: `currentColor`, or as a mask).
   * The kit's `<cosm-icon name>` draws one. In a package's main.ts, `cosm.point.read("cosm:icons")`. */
  readonly icon: { list(): Promise<{ name: string; svg: string }[]> };
}

// --- what the cosm holds, and the index ----------------------------------------------------------------------------------

/** What the index reads of a thing: its text, a name, a first line (the lead). */
export interface Text { thing: Thing; name?: string; lead?: string; text: string }
/** A fact's value: a text, a number, yes or no, a link to another thing (`{to}`), or a date (`{date: "2026-11-01"}`). */
export type FactValue = string | number | boolean | { to: Thing } | { date: string };
/** What is known of one thing: `{status: "open", links: [{to: "People/Anna Berg.md"}], due: {date: "2026-11-01"}}`. */
export type Facts = Record<string, FactValue | FactValue[]>;
/** A three-way merge: the common text, the user's, and what changed on disk; the merged text, or null when it can't. */
export interface Merge { base: string; mine: string; theirs: string }

export interface Kind {
  /** Another package's kind it narrows: `markdown:page`. */
  extends?: Ref;
  /** The files it claims: a glob, or several (`/profile.md` from the cosm's root). */
  match?: string | string[];
  /** Or things that are no files: a function listing them (`{key, name, lead?, text?}` each: its key, the name shown,
   * its first line, its text for search), listed again when `watch` changes. */
  items?: (input: {}) => Awaitable<Record<string, unknown>[]>;
  watch?: string;
  view?: Ref;
  /** A new file's starting text (`{name}`, `{date}`, `{time}` filled in): kept in code, or imported from a file of the
   * package (`await cosm.package.file.read("templates/article.md")`). */
  template?: string;
  label?: string;
  /** How a file of it is merged when it changed on disk while open: a function, or `"lines"` (Cosm's own). */
  merge?: "lines" | ((m: Merge) => Awaitable<string | null>);
  /** false keeps it out of ordinary search. */
  search?: boolean;
  /** What the index reads of its things (`"name"` or `"file"`: Cosm's own; else a function given them). */
  text?: "name" | "file" | ((input: { things: Thing[] }) => Awaitable<Text[]>);
  /** Facts of its things, combined with every other package's for the same things. */
  facts?: (input: { things: Thing[] }) => Awaitable<Record<Thing, Facts>>;
}

/** A search hit, best first: the thing, its first line, and with `passages` the passage that matched. */
export interface Hit { thing: Thing; lead?: string; passage?: string }
/** What `retrieve` gives. */
export interface Retrieved {
  total: number;
  words: { word: string; form: string; count: number }[];
  things: { thing: Thing; name: string; lead: string; kind: Ref | null; words: string[]; inName: string[]; bm25: number; named: boolean }[];
}
/** A thing `find` found: its name, kind, first line, and when it last changed (seconds since 1970). */
export interface Found { thing: Thing; name: string; kind: Ref | null; lead?: string; modified: number }


/** What the index holds: the calls a script and a view share. */
export interface IndexCalls {
  /** The things meeting every condition, as `cosm index find` takes them: `["status=open", "words>3", "kind=markdown:page"]`. */
  find(conditions: string[]): Promise<Found[]>;
  /** What matches the words: of a kind, in files a glob matches (any of them), with the passage that matched. */
  search(words: string, options?: { kind?: Ref; in?: string[]; passages?: boolean }): Promise<Hit[]>;
  /**
   * The text's words as the index makes them out, each with its form: the root search matches it by (with Advanced
   * search on, its stem in the cosm's languages), `""` for a glue word ("and", "the"); in the order they first come.
   */
  analyze(text: string): Promise<{ word: string; form: string }[]>;
  /**
   * The candidates for the words and their numbers, for a package that ranks them itself (a reranker, as Search hints):
   * how many things there are, how common each word is, and for each candidate the words it holds, which are in its
   * name, its BM25 score and whether the words name it. `search` is the same, ranked by Cosm.
   */
  retrieve(words: string, options?: { kind?: Ref; in?: string[] }): Promise<Retrieved>;
  /** One read-only SQL statement over the tables `things` and `facts`: its rows, each an object by column. */
  query(sql: string): Promise<Record<string, unknown>[]>;
}

// --- the agent ---------------------------------------------------------------------------------------------------------------

/**
 * One input of a tool: a flag in the shell (`--days 7`, or a word in its place), a field of the input object
 * elsewhere. `type`: `text` (the default), `number`, `switch` (true or false), `list` (texts: the remaining words),
 * `stdin` (a text: in the shell, what is piped in when not given as a word or flag; one at most).
 */
export interface Input {
  name: string;
  label?: string;
  description?: string;
  type?: "text" | "number" | "switch" | "list" | "stdin";
  choices?: readonly string[];
  optional?: boolean;
}
/** The value an input gives `run`: by its type, one of its choices when it has them. */
type ValueOf<I> = I extends { type: "number" } ? number : I extends { type: "switch" } ? boolean : I extends { type: "list" } ? string[]
  : I extends { choices: readonly (infer C extends string)[] } ? C : string;
type Flat<T> = { [K in keyof T]: T[K] } & {};
/** What `run` is given, worked out from the inputs: the needed ones always there, the optional ones maybe. */
export type ArgsOf<L extends readonly Input[]> = Flat<
  { [I in L[number] as I extends { optional: true } ? never : I["name"]]: ValueOf<I> } &
  { [I in L[number] as I extends { optional: true } ? I["name"] : never]?: ValueOf<I> }>;
/** A tool for the agent: a contribution to Cosm's point `cosm:commands` (`cosm <package>:<name>` in its shell, an MCP
 * tool where tools are offered). */
export interface Tool<L extends readonly Input[] = readonly Input[]> {
  description: string;
  /** How a call of it reads in a chat, as a step the agent took: "Searched your logs for “{words}”" (`{<input>}` filled
   * from the call). Without one, the agent's package says it its own way. */
  step?: string;
  /** Its inputs, in the order words fill them in the shell. Cosm checks every call against them before `run`. */
  inputs?: L;
  /** Its answer: a string is shown as it is, a list of strings one a line, anything else as JSON. A failure: throw.
   * Its second argument says who called it: a package's name (its `cosm.call`), `shell` or `window`. */
  run: (args: ArgsOf<L>, context: CallContext) => Awaitable<unknown>;
}
// --- points: one package defines, others add to ------------------------------------------------------------------------

/**
 * What a contribution's data must be: plain JSON Schema, most simply written with Cosm's `cosm/shape`
 * (`import { shape } from "cosm/shape"`: `shape.object({ title: shape.string() })`), or a schema from any library with
 * the Standard JSON Schema interface (zod, ArkType: the package's own, in its package.json). Cosm takes the JSON Schema
 * from it and checks every contribution, in code or a file, against it. Data only: what JSON Schema can't hold (a
 * function, a date, a transform) is refused when the point is defined; a point names its functions in `functions`.
 */
export type Shape = { readonly "~standard": unknown } | Record<string, unknown>;
declare const shaped: unique symbol;
/** A shape from `cosm/shape`: plain JSON Schema that carries, for TypeScript only, the type `T` it takes. */
export type Shaped<T> = Record<string, unknown> & { readonly [shaped]: T };
export interface PointDefinition {
  /** What it is for: the agent reads it when it writes a contribution. */
  description: string;
  /** Its name as the user reads it (Settings: "Sign-in: OAuth ▾"). */
  label?: string;
  /** Files (from the folder `<package>/<point>/` of each package), values (in code or `<name>.json` files there) or
   * functions (in code). */
  holds: "files" | "values" | "functions";
  shape?: Shape;
  /** For a point holding functions: those every contribution has beside its data (`["render"]`), checked to be there
   * and to be functions. */
  functions?: string[];
  /** `all` (the default): every contribution, together; `one`: one at a time, the user's default (`default()`), the
   * others still usable. */
  uses?: "all" | "one";
}
/** A contribution as a reader gets it: whose it is, its name, the name it is reached by (its own while no earlier one
 * has it, else `<package>:<name>`), its file for a point holding files, and what it is (its functions callable, run in
 * its package). */
export type Contribution<T = Record<string, unknown>> = T & { package: string; name: string; as: string; path?: string;
  /** For a point used one at a time: this is the one used now (the user's default, else the first), as `read` gives
   * it, without asking. */
  default?: true;
  /** The package whose override stands in its place, when one does (its functions run there). */
  by?: string };
export interface PointCalls {
  /** Every contribution to a point (`<package>:<point>`, a bare name the package's own, Cosm's as `agent:skills`),
   * in Cosm's package order, after the cosm's leave-outs and the overrides. */
  read<T = Record<string, unknown>>(point: Ref): Promise<Contribution<T>[]>;
  /** For a `uses: "one"` point: the contribution used now, the user's default (asked once when several and none
   * set), or null when nothing adds to it. */
  default<T = Record<string, unknown>>(point: Ref): Promise<Contribution<T> | null>;
}
export interface Points extends PointCalls {
  /** Defines a point of the package's own (`<package>:<name>` for others). */
  define(name: string, point: PointDefinition): void;
  /**
   * Adds to a point, the package's own or another's: its name (a part of the package, `<owner>/<point>/<name>`) and
   * what it is. Typed here: Cosm's own, those Cosm reads — `cosm:commands` (a command on its command line, the
   * agent's tool: `cosm <package>:<name>`), `cosm:views` (a view; its page the `file` it names), `cosm:items` (a ⌘K
   * entry, a menu entry, a button), `cosm:kinds` (what the cosm holds, how it opens and is indexed), `cosm:settings`,
   * `cosm:secrets`, `cosm:events` (an event the package fires, with what it means), `cosm:stems` (word forms for
   * search, one used at a time), `cosm:skip` (folders search leaves out), `cosm:schedules` (a function Cosm runs at set
   * times, waking the package) — and the built-in `agent` package's
   * `agent:mcp`, `agent:secrets` and `agent:agents`. Files add by folder: `agent/instructions.md`,
   * `agent/prompts/<name>.md`, `agent/skills/<name>/`, `agent/mcp/<name>.json`, `themes/`.
   */
  add<const P extends Ref, const L extends readonly Input[] = []>(point: P, contribution: Adding<P, L>): void;
}
/**
 * What a contribution added to a point is, by the point's name: a command's `run` typed from its `inputs`; one of Cosm's
 * points by its shape (`PointTypes`), as is a package's whose types are imported (`import type {} from "package:agent"`
 * adds the `agent` package's); any other package's loosely, by its name (Cosm checks it against the point's shape when
 * it runs); a `cosm:` name Cosm has no point by, nothing (refused). One signature,
 * so no overload is tried first and nothing falls through to a looser one.
 */
export type Adding<P extends Ref, L extends readonly Input[] = []> =
  P extends "cosm:commands" ? { name: string } & Tool<L>
  : P extends keyof PointTypes ? PointTypes[P]
  : P extends `cosm:${string}` ? never
  : { name: string; [key: string]: unknown };
/** What a contribution to a point is, by the point (besides `cosm:commands`, a `Tool`): Cosm's own here; a package
 * adds its own points' from its main.ts (`declare module "cosm" { interface PointTypes { "<package>:<point>": … } }`), for
 * the packages that import its types. */
export interface PointTypes {
  "cosm:views": { name: string } & View;
  "cosm:items": Item;
  "cosm:kinds": { name: string } & Kind;
  "cosm:settings": { name: string } & Setting;
  "cosm:secrets": { name: string; label?: string; description?: string };
  "cosm:themes": { name: string } & Theme;
  /** An icon, by its name: its SVG text, drawn in one colour (`currentColor`, or as a mask). */
  "cosm:icons": { name: string; svg: string };
  "cosm:events": { name: string; description: string };
  "cosm:stems": { name: string; stems: (input: { words: string[] }) => Awaitable<string[]>; compounds?: boolean };
  "cosm:skip": { name: string; globs: string[] };
  "cosm:schedules": Schedule;
}

/**
 * Something a package does at set times: Cosm runs `run` when it is due, waking the package for it, so the package
 * keeps no timer and sleeps between times. Only while Cosm runs; one missed while it was closed runs once at its next
 * start. `cosm schedule list` shows each with when it runs next.
 */
export interface Schedule {
  name: string;
  /** On this computer's clock: `every 10m` (or `2h`, `1d`: that long after it ran last), `daily 08:00`,
   * `weekly mon 08:00`, or once: `2026-11-07 13:00`, `today 13:00`, `tomorrow 13:00` (of the day Cosm first sees it). */
  when: string;
  /** What it is for, as `cosm schedule list` shows it. */
  description?: string;
  /** Run when it is due: `due` is the time it was due ("2026-11-07 08:00:00"), later than now when Cosm was closed. */
  run: (input: { name: string; when: string; due: string }) => Awaitable<unknown>;
}

/** Every colour a theme gives (the window's variables, `var(--page)` …). */
/** A theme's colours, all of them: what each is for (surfaces, text, lines and fills, the accent, what a message means),
 * then the palette of eight hues for telling unrelated things apart (tags, chart series, categories). A value may name
 * another (`"danger": "var(--red)"`). */
export type Colour = "page" | "side" | "chat" | "card" | "bubble" | "text" | "muted" | "faint" | "title" | "bullet"
  | "line" | "line-strong" | "sel" | "fill" | "fill-strong" | "accent" | "onaccent" | "ok" | "warn" | "danger"
  | "red" | "orange" | "yellow" | "green" | "teal" | "blue" | "purple" | "pink";
/** Every colour of a theme's terminal. */
export type TerminalColour = "background" | "foreground" | "cursor" | "cursorAccent" | "selectionBackground" | "black" | "red" | "green" | "yellow"
  | "blue" | "magenta" | "cyan" | "white" | "brightBlack" | "brightRed" | "brightGreen" | "brightYellow" | "brightBlue" | "brightMagenta"
  | "brightCyan" | "brightWhite";
/** A theme (`cosm:themes`), complete: kept in code, or in a JSON file the package imports (`import dusk from "./themes/dusk.json"`). */
export interface Theme {
  label: string;
  look: "light" | "dark";
  colours: Record<Colour, string>;
  /** Its terminal's colours (a view's `<cosm-terminal>`), every one. */
  terminal?: Record<TerminalColour, string>;
  /** One agent's own theme for its screen, by its package's name (as that agent's point `<agent>:config` takes it). */
  agents?: Record<string, unknown>;
}

// --- what the user sets ----------------------------------------------------------------------------------------------------

export interface Setting {
  /**
   * The values it takes, as a point's shape is written (`shape.boolean()`, `shape.enum(["a", "b"])`,
   * `shape.number({ min: 10 })`, `shape.string({ format: "font" })` from `cosm/shape`; a schema library's; or JSON Schema):
   * Settings picks the control from it (a
   * switch, a menu, a number field, a font picker, a text field). None: a text.
   */
  shape?: Shape;
  default?: unknown;
  label?: string;
  description?: string;
  question?: string;
  /** The value in use, when another tool holds it. Settings shows the last one worked out while it asks again (it never
   * waits on it); when it changes, `setting.changed` is heard with `current`. */
  current?: (input: {}) => Awaitable<unknown>;
  hidden?: boolean;
}
export interface SettingCalls {
  /** A setting's value: its own by name, another package's as `<package>:<name>`, Cosm's own as `cosm:<name>`. When one changes, `setting.changed`
   * is heard with `{package, name, value}`; the user's choices (a tie, an association, the layout) with `{scope}` only. */
  get<T = unknown>(name: string): Promise<T>;
}
export interface Settings extends SettingCalls {
  /** Values it suggests for settings of another package (`cosm` for Cosm's own), below the user's. */
  preset(owner: string, values: Record<string, unknown>): void;
}
export interface Secrets {
  /** A secret's value, its own or another package's (`{package}`: a package is trusted as a whole), or null when the
   * user hasn't given it. */
  get(name: string, options?: { package?: string }): Promise<string | null>;
}

// --- the services scripts and views share -------------------------------------------------------------------------------------------

/** How a question is asked: its line under it, the answer it takes (choices or what is typed), and where. */
export type Asking = { description?: string; in?: "background" } & ({ choices?: string[]; answer?: never } | { answer: "text" | "folder"; choices?: never });

/** A folder or file of the cosm, as `cosm.file.tree()` gives it (hidden files left out unless asked for). */
export interface TreeNode {
  /** Its name as Cosm shows it ("Acme deal" for "Acme deal.md"). */
  name: string;
  path: Path;
  folder: boolean;
  /** When it last changed, seconds since 1970 (a folder: its newest file). */
  modified: number;
  children: TreeNode[];
  kind?: Ref;
  /** The view it opens in; none: it opens as a card. */
  view?: Ref;
}
/** What `stat` gives: its kind, its name as shown, when it changed (seconds since 1970), its size. */
export interface Stat { kind: Ref | null; name: string; modified: number; size: number; folder: boolean }
/** The cosm's files, through Cosm (`node:fs` is for a package's own folders). */
export interface Files {
  read(path: Path): Promise<string>;
  read(path: Path, options: { bytes: true }): Promise<Uint8Array>;
  /**
   * Writes a file whole through Cosm (the before-events ask first, and the save is told): a new file, or a deliberate
   * replace. To change a file that may be open, `change`; to add to its end, `append`.
   */
  write(path: Path, content: string | Uint8Array): Promise<void>;
  /** Adds text to a file's end (made when it isn't there), without losing anything written meanwhile. */
  append(path: Path, text: string): Promise<void>;
  /**
   * Changes a file: `fn` gets its text now and gives the new text. Written only while the file is still that text; when
   * it changed meanwhile (the user typed in it), `fn` is run again on the newest. As Obsidian's `vault.process`.
   */
  change(path: Path, fn: (text: string) => string | Promise<string>): Promise<void>;
  /** A file's name as Cosm shows it: without its ending when a kind claims it ("Plan" for Plan.md), else whole. */
  name(path: Path): Promise<string>;
  /** The paths a glob matches; in a connected folder too (`@company/Reports/*.md`, a folder as `name/`;
   * `**` all under a folder). A file of a connected folder is `@<id>/<path>` wherever a path is taken. */
  list(glob: string): Promise<Path[]>;
  /** The cosm's folders and files; `skip` leaves out what its globs match, by Cosm's glob rule (a folder with all it holds).
   * `hidden: "include"` lists hidden files and folders too (a part of the path starts with `.`); never `.cosm`, `.trash`, `.git`, `.DS_Store`. */
  tree(options?: { skip?: string[]; hidden?: "include" }): Promise<TreeNode[]>;
  /** What is known of a file or folder; null when it isn't there, or is hidden (a name starting with `.`). */
  stat(path: Path): Promise<Stat | null>;
  /** Moves or renames a file or folder: `to` a new name (it stays in its folder), a path (`notes/x.md`), `./<name>` for
   * the cosm's top, or a folder ending in `/` (its name kept). A page in a folder of its own name takes the folder
   * along. Packages fix what pointed at it, just after it returns. */
  move(from: Path, to: Path): Promise<void>;
  /** To the cosm's trash, where it can be put back. */
  trash(path: Path): Promise<void>;
  /** The file a name means (as Cosm shows names), the nearest to `from`; null when none. */
  which(name: string, options?: { kind?: Ref; from?: Path }): Promise<Path | null>;
}
/** A file opened for editing (a view's): saved on top of the version read, merged by its kind when it changed. */
export interface FileHandle {
  /** Its path; follows a move. */
  readonly path: Path;
  /** When it was written, as opened or last read (seconds since 1970). */
  readonly modified: number;
  read(): Promise<string>;
  read(options: { bytes: true }): Promise<Uint8Array>;
  /** The whole text as it now stands on screen; Cosm saves it when it sees fit. A handle edits text: bytes are
   * written with `cosm.file.write`. */
  write(content: string): void;
  /** Saves what is unsaved now. */
  sync(): Promise<void>;
  /** It changed underneath (read it again): on disk, merged with what was typed, Keep theirs chosen, or another view. */
  on(event: "changed", fn: (e: { why: "changed" | "merged" | "theirs" | "edited" }) => void): () => void;
  on(event: "moved", fn: (e: { path: Path }) => void): () => void;
  on(event: "trashed", fn: () => void): () => void;
  /** Lets it go (saved first). */
  close(): Promise<void>;
}
/** The cosm's files, in a view: also a file opened for editing. */
export interface ViewFiles {
  /** The file it shows (its `view.arg`), to read and edit: any other is refused. A file that isn't text (an image, a
   * PDF) opens read only: `read({ bytes: true })`, `changed`, `moved`, `trashed`; `write` refused. */
  open(path: Path): Promise<FileHandle>;
}
/** A folder outside the cosm that Cosm reaches by a short name (a connected folder): its files are `@<id>/<path>`. */
export interface Root {
  /** Made from its name when added, never changed: `@<id>/…` always means this folder. */
  id: string;
  name: string;
  /** Where it is on this computer; null: not located here (`locate`). */
  path: string | null;
  /** Whether its folder is there now (a drive unplugged, Drive not running, moved: false). */
  reachable: boolean;
}
/** Folders outside the cosm, connected (roots). Nothing in one is read until asked for; none is searched or in the tree. */
export interface Roots {
  /** The connected folders. */
  list(): Promise<Root[]>;
  /** Connects a folder by its full path; refused when it overlaps the cosm or another (one file, one name). Its id is
   * made from `name` (its folder's name if not given); the same folder removed before gets its id back. */
  add(path: string, o?: { name?: string }): Promise<{ id: string; name: string; path: string; change: "added" | "none" }>;
  /** Forgets it, never its files; its id is never given to another folder. */
  remove(id: string): Promise<void>;
  /** Where it is on this computer (the cosm came from another computer, or the folder moved). */
  locate(id: string, path: string): Promise<{ id: string; name: string; path: string }>;
  /** Where a file of one (`@company/x.md`) is on this computer: for tools that aren't Cosm's. */
  path(path: Path): Promise<string>;
  /** Watches one folder level of one (`@company/Reports`) while a view shows it: a file there changing is told as
   * `file.saved` / `file.removed` to the window and the views (a view function's `changes: { files: "@company/Reports/*" }`
   * loads again), never to packages' handlers. Never deeper than the level. Answers how to stop: call it when the view
   * stops showing it. */
  watch(path: Path): Promise<() => Promise<void>>;
}
/** The cosm's trash (`.cosm/trash/`): what was moved there, and putting it back. */
export interface Trash {
  /** Newest first: its name in the trash, where it came from (null: unknown), whether it is a folder, when it went (seconds since 1970). */
  list(): Promise<{ name: string; from: string | null; folder: boolean; modified: number }[]>;
  /** Puts it back where it came from: its path now. */
  restore(name: string): Promise<Path>;
}
/**
 * A long-running program the package starts, run by Cosm apart from the package's code: it goes on while the
 * package's code loads again, its views close or the window closes, and ends when the package stops it, it exits, the
 * package is switched off or removed, the user stops it (Settings, `cosm process stop`) or Cosm quits. Named
 * `<package>:<name>` (the package's own by `name` alone). For a quick command, use Bun's `$` or `Bun.spawn`.
 */
export interface Process {
  name: string; package: string; program: string; as: "lines" | "terminal"; pid: number;
  /** When it started (milliseconds since 1970). */
  started: number;
  /** How many views are attached (`<cosm-terminal process="…">`). */
  attached: number;
  running: boolean;
  /** How it ended, once it has. */
  code?: number;
}
export interface Processes {
  /**
   * Starts one of the package's programs: `program` a file of the package or a command on the PATH, `args` passed
   * whole, in the cosm's folder with what a package's program gets (COSM_*). `as: "lines"` (the default): its output
   * is a stream of the package's named as it is (`<package>:<name>`), a line an item, kept from its first byte and
   * closed after its last line with how it ended (`code`): the package, or any other, reads it with
   * `cosm.stream.subscribe("<package>:<name>", …)`; what it says on stderr goes to the package's log. `as: "terminal"`: it runs in a terminal (`cols`, `rows`), drawn by a view that attaches.
   * One of that name still running is an error: attach to it, or stop it first. Its package hears `process.exited`
   * (`{name, code}`) when it ends, and `process.attached` / `process.detached` (`{name, attached}`) as views come and
   * go: when to stop one nobody watches is the package's choice.
   */
  start(name: string, options: { program: string; args?: string[]; as?: "lines" | "terminal"; cols?: number; rows?: number;
    /** Variables of its own beside what a package's program gets (never `PATH` or Cosm's context). */
    env?: Record<string, string> }): Promise<Process>;
  /** Typed into it: a terminal's keys, or text for a `lines` program (end a line with `\n`). */
  write(name: string, text: string): Promise<void>;
  /** A terminal's size. */
  resize(name: string, cols: number, rows: number): Promise<void>;
  /** Asks it to end, then makes it after a moment. */
  stop(name: string): Promise<void>;
  /** The programs packages run (or one package's), an ended one with its code until it is started again. */
  list(options?: { package?: string }): Promise<Process[]>;
}
/** One of the package's streams, opened: what it writes goes to every subscriber, in order. */
export interface OpenStream {
  /** Its full name, `<package>:<name>`. */
  readonly name: string;
  write(...items: unknown[]): Promise<void>;
  /** Ends it: subscribers get what was left, then that it closed. Closing it again does nothing. */
  close(): Promise<void>;
}
/**
 * Streams: a package's items in order, by name, for whoever follows them (a conversation's updates, a sync's
 * progress). Cosm keeps the latest (`keep`, 1000 by default), so one who subscribes late gets them first, and keeps
 * them while the package's code loads again; what is written goes out every 30 ms, a few items at a time. A package's
 * streams close when it is switched off or removed.
 */
export interface Streams {
  /** Opens one of the package's own (found again, with what it kept, after its code loaded again; a closed one opens
   * empty, its items numbered from 1 again). A program's output is the engine's to write: not opened here. */
  open(name: string, options?: { keep?: number }): Promise<OpenStream>;
  /** What the stream kept (told first, even when it is nothing), then what comes, in order; `closed` when it ends,
   * with `code` when it is a program's output (how the program ended); `missed`: how many items were lost before
   * these (more came than the stream kept before they were read: a gap). By its full name, any package's (the
   * package's own by its short name), or by a handle given it. One not open yet is followed all the same. It ends with
   * the stream (after `closed`, nothing more comes: one opened again under the name is subscribed to anew), or when
   * the function it returns is called. Batches come one at a time: an `async` function finishes with one before the
   * next (its end among them) is given it. */
  subscribe(stream: string | StreamHandle, f: (items: unknown[], o: StreamTold) => void | Promise<void>): Promise<() => void>;
  /** A handle on a stream (its own by its short name, or any package's in full), for the package's view: a view
   * function returns it, and the view subscribes to it (`cosm.stream.subscribe(handle, …)` in the view). The window
   * the view is in is sent that stream's items, and no window any other's; the package may sleep meanwhile. A program's
   * output is never handed to a view: read it, and write a stream of the package's own for the view. */
  pass(name: string): Promise<StreamHandle>;
  list(options?: { package?: string }): Promise<{ name: string; package: string; open: boolean; kept: number; subscribers: string[]; program: boolean }[]>;
}
/** A stream handed to a view (`cosm.stream.pass`): its full name and the handle the window follows it by. */
export interface StreamHandle { readonly name: string; readonly handle: string }
/** What a stream's subscriber is told with each batch of items. */
export interface StreamTold { closed: boolean; code?: number; missed?: number }
/** What the package keeps, by key, in the cosm's own state for it (JSON values). */
export interface Storage {
  get<T = unknown>(key: string): Promise<T | null>;
  set(key: string, value: unknown): Promise<void>;
  /** The value worked out from the one kept, written only if nothing changed it meanwhile (else read again and `fn`
   * run again, a few times, then a conflict error): two writers on this computer never lose each other's change.
   * `fn` is synchronous and only computes (make ids and times before). Answers what it wrote. */
  update<T = unknown>(key: string, fn: (value: T | null) => T): Promise<T>;
  delete(key: string): Promise<void>;
  /** Its keys. */
  list(): Promise<string[]>;
}
/** What a script and a view share. */
export interface Services {
  readonly package: { readonly name: string };
  readonly point: PointCalls;
  readonly index: IndexCalls;
  readonly setting: SettingCalls;
  readonly file: Files;
  readonly trash: Trash;
  readonly root: Roots;
  readonly process: Processes;
  readonly stream: Streams;
  readonly storage: Storage;
  readonly ui: UiCalls;
  /** Cosm's own instructions for the agent (`cosm instructions`): what every cosm's agent is told first, before each
   * package's `agent/instructions.md`. */
  instructions(): Promise<string>;
  /** Another package's export (`agent-session:start`, `cosm.package.export`), given its one input (an object): what it
   * returns, or a rejected Error. A package reaches another's API, never its commands. */
  call<T = unknown>(ref: Ref, input?: Record<string, unknown>): Promise<T>;
  /** Writes a line to the package's log (`cosm package log`). console.log goes there too. */
  log(...what: unknown[]): void;
}

/** A function of `cosm.package.export`: alone, or with the shape of its input and what it does. */
export type Export<F extends (input: any, context: CallContext) => Awaitable<unknown> = (input: any, context: CallContext) => Awaitable<unknown>> =
  F | { run: F; input?: Shape; description?: string };
/** What a view function's answer depends on: each a text or a list. */
export interface Changes { files?: string | string[]; storage?: string | string[]; data?: string | string[]; events?: string | string[] }
/** A function of `cosm.view.export`: alone, or with its input's shape, what it does and what its answer depends on. */
export type ViewExport<F extends (input: any, context: CallContext) => Awaitable<unknown> = (input: any, context: CallContext) => Awaitable<unknown>> =
  F | { run: F; input?: Shape; description?: string; changes?: Changes };
/** A view's `cosm.main`, from the list its main.ts's default function returns (`cosm.view.export({…})`): each function
 * called with its input, answering a promise of what it returns. */
export type ApiOf<M> = M extends (...a: any[]) => infer R ? ViewApi<Awaited<R>> : ViewApi<M>;
type ViewApi<E> = { readonly [K in keyof E]: E[K] extends { run: infer F; input: Shaped<infer I> } ? Called<F, I>
  : E[K] extends { run: infer F; input: { readonly "~standard": { readonly types?: { readonly input: infer I } } } } ? Called<F, I>
  : E[K] extends { run: infer F } ? Called<F> : Called<E[K]> };
/** A function as a view calls it: its input as its schema accepts it when it has one (defaults may be left out), else
 * as `run` takes it; its answer as `run` returns it. */
type Called<F, S = never> = F extends (input: infer I, ...rest: any[]) => infer R
  ? ([S] extends [never] ? Takes<I, Awaited<R>> : Takes<S, Awaited<R>>)
  : never;
type Takes<I, R> = unknown extends I ? (input?: Record<string, unknown>) => Promise<R> : undefined extends I ? (input?: I) => Promise<R> : (input: I) => Promise<R>;

/** What a package's main.ts is given. */
export interface Cosm extends Services {
  /**
   * The package's name, and its folders: its own (its code and content: never written to, it is replaced on an update
   * and may be shared by several cosms), the cosm's, its data in this cosm (`.cosm/data/<package>/`: lasts and syncs
   * with the cosm; its storage is there too, in storage/), and its cache on this computer (deleted and rebuilt at will, never
   * synced; Cosm keeps the code it runs, as it loaded last, in its `.code/`). Data and cache are made the first time they
   * are asked for.
   */
  readonly package: {
    readonly name: string;
    /** Aborted as the package stops (before `package.stopping`'s handlers): pass it to what runs on its own (`fetch`,
     * `setInterval`'s clean-up, a watcher), so it ends with the package. */
    readonly signal: AbortSignal;
    /**
     * Holds its code running while something goes on that Cosm can't see: a socket, a watch, work
     * that outlasts a call. A package's code otherwise runs only while something needs it (a call, an event, a process
     * it started) and can stop when idle. `why` says what, as Settings → Packages and `cosm package running` show it.
     * Release it when that work ends; several may be held; releasing twice does nothing; all go when the worker ends.
     * What must last is kept in `cosm.storage`, not held.
     */
    keep(why: string): { release(): void };
    /** Its own files, by their path in the package (`icons/book.svg`, `templates/article.md`). */
    readonly file: {
      /** A file of the package's own as its text, or its bytes (`{ bytes: true }`), as `cosm.file.read` reads the cosm's.
       * One read while main.ts registers counts as its code: changed, the package loads again. */
      read(path: string): Promise<string>;
      read(path: string, options: { bytes: true }): Promise<Uint8Array>;
    };
    readonly folders: { readonly package: string; readonly cosm: string; readonly data: string; readonly cache: string };
    /** How one of a package's programs is started from anywhere, as Cosm starts any (its own by default; an agent
     * package starts another's MCP server so): its full path (a file of the package, else a name on the PATH), its
     * arguments with `${NAME}` filled in, and the variables it gets (its context, settings and secrets). */
    program(program: string, options?: { args?: string[]; package?: string }): Promise<{ program: string; args: string[]; env: Record<string, string> }>;
    /** A text with `${NAME}` filled in from what a package's programs get (its own by default): an address, a header. */
    fill(text: string, options?: { package?: string }): Promise<string>;
    /**
     * *Registers* its API: functions other packages call (`await cosm.call("<package>:<name>", {…})`), changed with
     * care. Each is a function, or `{ run, input?, description? }`: `run` takes one object, its input, and the call's
     * context (who called it: a package's name, `window` or `shell`): `({ session }, { by }) => …`;
     * `input` is its shape (a schema library's, or JSON Schema), checked before `run` for every caller. Apart from
     * its views' functions (`cosm.view.export`) and its commands (`cosm:commands`): a function both need is listed in
     * both, pointing at the same code.
     */
    export(functions: Record<string, Export>): void;
    /**
     * *Registers* another package its code calls or reads (`cosm.call`, `cosm.point.read`, `cosm.point.default`):
     * this one switches on only while it is on, and switching it off asks first. `{ if: "on" }` when it does without it: called only
     * while it is on, nothing forced. A call or read of a package not said is refused, naming this line. A package
     * its registrations name already counts (a kind it extends, a part it overrides, an item for its kind):
     * `cosm package list` shows what each uses.
     */
    uses(pkg: string, o?: { if?: "on" }): void;
  };
  readonly view: {
    /**
     * *Registers* the functions its own views call (`cosm.main.<name>({…})`, `live(cosm.main.<name>)`); nobody
     * outside the package reaches them. Each is a function, or `{ run, input?, description?, changes? }`: `changes`
     * says what its answer depends on, so a view's live value reloads when one of them changed, whoever changed it:
     * `files` (globs of the user's files), `storage` (its keys), `data` (globs in its data folder, `"reading.db*"`),
     * `events` (`"<package>:<event>"`, for what Cosm can't see: a web service, another app). `changes: {}` says it
     * never changes by itself. A function kept live only reads. Answers the list: return it from main.ts's default
     * function, and a view types its `cosm.main` from it (`view<ApiOf<typeof main>>()`).
     */
    export<const E extends Record<string, ViewExport>>(functions: E): E;
  };
  /**
   * The current call's signal: it fires when no one waits on the call any more (the user pressed Skip, the agent
   * interrupted the tool, the package restarted). Pass it on (`fetch(url, { signal: cosm.signal })`, `Bun.spawn`) to
   * stop with it; code that doesn't runs on, by its choice, and its answer is dropped. Never fires outside a call.
   */
  readonly signal: AbortSignal;

  /** A handler for an event: what it returns is the answer where the event takes one (a before-event, a message). */
  on(event: "file.saved.before" | "file.created.before", handler: (data: BeforeData, context: Context) => Awaitable<TextAnswer>, options?: On): void;
  on(event: "file.moved.before", handler: (data: BeforeData, context: Context) => Awaitable<MoveAnswer>, options?: On): void;
  on(event: BeforeEvents, handler: (data: BeforeData, context: Context) => Awaitable<Answer>, options?: On): void;
  on(event: "file.moved", handler: (data: MovesData, context: Context) => Awaitable<string | void>, options?: On): void;
  on(event: FileEvents, handler: (data: FilesData, context: Context) => Awaitable<string | void>, options?: On): void;
  /**
   * Its own life: `package.started` each time a worker of its code starts (`startup`: its first in this run of Cosm;
   * `on`: switched on; `reload`: its code changed or it was restarted; `update`: a new version; `wake`: started again
   * for a call or an event after its worker slept or ended), never when its main.ts is only read (a check, Settings).
   * A package's code runs only when something needs it: what it keeps in variables lasts one worker,
   * so one-time work checks its storage first. A call waits for these handlers. Start what runs on its own here
   * (timers, connections, syncs), not in main.ts's default function.
   */
  on(event: "package.started", handler: (data: { reason: "startup" | "on" | "reload" | "update" | "wake" }, context: Context) => Awaitable<void>): void;
  /**
   * Before its code stops (`idle`: nothing needed it for a while, it starts again when something does; `off`, `reload`
   * (the new code runs already), `update`, `removed`, `quit`: Cosm stopping):
   * `cosm.package.signal` is aborted first, and the handlers have 3 seconds; then its worker ends, and what is left
   * (timers, sockets) with it. Clean up only what lives outside Cosm (a lock file, a server told goodbye).
   */
  on(event: "package.stopping", handler: (data: { reason: "idle" | "off" | "reload" | "update" | "removed" | "quit" }, context: Context) => Awaitable<void>): void;
  on(event: "process.exited", handler: (data: { name: string; code: number }, context: Context) => Awaitable<void>): void;
  on(event: "process.attached" | "process.detached", handler: (data: { name: string; attached: number }, context: Context) => Awaitable<void>): void;
  on(event: CosmEvents | (string & {}), handler: (data: Data, context: Context) => Awaitable<unknown>, options?: On): void;
  /** Fires one of its own events (heard as `<package>:<name>` by others, by its own views, and by the window). */
  /** One of its own about to happen (`<name>.before`): its handlers one after another, any able to stop it (`{stop}`). */
  emit(name: `${string}.before`, data?: Record<string, unknown>): Promise<{ stop?: string }>;
  emit(name: string, data?: Record<string, unknown>): Promise<void>;
  readonly point: Points;
  readonly index: IndexCalls;
  readonly ui: UiCalls;
  readonly setting: Settings;
  readonly secret: Secrets;
  readonly part: {
    /**
     * Takes the place of another package's part (`star-chart:agent/prompts/recall`): a file of its own at the same
     * path, or a value in the part's own shape (a handler, an item, a contribution, a kind). `cosm part replace` makes
     * the first; Cosm keeps the fingerprint of the part it took in cosm.lock, to say when the base's part changes.
     */
    override(part: Ref, with_: { file: string } | { value: unknown }): void;
  };
}

/** What a view has as `window.cosm`: its package's view functions, the window, the streams
 * its package handed it, processes by name to show, and a handle on the file it shows. Everything else (files, storage, the index, settings,
 * other packages, events beyond its own) goes through its package's main.ts. */
/** A view's processes: by name, to show one and type into it (the kit's <cosm-terminal>); starting and stopping are
 * its package's main.ts's. */
export interface ViewProcesses {
  /** What the process writes, as text, from what it wrote lately on, until it ends (`ended`, with its code) or the
   * function this answers is called. Typing and size go through `write` and `resize`. */
  attach(name: string, out: (text: string) => void, options?: { ended?: (code: number | null) => void }): Promise<() => void>;
  /** Typed into it: a terminal's keys. */
  write(name: string, text: string): Promise<void>;
  /** A terminal's size. */
  resize(name: string, cols: number, rows: number): Promise<void>;
}
export interface ViewCosm {
  readonly package: { readonly name: string };
  readonly process: ViewProcesses;
  /** The streams its package handed it: a view function answers `cosm.stream.pass(name)`, and the view subscribes to
   * that handle (what it kept, then what comes). A view never follows a stream by name. */
  readonly stream: { subscribe(handle: StreamHandle, f: (items: unknown[], o: StreamTold) => void): Promise<() => void> };
  /** Writes a line to the page's console. */
  log(...what: unknown[]): void;
  /** Which view this is (`markdown:page`) and what it was opened for (a path, a thing), null for none. */
  readonly view: {
    readonly name: Ref; readonly arg: string | null;
    /**
     * Publishes facts about this view, what it alone knows: Markdown's `{ selection }`. Merged into
     * what it published before; a fact set to null is taken away. Others read them on this view's entry of
     * `cosm.ui.shown()` (`facts`), and hear them change with `ui.changed`; they go when the view closes. They never pass
     * through main.ts, so no worker wakes for them. The window says which view published them.
     */
    publish(facts: Record<string, unknown>): void;
  };
  /** The functions its package lists for its views (`cosm.view.export`). */
  readonly main: Record<string, (input?: Record<string, unknown>) => Promise<any>>;
  /** Hears an event, or answers the window (`view.find`: return `{count, current}`). */
  on(event: "view.opened", handler: (e: { arg: string | null }) => void): () => void;
  /** Rename in place: answer the new name, or null when the name stays. */
  on(event: "view.rename", handler: (e: { path: Path }) => Awaitable<string | null>): () => void;
  /** Left the screen; take the cursor; ⌘F (the view shows its own find bar, the kit's `<cosm-find>`). */
  on(event: "view.closed" | "view.focus" | "view.find", handler: () => void): () => void;
  /**
   * The look changed (a theme, light or dark, the text settings), told once the view's variables are the new ones.
   * Only for drawing that copies colour values (a canvas, a library handed colours): anything coloured with
   * `var(--…)`, in CSS, an inline style or an SVG's style, follows by itself.
   */
  on(event: "theme.changed", handler: (data: { dark: boolean }) => void): () => void;
  /** The window's items changed (what `cosm.ui.items` gives). */
  on(event: "ui.changed", handler: (data: Data) => void): () => void;
  /** A handle on the file it was opened to show (its `view.arg`): an editor's. */
  readonly file: ViewFiles;
  readonly ui: ViewUi;
}
