// Builds one of a view's TypeScript modules into one browser module, so a view can be written in TypeScript: run by the engine with
// the Bun Cosm ships, in the package's folder (`bun view-build.ts <file>`). `cosm/view` stays outside (the window's import
// map gives it); `import type` is dropped; the source map is inline. Says, as one JSON line, the module or why it
// failed, and every file the build read (what the engine keys its kept copy on).
const file = process.argv[2];
/** A build message as one line: where, then what. */
const said = (m: any) => `${m?.position ? `${m.position.file}:${m.position.line}:${m.position.column}: ` : ""}${m?.message ?? String(m)}`;
try {
  const r = await Bun.build({ entrypoints: [file], target: "browser", format: "esm", external: ["cosm/view"], sourcemap: "inline", metafile: true } as Parameters<typeof Bun.build>[0] & { metafile: boolean });
  const inputs = Object.keys((r as unknown as { metafile?: { inputs?: Record<string, unknown> } }).metafile?.inputs ?? {});
  if (!r.success || !r.outputs.length) console.log(JSON.stringify({ error: r.logs.map(said).join("\n") || "the build made nothing", inputs }));
  else console.log(JSON.stringify({ code: await r.outputs[0].text(), inputs }));
} catch (e) {
  // A failed build throws with each error in `errors`: said one a line.
  const list = (e as { errors?: unknown[] })?.errors;
  console.log(JSON.stringify({ error: Array.isArray(list) && list.length ? list.map(said).join("\n") : String((e as { message?: string })?.message ?? e), inputs: [] }));
}
