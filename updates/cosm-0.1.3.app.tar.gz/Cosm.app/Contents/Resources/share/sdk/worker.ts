// One package's worker: loads its main.ts, gives it the Cosm API (cosm.d.ts), and runs the functions it registered
// when the engine calls them. What it registers goes to the engine in the shapes the engine reads (engine/core
// manifest.rs): every function as {"fn": "<id>"}, called later by that id.
import { mkdirSync } from "node:fs";
import { relative, resolve } from "node:path";
import { AsyncLocalStorage } from "node:async_hooks";
import { services } from "./calls.ts";
declare const self: Worker;

// With the host: JSON-RPC 2.0, the protocol every other part of Cosm speaks. The host asks `load` and `call` and cancels with `$/cancelRequest`; the
// worker asks the engine's own methods (the host adds who asks) and tells its console as `log`.
type Msg = { jsonrpc?: "2.0"; id?: number; method?: string; params?: any; result?: unknown; error?: { code: number; message: string; data?: unknown } };
const post = (m: Msg) => self.postMessage({ jsonrpc: "2.0", ...m });
/** An error as a reply carries it: its message, its stack in `data`. */
const failure = (err: any) => ({ code: 1, message: err?.message ?? String(err), data: { stack: err?.stack } });

// --- the functions it registered ----------------------------------------------------------------------------------------------

const fns = new Map<string, Function>();
let fnNext = 1;
/** Its registration's key: part of every function's id. The same code and settings give the same
 * key and so the same ids, in every worker that loads them; other code, another key, so an id never reaches another
 * version's function. */
let load = "";
/** Each function's print (a hash of its source): what an override's fingerprint reads, the same whatever its id. */
const prints: Record<string, string> = {};
/** A function kept for calling by its id: {"fn": "f3"}. */
function handle(f: Function): { fn: string } {
  if (typeof f !== "function") throw new Error(`a function was expected, not ${typeof f}`);
  const id = `${load}.f${fnNext++}`;
  fns.set(id, f);
  prints[id] = Bun.hash(String(f)).toString(16);
  return { fn: id };
}

// --- asking the engine -------------------------------------------------------------------------------------------------------

let apiNext = 1;
const waiting = new Map<number, { resolve: (v: any) => void; reject: (e: Error) => void }>();
/** The call each piece of code runs for (its signal), however its awaits interleave. */
const current = new AsyncLocalStorage<{ signal: AbortSignal }>();
/** Each call's controller, by the host's id for it: aborted when the engine no longer waits on the call. */
const controllers = new Map<number, AbortController>();
/** Outside a call (main.ts loading): a signal that never fires. */
const never = new AbortController().signal;
/** The package's own signal: aborted as it stops (switched off, loaded again, updated, removed, Cosm stopping), before
 * its `package.stopping` handlers run. */
const stopping = new AbortController();
/** Its `package.started` handlers, running: a call waits for them (at most STARTED_WAIT_MS, so a handler that calls its
 * own package can't hold it up for good), so what they set up is there when it runs. */
let ready: Promise<void> = Promise.resolve();
const STARTED_WAIT_MS = 10_000;
function engine(method: string, params: Record<string, unknown> = {}): Promise<any> {
  // While main.ts registers, it only declares: asking Cosm then would wait on the load it is part of. Its own settings
  // it may read: their values came with the load.
  if (loading && method === "setting.get" && params.package === me) { try { return Promise.resolve(settingNow(String(params.name))); } catch (e) { return Promise.reject(e); } }
  if (loading) return Promise.reject(new Error(`main.ts can't ask Cosm (${method}) while it registers: ask in a handler, a function, or on window.opened`));
  const id = apiNext++;
  post({ id, method, params });
  return new Promise((resolve, reject) => waiting.set(id, { resolve, reject }));
}

// --- the registrations ---------------------------------------------------------------------------------------------------------

const reg: any = {
  exports: {} as Record<string, any>, viewExports: {} as Record<string, any>, events: { on: {} as Record<string, any[]> }, presets: {}, overrides: {},
  points: {} as Record<string, any>, adds: [] as { point: string; name: string; value: any }[],
  uses: [] as { package: string; if?: "on" }[],
};
let loading = true;
/** The package's own settings as set when it loads (the cosm's or the user's, and the presets in effect). */
let given: { own?: Record<string, unknown>; presets?: Record<string, unknown> } = {};
/** The settings main.ts read while it registered: when one changes, Cosm loads it again. */
const readAtLoad = new Set<string>();
/** The package's own files main.ts read while it registered (`cosm.package.file.read`): when one changes, Cosm loads it
 * again, as it does when its code changes. */
const filesAtLoad = new Set<string>();
/** What of the cosm main.ts read while it registered (`cosm.file.read`, `cosm.file.list`): what it added may depend on
 * it, so a change to it registers the package again. */
const cosmAtLoad = { files: new Set<string>(), globs: new Set<string>() };
/** Whether a setting as declared takes a value (the engine's settings::takes checks it in full against the shape;
 * this is the part of it a load needs). */
function takes(d: any, v: unknown): boolean {
  const s = d?.shape ?? { type: "string" };
  if (Array.isArray(s.enum)) return s.enum.includes(v);
  switch (s.type) {
    case "boolean": return typeof v === "boolean";
    case "number": case "integer": return typeof v === "number" && (s.minimum === undefined || v >= s.minimum) && (s.maximum === undefined || v <= s.maximum);
    case "object": return !!v && typeof v === "object" && !Array.isArray(v);
    case "array": return Array.isArray(v);
    case "string": return typeof v === "string" && !(s.format === "font" && v === "default");
    default: return v !== undefined;
  }
}

/** A shape as JSON Schema: from any schema library through the shared Standard JSON Schema interface
 * (`~standard.jsonSchema`), else a plain object taken as JSON Schema. A shape says data only: what JSON Schema can't
 * hold (a function, a date) the library refuses, and a point names its functions beside it (`functions`). */
function schemaOf(shape: any, where: string): any {
  if (shape === undefined || shape === null) return undefined;
  const std = shape["~standard"];
  if (std) {
    if (!std.jsonSchema?.input) throw new Error(`${where}: its shape (${std.vendor ?? "a schema library"}) can't give JSON Schema (the Standard JSON Schema interface): write it with a library that can, or as JSON Schema`);
    try { return std.jsonSchema.input({ target: "draft-2020-12" }); }
    catch (e: any) { throw new Error(`${where}: its shape can't be JSON Schema (${e?.message ?? e}): a shape says data only; name a contribution's functions in functions: [...]`); }
  }
  if (typeof shape !== "object") throw new Error(`${where}: a shape is JSON Schema (an object: cosm/shape writes one) or a schema library's (zod, ArkType …)`);
  return shape;
}

/** A contribution as the engine keeps it: its functions as `{fn}`, a schema (zod, ArkType …) as JSON Schema, nested
 * ones too. */
function wired(v: any, where: string): any {
  if (typeof v === "function") return handle(v);
  if (Array.isArray(v)) return v.map((x) => wired(x, where));
  if (v && typeof v === "object" && v["~standard"]) return schemaOf(v, where);
  if (v && typeof v === "object" && Object.getPrototypeOf(v) === Object.prototype) return Object.fromEntries(Object.entries(v).filter(([, x]) => x !== undefined).map(([k, x]) => [k, wired(x, where)]));
  return v;
}
/** One of its own settings while it registers: as set, else its preset, else the default it declared (so far). */
function settingNow(name: string): unknown {
  const d = reg.adds.find((a: any) => a.point === "cosm:settings" && a.name === name)?.value;
  if (!d) throw new Error(`no setting ${name} (add it to cosm:settings first)`);
  readAtLoad.add(name);
  for (const v of [given.own?.[name], given.presets?.[name]]) if (v !== undefined && takes(d, v)) return v;
  return d.default ?? null;
}
function registering(what: string) {
  if (!loading) throw new Error(`${what} registers something: call it in main.ts's default function, not later`);
}

/** What a view function's answer depends on, as the engine keeps it: each kind a list (one glob, key or event given
 * alone is a list of one). */
function changesOf(c: any, where: string): Record<string, string[]> {
  if (!c || typeof c !== "object" || Array.isArray(c)) throw new Error(`${where}: changes is { files?, storage?, data?, events? } ({} for never by itself)`);
  const out: Record<string, string[]> = {};
  for (const [k, v] of Object.entries(c)) {
    if (!["files", "storage", "data", "events"].includes(k)) throw new Error(`${where}: changes.${k} isn't one: files (the user's files), storage (keys), data (files in its data folder), events`);
    const list = typeof v === "string" ? [v] : v;
    if (!Array.isArray(list) || !list.every((x) => typeof x === "string" && x)) throw new Error(`${where}: changes.${k} is a text or a list of texts`);
    if (k === "data" && list.some((x) => x.startsWith("/") || x.split("/").includes(".."))) throw new Error(`${where}: changes.data is globs inside its own data folder ("reading.db*")`);
    if (list.length) out[k] = list;
  }
  return out;
}
/** An export's input shape from a schema library (zod, ArkType …), by its function's id: run before the function, so
 * it gets the parsed value (defaults filled, transforms applied). JSON Schema shapes the engine checks. */
const parsers = new Map<string, { "~standard": { validate: (v: unknown) => any } }>();
/** An input through its export's schema: the parsed value, or a refusal saying what doesn't fit. */
async function parsed(id: string, input: unknown): Promise<unknown> {
  const s = parsers.get(id);
  if (!s) return input;
  const r = await s["~standard"].validate(input);
  if (r.issues) throw new Error(`its input doesn't fit: ${r.issues.map((i: any) => `${(i.path ?? []).map((p: any) => (typeof p === "object" ? p.key : p)).join(".") || "input"}: ${i.message}`).join("; ")}`);
  return r.value;
}
/** One entry of an export list: a function, or `{ run, input?, description? }` (and `changes?` for a view function). */
function exported(name: string, e: any, list: "cosm.package.export" | "cosm.view.export"): any {
  const where = `${list}: ${name}`;
  if (typeof e === "function") return handle(e);
  const keys = list === "cosm.view.export" ? ["run", "input", "description", "changes"] : ["run", "input", "description"];
  if (!e || typeof e !== "object" || typeof e.run !== "function") throw new Error(`${where} is a function, or { ${keys.map((k, i) => (i ? `${k}?` : k)).join(", ")} }`);
  for (const k of Object.keys(e)) if (!keys.includes(k)) throw new Error(`${where}: ${k} isn't a key of an entry (${keys.join(", ")})`);
  if (e.description !== undefined && typeof e.description !== "string") throw new Error(`${where}: description is a text`);
  const h = handle(e.run);
  if (e.input?.["~standard"]?.validate) parsers.set(h.fn, e.input);
  return {
    ...h,
    ...(e.input !== undefined ? { input: schemaOf(e.input, where) } : {}),
    ...(e.description ? { description: e.description } : {}),
    ...(e.changes !== undefined ? { changes: changesOf(e.changes, where) } : {}),
  };
}

/** An action as the engine reads it. */
function action(a: any): any {
  if (typeof a === "function") return handle(a);
  if (a && typeof a === "object") {
    if (a.ask) return { ask: { ...a.ask, yes: action(a.ask.yes) } };
    return a;
  }
  throw new Error(`an action is a function, or one of {ask}, {open}, {new}`);
}
/** An override's value as the engine reads the part it takes the place of: a contribution as any (`wired`), what a
 * package does on an event as its handlers. */
function wire(part: string, v: any): any {
  const kind = part.split(":").slice(1).join(":").split("/")[0];
  if (v === null || v === undefined) return v;
  if (kind === "on") return (Array.isArray(v) ? v : [v]).map((a) => (typeof a?.handler === "function" ? { ...handle(a.handler), ...(a.kind ? { kind: a.kind } : {}) } : action(a)));
  return wired(v, `cosm.part.override("${part}")`);
}

let me = "";
let dir = "";
let root = "";
let data = "";
let cache = "";
/** A folder of the package's, made the first time it is asked for. */
const made = (d: string) => { if (d) mkdirSync(d, { recursive: true }); return d; };

/** The calls main.ts shares with its views (share/sdk/calls.ts), on the engine and the cosm's files. */
/** Its progresses' cancels, by id (the window's Cancel: the host's `progress.cancel`). */
const cancels = new Map<number, () => void>();
/** What hears the streams' items the engine sends this package (it subscribed: cosm.stream.subscribe). */
const streamHearers = new Set<(d: any) => void>();
const shared = services({
  engine,
  get name() { return me; },
  thing: () => undefined,
  read: async (path, bytes) => {
    // A file of a connected folder (`@company/x.md`): where the engine says it is on this computer.
    const at = /^@[\p{L}\p{N}-]+\//u.test(path) ? String(await engine("root.path", { path })) : `${root}/${path}`;
    const f = Bun.file(at);
    return bytes ? new Uint8Array(await f.arrayBuffer()) : f.text();
  },
  log: (...what) => post({ method: "log", params: { line: what.map(said).join(" ") } }),
  hear: (f) => { streamHearers.add(f); return () => { streamHearers.delete(f); }; },
  cancelled: (id, f) => { cancels.set(id, f); return () => { cancels.delete(id); }; },
});

const api = {
  package: {
    get name() { return me; },
    /** Aborted as the package stops, before its `package.stopping` handlers run: pass it to what runs on its own. */
    get signal() { return stopping.signal; },
    /** Holds its worker running while what it says goes on (a worker otherwise stops when idle): until `release()`, or the worker ends. */
    keep(why: string) {
      if (loading) throw new Error("cosm.package.keep holds the package running while something goes on: call it there (a handler, a function), not while main.ts registers");
      const id = engine("package.keep", { why: String(why ?? "") });
      let released = false;
      return {
        release() {
          if (released) return;
          released = true;
          void id.then((r: any) => engine("package.release", { id: r?.id })).catch(() => {});
        },
      };
    },
    /** Another package it calls or reads from its code (`cosm.call`, `cosm.point.read`): on only while it is, and not
     * switched off under it unasked; `{ if: "on" }` when it does without it, calling it only while it is on (cosm.d.ts). */
    uses(pkg: string, o: { if?: "on" } = {}) {
      registering("cosm.package.uses");
      if (o.if !== undefined && o.if !== "on") throw new Error(`cosm.package.uses("${pkg}", { if }): "on", or not given`);
      if (!reg.uses.some((u: { package: string }) => u.package === pkg)) reg.uses.push(o.if ? { package: pkg, if: o.if } : { package: pkg });
    },
    /** Its API: functions other packages call (`cosm.call("<package>:<name>", input)`). */
    export(functions: Record<string, any>) {
      registering("cosm.package.export");
      for (const [k, f] of Object.entries(functions)) reg.exports[k] = exported(k, f, "cosm.package.export");
    },
    /** How one of a package's programs is started from anywhere (its own by default): its full path, its arguments
     * filled in, and the variables it gets. */
    async program(program: string, o: { args?: string[]; package?: string } = {}) {
      return engine("package.program", { package: o.package ?? me, program, args: o.args ?? [] });
    },
    /** A text with `${NAME}` filled in from what a package's programs get (its own by default). */
    async fill(text: string, o: { package?: string } = {}) { return (await engine("package.fill", { package: o.package ?? me, text })) as string; },
    /** Its own files, by their path in the package. */
    file: {
      /** A file of the package's own: its text, or its bytes (`{ bytes: true }`). One read while main.ts registers
       * counts as its code: changed, the package loads again. */
      async read(path: string, o: { bytes?: boolean } = {}) {
        const full = resolve(dir, path);
        const rel = relative(dir, full);
        if (!rel || rel.startsWith("..") || rel.startsWith("/")) throw new Error(`cosm.package.file.read("${path}"): a file inside the package, by its path in it`);
        const f = Bun.file(full);
        if (!(await f.exists())) throw new Error(`the package has no ${rel}`);
        if (loading) filesAtLoad.add(rel);
        return o.bytes ? new Uint8Array(await f.arrayBuffer()) : f.text();
      },
    },
    folders: {
      get package() { return dir; },
      get cosm() { return root; },
      get data() { return made(data); },
      get cache() { return made(cache); },
    },
  },

  view: {
    /** The functions its own views call (`cosm.main.<name>()`, `live(cosm.main.<name>)`), each with what its answer
     * depends on (`changes`). */
    export(functions: Record<string, any>) {
      registering("cosm.view.export");
      for (const [k, f] of Object.entries(functions)) reg.viewExports[k] = exported(k, f, "cosm.view.export");
    },
  },

  on(event: string, handler: any, options: { kind?: string; files?: string | string[] } = {}) {
    registering("cosm.on");
    if (typeof event !== "string" || !event) throw new Error("cosm.on: the event's name first");
    const a = typeof handler === "function" ? handle(handler) : action(handler);
    if (options.kind) a.kind = options.kind;
    if (options.files) a.files = Array.isArray(options.files) ? options.files : [options.files];
    (reg.events.on[event] ??= []).push(a);
  },
  point: {
    define(name: string, p: any) {
      registering("cosm.point.define");
      if (!p || typeof p !== "object") throw new Error(`cosm.point.define("${name}"): give { description, holds: "files" | "values" | "functions", shape?, functions?, uses? }`);
      if (p.functions !== undefined && !(Array.isArray(p.functions) && p.functions.every((f: unknown) => typeof f === "string"))) throw new Error(`cosm.point.define("${name}"): functions is a list of names, ["render"]`);
      const { shape, ...rest } = p;
      reg.points[name] = { ...rest, ...(shape !== undefined ? { shape: schemaOf(shape, `cosm.point.define("${name}")`) } : {}) };
    },
    add(point: string, c: any) {
      registering("cosm.point.add");
      if (!c || typeof c.name !== "string") throw new Error(`cosm.point.add("${point}"): give the contribution its name, { name, … }`);
      const { name, ...value } = c;
      const full = point.includes(":") ? point : `${me}:${point}`;
      if (reg.adds.some((a: any) => a.point === full && a.name === name)) throw new Error(`cosm.point.add("${full}"): this package already added ${name} to it: one contribution a name`);
      const where = `cosm.point.add("${full}", "${name}")`;
      // An item's content as a function with what it depends on: `{ run, changes }`.
      const ct = full === "cosm:items" ? value.content : undefined;
      if (ct && typeof ct === "object" && typeof ct.run === "function") {
        const extra = Object.keys(ct).filter((k) => k !== "run" && k !== "changes");
        if (extra.length) throw new Error(`${where}: content as a function is { run, changes? }, not ${extra.join(", ")}`);
        value.content = { ...handle(ct.run), ...(ct.changes !== undefined ? { changes: changesOf(ct.changes, `${where} content`) } : {}) };
        reg.adds.push({ point: full, name, value: { ...wired({ ...value, content: undefined }, where), content: value.content } });
        return;
      }
      reg.adds.push({ point: full, name, value: wired(value, where) });
    },
    ...shared.point,
  },

  index: {
    ...shared.index,
  },

  ui: shared.ui,

  setting: {
    get: shared.setting.get,
    preset(owner: string, values: Record<string, unknown>) { registering("cosm.setting.preset"); reg.presets[owner] = { ...(reg.presets[owner] ?? {}), ...values }; },
  },
  secret: {
    async get(name: string, o: { package?: string } = {}) { return (await engine("secret.get", { name, package: o.package ?? "" })) ?? null; },
  },
  part: {
    override(part: string, w: any) {
      registering("cosm.part.override");
      if (typeof w?.file === "string") reg.overrides[part] = { file: w.file };
      else if (w && "value" in w) reg.overrides[part] = { value: wire(part, w.value) };
      else throw new Error(`cosm.part.override("${part}"): give { file } (a file part) or { value } (what takes the part's place)`);
    },
  },

  get signal() { return current.getStore()?.signal ?? never; },
  file: {
    ...shared.file,
    async read(path: string, o: { bytes?: boolean } = {}) { if (loading) cosmAtLoad.files.add(path); return shared.file.read(path, o); },
    async list(glob: string) {
      if (!loading) return shared.file.list(glob);
      // While it registers it doesn't ask Cosm (that would wait on this load): the cosm's files listed here, outside
      // hidden folders, as Cosm lists them.
      cosmAtLoad.globs.add(glob);
      // Cosm's glob rule: a name with no folder in it matches in any folder; `/` first, from the cosm's top.
      const g = glob.startsWith("/") ? glob.slice(1) : glob.replace(/\/$/, "").includes("/") ? glob : `**/${glob}`;
      return [...new Bun.Glob(g).scanSync({ cwd: root, onlyFiles: true, dot: false })].filter((f) => !f.split("/").some((x) => x.startsWith("."))).sort();
    },
  },
  trash: shared.trash,
  root: shared.root,
  process: shared.process,
  stream: shared.stream,
  storage: shared.storage,
  instructions: shared.instructions,
  call: shared.call,
  run: shared.run,
  emit: shared.emit,
  log: shared.log,
};

function said(x: unknown): string {
  if (typeof x === "string") return x;
  if (x instanceof Error) return x.stack ?? x.message;
  try { return JSON.stringify(x); } catch { return String(x); }
}
// An error nothing caught (a promise not awaited, a throw in a timer) is said in the package's log; the worker runs on.
process.on("unhandledRejection", (e) => api.log("uncaught:", e));
process.on("uncaughtException", (e) => api.log("uncaught:", e));
// The package's console goes to its log.
for (const k of ["log", "info", "warn", "error", "debug"] as const) (console as any)[k] = (...a: unknown[]) => api.log(...a);

// --- the engine's messages ------------------------------------------------------------------------------------------------------

/** Values the engine can carry: functions dropped, undefined left out. */
function plain(v: unknown): unknown {
  if (v === undefined) return null;
  return JSON.parse(JSON.stringify(v, (_k, x) => (typeof x === "function" ? undefined : x)) ?? "null");
}

/** Its own handlers of one of its life's events, run here: each `(data, context)`, one after another. */
async function own(event: string, data: Record<string, unknown>) {
  for (const h of reg.events.on[event] ?? []) {
    const f = typeof h?.fn === "string" ? fns.get(h.fn) : undefined;
    if (!f) continue;
    try { await current.run({ signal: never }, () => f(data, { name: event, package: "cosm", by: "cosm" })); }
    catch (err) { api.log(`${event}:`, err); }
  }
}

self.onmessage = async (e: MessageEvent) => {
  const m: Msg = e.data;
  // The host checking this worker still runs its messages (host.ts, the watch on frozen code): answered at once, before
  // anything else, so only code that holds the thread leaves it unanswered.
  if (m.method === "ping") { post({ method: "pong" }); return; }
  // A reply to what this worker asked the engine.
  if (m.method === undefined && m.id !== undefined) {
    const w = waiting.get(m.id);
    if (!w) return;
    waiting.delete(m.id);
    if (m.error) w.reject(new Error(m.error.message || "the engine said no")); else w.resolve(m.result);
    return;
  }
  const p = m.params ?? {};
  switch (m.method) {
    case "load": {
      me = p.package; dir = p.dir; root = p.root; data = p.data ?? ""; cache = p.cache ?? ""; load = String(p.load ?? ""); given = p.settings ?? {};
      try {
        // Its code as one file, built from its main.ts (host.ts): none when it has no main.ts.
        const main = String(p.main ?? "");
        if (main) {
          const mod = await import(main);
          if (typeof mod.default !== "function") throw new Error("main.ts exports no default function: export default function (cosm: Cosm) { … }");
          await mod.default(api);
        }
        loading = false;
        post({ id: m.id, result: plain({ ...reg, fns: prints, read: [...readAtLoad], files: [...filesAtLoad],
          ...(cosmAtLoad.files.size || cosmAtLoad.globs.size ? { cosmRead: { files: [...cosmAtLoad.files], globs: [...cosmAtLoad.globs] } } : {}) }) });
      } catch (err: any) {
        post({ id: m.id, error: failure(err) });
      }
      break;
    }
    case "progress.cancel": { cancels.get(Number(p.id))?.(); break; }
    case "stream.items": { for (const f of streamHearers) { try { f(p); } catch (e) { console.error(e); } } break; }
    case "call": {
      const f = fns.get(p.fn);
      if (!f) { post({ id: m.id, error: { code: 1, message: `no function ${p.fn} (the package was loaded again)` } }); break; }
      await Promise.race([ready, new Promise((r) => setTimeout(r, STARTED_WAIT_MS))]);
      try {
        const c = new AbortController();
        controllers.set(m.id!, c);
        const args = [...(p.args ?? [])];
        if (parsers.has(p.fn)) args[0] = await parsed(p.fn, args[0]);
        const value = await current.run({ signal: c.signal }, () => f(...args));
        post({ id: m.id, result: plain(value) });
      } catch (err: any) {
        post({ id: m.id, error: failure(err) });
      } finally {
        controllers.delete(m.id!);
      }
      break;
    }
    // Its own life: `package.started` each time a worker of it runs live, `package.stopping` (its signal aborted
    // first) before its worker ends. Its own handlers only, one after another; a throw is said in its log.
    case "started": { ready = own("package.started", { reason: p.reason ?? "startup" }); break; }
    case "stopping": {
      if (!stopping.signal.aborted) stopping.abort(new Error(`${me} stops: ${p.reason ?? "off"}`));
      // Its handlers switched off in this cosm (`events/package.stopping`): the signal still aborts, nothing else runs.
      if (!p.quiet) await own("package.stopping", { reason: p.reason ?? "off" });
      post({ id: m.id, result: null });
      break;
    }
    // The host no longer waits on a call: its signal fires.
    case "$/cancelRequest": {
      controllers.get(p.id)?.abort(new Error("the call was abandoned: skipped, or its caller went"));
      break;
    }
  }
};
