// cosm/test: a package's own tests (`bun test` in its tests/ folder, run by `cosm package test`) make a throwaway cosm
// on the real engine, with the package switched on, and use it as the agent and the user would: the `cosm` command,
// the cosm's files, the package's storage. No fake of Cosm: what a test sees is what the engine does.
//
//   import { test, expect } from "bun:test";
//   import { testCosm } from "cosm/test";
//   test("the inbox counts its files", async () => {
//     await using c = await testCosm({ files: { "01-inbox/a.md": "A\n" } });
//     expect(await c.run("star-chart:inbox-count")).toBe("1");
//   });
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";

/** What a test cosm starts with. */
export type TestCosmOptions = {
  /** Files written into it, by path. */
  files?: Record<string, string>;
  /** A folder of the package's `tests/fixtures/` copied in whole first (its name). */
  fixture?: string;
  /** More packages switched on, by name (the package under test always is, with the packages it uses; every other
   * package is off, default ones included). */
  packages?: string[];
  /** Settings, as [package, setting, value]. */
  settings?: [string, string, string][];
};

/** A throwaway cosm on the real engine. */
export type TestCosm = {
  /** Its folder. */
  root: string;
  /** A `cosm` command in it, as the agent runs one: its output, trimmed. Throws with what the command said when it fails. */
  run(...words: string[]): Promise<string>;
  /** The same, but the failure's words instead of a throw (`""` when it worked). */
  fails(...words: string[]): Promise<string>;
  /** A file of the cosm, or null when it isn't there. */
  read(path: string): string | null;
  /** Writes a file of the cosm (its folders made), as the user or another program would. */
  write(path: string, text: string): void;
  /** A value a package keeps (`cosm storage get`), or null. */
  storage(pkg: string, key: string): Promise<unknown>;
  /** Waits until `check` is true (or returns something other than false, null or undefined), `seconds` at most
   * (5 unless given); throws saying what it waited for. Never sleep in a test: wait for what you expect. */
  until<T>(check: () => T | Promise<T>, o?: { seconds?: number; what?: string }): Promise<T>;
  /** The window, headless, on this cosm (WebKit, the window's own engine): `cosm ui open`, `outline`, `click`, `wait`
   * then work in it, as the agent uses them. From Cosm's own repository only, for now (it runs the window's dev server). */
  window(): Promise<TestWindow>;
  /** Stops its engine and removes it (also by `await using`). */
  close(): Promise<void>;
  [Symbol.asyncDispose](): Promise<void>;
};

/** A headless window on a test cosm. */
export type TestWindow = {
  /** A picture of the window, as a PNG at `path`. */
  screenshot(path: string): Promise<void>;
  /** Answers the question on screen (a package's `cosm.ui.ask`, a sheet of the window's), as the user would: typed
   * into its field, or the choice of that name; waits for it up to 5 seconds. */
  answer(answer: string): Promise<void>;
  /** Keys pressed as the user presses them, in whatever has the focus (`"Meta+f"`, `"Escape"`, `"Enter"`). */
  keys(...keys: string[]): Promise<void>;
  close(): Promise<void>;
};

/** The package being tested (`cosm package test` says which) and the engine to run. */
const PKG = process.env.COSM_TEST_PACKAGE ?? "";
const PKG_DIR = process.env.COSM_TEST_PACKAGE_DIR ?? "";
const BIN = process.env.COSM_TEST_BIN || "cosm";
/** Cosm's repository (this file is share/sdk/modules/cosm/test.ts in it). */
const REPO = join(import.meta.dir, "../../../..");

/** The window's dev server, started once for the test run (the window in a browser on a real engine: app/engine-relay.ts),
 * and the browser: WebKit, the engine Cosm's window runs on. */
let served: Promise<{ url: string; browser: import("playwright-core").Browser }> | null = null;
function serve() {
  served ??= (async () => {
    if (!existsSync(join(REPO, "app/engine-relay.ts"))) throw new Error("a view can be tested only from Cosm's own repository for now (it runs the window's dev server)");
    const free = Bun.listen({ hostname: "127.0.0.1", port: 0, socket: { data() {} } });
    const port = free.port; free.stop(true);
    const dev = Bun.spawn([join(REPO, "share/bin/bun"), join(REPO, "app/node_modules/vite/bin/vite.js"), "--port", String(port), "--strictPort"], { cwd: join(REPO, "app"), stdout: "ignore", stderr: "pipe" });
    process.on("exit", () => dev.kill());
    const url = `http://localhost:${port}/`;
    for (let i = 0; ; i++) {
      try { if ((await fetch(url)).ok) break; } catch {}
      if (i > 150 || dev.exitCode !== null) throw new Error(`the window's dev server didn't start: ${dev.exitCode !== null ? await new Response(dev.stderr).text() : "no answer in 15 s"}`);
      await Bun.sleep(100);
    }
    const { webkit } = await import("playwright-core");
    const browser = await webkit.launch().catch((e: Error) => {
      throw new Error(/Executable doesn't exist/.test(e.message) ? `WebKit for tests isn't installed on this computer: ${join(REPO, "share/bin/bun")} x playwright-core install webkit` : e.message);
    });
    return { url, browser };
  })();
  return served;
}

/** Makes a test cosm: a folder of its own under the system's temporary folder, a home of its own (no cosm, setting or
 * sign-in of the user's is touched), trusted, the package under test switched on and loaded. */
export async function testCosm(o: TestCosmOptions = {}): Promise<TestCosm> {
  const tmp = realpathSync(mkdtempSync(join(tmpdir(), "cosm-test-")));
  // The engine only takes a cosm inside the home folder.
  const home = join(tmp, "home"), root = join(home, "cosm");
  mkdirSync(join(root, ".cosm"), { recursive: true });
  if (o.fixture) {
    const from = join(PKG_DIR, "tests/fixtures", o.fixture);
    if (!existsSync(from)) throw new Error(`no fixture ${o.fixture}: give a folder of tests/fixtures/`);
    cpSync(from, root, { recursive: true });
  }
  for (const [p, t] of Object.entries(o.files ?? {})) { mkdirSync(dirname(join(root, p)), { recursive: true }); writeFileSync(join(root, p), t); }
  const env = { ...process.env, HOME: home } as Record<string, string>;
  const cosm = async (words: string[]) => {
    const p = Bun.spawn([BIN, ...words], { cwd: root, env, stdout: "pipe", stderr: "pipe" });
    const [out, err, code] = await Promise.all([new Response(p.stdout).text(), new Response(p.stderr).text(), p.exited]);
    return { out: out.trim(), err: (err.trim() || out.trim()).replace(/^FAIL:\s*/, ""), code };
  };
  const run = async (...words: string[]) => {
    const r = await cosm(words);
    if (r.code !== 0) throw new Error(`cosm ${words.join(" ")}: ${r.err}`);
    return r.out;
  };
  const until = async <T>(check: () => T | Promise<T>, w: { seconds?: number; what?: string } = {}) => {
    const end = Date.now() + (w.seconds ?? 5) * 1000;
    for (;;) {
      const v = await check();
      if (v !== false && v !== null && v !== undefined) return v;
      if (Date.now() > end) throw new Error(`waited ${w.seconds ?? 5} s for ${w.what ?? "it"}, and it didn't happen`);
      await Bun.sleep(50);
    }
  };
  await run("trust", "set", "yes");
  // A package that isn't built in (a cosm's own, one being written) is added from its folder, used where it is, as
  // `cosm package add <folder>` adds one: the test runs the code as it is now, the way the user tries it.
  const builtin = process.env.COSM_BUILTIN_DIR ?? "";
  if (PKG && PKG_DIR && !(builtin && PKG_DIR.startsWith(`${realpathSync(builtin)}/`))) await run("package", "add", PKG_DIR, "--yes");
  // Only the package under test, those a test names, and what they use are on: no other package (a default one, a
  // layout) shapes what the test sees.
  type Row = { name: string; on: boolean; uses?: string[] };
  const rows = JSON.parse(await run("package", "list", "--json")) as Row[];
  const want: string[] = [];
  const need = (n: string) => { if (want.includes(n)) return; for (const u of rows.find((r) => r.name === n)?.uses ?? []) need(u); want.push(n); };
  for (const n of [PKG, ...(o.packages ?? [])].filter(Boolean)) need(n);
  for (const r of rows) if (r.on && !want.includes(r.name)) await run("package", "off", r.name, "--yes");
  for (const n of want) await run("package", "on", n);
  for (const [p, s, v] of o.settings ?? []) await run("setting", "set", p, s, v);
  // Every package registered, so the test starts on a cosm that doesn't change under it.
  await until(async () => !(JSON.parse(await run("package", "list", "--json")) as { loading?: boolean }[]).some((p) => p.loading), { seconds: 20, what: "the packages to load" });
  let closed = false;
  const windows: TestWindow[] = [];
  const close = async () => { if (closed) return; closed = true; for (const w of windows) await w.close(); await cosm(["serve", "stop"]); rmSync(tmp, { recursive: true, force: true }); };
  const window = async (): Promise<TestWindow> => {
    const { url, browser } = await serve();
    const page = await browser.newPage({ viewport: { width: 1280, height: 820 } });
    const q = new URLSearchParams({ engine: root, home, builtin: process.env.COSM_BUILTIN_DIR ?? "" });
    await page.goto(`${url}?${q}`);
    await page.waitForSelector(".pane.left", { timeout: 15000 });
    // Its views connected: the engine knows what is on screen.
    await until(async () => (await cosm(["ui", "shown"])).code === 0, { seconds: 15, what: "the window to connect" });
    const w: TestWindow = {
      screenshot: async (path) => { await page.screenshot({ path }); },
      answer: async (answer) => {
        const sheet = page.locator(".sheet-box").last();
        await sheet.waitFor({ timeout: 5000 });
        const field = sheet.locator("input, textarea");
        if (await field.count()) { await field.first().fill(answer); await sheet.locator("button.primary").click(); }
        else await sheet.locator("button", { hasText: answer }).first().click();
      },
      keys: async (...keys) => { for (const k of keys) await page.keyboard.press(k); },
      close: async () => { await page.close().catch(() => {}); },
    };
    windows.push(w);
    return w;
  };
  return {
    root, run, until, close, window, [Symbol.asyncDispose]: close,
    fails: async (...words: string[]) => { const r = await cosm(words); return r.code === 0 ? "" : r.err; },
    read: (path) => (existsSync(join(root, path)) ? readFileSync(join(root, path), "utf8") : null),
    write: (path, text) => { mkdirSync(dirname(join(root, path)), { recursive: true }); writeFileSync(join(root, path), text); },
    storage: async (pkg, key) => { const v = await run("storage", "get", key, "--package", pkg, "--json"); return v ? JSON.parse(v) : null; },
  };
}
