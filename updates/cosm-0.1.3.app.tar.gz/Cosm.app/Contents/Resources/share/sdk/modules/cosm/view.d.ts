// `cosm/view`: a view's runtime (app/kit/src/view.ts), as a view's own modules import it. The window gives every view
// the module (an import map); a view's .ts modules are built with it left outside, for the window to give.
import type { ViewCosm } from "cosm";

/** A value the view keeps for itself: read and set through `value`; setting it redraws every show() that read it.
 * Replaced whole, never changed in place. Not kept: it starts again with the view. Made once, outside the drawing
 * function. */
export interface State<T> {
  value: T;
  /** `fn` told when the value changed, once a turn (for a view that draws itself: React's
   * `useSyncExternalStore(s.subscribe, () => s.value)`); answers how to stop. */
  subscribe(fn: () => void): () => void;
}
export function state<T>(initial: T): State<T>;

/** What a live value is doing: its first load, a reload with the last answer still shown, done, or failed (the last
 * good answer, if any, still in `value`). */
export type Status = "loading" | "refreshing" | "ready" | "failed";

/** What one of the package's view functions answers, kept up to date: loaded once, then again when what the function
 * says it depends on changed (its `changes`), when its input changes, or by `refresh()`. */
export interface Live<T> {
  /** The last good answer; `undefined` before the first (answers travel as JSON: `null`, `0` and `false` are answers). */
  readonly value: T | undefined;
  readonly status: Status;
  /** Why the last load failed. */
  readonly error: Error | undefined;
  /** Loads it again now; settles when that load is done (a failure is in `status` and `error`, never thrown). */
  refresh(): Promise<void>;
  /** `fn` told when its value, status or error changed, once a turn (for a view that draws itself); answers how to stop. */
  subscribe(fn: () => void): () => void;
  /**
   * A change the view makes, shown at once (SWR's `mutate`): runs `action` (a call that changes what this answers),
   * shows `optimisticData` meanwhile (a value, or one made from the value now), then loads again. When the action
   * fails what was shown is put back (`rollbackOnError: false` keeps it) and the failure is thrown. A tick, a rename,
   * a row added: the user sees it on the click, not after the write.
   *
   *   tasks.mutate(() => cosm.main.tick({ id }), { optimisticData: (v) => v!.map((t) => (t.id === id ? { ...t, done: true } : t)) });
   */
  mutate<R>(action: () => Promise<R>, options?: { optimisticData?: T | ((value: T | undefined) => T); rollbackOnError?: boolean }): Promise<R>;
}
/** A live value of a view function (`cosm.main.<name>`), with its input: a value, or a function reading state(),
 * read again when that state changes. Made once, outside the drawing function. */
export function live<T>(fn: () => Promise<T>): Live<T>;
export function live<I, T>(fn: (input: I) => Promise<T>, input: I | (() => I)): Live<T>;

/** Draws what `draw` gives (`html`…``) into the target (an element, or a selector), replacing what was there, and again
 * whenever a state or live value it read changes; changes in one turn are one redraw. Answers how to stop. */
export function show(target: Element | string, draw: () => unknown): () => void;

/** Lit's `html` (lit.dev): a template of the view's markup, values as `${…}`, properties as `.name=${…}`, events as
 * `@click=${…}`. */
export function html(strings: TemplateStringsArray, ...values: unknown[]): unknown;

/** Lit's `repeat` (lit.dev): a list drawn by key, each row keeping its own elements as rows come, go and move. Use it
 * for rows holding state the template doesn't set (a checkbox the user ticked, a field being typed in, focus): with
 * `.map`, a row that goes hands its elements, state and all, to the row after it. */
export function repeat<T>(items: Iterable<T>, key: (item: T, index: number) => unknown, row: (item: T, index: number) => unknown): unknown;

/** The view's `cosm`, with `main` typed by the package's view functions. */
export function view<Api = Record<string, (input?: any) => Promise<any>>>(): Omit<ViewCosm, "main"> & { readonly main: Api };
