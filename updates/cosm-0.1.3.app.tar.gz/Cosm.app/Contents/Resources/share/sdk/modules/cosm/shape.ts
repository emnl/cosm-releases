// `cosm/shape`: shapes written without a schema library. Each answers plain JSON Schema, which Cosm checks every value
// against (a setting, a contribution, a function's input), and carries the TypeScript type of what it takes, so a view's
// call of the function is typed (`Infer<typeof s>` names it). It runs in the package's own worker and costs nothing
// beside the SDK; zod and the like still work for a package that brings one.
//
//   import { shape } from "cosm/shape";
//   input: shape.object({ path: shape.string(), wrap: shape.optional(shape.boolean()) })
//   shape: shape.number({ min: 9, max: 24 })

import type { Shaped } from "cosm";

/** The type a shape takes. */
export type Infer<S> = S extends Shaped<infer T> ? T : unknown;

/** What every shape may carry: what it is, said to the agent and in Settings. */
type About = { description?: string };
/** A shape left out of an object's required keys (`shape.optional`). */
type Optional<T> = Shaped<T | undefined> & { readonly [optional]: true };
declare const optional: unique symbol;
const OPTIONAL = Symbol("optional");

const made = <T>(schema: Record<string, unknown>, about?: About): Shaped<T> =>
  (about?.description ? { ...schema, description: about.description } : schema) as Shaped<T>;

/** An object's keys: those not `optional` are required. */
type Props = Record<string, Shaped<unknown>>;
type ObjectOf<P extends Props> =
  { [K in keyof P as P[K] extends { readonly [optional]: true } ? never : K]: Infer<P[K]> } &
  { [K in keyof P as P[K] extends { readonly [optional]: true } ? K : never]?: Exclude<Infer<P[K]>, undefined> };
type Flat<T> = { [K in keyof T]: T[K] } & {};

export const shape = {
  /** A text: a text field in Settings (`format: "font"`: a font picker). */
  string: (about?: About & { minLength?: number; maxLength?: number; pattern?: string; format?: string }) => {
    const { description, ...rest } = about ?? {};
    return made<string>({ type: "string", ...rest }, { description });
  },
  /** A number, with its bounds (a whole number with `whole`): a number field in Settings. */
  number: (about?: About & { min?: number; max?: number; whole?: boolean }) => {
    const { description, min, max, whole } = about ?? {};
    return made<number>({ type: whole ? "integer" : "number", ...(min !== undefined ? { minimum: min } : {}), ...(max !== undefined ? { maximum: max } : {}) }, { description });
  },
  /** Yes or no: a switch in Settings. */
  boolean: (about?: About) => made<boolean>({ type: "boolean" }, about),
  /** One of these texts: a menu in Settings. */
  enum: <const V extends readonly [string, ...string[]]>(values: V, about?: About) => made<V[number]>({ type: "string", enum: [...values] }, about),
  /** A list of one shape. */
  array: <S extends Shaped<unknown>>(item: S, about?: About & { min?: number; max?: number }) => {
    const { description, min, max } = about ?? {};
    return made<Infer<S>[]>({ type: "array", items: plain(item), ...(min !== undefined ? { minItems: min } : {}), ...(max !== undefined ? { maxItems: max } : {}) }, { description });
  },
  /** Named keys, each with its shape; every key is required unless its shape is `shape.optional(…)`. */
  object: <const P extends Props>(props: P, about?: About) => {
    const required = Object.keys(props).filter((k) => !(props[k] as any)[OPTIONAL]);
    return made<Flat<ObjectOf<P>>>({
      type: "object",
      properties: Object.fromEntries(Object.entries(props).map(([k, s]) => [k, plain(s)])),
      ...(required.length ? { required } : {}),
    }, about);
  },
  /** Any keys, each value of one shape. */
  record: <S extends Shaped<unknown>>(value: S, about?: About) =>
    made<Record<string, Infer<S>>>({ type: "object", additionalProperties: plain(value) }, about),
  /** Anything at all. */
  unknown: (about?: About) => made<unknown>({}, about),
  /** A key an object may leave out. */
  optional: <S extends Shaped<unknown>>(s: S): Optional<Infer<S>> => ({ ...plain(s), [OPTIONAL]: true }) as unknown as Optional<Infer<S>>,
};

/** A shape as JSON Schema alone (an optional's mark taken off). */
function plain(s: Shaped<unknown>): Record<string, unknown> {
  const { [OPTIONAL]: _, ...rest } = s as any;
  return rest;
}
