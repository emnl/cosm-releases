// The package host: one Bun process for every package of a cosm, a worker per package.
// The engine starts it as its child and talks JSON-RPC 2.0 over its stdin and stdout, one message a line.
//
// The engine asks:  load {package, dir, root, data, cache, live, settings, key, bundle, from} → the package's registrations (worker.ts says their shape)
//                   call {package, fn, args}            → what the function returned, or an error {message, data: {stack}}
//                   ($/cancelRequest {id}: a call it no longer waits on; its signal fires)
//                   stop {package}                     → {} (its worker ended, its calls failed)
// The host tells:   exited {package, why}              (a worker that ended by itself: the engine loads it again on its next use)
//                   keeps {package, keeps: [{why, since}]} (what holds the package's workers running: cosm.package.keep)
//                   unresponsive {package} / responsive {package} (a worker with calls in flight that hasn't run a message for 3 s, and when it does again)
//                   frozen {package}                   (the same for 30 s: the engine restarts it)
// The host asks the engine for what the API does (files, storage, the index, emit …): the engine's own methods, each
// with {context: {package}}. A worker's console goes to the engine as `log` notifications.
//
// A worker that is loaded but not live (a package that is off: the check and Settings read what it adds) is ended
// as soon as it has registered.
//
// A package's code runs as one file, its bundle: its main.ts and what it imports,
// built with Bun's bundler, `cosm`, `cosm/*` and `package:*` left for the worker to give. A load `from: "saved"` builds
// it from the main.ts as saved and keeps it at `bundle` once it has loaded; a load `from: "bundle"` (a wake) runs the one
// kept, and builds only when there is none. A save that doesn't build or load leaves the bundle as it was.
//
// A package loaded again (its code edited, an update): the new code loads beside what runs and takes its place once
// loaded. A call goes to the load its function's id names (`<key>.f13`: the registration's key), so the
// worker it replaced still answers the calls addressed to it for a moment (RETIRE_MS) and finishes those it has; then it stops (its own
// `package.stopping`), at the latest once its calls ran for DRAIN_MS more. No call fails because the package loaded
// again; a call for a load that is gone fails as one (`no function …`).

import { renameSync, rmSync } from "node:fs";
import { dirname } from "node:path";

const WORKER = new URL("./worker.ts", import.meta.url).href;

type Pending = { resolve: (v: unknown) => void; reject: (e: RpcError) => void };
type RpcError = { code: number; message: string; data?: unknown };
type Call = { what: string; started: number; call: number; reply: (r: { result?: unknown; error?: RpcError }) => void; skipped?: number; told?: boolean };

const out = (msg: unknown) => process.stdout.write(JSON.stringify(msg) + "\n");
const answer = (id: number, r: { result?: unknown; error?: RpcError }) => out({ jsonrpc: "2.0", id, ...("error" in r && r.error ? { error: r.error } : { result: r.result ?? null }) });

// --- the engine, asked by the workers --------------------------------------------------------------------------------------

let next = 1;
const asked = new Map<number, Pending>();
function ask(method: string, params: Record<string, unknown>): Promise<unknown> {
  const id = next++;
  out({ jsonrpc: "2.0", id, method, params });
  return new Promise((resolve, reject) => asked.set(id, { resolve, reject }));
}

// --- the workers ---------------------------------------------------------------------------------------------------------------

class Package {
  worker: Worker;
  /** Replaced by newer code: answering only what is addressed to it, until it stops. */
  retiring = false;
  /** Each worker's own number, so an answer of an ended worker is never taken for the new one's. */
  id = String(next++);
  /** Its registration's key, which its functions' ids start with: the same for every worker of the same code and
   * settings (a package woken after it slept), so a call names the registration, not the worker. */
  key: string;
  calls = new Map<number, Call>();
  /** What its code holds it running for (`cosm.package.keep`), by the handle's number: they go with the worker. */
  keeps = new Map<number, { why: string; since: number }>();
  loaded: Promise<unknown>;
  private ready!: { resolve: (v: unknown) => void; reject: (e: RpcError) => void };

  constructor(public name: string, public dir: string, root: string, data: string, cache: string, public live: boolean, settings: unknown = {}, key = "", main = "") {
    this.key = key || this.id;
    this.loaded = new Promise((resolve, reject) => (this.ready = { resolve, reject }));
    this.worker = new Worker(WORKER, { env: { ...process.env, COSM_PACKAGE: name } } as any);
    this.worker.onmessage = (e: MessageEvent) => this.heard(e.data);
    this.worker.onerror = (e: ErrorEvent) => {
      // An error nothing caught: the package's own fault, said in its log; a load that hadn't finished fails with it.
      const message = e.message || String(e);
      out({ jsonrpc: "2.0", method: "log", params: { package: name, line: `uncaught: ${message}` } });
      this.ready.reject({ code: 1, message });
      e.preventDefault?.();
    };
    // The worker ended by itself (not by `end`): its calls fail, and the engine is told, so the package loads again on
    // its next use instead of calls waiting on a worker that is gone.
    this.worker.addEventListener("close", () => {
      if (this.ended) return;
      this.ended = true;
      this.unlist();
      for (const c of this.calls.values()) c.reply({ error: { code: 1, message: `${name}'s code stopped running` } });
      this.calls.clear();
      this.ready.reject({ code: 1, message: `${name}'s code stopped running` });
      if (packages.get(name) === this) {
        packages.delete(name);
        out({ jsonrpc: "2.0", method: "exited", params: { package: name, why: "its worker ended" } });
      }
    });
    this.loadId = next++;
    this.worker.postMessage({ jsonrpc: "2.0", id: this.loadId, method: "load", params: { package: name, dir, root, data, cache, main, load: this.key, settings } });
  }
  /** The id of the `load` asked of its worker. */
  private loadId: number;

  /** What its worker says (JSON-RPC 2.0): a reply to `load` or a `call`, a request for the engine (sent on
   * with who asks: the package), or its console's `log`. */
  heard(m: any) {
    if (m.method === undefined && m.id !== undefined) {
      const error = m.error ? { code: m.error.code ?? 1, message: m.error.message, data: m.error.data } : undefined;
      if (m.id === this.loadId) { if (error) this.ready.reject(error); else this.ready.resolve(m.result); return; }
      const c = this.calls.get(m.id);
      if (!c) return;
      this.calls.delete(m.id);
      c.reply(error ? { error } : { result: m.result ?? null });
      return;
    }
    if (m.method === "log") { out({ jsonrpc: "2.0", method: "log", params: { package: this.name, line: m.params?.line } }); return; }
    if (m.method === "pong") { this.pinged = 0; if (this.unresponsive) { this.unresponsive = this.frozen = false; out({ jsonrpc: "2.0", method: "responsive", params: { package: this.name } }); } return; }
    if (m.id === undefined) return;
    // Its holds, kept here with the worker (they end with it, however it ends), told to the engine as they change.
    if (m.method === "package.keep") {
      const id = next++;
      this.keeps.set(id, { why: String(m.params?.why ?? "") || "(no reason given)", since: Date.now() });
      this.worker.postMessage({ jsonrpc: "2.0", id: m.id, result: { id } });
      tellKeeps(this.name);
      return;
    }
    if (m.method === "package.release") {
      this.keeps.delete(Number(m.params?.id));
      this.worker.postMessage({ jsonrpc: "2.0", id: m.id, result: null });
      tellKeeps(this.name);
      return;
    }
    ask(m.method, { ...(m.params ?? {}), context: { package: this.name } }).then(
      (result) => this.worker.postMessage({ jsonrpc: "2.0", id: m.id, result: result ?? null }),
      (error: RpcError) => this.worker.postMessage({ jsonrpc: "2.0", id: m.id, error: { code: error.code ?? 1, message: error.message || "the engine said no" } }),
    );
  }

  call(fn: string, args: unknown[], what: string, call: number, reply: Call["reply"]) {
    const id = next++;
    this.calls.set(id, { what, started: Date.now(), call, reply });
    this.worker.postMessage({ jsonrpc: "2.0", id, method: "call", params: { fn, args } });
  }

  /** Ended, by `end` or by itself. */
  ended = false;
  /** When the ping not yet answered was sent (0: none out), and what the engine was told of it. */
  pinged = 0;
  unresponsive = false;
  frozen = false;

  /** Its code told it starts running: its own `package.started` handlers. */
  started(reason: string, off: string[] = []) { if (this.live && !this.ended && !off.includes("package.started")) this.worker.postMessage({ jsonrpc: "2.0", method: "started", params: { reason } }); }

  /** Its code told it stops (its own `package.stopping` handlers, `cosm.package.signal` aborted first), given 3 s, then
   * its worker ended: what is left (timers, sockets) ends with it. */
  async stop(reason: string, why: string, off: string[] = []) {
    if (this.ended) return;
    if (this.live) {
      const id = next++;
      const heard = new Promise<void>((resolve) => this.calls.set(id, { what: "package.stopping", started: Date.now(), call: 0, reply: () => resolve() }));
      this.worker.postMessage({ jsonrpc: "2.0", id, method: "stopping", params: { reason, quiet: off.includes("package.stopping") } });
      await Promise.race([heard, new Promise((r) => setTimeout(r, STOPPING_MS))]);
      this.calls.delete(id);
    }
    this.end(why);
  }

  /** No longer reached by its key (a newer worker of the same key may hold it already); its holds go with it. */
  unlist() {
    if (byLoad.get(this.key) === this) byLoad.delete(this.key);
    if (this.keeps.size) { this.keeps.clear(); tellKeeps(this.name); }
  }

  end(why: string) {
    this.ended = true;
    this.unlist();
    const left = [...this.calls.values()].filter((c) => c.skipped).length;
    if (left) out({ jsonrpc: "2.0", method: "log", params: { package: this.name, line: `${left} skipped call${left === 1 ? "" : "s"} still ran when its worker ended: its code doesn't stop on cosm.signal` } });
    this.worker.terminate();
    for (const c of this.calls.values()) c.reply({ error: { code: 1, message: why } });
    this.calls.clear();
    this.ready.reject({ code: 1, message: why });
  }
}

const packages = new Map<string, Package>();
/** A package's holds as they are now, across its workers (one just replaced still running), told to the engine. */
function tellKeeps(name: string) {
  const all = new Set([...packages.values(), ...byLoad.values()].filter((p) => p.name === name && !p.ended));
  const keeps = [...all].flatMap((p) => [...p.keeps.values()]).sort((a, b) => a.since - b.since);
  out({ jsonrpc: "2.0", method: "keeps", params: { package: name, keeps } });
}
/** Every worker that answers calls, the current and those just replaced, by its registration's key (a function id's
 * prefix). */
const byLoad = new Map<string, Package>();
// --- the watch on frozen code ------------------------------------------------------------------------------------------------
// A slow call is the package's business: it times its own work and stops on cosm.signal. Code that holds its worker's
// thread is Cosm's: while a worker has calls in flight it is pinged each second (worker.ts answers before anything
// else). Unanswered for 3 s, the engine is told (the window says it isn't responding, with Restart Package); for 30 s,
// the engine restarts it. A skipped call still running 30 s later is said once in the package's log.
const UNRESPONSIVE_MS = 3000;
// COSM_PACKAGE_FROZEN_SECS: shorter, for the engine's tests.
const FROZEN_MS = 1000 * (Number(process.env.COSM_PACKAGE_FROZEN_SECS) || 30);
setInterval(() => {
  const now = Date.now();
  for (const pk of new Set([...packages.values(), ...byLoad.values()])) {
    if (pk.ended) continue;
    for (const c of pk.calls.values()) if (c.skipped && !c.told && now - c.skipped > FROZEN_MS) { c.told = true; out({ jsonrpc: "2.0", method: "log", params: { package: pk.name, line: `${c.what} was skipped 30 s ago and still runs: its code doesn't stop on cosm.signal` } }); }
    if (!pk.calls.size) { pk.pinged = 0; continue; }
    if (!pk.pinged) { pk.pinged = now; pk.worker.postMessage({ jsonrpc: "2.0", method: "ping" }); continue; }
    const held = now - pk.pinged;
    if (held > UNRESPONSIVE_MS && !pk.unresponsive) { pk.unresponsive = true; out({ jsonrpc: "2.0", method: "unresponsive", params: { package: pk.name } }); }
    if (held > FROZEN_MS && !pk.frozen) { pk.frozen = true; out({ jsonrpc: "2.0", method: "frozen", params: { package: pk.name } }); }
  }
}, 1000);

/** How long a package's `package.stopping` handlers may take before its worker ends anyway. */
const STOPPING_MS = 3000;
/** How long a replaced worker still takes calls addressed to it, and then at most waits for those it has. */
const RETIRE_MS = 3000;
const DRAIN_MS = 30000;

/** A worker replaced by newer code: calls addressed to it still reach it for a moment, then it stops once the calls it
 * has are done (or DRAIN_MS passed). */
function retire(old: Package, reason: string, why: string, off: string[]) {
  old.retiring = true;
  setTimeout(async () => {
    old.unlist();
    const until = Date.now() + DRAIN_MS;
    while (old.calls.size && Date.now() < until && !old.ended) await new Promise((r) => setTimeout(r, 100));
    await old.stop(reason, why, off);
  }, RETIRE_MS);
}

/** The package's main.ts as saved, and what it imports, built into one file beside its bundle (`<bundle>.<n>.js`) for
 * its worker to load: none when it has no main.ts. Built in a process of its own (code-build.ts), so a library
 * installed since the host started is found. Its source map is in the file, naming the saved files, so an error's
 * stack names their lines. A file the build makes beside the code (one imported as a file) goes into the bundle's
 * folder under its own name; those it added (`added`) go again when the code doesn't load. */
async function build(dir: string, bundle: string, added: string[]): Promise<string> {
  if (!(await Bun.file(`${dir}/main.ts`).exists())) return "";
  const made = `${bundle}.${next++}.js`;
  const p = Bun.spawn([process.execPath, `${import.meta.dir}/code-build.ts`, dir, made, dirname(bundle)], { stdout: "pipe", stderr: "pipe", stdin: "ignore" });
  const [out, err] = await Promise.all([new Response(p.stdout).text(), new Response(p.stderr).text(), p.exited]);
  let r: { error?: string; added?: string[] };
  try { r = JSON.parse(out.trim().split("\n").pop() ?? ""); } catch { r = { error: err.trim() || out.trim() || "its main.ts didn't build" }; }
  added.push(...(r.added ?? []));
  if (r.error !== undefined) { rmSync(made, { force: true }); throw { code: 1, message: r.error }; }
  return made;
}

async function load(p: { package: string; dir: string; root: string; data: string; cache: string; live: boolean; settings?: unknown; reason?: string; off?: string[]; key?: string; bundle: string; from?: "saved" | "bundle" }) {
  // The code it runs: its bundle as it loaded last, for a wake (built when there is none); else its main.ts as saved,
  // built anew.
  const kept = p.from === "bundle" && (await Bun.file(p.bundle).exists());
  // The new code loads beside what runs: only once it has loaded does it take the old one's place, so code that
  // doesn't build or load leaves the last version that did running (the engine says why).
  const old = packages.get(p.package);
  let made = "";
  const added: string[] = [];
  try { if (!kept) made = await build(p.dir, p.bundle, added); }
  catch (e) { for (const f of added) rmSync(f, { force: true }); if (!p.live) { old?.end(`${p.package} is off`); packages.delete(p.package); } throw e; }
  const pk = new Package(p.package, p.dir, p.root, p.data, p.cache, p.live, p.settings ?? {}, p.key ?? "", kept ? p.bundle : made);
  try {
    const r = await pk.loaded;
    // It loaded: what it was built into is its bundle now (with no main.ts, it has none).
    if (!kept) { if (made) renameSync(made, p.bundle); else rmSync(p.bundle, { force: true }); }
    // The new code runs first, then the old hears it stops (`reload` or `update`): what it hands on is ready for it.
    const why = p.reason === "update" ? "update" : "reload";
    if (p.live) {
      packages.set(p.package, pk); byLoad.set(pk.key, pk);
      pk.started(p.reason ?? "startup", p.off ?? []);
      if (old) retire(old, why, `${p.package} was loaded again`, p.off ?? []);
    }
    else { void old?.stop("off", `${p.package} is off`); packages.delete(p.package); }
    return r;
  } catch (e) {
    for (const f of made ? [made, ...added] : added) rmSync(f, { force: true });
    pk.end("it didn't load");
    if (!p.live) { old?.end(`${p.package} is off`); packages.delete(p.package); }
    throw e;
  } finally {
    if (!p.live) pk.end("loaded to read what it adds");
  }
}

// --- the engine's requests ----------------------------------------------------------------------------------------------------

async function handle(id: number, method: string, p: any) {
  try {
    switch (method) {
      case "load":
        return answer(id, { result: await load(p) });
      case "call": {
        // The load its function's id names, while it answers (just replaced, for a moment); else the current one.
        const own = byLoad.get(String(p.fn ?? "").split(".")[0] ?? "");
        const pk = own && own.name === p.package && !own.ended ? own : packages.get(p.package);
        if (!pk) return answer(id, { error: { code: 1, message: `${p.package} isn't running` } });
        await pk.loaded;
        return pk.call(p.fn, p.args ?? [], p.what ?? p.fn, id, (r) => answer(id, r));
      }
      case "stop": {
        const pk = packages.get(p.package);
        packages.delete(p.package);
        // Stopped (off, restarted): one still answering after a reload stops too, at once.
        for (const r of [...byLoad.values()]) if (r.name === p.package && r !== pk) r.end(`${p.package} was stopped`);
        const reason = p.reason ?? "reload";
        await pk?.stop(reason, reason === "reload" ? `${p.package} was restarted` : `${p.package} was stopped (${reason})`, p.off ?? []);
        return answer(id, { result: {} });
      }
      // Cosm stops (`quit`): every package hears it, side by side, within the same 3 s.
      case "stop.all": {
        const all = [...packages.values()];
        for (const r of [...byLoad.values()]) if (!all.includes(r)) r.end("Cosm stopped");
        packages.clear();
        await Promise.all(all.map((pk) => pk.stop(p.reason ?? "quit", "Cosm stopped")));
        return answer(id, { result: {} });
      }
      default:
        return answer(id, { error: { code: -32601, message: `the package host has no method ${method}` } });
    }
  } catch (e: any) {
    answer(id, { error: e && typeof e === "object" && "message" in e ? { code: e.code ?? 1, message: e.message, data: e.data } : { code: 1, message: String(e) } });
  }
}

// --- reading the engine ------------------------------------------------------------------------------------------------------

let buf = "";
const decoder = new TextDecoder();
for await (const chunk of Bun.stdin.stream()) {
  buf += decoder.decode(chunk, { stream: true });
  let at: number;
  while ((at = buf.indexOf("\n")) >= 0) {
    const line = buf.slice(0, at);
    buf = buf.slice(at + 1);
    if (!line.trim()) continue;
    let m: any;
    try { m = JSON.parse(line); } catch { continue; }
    if (m.method !== undefined && m.id !== undefined) handle(m.id, m.method, m.params ?? {});
    // Something for a package's code (a stream's items): passed to its worker, nothing answered.
    else if (m.method === "notify") packages.get(m.params?.package)?.worker.postMessage({ jsonrpc: "2.0", method: m.params?.method, params: m.params?.params ?? {} });
    // A call the engine no longer waits on (its id): its signal fires in its worker.
    else if (m.method === "$/cancelRequest") {
      for (const pk of new Set([...packages.values(), ...byLoad.values()])) for (const [cid, c] of pk.calls) if (c.call === m.params?.id) { c.skipped = Date.now(); pk.worker.postMessage({ jsonrpc: "2.0", method: "$/cancelRequest", params: { id: cid } }); }
    }
    else if (m.id !== undefined) {
      const w = asked.get(m.id);
      if (!w) continue;
      asked.delete(m.id);
      if (m.error) w.reject(m.error); else w.resolve(m.result);
    }
  }
}
// The engine went: so do the packages.
for (const pk of new Set([...packages.values(), ...byLoad.values()])) pk.end("Cosm stopped");
process.exit(0);
