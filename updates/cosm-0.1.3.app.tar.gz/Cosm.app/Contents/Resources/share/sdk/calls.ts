// The calls a package's script and its views share (share/sdk/cosm.d.ts `Services`), written once. The worker
// (share/sdk/worker.ts) builds main.ts's `cosm` on them and the kit's bridge (app/kit/src/bridge.ts) builds a view's;
// each side gives how it reaches the engine and the cosm's files. Every name is the engine method of the same name.

/** An engine method with its params: its answer, or a rejected Error with the engine's reason. */
export type Engine = (method: string, params: Record<string, unknown>) => Promise<any>;

/** What a side gives: the engine, the package's name, the thing that is no file its view shows (a view's; none for
 * main.ts), and the cosm's files read. */
export interface Host {
  engine: Engine;
  name: string;
  thing: () => string | undefined;
  read: (path: string, bytes: boolean) => Promise<string | Uint8Array>;
  log: (...what: unknown[]) => void;
  /** Hears the streams' items as the engine sends them (`stream.items`): a view through its events, main.ts through
   * its host. Stops when called. */
  hear: (f: (d: Items) => void) => () => void;
  /** Hears the window's Cancel on one of its progresses (`ui.progress` with `cancelled`, or the host's
   * `progress.cancel`). Stops when called. */
  cancelled: (id: number, f: () => void) => () => void;
}

/** A batch of a stream's items as the engine sends it: numbered from 1 each time the stream opens; `code` once a
 * program's output closed (how the program ended). */
export type Items = { name: string; items: { n: number; item: unknown }[]; closed: boolean; code?: number };
/** A handle on a stream, as `cosm.stream.pass` gives it: what a package's code hands its view. */
export type Handle = { name: string; handle: string };
/** What a subscriber is told with each batch: whether the stream closed (and how its program ended), and how many
 * items were lost before these (a gap in the numbers: more came than the stream kept before they were read). */
export type Told = { closed: boolean; code?: number; missed?: number };

/** Follows a stream from what it kept, in order, dropping what was already had and saying what was missed: `hear`
 * gets the engine's batches, `read` asks for what the stream kept. The answer stops following. A batch is given only
 * once the one before was taken: an `async` subscriber finishes with one before the next (its end among them) comes. */
export async function follow(name: string, f: (items: unknown[], o: Told) => void | Promise<void>, hear: (f: (d: Items) => void) => () => void, read: () => Promise<Items>, stop: () => void) {
  let last = 0, ready = false;
  let turn: Promise<void> = Promise.resolve();
  const give = (items: unknown[], o: Told) => {
    turn = turn.then(() => f(items, o)).catch((e: unknown) => console.error(`a subscriber of ${name} threw: ${e instanceof Error ? e.stack ?? e.message : e}`));
  };
  const early: Items[] = [];
  const take = (d: Items, kept = false) => {
    if (d.name !== name) return;
    const items = d.items.filter((x) => x.n > last);
    const missed = items.length ? items[0]!.n - last - 1 : 0;
    if (items.length) last = items[items.length - 1]!.n;
    if (items.length || d.closed || kept) give(items.map((x) => x.item), { closed: d.closed, ...(d.closed && typeof d.code === "number" ? { code: d.code } : {}), ...(missed > 0 ? { missed } : {}) });
    // Its end is the subscription's: nothing more is heard of it.
    if (d.closed) { off(); stop(); }
  };
  let stopHearing = () => {};
  const off = () => stopHearing();
  stopHearing = hear((d) => (ready ? take(d) : void early.push(d)));
  let r: Items;
  try { r = await read(); } catch (e) { off(); throw e; }
  take({ ...r, name }, true);
  ready = true;
  for (const d of early) take(d);
  return () => { off(); stop(); };
}

/** The engine methods the shared calls use: all a view's `cosm` may reach of the engine, besides its own window's. */
export const METHODS = [
  "index.find", "index.search", "index.analyze", "index.retrieve", "index.query",
  "setting.get", "secret.get",
  "file.write", "file.list", "file.name", "file.append", "file.change", "file.tree", "file.stat", "file.move", "file.trash", "file.which",
  "storage.get", "storage.set", "storage.delete", "storage.list", "trash.list", "trash.restore",
  "stream.open", "stream.write", "stream.close", "stream.pass", "stream.subscribe", "stream.unsubscribe", "stream.list",
  "process.start", "process.write", "process.resize", "process.stop", "process.list",
  "ui.shown", "ui.active", "ui.open", "ui.close", "ui.back", "ui.forward", "ui.items", "ui.run", "ui.notify", "ui.ask",
  "ui.progress.start", "ui.progress.update", "ui.progress.end",
  "point.read", "point.default", "point.call",
  "package.call", "emit",
] as const;

/** A point's contribution as the engine gives it to a reader: its functions (`{fn, package}`) made callable, run in
 * the package that added them. */
/** An input as it travels: plain JSON (functions left out). */
const plainInput = (input: unknown) => JSON.parse(JSON.stringify(input ?? {}, (_k, x) => (typeof x === "function" ? undefined : x)) ?? "{}");

function callable(engine: Engine, v: any): any {
  if (Array.isArray(v)) return v.map((x) => callable(engine, x));
  if (v && typeof v === "object") {
    const keys = Object.keys(v);
    if (keys.length === 2 && typeof v.fn === "string" && typeof v.package === "string") {
      const { fn, package: pk } = v;
      return (input: unknown = {}) => engine("point.call", { package: pk, fn, args: [plainInput(input)] });
    }
    return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, callable(engine, x)]));
  }
  return v;
}



/** A package's storage. */
function storage(engine: Engine) {
  return {
    async get(key: string) { const v = await engine("storage.get", { key }); return v === undefined ? null : v; },
    async set(key: string, value: unknown) { await engine("storage.set", { key, value: value === undefined ? null : value }); },
    /** The value worked out from the one kept (`fn`, synchronous, only computing), written only while nothing changed
     * it meanwhile: else read again and `fn` run again, a few times, then a conflict error. Answers what it wrote. */
    async update(key: string, fn: (value: any) => unknown) {
      if (typeof fn !== "function") throw new Error("cosm.storage.update(key, fn): fn works out the new value from the one kept");
      for (let tries = 0; tries < 5; tries++) {
        const { value, token } = await engine("storage.get", { key, token: true });
        const next = fn(value === undefined ? null : value);
        if (next && typeof (next as { then?: unknown }).then === "function") throw new Error("cosm.storage.update: fn is synchronous (work out ids and times before update)");
        try { await engine("storage.set", { key, value: next === undefined ? null : next, if: token }); return next; }
        catch (e) { if (!String((e as Error)?.message ?? e).startsWith("conflict:")) throw e; }
        // Another writer got there first: a short pause, random and growing, so writers at once don't keep colliding.
        await new Promise((r) => setTimeout(r, Math.random() * 10 * 2 ** tries));
      }
      throw new Error(`conflict: ${key} kept changing while it was updated (5 tries)`);
    },
    async delete(key: string) { await engine("storage.delete", { key }); },
    async list() { return Object.keys((await engine("storage.list", {})) ?? {}); },
  };
}

/** The shared calls, on one side's host. */
export function services(h: Host) {
  const { engine } = h;
  /** A point in full: a bare name is the package's own. */
  const full = (point: string) => (point.includes(":") ? point : `${h.name}:${point}`);
  return {
    point: {
      /** Every contribution to a point, resolved, in Cosm's package order. */
      async read(point: string) { return callable(engine, await engine("point.read", { point: full(point) })); },
      /** The contribution a `uses: "one"` point uses now (the user's default), or null. */
      async default(point: string) { return callable(engine, await engine("point.default", { point: full(point) })); },
    },
    index: {
      async find(conditions: string[]) { return engine("index.find", { conditions }); },
      async search(words: string, options: { kind?: string; in?: string[]; passages?: boolean } = {}) {
        const hits: any[] = await engine("index.search", { words, ...options });
        return hits.map(({ path, ...x }) => ({ thing: path, ...x }));
      },
      async analyze(text: string) { return engine("index.analyze", { text }); },
      async retrieve(words: string, options: { kind?: string; in?: string[] } = {}) { return engine("index.retrieve", { words, ...options }); },
      async query(sql: string) {
        const t: { columns: string[]; rows: unknown[][] } = await engine("index.query", { sql });
        return t.rows.map((r) => Object.fromEntries(t.columns.map((c, i) => [c, r[i]])));
      },
    },
    setting: {
      async get(name: string) {
        const [pk, key] = name.includes(":") ? name.split(":", 2) : [h.name, name];
        return (await engine("setting.get", { package: pk, name: key })) ?? null;
      },
    },
    file: {
      async read(path: string, o: { bytes?: boolean } = {}) { return h.read(path, !!o.bytes); },
      async write(path: string, content: string | Uint8Array) {
        await engine("file.write", typeof content === "string" ? { path, text: content } : { path, bytes: Array.from(content) });
      },
      async name(path: string) { return ((await engine("file.name", { paths: [path] })) as string[])[0]; },
      async append(path: string, text: string) { await engine("file.append", { path, text }); },
      async change(path: string, fn: (text: string) => string | Promise<string>) {
        // The change made on the file's text now, written only while it is still that text; changed meanwhile (the user
        // typed): made again on the newest, so nothing of theirs is lost.
        for (let i = 0; i < 5; i++) {
          const base = await h.read(path, false).catch(() => { throw new Error(`no file ${path}`); }) as string;
          const text = await fn(base);
          if (text === base) return;
          // True: written; false: the file changed meanwhile, so it is made again on the newest.
          if (await engine("file.change", { path, text, base })) return;
        }
        throw new Error(`${path} kept changing while it was changed: try again`);
      },
      async list(glob: string) { return engine("file.list", { glob }); },
      async tree(options: { skip?: string[]; hidden?: "include" } = {}) { return engine("file.tree", { skip: options.skip ?? [], ...(options.hidden === "include" ? { hidden: true } : {}) }); },
      async stat(path: string) { return (await engine("file.stat", { path })) ?? null; },
      async move(from: string, to: string) { await engine("file.move", { from, to }); },
      async trash(path: string) { await engine("file.trash", { path }); },
      async which(name: string, o: { kind?: string; from?: string } = {}) {
        return (await engine("file.which", { name, kind: o.kind ?? "", from: o.from ?? "" }).catch(() => null)) ?? null;
      },
    },
    trash: {
      /** What is in the cosm's trash, newest first: its name there, where it came from, a folder or not, when it went. */
      async list() { return engine("trash.list", {}); },
      /** Puts it back where it was: its path. */
      async restore(name: string) { return (await engine("trash.restore", { name })) as string; },
    },
    root: {
      async list() { return engine("root.list", {}); },
      async add(path: string, o: { name?: string } = {}) { return engine("root.add", { path, name: o.name }); },
      async remove(id: string) { await engine("root.remove", { id }); },
      async locate(id: string, path: string) { return engine("root.locate", { id, path }); },
      async path(path: string) { return String(await engine("root.path", { path })); },
      async watch(path: string) { await engine("root.watch", { path }); return async () => { await engine("root.unwatch", { path }); }; },
    },
    stream: {
      /** Opens one of the package's streams (found again, with what it kept, after the code loaded again). */
      async open(name: string, o: { keep?: number } = {}) {
        const full = ((await engine("stream.open", { name, keep: o.keep })) as { name: string }).name;
        return {
          name: full,
          write: async (...items: unknown[]) => { await engine("stream.write", { name: full, items }); },
          close: async () => { await engine("stream.close", { name: full }); },
        };
      },
      /** A handle on a stream (the package's own by its short name, or any package's in full), for a view: a view
       * function returns it, and the view subscribes to it. A program's output is never handed to a view. */
      async pass(name: string): Promise<Handle> { return engine("stream.pass", { name }); },
      /** What the stream kept (always told, even when nothing: a stream not open yet is empty), then what comes, in
       * order, a few items at a time; `closed` when it ends (with `code` for a program's output), `missed` when items
       * were lost before these. By name (any package's, or the package's own by its short name) or by a handle. Stops
       * when the returned function is called. */
      async subscribe(stream: string | Handle, f: (items: unknown[], o: Told) => void | Promise<void>) {
        const by = typeof stream === "string" ? { name: stream.includes(":") ? stream : `${h.name}:${stream}` } : { handle: stream.handle };
        const name = typeof stream === "string" ? by.name! : stream.name;
        let known = name;
        return follow(name, f, (g) => h.hear((d) => g(d.name === known ? { ...d, name } : d)),
          async () => { const r = (await engine("stream.subscribe", by)) as Items; known = r.name; return r; },
          () => { void engine("stream.unsubscribe", by).catch(() => {}); });
      },
      async list(o: { package?: string } = {}) { return engine("stream.list", { package: o.package ?? "" }); },
    },
    process: {
      async start(name: string, o: { program: string; args?: string[]; as?: "lines" | "terminal"; cols?: number; rows?: number; env?: Record<string, string> }) {
        return engine("process.start", { name, program: o.program, args: o.args ?? [], as: o.as ?? "lines", cols: o.cols ?? 80, rows: o.rows ?? 24, env: o.env ?? {} });
      },
      async write(name: string, text: string) { await engine("process.write", { name, text }); },
      async resize(name: string, cols: number, rows: number) { await engine("process.resize", { name, cols, rows }); },
      async stop(name: string) { await engine("process.stop", { name }); },
      async list(o: { package?: string } = {}) { return engine("process.list", { package: o.package ?? "" }); },
    },
    storage: storage(engine),
    async instructions() { return String(await engine("instructions", {})); },
    ui: {
      async shown(pane?: string) { return engine("ui.shown", { pane: pane ?? "" }); },
      async active(view?: string) { return (await engine("ui.active", { view: view ?? "" })) ?? null; },
      /** True once the window is told; a target that is neither a file of the cosm nor a view of a package that is on is refused. */
      async open(target: string, arg?: string) { await engine("ui.open", { target, arg: arg ?? "" }); },
      async close(target?: string) { await engine("ui.close", { target: target ?? "" }); },
      async back() { await engine("ui.back", {}); },
      async forward() { await engine("ui.forward", {}); },
      async items(place: string) { return engine("ui.items", { place, thing: h.thing() ?? "" }); },
      async run(item: string, on: { path?: string; folder?: string; thing?: string } = {}) { await engine("ui.run", { item, path: on.path ?? "", folder: on.folder ?? "", thing: on.thing ?? h.thing() ?? "" }); },
      async notify(text: string, o: { as?: "problem" } = {}) { await engine("ui.notify", { text, as: o.as ?? "" }); },
      async ask(question: string, o: { description?: string; choices?: string[]; answer?: "text" | "folder"; in?: "background" } = {}) {
        const r = await engine("ui.ask", { question, description: o.description ?? "", choices: o.choices ?? [], answer: o.answer ?? "", in: o.in ?? "" });
        return r ?? null;
      },
      /**
       * Long work the user sees where notices show, and can cancel: `fn(progress, signal)`, where `progress({message,
       * done})` says how far it is (`done` 0 to 1; none: a running line) and `signal` aborts on Cancel. It goes when
       * `fn` returns (its answer) or throws (thrown on: what started the work says it).
       */
      async progress<T>(title: string, fn: (progress: (p: { message?: string; done?: number }) => void, signal: AbortSignal) => Promise<T> | T): Promise<T> {
        const { id } = (await engine("ui.progress.start", { title })) as { id: number };
        const c = new AbortController();
        const off = h.cancelled(id, () => c.abort(new Error(`${title}: cancelled`)));
        const progress = (p: { message?: string; done?: number }) => { void engine("ui.progress.update", { id, ...p }).catch(() => {}); };
        try { return await fn(progress, c.signal); }
        finally { off(); await engine("ui.progress.end", { id }).catch(() => {}); }
      },
    },
    /** Another package's export (`cosm.package.export`), given its one input: what it returns. */
    async call(ref: string, input: unknown = {}) {
      if (!ref.includes(":")) throw new Error(`cosm.call("${ref}"): an export is named in full, <package>:<name>`);
      return (await engine("package.call", { name: ref, args: [plainInput(input)] })) ?? null;
    },
    async emit(name: string, data: Record<string, unknown> = {}) { return (await engine("emit", { event: name, data })) ?? undefined; },
    log(...what: unknown[]) { h.log(...what); },
  };
}
