# The Claude Code adapter

How the app hands cosm's core (`../../core`) to Claude Code, which runs unmodified:

- At start the app assembles a Claude Code plugin in its data folder: `plugin.json`, `hooks.json`, and links to the core's
  `commands/`, `skills/` and `bin/`. Commands then answer to `/cosm:<name>`.
- `claude --plugin-dir <plugin> --append-system-prompt-file core/rules.md --settings settings.json`, in the cosm's folder,
  with `bin/` on the PATH (the agent runs `cosm search …`) and `COSM_OPEN_PAGE` naming the file where the app writes the open page.
- `settings.json` holds the intents of cosm's settings in Claude Code's terms: concise answers, Claude's own memory off,
  the commands cosm runs allowed, sending or deleting mail denied.
- The chat runs with `--permission-prompt-tool stdio`: a step Claude Code would ask about arrives as a `control_request`
  (`can_use_tool`), drawn as Allow / Deny in the chat; the answer goes back as a `control_response` (`chat_answer`).
