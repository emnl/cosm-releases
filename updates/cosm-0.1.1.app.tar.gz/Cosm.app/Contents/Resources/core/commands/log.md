---
description: Write a record of this session into the archive — what was decided, what changed, what's next
---
# /cosm:log

Now: !`date '+%Y-%m-%d %H.%M'`

Write one file, `04-archive/logs/<YYYY-MM>/<now> Log – <Topic>.md` (the month from `<now>`; make the folder if it isn't there), where `<Topic>` is two to six words for what the session was mostly about, written as the user would (`04-archive/logs/2026-10/2026-10-21 21.51 Log – Acme pricing.md`). The date, time and ` Log – ` (with an en dash, –) must stay exactly so: `/cosm:recall` finds the newest log by them and reads its Summary next time. It goes straight to the archive; nothing files it later.

Written from this session only. It records; it doesn't decide anything new. Facts should already be on their pages (Cosm's rules, write as you go): before writing the log, check that each decision and each open item below is on its page, and write it there where it isn't.

```
# <Topic in words>, <date>

## Summary
Two to four sentences: what the session was about and where it ended.

## Decided
- Each decision the user made, with its reason in their words; link the page it lives on.

## Changed in the cosm
- Each page created or changed, as a link, with a few words on what changed.

## Open
- What is unfinished or waiting, and on whom.

## Proposed tasks
- Things the user said they'd do that aren't on their list yet.
```

Leave a section out when it would be empty. No transcript, no tool output, no long quotes.

Then say in one line where the log is. If it has proposed tasks, ask once, naming them: "Add <task> and <task> to your list? **y** yes · **n** no", and on **y** add them to the user's list (`todo.md` in their space, or where `profile.md` says they keep it), each linked to its space.
